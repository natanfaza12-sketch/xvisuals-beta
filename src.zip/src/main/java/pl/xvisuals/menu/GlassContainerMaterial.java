package pl.xvisuals.menu;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.util.Identifier;

/** Recolors the original artwork in the shader so slots and machine diagrams stay intact. */
public final class GlassContainerMaterial {
  public static final RenderPipeline PIPELINE = RenderPipeline.builder(RenderPipelines.POSITION_TEX_COLOR_SNIPPET)
      .withLocation(Identifier.of("xvisuals", "pipeline/glass_container"))
      .withFragmentShader(Identifier.of("xvisuals", "core/glass_container"))
      .withDepthTestFunction(com.mojang.blaze3d.platform.DepthTestFunction.NO_DEPTH_TEST)
      .withDepthWrite(false).build();

  private GlassContainerMaterial() {}
}
