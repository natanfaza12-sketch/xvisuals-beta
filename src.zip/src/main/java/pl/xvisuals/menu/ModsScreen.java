package pl.xvisuals.menu;

import pl.xvisuals.gui.components.*;
import pl.xvisuals.gui.themes.Theme;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public final class ModsScreen extends Screen {
  private final Screen parent;
  private int scroll;

  public ModsScreen(Screen parent) {
    super(Text.literal("Installed mods"));
    this.parent = parent;
  }

  @Override
  public void renderBackground(DrawContext g, int mx, int my, float dt) {}

  @Override
  protected void init() {
    addDrawableChild(new MenuAction(width / 2 - 20, height - 39, 60, 25, "Back", false, this::close));
  }

  @Override
  public void close() {
    client.setScreen(parent);
  }

  @Override
  public void render(DrawContext g, int mx, int my, float dt) {
    MenuBackdrop.draw(g, width, height);
    g.fill(0, 0, width, height, 0xA0090911);
    int w = Math.min(500, width - 30), x = (width - w) / 2;
    Glass.text(g, "INSTALLED MODS", x + 18, 42, Theme.text());
    g.enableScissor(x + 8, 65, x + w - 8, height - 62);
    int y = 72 - scroll;
    for (var mod :
        FabricLoader.getInstance().getAllMods().stream()
            .sorted(java.util.Comparator.comparing(m -> m.getMetadata().getName()))
            .toList()) {
      Glass.text(g, mod.getMetadata().getName(), x + 19, y, Theme.text());
      Glass.text(
          g, mod.getMetadata().getVersion().getFriendlyString(), x + w - 140, y, Theme.muted());
      y += 25;
    }
    g.disableScissor();
    super.render(g, mx, my, dt);
  }

  @Override
  public boolean mouseScrolled(double x, double y, double hx, double dy) {
    scroll =
        Math.max(
            0,
            Math.min(
                Math.max(0, FabricLoader.getInstance().getAllMods().size() * 25 - (height - 130)),
                scroll - (int) (dy * 28)));
    return true;
  }
}
