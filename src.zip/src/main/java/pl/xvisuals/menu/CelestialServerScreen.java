package pl.xvisuals.menu;

import pl.xvisuals.gui.components.Glass;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Drawable;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.*;
import net.minecraft.client.gui.widget.*;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import java.util.*;

/** Custom presentation; vanilla retains connection, storage, ping and LAN lifecycle. */
public final class CelestialServerScreen extends MultiplayerScreen {
  public static final Identifier BACKGROUND = Identifier.of("xvisuals", "textures/menu/alpine.png");
  private final List<MultiplayerServerListWidget.Entry> all = new ArrayList<>();
  private TextFieldWidget search;
  private int left, top, panelWidth, listBottom;
  private String query = "";
  private float viewScale = 1;
  private int viewportWidth, viewportHeight;
  private double viewportGuiScale;
  private Text hoverTooltip;
  public void tooltip(Text text) { hoverTooltip=text; }
  private boolean compact = true, initializing;
  private List<ButtonWidget> buttons = List.of();
  public CelestialServerScreen(Screen parent) { super(parent); }

  @Override protected void init() {
    updateViewport();
    initializing = true;
    super.init();
    initializing = false;
    buttons = children().stream().filter(e -> e instanceof ButtonWidget).map(e -> (ButtonWidget)e).toList();
    all.clear(); all.addAll(serverListWidget.children());
    rebuildLayout();
  }
  private void rebuildLayout() {
    clearChildren();
    var layout=updateViewport();
    panelWidth=layout.panelWidth();left=layout.left();top=layout.top();
    int listHeight=layout.listHeight();
    listBottom = top + 31 + listHeight;
    serverListWidget.position(panelWidth - 12, listHeight, left + 6, top + 31);
    addDrawableChild(serverListWidget);
    search = new TextFieldWidget(textRenderer, left + 29, top + 12, panelWidth - 108, 12, Text.literal("Search servers"));
    search.setDrawsBackground(false);
    search.setTextShadow(false);
    search.setPlaceholder(Text.literal("Search servers"));
    search.setText(query);
    search.setChangedListener(value -> { query = value; filter(); });
    addDrawableChild(search);
    int slot = 0;
    for (ButtonWidget source : buttons) {
      String key = source.getMessage().getString();
      if (key.equals(Text.translatable("selectServer.refresh").getString())) {
        addDrawableChild(new Action(left + panelWidth - 29, top + 7, 22, 19, "↻", source, false));
      } else if (key.equals(Text.translatable("gui.back").getString()) || key.equals(Text.translatable("gui.cancel").getString())) {
        addDrawableChild(new Action(left + panelWidth - 46, top - 22, 46, 17, "Back", source, false));
      } else {
        int gap = 6, columns=layout.footerColumns(), available = panelWidth - 12, bw = (available - gap * (columns-1)) / columns;
        String label = key.equals(Text.translatable("selectServer.select").getString()) ? "Join"
            : key.equals(Text.translatable("selectServer.direct").getString()) ? "Direct"
            : key.equals(Text.translatable("selectServer.add").getString()) ? "Add" : key;
        addDrawableChild(new Action(left + 6 + (slot % columns) * (bw + gap), listBottom + 12 + (slot / columns)*25, bw, 19, label, source, slot == 0));
        slot++;
      }
    }
    addDrawableChild(ButtonWidget.builder(Text.literal("≡"), button -> compact = !compact).dimensions(left + panelWidth - 59, top + 7, 25, 19).build());
    filter();
  }
  private boolean footerAction(ButtonWidget button) {
    String key=button.getMessage().getString();
    return !key.equals(Text.translatable("selectServer.refresh").getString())
        && !key.equals(Text.translatable("gui.back").getString())
        && !key.equals(Text.translatable("gui.cancel").getString());
  }
  private ServerMenuLayout updateViewport() {
    var window=client.getWindow();
    viewportWidth=window.getFramebufferWidth();viewportHeight=window.getFramebufferHeight();
    viewportGuiScale=window.getScaleFactor();
    var layout=ServerMenuLayout.forWindow(viewportWidth,viewportHeight,viewportGuiScale,
        (int)buttons.stream().filter(this::footerAction).count());
    viewScale=layout.scale();width=layout.width();height=layout.height();
    return layout;
  }
  private void ensureViewport() {
    var window=client.getWindow();
    if(search!=null && (viewportWidth!=window.getFramebufferWidth()
        || viewportHeight!=window.getFramebufferHeight() || viewportGuiScale!=window.getScaleFactor())) {
      double scroll=serverListWidget.getScrollY();
      rebuildLayout();
      serverListWidget.setScrollY(scroll);
    }
  }
  private net.minecraft.client.gui.Click logical(net.minecraft.client.gui.Click click) {
    ensureViewport();
    return new net.minecraft.client.gui.Click(click.x()/viewScale,click.y()/viewScale,click.buttonInfo());
  }
  @Override public boolean mouseClicked(net.minecraft.client.gui.Click click,boolean doubled) {
    return super.mouseClicked(logical(click),doubled);
  }
  @Override public boolean mouseReleased(net.minecraft.client.gui.Click click) {
    return super.mouseReleased(logical(click));
  }
  @Override public boolean mouseDragged(net.minecraft.client.gui.Click click,double dx,double dy) {
    return super.mouseDragged(logical(click),dx/viewScale,dy/viewScale);
  }
  @Override public void mouseMoved(double x,double y) {ensureViewport();super.mouseMoved(x/viewScale,y/viewScale);}
  @Override public boolean mouseScrolled(double x,double y,double horizontal,double vertical) {
    ensureViewport();
    return super.mouseScrolled(x/viewScale,y/viewScale,horizontal,vertical);
  }
  @Override protected void refreshWidgetPositions() {
    if (!initializing && search != null) {
      // Vanilla updates the widget while an add/edit/delete dialog is open.
      // Returning to this screen refreshes positions without calling init again.
      // Rebuild from the saved servers before filtering, not the old visible rows.
      var selected = serverListWidget.getSelectedOrNull();
      serverListWidget.setServers(getServerList());
      if (selected instanceof MultiplayerServerListWidget.ServerEntry saved) {
        serverListWidget.setSelected(serverListWidget.children().stream()
            .filter(e -> e instanceof MultiplayerServerListWidget.ServerEntry entry
                && entry.getServer() == saved.getServer())
            .findFirst().orElse(null));
      }
      all.clear();
      all.addAll(serverListWidget.children());
      rebuildLayout();
    }
  }
  private void filter() {
    String q = query.strip().toLowerCase(Locale.ROOT);
    var entries = all.stream().filter(e -> !(e instanceof MultiplayerServerListWidget.ScanningEntry)).filter(e -> !(e instanceof MultiplayerServerListWidget.ServerEntry s)
        ? q.isEmpty() : (s.getServer().name + " " + s.getServer().address).toLowerCase(Locale.ROOT).contains(q)).toList();
    if (!serverListWidget.children().equals(entries)) {
      var selected = serverListWidget.getSelectedOrNull();
      serverListWidget.replaceEntries(entries);
      serverListWidget.setSelected(entries.contains(selected) ? selected : null);
    }
  }
  @Override public void tick() {
    // LAN updates can rebuild vanilla's list. Only refresh our source when that happens.
    var before = List.copyOf(serverListWidget.children());
    super.tick();
    if (!before.equals(serverListWidget.children())) {
      all.clear(); all.addAll(serverListWidget.children()); filter();
    }
  }
  public boolean selected(MultiplayerServerListWidget.ServerEntry e) { return serverListWidget.getSelectedOrNull() == e; }
  public void select(MultiplayerServerListWidget.ServerEntry e, boolean connect) {
    serverListWidget.setSelected(e);
    if (connect) e.connect();
  }
  public boolean filtering() { return !query.isBlank(); }
  public boolean canMove(MultiplayerServerListWidget.ServerEntry entry,int direction) {
    var rows=serverListWidget.children();int index=rows.indexOf(entry)+direction;
    return rows.contains(entry) && index>=0 && index<rows.size()
        && rows.get(index) instanceof MultiplayerServerListWidget.ServerEntry;
  }
  public void move(MultiplayerServerListWidget.ServerEntry entry,int direction) {
    var saved=new ArrayList<net.minecraft.client.network.ServerInfo>();
    for(int i=0;i<getServerList().size();i++)saved.add(getServerList().get(i));
    var visible=serverListWidget.children().stream()
        .filter(e->e instanceof MultiplayerServerListWidget.ServerEntry)
        .map(e->((MultiplayerServerListWidget.ServerEntry)e).getServer()).toList();
    var swap=ServerReorder.resolve(saved,visible,entry.getServer(),direction);
    if(swap==null)return;
    double scroll=serverListWidget.getScrollY();
    getServerList().swapEntries(swap.from(),swap.to());
    serverListWidget.setServers(getServerList());
    all.clear();all.addAll(serverListWidget.children());filter();
    var moved=serverListWidget.children().stream()
        .filter(e->e instanceof MultiplayerServerListWidget.ServerEntry s && s.getServer()==entry.getServer())
        .findFirst().orElse(null);
    serverListWidget.setSelected(moved);
    serverListWidget.setFocused(moved);
    serverListWidget.setScrollY(scroll);
  }
  public boolean compact() { return compact; }
  public int rowWidth() { return panelWidth - 24; }
  public void syncEntries() { all.clear(); all.addAll(serverListWidget.children()); filter(); }
  public void previewSearch(String text) { search.setText(text); }
  public int previewVisibleServers() { return (int)serverListWidget.children().stream().filter(e -> e instanceof MultiplayerServerListWidget.ServerEntry).count(); }
  public void previewFixture() {
    if (!net.fabricmc.loader.api.FabricLoader.getInstance().isDevelopmentEnvironment()) return;
    String[] names={"Donut SMP", "X Network", "Friends", "2b2t", "Crystal PvP", "Hypixel"};
    String[] descriptions={"The home of chaos.", "More than a game.", "Private server.", "The oldest anarchy server.", "Perfect your skills.", "Mini games, major fun."};
    for(int i=0;i<names.length;i++) {
      var info=new net.minecraft.client.network.ServerInfo(names[i],"preview-"+i+".invalid",net.minecraft.client.network.ServerInfo.ServerType.OTHER);
      info.setStatus(net.minecraft.client.network.ServerInfo.Status.SUCCESSFUL);
      info.label=Text.literal(descriptions[i]); info.playerCountLabel=Text.literal((i+1)*127+" / 5000"); info.ping=24+i*11;
      getServerList().add(info,false);
    }
    serverListWidget.setServers(getServerList());
    all.clear(); all.addAll(serverListWidget.children()); filter();
    serverListWidget.setSelected(serverListWidget.children().getFirst());
  }
  @Override public void renderBackground(DrawContext g, int mx, int my, float dt) {
    ensureViewport();
    g.getMatrices().pushMatrix();
    try {g.getMatrices().scale(viewScale,viewScale);GlassMenus.background(g,this);}
    finally {g.getMatrices().popMatrix();}
  }
  @Override public void render(DrawContext g, int mx, int my, float dt) {
    ensureViewport();
    hoverTooltip=null;
    g.getMatrices().pushMatrix();
    try {
      g.getMatrices().scale(viewScale,viewScale);
      renderContent(g,(int)(mx/viewScale),(int)(my/viewScale),dt);
    } finally {g.getMatrices().popMatrix();}
    if(hoverTooltip!=null)g.drawTooltip(textRenderer,hoverTooltip,mx,my);
  }
  private void renderContent(DrawContext g,int mx,int my,float dt) {
    g.drawCenteredTextWithShadow(textRenderer,Text.translatable("multiplayer.title"),width/2,15,0xFFFFFFFF);
    plate(g, left+9, top+7, panelWidth-74, 19, search.isFocused());
    pl.xvisuals.gui.components.StudioIcons.draw(g,"search",left+15,top+12,9,0xFF9BA5B4);

    for (var child : children()) if (child instanceof Drawable drawable) drawable.render(g,mx,my,dt);
    if (getServerList().size() == 0) {
      Glass.center(g, "No saved servers", width/2f, top+72, 0xFFECE4FA);
      
    } else if (serverListWidget.children().isEmpty()) {
      Glass.center(g, "No matching servers", width/2f, top+72, 0xFFCEC3E1);
    }
  }
  public static void plate(DrawContext g, float x, float y, float w, float h, boolean lit) {
    g.fill((int)x,(int)y,(int)(x+w),(int)(y+h),0x3304080C);
    g.fill((int)x,(int)(y+h-1),(int)(x+w),(int)(y+h),lit?0xD9DBE5ED:0x47DBE5ED);
  }
  private final class Action extends ClickableWidget {
    private final ButtonWidget source;
    private final boolean primary;
    Action(int x,int y,int w,int h,String label,ButtonWidget source,boolean primary) {
      super(x,y,w,h,Text.literal(label));
      this.source=source; this.primary=primary;
    }
    public void onPress(net.minecraft.client.input.AbstractInput input) {
      if (!source.active) return;
      var selected = serverListWidget.getSelectedOrNull();
      serverListWidget.replaceEntries(all);
      serverListWidget.setSelected(selected);
      source.onPress(input);
    }
    @Override public void onClick(net.minecraft.client.gui.Click click, boolean doubled) { onPress(click); }
    @Override public boolean keyPressed(net.minecraft.client.input.KeyInput input) {
      if (active && isFocused() && (input.key()==257 || input.key()==335 || input.key()==32)) {
        playDownSound(client.getSoundManager()); onPress(input); return true;
      }
      return super.keyPressed(input);
    }
    @Override protected void appendClickableNarrations(net.minecraft.client.gui.screen.narration.NarrationMessageBuilder b) { appendDefaultNarrations(b); }
    @Override protected void renderWidget(DrawContext g,int mx,int my,float dt) {
      active=source.active;
      GlassMenus.surface(g,getX(),getY(),width,height,active && (isHovered() || isFocused()),active?1:.35f);
      g.drawCenteredTextWithShadow(textRenderer,textRenderer.trimToWidth(getMessage().getString(),width-6),getX()+width/2,getY()+(height-9)/2,active?0xFFFFFFFF:0xFF808080);
    }
  }
}


