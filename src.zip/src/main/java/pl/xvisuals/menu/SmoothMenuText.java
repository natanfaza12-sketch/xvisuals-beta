package pl.xvisuals.menu;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.*;
import net.minecraft.util.Identifier;
public final class SmoothMenuText {
  private record Entry(Identifier id,int width,int height,float baseline) {}
  private record Key(String text,int pixels) {}
  private static final pl.xvisuals.util.DeferredReleaseCache<Key,Entry> cache=new pl.xvisuals.util.DeferredReleaseCache<>(64);
  private static Font font;
  private static int serial;
  public static void beginFrame() {
    cache.beginFrame(e -> MinecraftClient.getInstance().getTextureManager().destroyTexture(e.id()));
  }
  private static class Texture extends NativeImageBackedTexture {
    Texture(NativeImage image){super(()->"Smooth menu text",image);
      sampler=com.mojang.blaze3d.systems.RenderSystem.getSamplerCache().get(com.mojang.blaze3d.textures.FilterMode.LINEAR);}
  }
  static boolean draw(DrawContext g,String text,float x,float y,float size,int color,boolean center){
    if(Boolean.getBoolean("visuals.menuNativeFont"))return false;
    try {
      if(font==null)try(var input=SmoothMenuText.class.getResourceAsStream("/assets/xvisuals/font/inter.ttf")){font=Font.createFont(Font.TRUETYPE_FONT,input);}
      int pixels=Math.max(12,Math.round(size*MinecraftClient.getInstance().getWindow().getScaleFactor()*2));
      var key=new Key(text,pixels);Entry e=cache.get(key);
      if(e==null){
        var f=font.deriveFont((float)pixels);var metrics=new java.awt.font.FontRenderContext(null,true,true);
        var bounds=f.getStringBounds(text,metrics);int w=Math.max(1,(int)Math.ceil(bounds.getWidth())+8),h=(int)Math.ceil(bounds.getHeight())+8;
        var image=new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);var graphics=image.createGraphics();
        graphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        graphics.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS,RenderingHints.VALUE_FRACTIONALMETRICS_ON);
        graphics.setFont(f);graphics.setColor(Color.WHITE);graphics.drawString(text,4,4-(float)bounds.getY());graphics.dispose();
        var bytes=new ByteArrayOutputStream();javax.imageio.ImageIO.write(image,"png",bytes);
        var nativeImage=NativeImage.read(new ByteArrayInputStream(bytes.toByteArray()));
        var id=Identifier.of("xvisuals","smooth_text/"+serial++);
        MinecraftClient.getInstance().getTextureManager().registerTexture(id,new Texture(nativeImage));
        e=new Entry(id,w,h,4-(float)bounds.getY());cache.put(key,e);
      }
      float scale=size/pixels;
      g.getMatrices().pushMatrix();
      try {
      g.getMatrices().translate(center?x-e.width()*scale/2:x-4*scale,y-4*scale);
      g.getMatrices().scale(scale,scale);
      g.drawTexture(net.minecraft.client.gl.RenderPipelines.GUI_TEXTURED,e.id(),0,0,0,0,e.width(),e.height(),e.width(),e.height(),color);
      } finally { g.getMatrices().popMatrix(); }
      return true;
    }catch(Exception ex){return false;}
  }
}
