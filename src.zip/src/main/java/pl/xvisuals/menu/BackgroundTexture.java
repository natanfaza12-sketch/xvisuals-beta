package pl.xvisuals.menu;

import java.io.*;
import java.nio.file.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.*;
import net.minecraft.util.Identifier;

final class BackgroundTexture {
  static final Identifier ID = Identifier.of("xvisuals", "custom_background");
  private static String loaded = "";
  static boolean available;
  static int width, height;

  private static final class SmoothTexture extends NativeImageBackedTexture {
    SmoothTexture(NativeImage image) {
      super(() -> "Custom menu background", image);
      sampler = com.mojang.blaze3d.systems.RenderSystem.getSamplerCache().get(com.mojang.blaze3d.textures.FilterMode.LINEAR);
    }
  }
  static boolean draw(net.minecraft.client.gui.DrawContext g, int w, int h) {
    load(MenuThemes.customPath());
    if (!available) return false;
    float cover=Math.max((float)w/width,(float)h/height);
    int dw=Math.round(width*cover), dh=Math.round(height*cover);
    g.drawTexture(net.minecraft.client.gl.RenderPipelines.GUI_TEXTURED,ID,(w-dw)/2,(h-dh)/2,0,0,dw,dh,dw,dh);
    return true;
  }
  static void load(String path) {
    if (path == null) path = "";
    if (path.equals(loaded)) return;
    loaded = path;
    available = false;
    MenuBackdropContrast.clearCustom();
    MinecraftClient.getInstance().getTextureManager().destroyTexture(ID);
    if (path.isBlank()) return;
    try {
      Path file = Path.of(path);
      if (Files.size(file) > 32 * 1024 * 1024)
        throw new IOException("Background is larger than 32 MB");
      try (var input = Files.newInputStream(file)) {
        NativeImage image = NativeImage.read(input);
        width = image.getWidth();
        height = image.getHeight();
        if (width > 8192 || height > 8192) {
          image.close();
          throw new IOException("Background exceeds 8192 pixels");
        }
        MenuBackdropContrast.custom(image);
        MinecraftClient.getInstance()
            .getTextureManager()
            .registerTexture(ID, new SmoothTexture(image));
        available = true;
      }
    } catch (Exception e) {
      if (pl.xvisuals.XVisuals.ready())
        pl.xvisuals.XVisuals.STORE.message = "Background: " + e.getMessage();
    }
  }
}
