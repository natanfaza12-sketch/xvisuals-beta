package pl.xvisuals.menu;

import pl.xvisuals.XVisuals;
import pl.xvisuals.gui.components.*;
import pl.xvisuals.rendering.shaders.SdfRenderer;
import pl.xvisuals.util.Colors;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;

/** Floating pause buttons; native widgets retain focus, narration and hit testing. */
public final class XPauseScreen extends Screen {

  public XPauseScreen() { super(Text.literal("Paused")); }
  @Override public void renderBackground(DrawContext g, int mx, int my, float dt) {}

  @Override protected void init() {
    int w = Math.min(108, width - 24), x = (width - w) / 2;
    int top = Math.max(4, (height - 53) / 2), half = (w - 4) / 2;

    add(x, top, w, 15, "Resume", "play", this::close);
    add(x, top + 19, half, 15, "Settings", "settings",
        () -> client.setScreen(new OptionsScreen(this, client.options)));
    add(x + half + 4, top + 19, w - half - 4, 15, "Mods", "mods",
        () -> ModMenuBridge.open(this));
    add(x, top + 38, w, 15, client.isInSingleplayer() ? "Save & Quit" : "Disconnect", "logout", () ->
        client.getAbuseReportContext().tryShowDraftScreen(client, this,
            () -> client.disconnect(ClientWorld.QUITTING_MULTIPLAYER_TEXT), true));
  }

  private void add(int x, int y, int w, int h, String label, String icon, Runnable action) {
    addDrawableChild(new PauseButton(x, y, w, h, label, icon, action));
  }

  private static boolean motionOff() {
    return XVisuals.config().module("performance").text("animation").equals("Off");
  }

  @Override public void close() { client.setScreen(null); client.mouse.lockCursor(); }

  private final class PauseButton extends ClickableWidget {
    private final Runnable action;
    private final String icon;
    private final Spring hover = new Spring(0);

    PauseButton(int x, int y, int w, int h, String label, String icon, Runnable action) {
      super(x, y, w, h, Glass.label(label));
      this.icon = icon; this.action = action;
    }

    @Override protected void renderWidget(DrawContext g, int mx, int my, float dt) {
      float target = active && (isHovered() || isFocused()) ? 1 : 0;
      float focus = motionOff() ? hover.snap(target) : hover.to(target);
      float a = alpha * (active ? 1 : .45f);
      Glass.rounded(g, getX(), getY(), width, height, 2,
          Colors.alpha(Colors.mix(0xFF202020, 0xFF363636, focus), .88 * a));
      SdfRenderer.rect(g, getX(), getY(), width, height, 2,
          Colors.alpha(Colors.mix(0xFF555555, 0xFF999999, focus), (.22 + focus * .35) * a), 22);
      if (isFocused()) SdfRenderer.rect(g, getX() - 2, getY() - 2, width + 4, height + 4, 3,
          Colors.alpha(0xFFEEEEEE, .8 * a), 22);

      String label = getMessage().getString();
      float textScale = .72f, iconSize = 8, gap = 4;
      float contentWidth = iconSize + gap + Glass.textWidth(label) * textScale;
      float x = getX() + (width - contentWidth) / 2f;
      int ink = Colors.alpha(0xFFF0F0F0, a);
      StudioIcons.draw(g, icon, x, getY() + (height - iconSize) / 2f, iconSize,
          Colors.alpha(Colors.mix(0xFFBBBBBB, 0xFFEEEEEE, focus), a));
      StudioChrome.scaled(g, label, x + iconSize + gap, getY() + (height - 9 * textScale) / 2f, textScale, ink);
    }

    @Override public void onClick(Click click, boolean doubled) { action.run(); }
    @Override public boolean keyPressed(KeyInput input) {
      if (active && isFocused() && (input.key() == 257 || input.key() == 335 || input.key() == 32)) {
        playDownSound(client.getSoundManager()); action.run(); return true;
      }
      return super.keyPressed(input);
    }
    @Override protected void appendClickableNarrations(NarrationMessageBuilder builder) { appendDefaultNarrations(builder); }
  }
}
