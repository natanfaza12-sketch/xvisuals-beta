package pl.xvisuals.menu;

/** Consistent apparent size across Minecraft GUI scales; coordinates remain reversible. */
public record ServerMenuLayout(float scale, int width, int height, int panelWidth,
    int left, int top, int listHeight, int footerColumns) {
  public static ServerMenuLayout of(int scaledWidth,int scaledHeight,int actions) {
    float scale=Math.max(.01f,Math.min(Math.max(1,scaledHeight)/300f,Math.max(1,scaledWidth)/360f));
    int width=Math.round(scaledWidth/scale),height=Math.round(scaledHeight/scale);
    int panel=Math.min(width-32,620),left=(width-panel)/2,top=Math.max(42,(height-244)/2);
    int columns=Math.max(1,Math.min(5,actions)),footerRows=Math.max(1,(actions+columns-1)/columns);
    int rows=Math.max(1,Math.min(7,(height-top-72-(footerRows-1)*25)/36));
    return new ServerMenuLayout(scale,width,height,panel,left,top,rows*36+4,columns);
  }
  /** Use framebuffer dimensions, avoiding rounded GUI dimensions changing the layout. */
  public static ServerMenuLayout forWindow(int framebufferWidth,int framebufferHeight,double guiScale,int actions) {
    var pixels=of(framebufferWidth,framebufferHeight,actions);
    return new ServerMenuLayout((float)(pixels.scale()/Math.max(.01,guiScale)),
        pixels.width(),pixels.height(),pixels.panelWidth(),pixels.left(),pixels.top(),
        pixels.listHeight(),pixels.footerColumns());
  }
  public double logical(double coordinate){return coordinate/scale;}
}
