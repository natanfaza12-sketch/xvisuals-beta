package pl.xvisuals.menu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;

/** Small CPU-only image summary; never reads the framebuffer or retains a full image. */
final class MenuBackdropContrast {
  private static final int GRID = 64;
  private static String loaded = "";
  private static int[] builtin;
  private static int imageWidth=1,imageHeight=1;
  private static int[] custom;
  private record Region(int width,int height,float x,float y,float w,float h,boolean imported,int surface,int preferred) {}
  private static final java.util.Map<Region,Integer> colors=new java.util.HashMap<>();
  static void custom(NativeImage image) { custom=sample(image);colors.clear(); }
  static void clearCustom() { custom=null;colors.clear(); }
  private static int[] sample(NativeImage image) {
    int[] pixels=new int[GRID*GRID];
    for(int y=0;y<GRID;y++)for(int x=0;x<GRID;x++)
      pixels[y*GRID+x]=image.getColorArgb(Math.min(image.getWidth()-1,x*image.getWidth()/GRID),Math.min(image.getHeight()-1,y*image.getHeight()/GRID));
    return pixels;
  }
  static int foreground(int width,int height,float x,float y,float w,float h) {
    return foreground(width,height,x,y,w,h,0,0);
  }
  static int foreground(int width,int height,float x,float y,float w,float h,int surface,int preferred) {
    var theme=MenuThemes.get(MenuThemes.selected());
    if(!loaded.equals(theme.asset())) {
      loaded=theme.asset();builtin=null;colors.clear();
      try(var input=MinecraftClient.getInstance().getResourceManager().open(theme.texture());var image=NativeImage.read(input)) {
        builtin=sample(image);imageWidth=image.getWidth();imageHeight=image.getHeight();
      } catch(Exception ignored) { /* White with a shadow is the safe missing-resource fallback. */ }
    }
    boolean imported=BackgroundTexture.available && custom!=null;
    var region=new Region(width,height,x,y,w,h,imported,surface,preferred);
    Integer cached=colors.get(region);if(cached!=null)return cached;
    int[] pixels=imported?custom:builtin;
    if(pixels==null)return 0xFFF8FAFD;
    int iw=imported?BackgroundTexture.width:imageWidth,ih=imported?BackgroundTexture.height:imageHeight;
    double cover=Math.max((double)width/iw,(double)height/ih),dw=iw*cover,dh=ih*cover;
    double sum=0;
    for(int row=0;row<7;row++)for(int col=0;col<17;col++) {
      double sx=x+w*col/16,sy=y+h*row/6;
      int px=Math.clamp((int)((sx+(dw-width)/2)/dw*GRID),0,GRID-1);
      int py=Math.clamp((int)((sy+(dh-height)/2)/dh*GRID),0,GRID-1);
      int rgb=pixels[py*GRID+px];
      // Match the title's dark wash and lower gradient before deciding contrast.
      double shade=1-(1-37/255.0)*(1-Math.clamp((sy-height/2.0)/(height/2.0),0,1)*128/255.0);
      double r=((rgb>>16)&255)*(1-shade)+13*shade;
      double g=((rgb>>8)&255)*(1-shade)+21*shade;
      double b=(rgb&255)*(1-shade)+33*shade;
      double alpha=(surface>>>24)/255.0;
      r=r*(1-alpha)+((surface>>16)&255)*alpha;
      g=g*(1-alpha)+((surface>>8)&255)*alpha;
      b=b*(1-alpha)+(surface&255)*alpha;
      sum+=.2126*linear(r)+.7152*linear(g)+.0722*linear(b);
    }
    double background=sum/119;
    int result=choose(background);
    double requested=.2126*linear((preferred>>16)&255)+.7152*linear((preferred>>8)&255)+.0722*linear(preferred&255);
    if((preferred>>>24)==255 && (Math.max(requested,background)+.05)/(Math.min(requested,background)+.05)>=4.5) result=preferred;
    if(colors.size()>=32)colors.clear();
    colors.put(region,result);return result;
  }
  static int choose(double luminance) { return luminance>.22?0xFF111820:0xFFF8FAFD; }
  private static double linear(double channel) {double c=channel/255;return c<=.04045?c/12.92:Math.pow((c+.055)/1.055,2.4);}
  private MenuBackdropContrast() {}
}
