package pl.xvisuals.menu;

import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;

/** Bootstrap-safe user artwork and a live, animated resource-loading track. */
public final class LaunchArtwork {
  public static void draw(DrawContext g, float progress, float alpha, double seconds) {
    draw(g, progress, alpha, seconds, false, progress >= 1);
  }

  public static void draw(DrawContext g, float progress, float alpha, double seconds,
      boolean reloading, boolean complete) {
    draw(g, progress, alpha, seconds, reloading, complete, null, false);
  }

  public static void world(DrawContext g,float progress,double seconds,boolean known,boolean saving){
    draw(g,progress,1,seconds,false,false,saving?"SAVING WORLD":"LOADING WORLD",!known);
  }
  public static void preparing(DrawContext g, double seconds) {
    draw(g, 0, 1, seconds, false, false, "PREPARING RESOURCES", true);
  }

  private static void draw(DrawContext g, float progress, float alpha, double seconds,
      boolean reloading, boolean complete, String stage, boolean indeterminate) {
    if (!LoadingTextures.ready()) {
      LoadingFallback.draw(g, progress, alpha, seconds);
      return;
    }
    int w = g.getScaledWindowWidth(), h = g.getScaledWindowHeight();
    g.createNewRootLayer();
    var image = LoadingTextures.background;
    float cover = Math.max(w / (float) image.width(), h / (float) image.height());
    float iw = image.width() * cover, ih = image.height() * cover;
    g.getMatrices().pushMatrix();
    g.getMatrices().translate((w - iw) / 2, (h - ih) / 2);
    g.getMatrices().scale(cover, cover);
    g.drawTexture(RenderPipelines.GUI_TEXTURED, image.id(), 0, 0, 0, 0,
        image.width(), image.height(), image.width(), image.height(), color(0xFFFFFF, alpha));
    g.getMatrices().popMatrix();

    rect(g,0,0,w,h,color(0x0D1521,alpha*.30f));
    float barW=Math.min(w*.32f,220),x=(w-barW)/2,y=h*.62f;
    float p=Math.clamp(progress,0,1),filled=barW*(indeterminate?.18f:p);
    text(g,"VISUALS",w*.5f,y-51,24,3.0f,color(0xF0F5FC,alpha));
    rect(g,x,y,barW,2,color(0xDCE7F3,alpha*.2f));
    if(indeterminate)x+=(barW-filled)*(float)(.5-.5*Math.cos(seconds*1.3));
    rect(g,x,y,filled,2,color(0xE5F0FC,alpha*.9f));    String status = stage != null ? stage : complete && p == 1 ? "READY" : complete ? "FINISHING"
        : reloading ? "RELOADING RESOURCES" : "LOADING RESOURCES";
    text(g, status, w * .5f, y + 17, 6.5f, .8f, color(0xE5EDF6, alpha));
    text(g, indeterminate ? "SETTING UP YOUR WORLD" : (p == 1 && complete ? 100 : (int) (p * 100)) + "%", w * .5f,
        y + 30, 6, .4f, color(0xB4C3D4, alpha));
  }
  private static void text(DrawContext g, String text, float cx, float y, float height, float tracking, int color) {
    float scale = height / 48f, width = 0;
    for (char c : text.toCharArray()) width += LoadingTextures.advances[Math.clamp(c - 32, 0, 95)] * scale + tracking;
    float x = cx - (width - tracking) / 2;
    for (char c : text.toCharArray()) {
      int index = Math.clamp(c - 32, 0, 95);
      g.getMatrices().pushMatrix();
      g.getMatrices().translate(x - 2 * scale, y - 11 * scale);
      g.getMatrices().scale(scale, scale);
      g.drawTexture(RenderPipelines.GUI_TEXTURED, LoadingTextures.type.id(), 0, 0,
          index % 16 * 64, index / 16 * 64, 64, 64, 64, 64, 1024, 384, color);
      g.getMatrices().popMatrix();
      x += LoadingTextures.advances[index] * scale + tracking;
    }
  }

  private static void line(DrawContext g, float x, float y, float ex, float ey, float thickness, int color) {
    g.getMatrices().pushMatrix();
    g.getMatrices().translate(x, y - thickness / 2);
    g.getMatrices().rotate((float) Math.atan2(ey - y, ex - x));
    g.getMatrices().scale((float) Math.hypot(ex - x, ey - y), thickness);
    g.fill(0, 0, 1, 1, color);
    g.getMatrices().popMatrix();
  }

  private static void rect(DrawContext g, float x, float y, float w, float h, int color) {
    if (w <= 0 || h <= 0) return;
    g.getMatrices().pushMatrix();
    g.getMatrices().translate(x, y);
    g.getMatrices().scale(w, h);
    g.fill(0, 0, 1, 1, color);
    g.getMatrices().popMatrix();
  }

  private static int color(int rgb, float alpha) { return Math.clamp(Math.round(alpha * 255), 0, 255) << 24 | rgb; }
  private LaunchArtwork() {}
}

