package pl.xvisuals.menu;
import net.minecraft.client.gui.widget.PlayerSkinWidget;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Click;
import net.minecraft.client.input.MouseInput;
import net.minecraft.client.render.entity.model.LoadedEntityModels;
import net.minecraft.entity.player.SkinTextures;
import java.util.function.Supplier;
final class AccountSkinWidget extends PlayerSkinWidget {
  AccountSkinWidget(int w,int h,LoadedEntityModels models,Supplier<SkinTextures> account){
    super(w,h,models,account);
    // Vanilla starts at 30 degrees yaw and -5 pitch; launch squarely facing the user.
    super.onDrag(new Click(0,0,new MouseInput(0,0)),-12,-2);
  }
}
