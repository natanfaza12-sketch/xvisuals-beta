package pl.xvisuals.menu;

import java.util.Set;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableTextContent;

/** Translation keys keep reporting controls hidden in every language. */
public final class ReportingButtons {
  private static final Set<String> KEYS = Set.of(
      "menu.reportBugs", "menu.playerReporting", "known_server_link.report_bug", "gui.report_to_server",
      "gui.socialInteractions.report", "gui.abuseReport.send", "gui.abuseReport.read_info",
      "gui.abuseReport.draft.edit", "gui.abuseReport.discard.return", "gui.chatReport.send",
      "gui.chatReport.read_info", "gui.chatReport.draft.edit", "gui.chatReport.discard.return");
  public static boolean matches(Text text) {
    if (text.getContent() instanceof TranslatableTextContent translated
        && (KEYS.contains(translated.getKey()) || translated.getKey().startsWith("gui.abuseReport.type."))) return true;
    return text.getSiblings().stream().anyMatch(ReportingButtons::matches);
  }
  private ReportingButtons() {}
}
