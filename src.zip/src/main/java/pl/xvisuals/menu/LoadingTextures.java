package pl.xvisuals.menu;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import java.io.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.*;
import net.minecraft.util.Identifier;

/** Packaged assets are readable before the first resource reload completes. */
final class LoadingTextures {
  record Asset(Identifier id, int width, int height) {}

  static Asset type, background;
  private static String backgroundName;
  static final float[] advances = new float[96];
  private static boolean attempted, ready;

  static boolean ready() {
    if (attempted) {
      if (ready) updateBackground();
      return ready;
    }
    attempted = true;
    try {
      type = load("loading/type");
      updateBackground();
      try (var in = new DataInputStream(resource("loading/advances.bin"))) {
        for (int i = 0; i < 96; i++) advances[i] = in.readFloat();
      }
      ready = background != null;
    } catch (Exception e) {
      org.slf4j.LoggerFactory.getLogger("xvisuals")
          .warn("Loading artwork unavailable; using bootstrap fallback", e);
    }
    return ready;
  }

  private static void updateBackground() {
    BackgroundTexture.load(MenuThemes.customPath());
    if (BackgroundTexture.available) {
      if (background != null && !background.id().equals(BackgroundTexture.ID))
        MinecraftClient.getInstance().getTextureManager().destroyTexture(background.id());
      background = new Asset(BackgroundTexture.ID, BackgroundTexture.width, BackgroundTexture.height);
      backgroundName = null;
      return;
    }
    String name = MenuThemes.get(MenuThemes.selected()).asset();
    if (name.equals(backgroundName)) return;
    backgroundName = name;
    try {
      Asset next = load("menu/" + name);
      if (background != null && !background.id().equals(BackgroundTexture.ID)) MinecraftClient.getInstance().getTextureManager().destroyTexture(background.id());
      background = next;
    } catch (Exception e) {
      org.slf4j.LoggerFactory.getLogger("xvisuals").warn("Could not load selected theme {}", name, e);
    }
  }

  private static InputStream resource(String file) throws IOException {
    var stream =
        LoadingTextures.class.getResourceAsStream(
            "/assets/xvisuals/textures/" + file);
    if (stream == null) throw new FileNotFoundException(file);
    return stream;
  }

  private static Asset load(String name) throws IOException {
    try (var in = resource(name + ".png")) {
      NativeImage image = NativeImage.read(in);
      Identifier id = Identifier.of("xvisuals", "bootstrap/" + name);
      var asset = new Asset(id, image.getWidth(), image.getHeight());
      MinecraftClient.getInstance()
          .getTextureManager()
          .registerTexture(id, new LinearTexture(name, image));
      return asset;
    }
  }

  private static final class LinearTexture extends NativeImageBackedTexture {
    LinearTexture(String name, NativeImage image) {
      super(() -> "X Visuals loading " + name, image);
      sampler = RenderSystem.getSamplerCache().get(FilterMode.LINEAR);
    }
  }

  private LoadingTextures() {}
}
