package pl.xvisuals.menu;

import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.gui.components.Spring;
import pl.xvisuals.gui.components.StudioChrome;
import pl.xvisuals.util.Colors;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.input.KeyInput;

/** Rounded glass navigation with matching pointer and keyboard focus treatments. */
public final class TempleButton extends ClickableWidget {
  private final Runnable action;
  private final int icon;
  private final Spring focus = new Spring(0);
  public TempleButton(int x,int y,int w,int h,String label,int icon,Runnable action) {
    super(x,y,w,h,Glass.label(label)); this.icon=icon; this.action=action;
  }
  @Override protected void renderWidget(DrawContext g,int mx,int my,float dt) {
    float lit=focus.to(active && (isHovered() || isFocused()) ? 1 : 0);
    float x=getX(),y=getY();
    Glass.rounded(g,x,y,width,height,6,Colors.alpha(Colors.mix(0x24262B,0x3A3D44,lit),.96*alpha));
    int ink=Colors.alpha(0xF3F4F6,alpha*(active?1:.4));
    if(width>36) StudioChrome.text(g,getMessage().getString(),x+31,Math.round(y+(height-9)/2f),ink);
    g.getMatrices().pushMatrix();
    g.getMatrices().translate(x+(width<=36?width/2f:height*.66f),y+height/2f);
    g.getMatrices().scale(height/26f,height/26f);
    drawIcon(g,icon,ink);
    g.getMatrices().popMatrix();

  }
  private static void circle(DrawContext g,float x,float y,float r,int ink) {
    for(int i=0;i<24;i++) {
      double a=i*Math.PI/12,b=(i+1)*Math.PI/12;
      Glass.line(g,x+Math.cos(a)*r,y+Math.sin(a)*r,x+Math.cos(b)*r,y+Math.sin(b)*r,.7,ink);
    }
  }
  private static void person(DrawContext g,float x,float y,float s,int ink) {
    circle(g,x,y-3*s,2.5f*s,ink);
    Glass.line(g,x-4*s,y+6*s,x-4*s,y+3*s,.8,ink);
    Glass.line(g,x-4*s,y+3*s,x-2*s,y+1*s,.8,ink);
    Glass.line(g,x-2*s,y+1*s,x+2*s,y+1*s,.8,ink);
    Glass.line(g,x+2*s,y+1*s,x+4*s,y+3*s,.8,ink);
    Glass.line(g,x+4*s,y+3*s,x+4*s,y+6*s,.8,ink);
    Glass.line(g,x-4*s,y+6*s,x+4*s,y+6*s,.8,ink);
  }
  private static void drawIcon(DrawContext g,int icon,int ink) {
    if(icon==0) person(g,0,0,1,ink);
    else if(icon==1) { person(g,-3,0,.8f,ink); person(g,4,1,.65f,ink); }
    else if(icon==2) {
      circle(g,0,0,4,ink); circle(g,0,0,1.4f,ink);
      for(int i=0;i<8;i++) { double a=i*Math.PI/4; Glass.line(g,Math.cos(a)*4,Math.sin(a)*4,Math.cos(a)*6,Math.sin(a)*6,1,ink); }
    } else {
      Glass.line(g,-5,-6,3,-6,1,ink); Glass.line(g,-5,-6,-5,6,1,ink);
      Glass.line(g,-5,6,3,6,1,ink); Glass.line(g,3,-6,3,6,1,ink);
      Glass.line(g,-1,-4,-1,5,1,ink); Glass.line(g,-1,-4,-5,-6,1,ink);
      Glass.dot(g,1,1,1,ink,0);
    }
  }
  @Override public void onClick(Click click,boolean doubled) { action.run(); }
  @Override public boolean keyPressed(KeyInput key) {
    if(active && isFocused() && (key.key()==257 || key.key()==335 || key.key()==32)) {
      playDownSound(net.minecraft.client.MinecraftClient.getInstance().getSoundManager()); action.run(); return true;
    }
    return super.keyPressed(key);
  }
  @Override protected void appendClickableNarrations(NarrationMessageBuilder builder) { appendDefaultNarrations(builder); }
}

