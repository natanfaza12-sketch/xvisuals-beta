package pl.xvisuals.menu;

/** Monotonic, elapsed-time-based presentation of real resource progress. */
public final class LoadingProgress {
  private double shown, target;
  private double elapsed;
  private final double minimumSeconds;

  public LoadingProgress() { this(0); }
  public LoadingProgress(double minimumSeconds) { this.minimumSeconds = Math.max(0, minimumSeconds); }

  public float update(double actual, boolean complete, double seconds) {
    double delta = Double.isFinite(seconds) ? Math.max(0, seconds) : 0;
    elapsed += delta;
    if (Double.isFinite(actual))
      target = Math.max(target, Math.clamp(actual, 0, complete ? 1 : .999));
    if (complete) target = 1;
    double ceiling = minimumSeconds == 0 ? 1 : Math.min(1, elapsed / minimumSeconds);
    shown = Math.min(ceiling, shown + (target - shown) * (1 - Math.exp(-9 * Math.min(delta, .1))));
    if (complete && ceiling >= 1 && 1 - shown < .001) shown = 1;
    return (float) shown;
  }

  public static float fade(double t) {
    t = Math.clamp(t, 0, 1);
    return (float) (t * t * (3 - 2 * t));
  }
}
