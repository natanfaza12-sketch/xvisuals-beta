package pl.xvisuals.menu;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.*;
import net.minecraft.util.Identifier;
final class MenuText {
  static void center(DrawContext g,String text,float x,float y,float scale,int color){draw(g,text,x,y,scale*.5f,color,"menu",true);}
  static void left(DrawContext g,String text,float x,float y,float scale,int color){draw(g,text,x,y,scale*.5f,color,"menu",false);}
  static void clock(DrawContext g,String text,float x,float y){draw(g,text,x,y,1,0xFFF8FAFD,"clock",true);}
  static void adaptive(DrawContext g,String text,float x,float y,float scale,int color,boolean clock) {
    float pixel=(float)(1/MinecraftClient.getInstance().getWindow().getScaleFactor());
    int shadow=color==0xFF111820?0x70FFFFFF:0xB0000000;
    String font=clock?"clock":"menu";
    float size=clock?1:scale*.5f;
    draw(g,text,x,y+pixel,size,shadow,font,true);
    draw(g,text,x,y,size,color,font,true);
  }
  private static void draw(DrawContext g,String text,float x,float y,float scale,int color,String font,boolean centered){
    if(SmoothMenuText.draw(g,text,x,y-(font.equals("clock")?35:3),scale*(font.equals("clock")?44:22),color,centered))return;
    var renderer=MinecraftClient.getInstance().textRenderer;
    var label=Text.literal(text).setStyle(Style.EMPTY.withFont(new StyleSpriteSource.Font(Identifier.of("xvisuals",font))));
    // Minecraft's TTF glyph bearing already offsets the clock; only the smooth texture above
    // needs the 35-pixel origin adjustment. Applying it here would overlap the date.
    if(font.equals("menu"))y+=3;
    if(centered)x-=renderer.getWidth(label)*scale/2;
    g.getMatrices().pushMatrix();g.getMatrices().translate(x,y);g.getMatrices().scale(scale,scale);
    g.drawText(renderer,label,0,0,color,false);g.getMatrices().popMatrix();
  }
  static void button(DrawContext g,String text,float x,float y,float w,float h) {
    var s=pl.xvisuals.XVisuals.config().module("menubuttons");
    var renderer=MinecraftClient.getInstance().textRenderer;
    String font=s.text("font");
    Identifier id=font.equals("Smooth")?Identifier.of("xvisuals","menu")
        :Identifier.of("minecraft",font.equals("Classic")?"uniform":"default");
    var label=Text.literal(text).setStyle(Style.EMPTY.withFont(new StyleSpriteSource.Font(id)));
    float scale=(font.equals("Smooth")?.375f:.75f)*(float)s.number("fontSize");
    scale=Math.min(scale,(w-10)/Math.max(1,renderer.getWidth(label)));
    int ink=s.color("textColor");
    if(font.equals("Smooth")) {
      float size=22*scale;
      if(SmoothMenuText.draw(g,text,x+w/2,y+(h-size*1.2f)/2,size,ink,true))return;
    }
    g.getMatrices().pushMatrix();
    g.getMatrices().translate(x+(w-renderer.getWidth(label)*scale)/2,y+h/2+(font.equals("Smooth")?3:-4)*scale);
    g.getMatrices().scale(scale,scale);g.drawText(renderer,label,0,0,ink,false);
    g.getMatrices().popMatrix();
  }
  private MenuText(){}
}
