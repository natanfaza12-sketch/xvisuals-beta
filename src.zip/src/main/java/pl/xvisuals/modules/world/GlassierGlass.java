package pl.xvisuals.modules.world;
import pl.xvisuals.XVisuals;
import net.minecraft.util.Identifier;
import java.util.List;
/** Texture-only glass styling. Shares the existing atlas restoration and resource-reload lifecycle. */
public final class GlassierGlass {
 private static boolean initialized;
 private static long revision;
 public static long revision(){return revision;}
 public static void init(){
  if(initialized)return;initialized=true;
  register("glass",false,false);register("glass_pane_top",false,true);
  for(String color:List.of("white","orange","magenta","light_blue","yellow","lime","pink","gray","light_gray","cyan","purple","blue","brown","green","red","black")){
   register(color+"_stained_glass",true,false);register(color+"_stained_glass_pane_top",true,true);
  }
 }
 public static net.minecraft.item.ItemStack appearance(net.minecraft.item.ItemStack original){
  if(!XVisuals.ready()||!XVisuals.config().module("glassierglass").enabled)return original;
  var id=net.minecraft.registry.Registries.ITEM.getId(original.getItem());
  if(!isGlassItem(id))return original;
  var model=original.get(net.minecraft.component.DataComponentTypes.ITEM_MODEL);
  if(model!=null&&!model.equals(id))return original;
  var copy=original.copy();
  copy.set(net.minecraft.component.DataComponentTypes.ITEM_MODEL,Identifier.of("xvisuals","glass_items/"+id.getPath()));
  return copy;
 }
 public static boolean isGlassItem(Identifier id){
  if(!id.getNamespace().equals("minecraft"))return false;
  String p=id.getPath();
  if(p.equals("glass")||p.equals("glass_pane"))return true;
  for(String color:List.of("white","orange","magenta","light_blue","yellow","lime","pink","gray","light_gray","cyan","purple","blue","brown","green","red","black"))
   if(p.equals(color+"_stained_glass")||p.equals(color+"_stained_glass_pane"))return true;
  return false;
 }
 private GlassierGlass(){}
}
