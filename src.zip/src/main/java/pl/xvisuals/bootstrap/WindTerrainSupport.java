package pl.xvisuals.bootstrap;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.*;
/** Neutral terrain setup required before authenticated late activation. No feature or account logic. */
public final class WindTerrainSupport {
 private static GpuBuffer uniform;
 private static final ByteBuffer DATA=ByteBuffer.allocateDirect(16).order(ByteOrder.nativeOrder());
 public static boolean nativeTerrain(){var f=FabricLoader.getInstance();return !f.isModLoaded("iris")&&!f.isModLoaded("sodium");}
 public static void update(float x,float z,float time){
  if(!nativeTerrain())return;
  DATA.clear();DATA.putFloat(x).putFloat(z).putFloat(time).putFloat(0).flip();
  if(uniform==null)uniform=RenderSystem.getDevice().createBuffer(()->"Visual wind",GpuBuffer.USAGE_UNIFORM|GpuBuffer.USAGE_COPY_DST,DATA);
  else RenderSystem.getDevice().createCommandEncoder().writeToBuffer(uniform.slice(),DATA);
 }
 public static void bind(RenderPass pass){if(nativeTerrain()){if(uniform==null)update(0,0,0);pass.setUniform("VisualWind",uniform);}}
 public static void close(){if(uniform!=null){uniform.close();uniform=null;}}
 private WindTerrainSupport(){}
}
