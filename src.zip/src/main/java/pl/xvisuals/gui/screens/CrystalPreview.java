package pl.xvisuals.gui.screens;

import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.entity.CrystalSkins;
import pl.xvisuals.rendering.shaders.GuiAccess;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.util.Identifier;
import org.joml.Matrix3x2f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/** Transparent, bounded crystal-only preview using the vanilla crystal texture and skin palettes. */
final class CrystalPreview {
 private static int[][] pixels;
 private static boolean failed;
 private static int[][] texture(){
  if(pixels==null&&!failed)try(var input=MinecraftClient.getInstance().getResourceManager().open(Identifier.ofVanilla("textures/entity/end_crystal/end_crystal.png"));var image=NativeImage.read(input)){
   pixels=new int[image.getHeight()][image.getWidth()];for(int y=0;y<pixels.length;y++)for(int x=0;x<pixels[y].length;x++)pixels[y][x]=image.getColorArgb(x,y);
  }catch(java.io.IOException e){failed=true;}
  return pixels;
 }
 static void draw(DrawContext g,String design,int x,int y,int w,int h){
  var texture=texture();if(texture==null)return;
  var s=XVisuals.config().module("crystals");int skin=CrystalSkins.index(design);
  boolean custom=skin==0||s.flag("customColors");int a=custom?s.color("color"):CrystalSkins.ALL[skin].primary(),b=custom?s.color("secondary"):CrystalSkins.ALL[skin].secondary();
  boolean animated=s.flag("animated")&&!XVisuals.config().module("performance").text("animation").equals("Off");
  double time=animated?System.nanoTime()/1e9:0,phase=(time*s.number("speed")*.2%1)*Math.PI*2;
  float unit=Math.max(1,Math.min(w-12,h-10))*.56f,cx=x+w*.5f,cy=y+h*.5f;
  var faces=new java.util.ArrayList<SwingPreview.Face>();
  for(int layer=0;layer<3;layer++){
   float size=layer==0?.48f:layer==1?.36f:.23f;
   var matrix=new Matrix4f().rotateY((float)(time*.45% (Math.PI*2))+.4f).rotateZ(.55f+layer*.65f).rotateX(.65f+layer*.25f);
   cube(faces,texture,matrix,cx,cy,unit,size,layer==2?32:0,imported?-1:skin,a,b,phase);
  }
  faces.sort(java.util.Comparator.comparingDouble(SwingPreview.Face::depth));
  var pose=new Matrix3x2f(g.getMatrices());var access=(GuiAccess)g;var bounds=new ScreenRect(x,y,w,h).transformEachVertex(pose);
  if(access.visuals$clip()!=null){bounds=bounds.intersection(access.visuals$clip());if(bounds==null)return;}
  access.visuals$state().addSimpleElement(new SwingPreview.Mesh(pose,java.util.List.copyOf(faces),bounds));
 }
 private static void cube(java.util.List<SwingPreview.Face> out,int[][] image,Matrix4f matrix,float cx,float cy,float unit,float size,int u,int skin,int a,int b,double t){
  int[][] uv={{u+8,8},{u+24,8},{u,8},{u+16,8},{u+8,0},{u+16,0}};
  int resolution=Math.max(8,Math.min(32,image[0].length/8));
  for(int face=0;face<6;face++)for(int row=0;row<resolution;row++)for(int col=0;col<resolution;col++){
   int px=(int)((uv[face][0]+(col+.5)*8/resolution)*image[0].length/64),py=(int)((uv[face][1]+(row+.5)*8/resolution)*image.length/32);if(py>=image.length||px>=image[0].length)continue;
   int base=image[py][px];if((base>>>24)<26)continue;
   int color=skin<0?base:shade(base,a,b,(px+.5)/image[0].length,(py+.5)/image.length,skin,t);
   Vector3f[] points=new Vector3f[4];double depth=0;
   for(int k=0;k<4;k++){
    float p=((col+(k==1||k==2?1:0))/(float)resolution*2-1)*size,q=((row+(k>=2?1:0))/(float)resolution*2-1)*size;
    float X=0,Y=0,Z=0;
    switch(face){case 0->{X=-p;Y=-q;Z=-size;}case 1->{X=p;Y=-q;Z=size;}case 2->{X=-size;Y=-q;Z=p;}case 3->{X=size;Y=-q;Z=-p;}case 4->{X=p;Y=size;Z=q;}case 5->{X=p;Y=-size;Z=-q;}}
    points[k]=SwingPreview.project(matrix,X,Y,Z,cx,cy,unit);depth+=points[k].z;
   }
   // GUI quads must retain the same winding after 3D projection.
   float area=(points[1].x-points[0].x)*(points[2].y-points[0].y)-(points[1].y-points[0].y)*(points[2].x-points[0].x);
   if(area>0){var swap=points[1];points[1]=points[3];points[3]=swap;}
   out.add(new SwingPreview.Face(points,color,depth/4));
  }
 }
 private static double smooth(double lo,double hi,double v){double x=Math.clamp((v-lo)/(hi-lo),0,1);return x*x*(3-2*x);}
 private static int shade(int base,int a,int b,double u,double v,int skin,double t){
  int frame=Math.floorMod((int)(t/(Math.PI*2)*8),8);
  int sample=pl.xvisuals.rendering.ArtworkTextures.sample("crafted/crystals",(skin+(.5+u*63)/64)/9,(frame+(.5+v*63)/64)/8);
  double flow=(sample&255)/255.;
  int colour=pl.xvisuals.util.Colors.mix(a,b,flow);
  double r=(base>>16&255)/255.,g=(base>>8&255)/255.,blue=(base&255)/255.;
  double chroma=Math.max(r,Math.max(g,blue))-Math.min(r,Math.min(g,blue));
  return pl.xvisuals.util.Colors.mix(base,colour,smooth(.025,.13,chroma));
 }

 private CrystalPreview(){}
}
