package pl.xvisuals.gui.screens;

import pl.xvisuals.XVisuals;
import pl.xvisuals.config.*;
import pl.xvisuals.gui.components.*;
import pl.xvisuals.gui.themes.Theme;
import pl.xvisuals.modules.*;
import pl.xvisuals.rendering.shaders.SdfRenderer;
import pl.xvisuals.util.Colors;
import java.util.*;
import java.util.function.*;
import net.minecraft.client.gui.*;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.*;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Glass module browser with a persistent inspector and optional expanded controls. */
public final class StudioScreen extends Screen {
  // Navigation belongs to the editor session, not to individual visual profiles.
  private static Navigation remembered;
  private record Navigation(String tab, String filter, String search, String selected,
      int page, double scroll, boolean allSettings,
      boolean lookHotkeys, boolean lookColors, String localSelection) {}
  private int W = 1100, H = 640;
  private boolean workspace() { return tab.equals("Visuals") || tab.equals("World") || tab.equals("Environment FX"); }
  private boolean docked() { return workspace(); }
  private StudioLayout layout;
  private int catalogWidth() { return workspace() ? layout.catalogWidth() : W; }
  private boolean expandedInspector;
  private static final int POPUP_W = 480;
  private static final int SETTING_ROW_HEIGHT = 44;
  private int POPUP_H = 320;
  private float popupX() { if (docked() && !expandedInspector) return layout.inspectorX(); return (8 + (float) cfg().popupX * Math.max(0, width - POPUP_W * scale - 16) - ox) / scale; }
  private float popupY() { if (docked() && !expandedInspector) return 110; return (8 + (float) cfg().popupY * Math.max(0, height - POPUP_H * scale - 16) - oy) / scale; }
  private int windowHeight() { return H; }
  private void dismissInspector() {
    if (expandedInspector) { expandedInspector=false; scroll=0; dropdown=null; return; }
    finishEdit(); selected = ""; inspectorId = ""; scroll = 0; focus = -1;
    dropdown = null; dragging = null; moduleBinding = null;
    movingPopup = false;
  }
  private final Screen parent;
  private boolean worldPanel;
  public StudioScreen asWorldPanel() { worldPanel = true; return this; }
  public void switchDisplayMode() {
    finishEdit();
    dragging = null;
    movingWindow = movingPopup = false;
    dropdown = null;
    focus = -1;
    cfg().worldGui = !worldPanel;
    dirty();
    XVisuals.STORE.save();
    if (worldPanel) {
      pl.xvisuals.gui.world.WorldStudio.close();
      worldPanel = false;
      client.setScreen(this);
    } else if (client.world != null && client.player != null) {
      pl.xvisuals.gui.world.WorldStudio.open(this);
    }
  }
  // The colour wheel is mouse-driven; only actual text/key entry captures movement.
  public boolean worldTyping() { return (!editing.isEmpty() && colourPicker == null) || binding || moduleBinding != null; }
  public boolean worldColourEditing() { return colourPicker != null; }
  private boolean titleDraggable() {
    return selected.isEmpty() || (docked() && !expandedInspector);
  }
  public boolean worldTitleAt(double x, double y) {
    return titleDraggable() && editing.isEmpty() && dropdown == null
        && x >= ox && x < ox + (W - 194) * scale && y >= oy && y < oy + 54 * scale;
  }
  public boolean worldSurfaceAt(double x, double y) {
    if (!selected.isEmpty() || dropdown != null || !editing.isEmpty()) return true;
    return x >= ox && x <= ox + W * scale && y >= oy && y <= oy + windowHeight() * scale;
  }
  private final List<Hit> hits = new ArrayList<>();
  private final List<Hit> moduleSettings = new ArrayList<>();
  private final Map<String, Spring> animations = new HashMap<>();
  private int controlIndex;
  private String searchDisplaySource = "", searchDisplay = "";
  private int searchDisplayWidth = -1;
  private String measuredFont="";
  private boolean searchDisplayFocused;
  private long searchCaretEpoch;
  private final Map<String,List<net.minecraft.text.OrderedText>> descriptions=new HashMap<>();
  private final Spring entrance = new Spring(0);
  private String tab = "Visuals",
      filter = "All",
      search = "",
      selected = "",
      editing = "",
      buffer = "",
      notice = "";
  private Consumer<String> commit;
  private double mx, my, scroll, maxScroll;
  private float contentX,contentY;
  private float scale, ox, oy;
  private int page, focus = -1;
  private boolean binding;
  private java.util.function.Consumer<String> moduleBinding;
  private Slider dragging;
  private Dropdown dropdown;
  private Dropdown lastDropdown;
  private int dropdownOffset;
  private boolean clippingSettings;
  private double clipTop, clipBottom;
  private boolean movingWindow, movingPopup, allSettings;
  private double grabX, grabY;
  private String inspectorId = "";
  private boolean lookHotkeys, lookColors;
  private String hoverHint = "";
  public boolean editingAttackIndicator(){return "attackindicator".equals(selected);}
  private DesignPreviews designPreviews;
  // Selection outlives preview resources, which are rebuilt when the setting key changes.
  private boolean criticalGallery;
  private String itemGallery="shape", totemGallery="style", previewSetting="";
  private String previewModule="";
  private int soundHover=-1;
  private double soundMouseX=Double.NaN,soundMouseY;
  private ColourPicker colourPicker;
  private String localSelection = "";
  private List<String> localNames;

  private record Hit(double x, double y, double w, double h, Runnable action) {}

  private record Slider(double x, double width, Setting setting, VisualConfig.ModuleState state) {}

  private record Dropdown(
      float x, float y, float width, List<String> choices, Consumer<String> action) {}

  public StudioScreen(Screen parent) {
    super(Text.literal("X Visuals"));
    this.parent = parent;
    pl.xvisuals.audio.CustomGuiSounds.play("open");
    if (remembered != null) {
      tab = remembered.tab(); filter = remembered.filter(); search = remembered.search();
      selected = cfg().module(remembered.selected()) == null ? "" : remembered.selected();
      inspectorId = selected; // Do not reset the restored inspector on its first render.
      page = remembered.page(); scroll = remembered.scroll(); allSettings = remembered.allSettings();
      lookHotkeys = remembered.lookHotkeys();
      lookColors = remembered.lookColors(); localSelection = remembered.localSelection();
    }
  }

  public StudioScreen buttonAppearance() {
    tab="Setup";selected="menubuttons";allSettings=true;return this;
  }

  public StudioScreen hudAppearance() {
    tab = "HUD";
    selected = "hud";
    allSettings = true;
    return this;
  }

  private void toggleModule(String id) {
    var m = cfg().module(id);
    m.enabled = !m.enabled;
    pl.xvisuals.audio.CustomGuiSounds.play(m.enabled?"enable":"disable");
    if(id.equals("music")) pl.xvisuals.hud.MusicControls.setEnabled(cfg(),m.enabled);
    dirty();
  }

  private void soundPage(int next){
    if(next!=page){page=next;pl.xvisuals.audio.CustomGuiSounds.play("page");}
  }

  private void runAction(Runnable action) {
    action.run();
  }

  private VisualConfig cfg() {
    return XVisuals.config();
  }

  private void dirty() {
    XVisuals.STORE.dirty();
  }

  @Override
  public boolean shouldPause() {
    return false;
  }

  @Override
  public void renderBackground(DrawContext g, int x, int y, float dt) {}

  @Override
  public void close() {
    pl.xvisuals.audio.CustomGuiSounds.play("close");
    rememberNavigation();
    XVisuals.STORE.save();
    if (worldPanel) { pl.xvisuals.gui.world.WorldStudio.close(); return; }
    client.setScreen(parent);
  }

  @Override
  public void removed() {
    if(configContent!=null)configContent.removed();
    if(designPreviews!=null){designPreviews.close();designPreviews=null;previewModule="";}
    rememberNavigation();
    XVisuals.STORE.save();
  }

  private void rememberNavigation() {
    remembered = new Navigation(tab, filter, search, selected, page, scroll, allSettings,
        lookHotkeys, lookColors, localSelection);
  }

  @Override
  public void render(DrawContext g, int mouseX, int mouseY, float dt) {
    String font=pl.xvisuals.gui.FontSelection.selected();
    if(!font.equals(measuredFont)){measuredFont=font;descriptions.clear();searchDisplayWidth=-1;}
    if (client.world == null) pl.xvisuals.menu.MenuBackdrop.draw(g, width, height);
    if (!worldPanel) {
      if (cfg().blur) applyBlur(g);
      g.fill(0, 0, width, height, 0x24080D12);
    }
    var window=client.getWindow();
    layout=StudioLayout.forWindow(worldPanel?1600:window.getFramebufferWidth(),worldPanel?1080:window.getFramebufferHeight(),width,height,worldPanel?1:cfg().guiScale);
    W=layout.width();H=layout.height();
    POPUP_H = docked() ? expandedInspector ? Math.min(520,H-60) : H - 155 : 320;
    float a = entrance.to(1);
    scale = layout.scale();
    if (!cfg().module("performance").text("animation").equals("Off")) scale *= .98f + .02f * a;
    ox = (worldPanel ? .5f : (float) cfg().studioX) * Math.max(0, width - W * scale);
    oy = (worldPanel ? .5f : (float) cfg().studioY) * Math.max(0, height - H * scale);
    mx = (mouseX - ox) / scale;
    my = (mouseY - oy) / scale;
    g.getMatrices().pushMatrix();
    g.getMatrices().translate(ox, oy);
    g.getMatrices().scale(scale, scale);
    hits.clear();
    controlIndex = 0;
    moduleSettings.clear();
    hoverHint = "";
    boolean modal = !selected.isEmpty() && (!docked() || expandedInspector);
    double savedMouseX = mx, savedMouseY = my;
    if (modal) { mx = -10000; my = -10000; }
    Glass.rounded(g,-3,5,W+6,windowHeight()+2,16,0x50000000);
    glassSurface(g,0,0,W,windowHeight(),14,Math.clamp(cfg().glassOpacity,.90,.97),false);
    Glass.logo(g, 33, 30, 23, Theme.accent());
    StudioChrome.scaled(g, "Visuals", 53, 30 - client.textRenderer.fontHeight * 1.55f / 2, 1.55f, Theme.text());
    button(
        g,
        fitLabel(XVisuals.STORE.activeProfile, 94) + "  \u25be",
        W - 184,
        17,
        124,
        25,
        () ->
            dropdown =
                new Dropdown(
                    W - 220,
                    47,
                    200,
                    XVisuals.STORE.profiles(),
                    v -> attempt(() -> XVisuals.STORE.select(v))));
    iconButton(g,"close",W-45,17,27,this::close);
    {
      String[] tabs = {"Visuals", "Presets", "World", "Environment FX", "HUD", "Style", "Configs", "Setup", "Autor"};
      float totalTabWidth=0;
      for(String name:tabs)totalTabWidth+=Math.max(76,Glass.textWidth(name)+44);
      float tabFit=Math.min(1,(W-36f)/totalTabWidth),nextTabX=18;
      for (int i = 0; i < tabs.length; i++) {
        String name = tabs[i];
        float tabStep=Math.max(76,Glass.textWidth(name)+44)*tabFit, tabWidth=tabStep-6;
        float x = nextTabX;nextTabX+=tabStep;
        boolean active = tab.equals(name);
        float hover = anim("tab" + name, active || inside(x, 60, tabWidth, 32) ? 1 : 0);
        float selection = anim("tabSelected" + name, active ? 1 : 0);
        StudioChrome.navigation(g,x,60,tabWidth,32,selection,hover);
        StudioIcons.draw(g,StudioIcons.navigation(name),x+9,68,16,Colors.mix(Theme.muted(),Theme.accent(),selection));
        StudioChrome.scaled(g,name,x+30,72,Math.min(1,(tabWidth-34)/Math.max(1,Glass.textWidth(name))),active?Theme.text():Theme.muted());
        hit(
            x,
            60,
            tabWidth,
            32,
            () -> {
              finishEdit();
              if (name.equals("Configs")) { openConfigs(""); return; }
              if(configContent!=null)configContent.removed();
              tab = name;
              expandedInspector=false;
              localNames = null;
              selected = "";
              search = "";
              scroll = 0;
              page = 0;
              dropdown = null;
            });
      }
      g.fill(18, 98, W - 18, 99, 0x14E9EDFF);
      boolean compact=Set.of("Style","Presets","Setup","HUD","Autor").contains(tab);
      double pageMouseX=mx,pageMouseY=my;
      if(compact) {
        contentX=Math.max(0,(W-620f)/2);
        float bottom=switch(tab){case "HUD"->318;case "Style"->351;case "Setup"->346;default->382;};
        contentY=Math.max(0,(windowHeight()-48-bottom)/2);
        g.getMatrices().pushMatrix();g.getMatrices().translate(contentX,contentY);
        mx-=contentX;my-=contentY;
      }
      switch (tab) {
        case "Style" -> themes(g);
        case "Presets" -> quickLooks(g);
        case "Configs" -> localConfigs(g);
        case "Setup" -> setup(g);
        case "Autor" -> author(g);
        case "HUD" -> hud(g);
        default -> modules(g);
      }
      if(compact){g.getMatrices().popMatrix();mx=pageMouseX;my=pageMouseY;contentX=contentY=0;}
    }
    g.fill(18, windowHeight() - 32, W - 18, windowHeight() - 31, 0x10FFFFFF);
    if (!notice.isEmpty()) StudioChrome.scaled(
        g,
        shorten(notice, 56),
        20,
        windowHeight() - 20,
        .8f,
        Theme.muted());
    if (client.world != null)
      button(g, worldPanel ? "GUI: World" : "GUI: Screen", W - 115, windowHeight() - 27, 96, 21,
          this::switchDisplayMode);
    mx = savedMouseX; my = savedMouseY;
    if (modal) {
      // Background remains visible, but only popup controls receive mouse/keyboard focus.
      hits.clear();
      Glass.rounded(g, 0, 0, W, windowHeight(), 14, 0x78060A13);
      drawInspector(g);
    }
    if (docked() && !expandedInspector) {
      if (!selected.isEmpty()) drawInspector(g);
      else {
        float center=layout.inspectorX()+layout.inspectorWidth()/2f;
        glassSurface(g,layout.inspectorX(),110,layout.inspectorWidth(),H-155,9,.91,false);
        StudioIcons.draw(g,"settings",center-20,H/2f-35,40,Theme.quiet());
        StudioChrome.center(g,"Select a module",center,H/2f+23,Theme.text());
      }
    }
    if (dropdown != null) drawDropdown(g);
    if (!editing.isEmpty() && !editing.equals("Search")) drawEditor(g);
    if (!hoverHint.isEmpty() && editing.isEmpty() && dropdown == null) {
      float tipW = Math.min(440, Glass.textWidth(hoverHint) + 20);
      var lines = textRenderer.wrapLines(Glass.label(hoverHint), (int)tipW - 16);
      int tipH = 16 + lines.size() * 10;
      float tx = (float)Math.clamp(mx + 10, 8, W - tipW - 8);
      float ty = (float)Math.max(8, Math.min(my + 18, H - tipH - 8));
      Glass.rounded(g, tx, ty, tipW, tipH, 7, 0xff252c39);
      for (int i = 0; i < lines.size(); i++)
        g.drawText(textRenderer, lines.get(i), (int)tx + 8, (int)ty + 8 + i * 10, Theme.text(), false);
    }
    int hovered=-1;
    for(int i=hits.size()-1;i>=0;i--){var target=hits.get(i);if(inside(target.x,target.y,target.w,target.h)){hovered=i;break;}}
    if(!Double.isNaN(soundMouseX)&&(mx!=soundMouseX||my!=soundMouseY)&&hovered>=0&&hovered!=soundHover)
      pl.xvisuals.audio.CustomGuiSounds.play("hover");
    soundHover=hovered;soundMouseX=mx;soundMouseY=my;
    if (focus >= 0 && focus < hits.size()) {
      Hit h = hits.get(focus);
      g.drawStrokedRectangle((int) h.x, (int) h.y, (int) h.w, (int) h.h, Theme.accent());
    }
    g.getMatrices().popMatrix();
  }

  private void modules(DrawContext g) {
    if (tab.equals("Visuals")) {
      String[] filters = {"All", "New", "Entities", "Motion", "Starred", "Enabled"};
      float[] widths = {28,34,49,46,47,50};
      float nextX=19;
      for (int i = 0; i < filters.length; i++) {
        String f = filters[i];
        float x=nextX,fw=widths[i];nextX+=fw+2;
        boolean active = filter.equals(f);
        if(f.equals("New")&&inside(x,110,fw,24))hoverHint="Recently added and updated modules";
        StudioChrome.navigation(g,x,110,fw,24,anim("filterSelected"+f,active?1:0),anim("filterHover"+f,inside(x,110,fw,24)?1:0));
        StudioChrome.center(g,f,x+fw/2,118,active?Theme.text():Theme.muted());
        hit(x,110,fw,24,()->{filter=f;page=0;});
      }
    } else StudioChrome.text(g, tab, 22, 117, Theme.muted());
    searchBar(g);
    boolean nameSearch=ModuleCatalog.preferNames(search);
    List<ModuleSpec> list =
        Modules.ALL.stream()
            .filter(
                m -> {
                  return (!tab.equals("Visuals") || !filter.equals("Enabled") || cfg().module(m.id()).enabled)
                      && pl.xvisuals.modules.ModuleCatalog.visible(
                      m, tab, filter, search, cfg().module(m.id()).favorite, nameSearch);
                })
            .sorted(Comparator.<ModuleSpec>comparingInt(m -> ModuleCatalog.searchRank(m, search))
                .thenComparingInt(m -> tab.equals("Visuals") && filter.equals("New") ? ModuleCatalog.recentRank(m) : 0))
            .toList();
    int pageSize=layout.pageSize();
    int pages = Math.max(1, (list.size() + pageSize - 1) / pageSize);
    page = Math.min(page, pages - 1);
    for (int i = 0; i < pageSize; i++) {
      int index = page * pageSize + i;
      if (index >= list.size()) break;
      card(g, list.get(index), 19 + (i % layout.columns()) * 278, layout.listTop() + (i / layout.columns()) * 40);
    }
    if (list.isEmpty()) StudioChrome.center(g, "No matching modules", catalogWidth() / 2f, 204, Theme.muted());
    long enabled = list.stream().filter(m -> cfg().on(m.id())).count();
    StudioChrome.text(g, list.size() + (list.size()==1?" module  \u00b7  ":" modules  \u00b7  ") + enabled + " enabled", 22, windowHeight() - 55, Theme.quiet());
    if (pages > 1) {
      button(g, "\u2039", catalogWidth() - 122, windowHeight() - 63, 25, 22, () -> soundPage(Math.max(0, page - 1)));
      StudioChrome.center(g, (page + 1) + " / " + pages, catalogWidth() - 73, windowHeight() - 55, Theme.muted());
      button(g, "\u203a", catalogWidth() - 47, windowHeight() - 63, 27, 22, () -> soundPage(Math.min(pages - 1, page + 1)));
    }
  }

  private void beginSearch() {
    edit("Search",search,v->{search=v;page=0;});
    searchCaretEpoch=System.nanoTime();
  }

  private void searchBar(DrawContext g) {
    float x=layout.searchX(),y=layout.searchY(),w=layout.searchWidth();
    boolean focused=editing.equals("Search");
    float hover=anim("searchHover",inside(x,y,w,24)?1:0),focusAmount=anim("searchFocus",focused?1:0);
    StudioChrome.search(g,x,y,w,hover,focusAmount);
    float iconSize=14+(fullMotion()?hover*.6f:0);
    StudioIcons.draw(g,"search",x+17-iconSize/2,y+12-iconSize/2,iconSize,
        Colors.mix(Theme.muted(),Theme.accent(),focusAmount));
    String value=focused?buffer:search;
    int available=(int)w-62;
    if(!value.equals(searchDisplaySource)||available!=searchDisplayWidth||focused!=searchDisplayFocused) {
      searchDisplaySource=value;searchDisplayWidth=available;searchDisplay=value;searchDisplayFocused=focused;
      if(focused) {
        // Keep the insertion end visible, including after pasting a long query.
        while(!searchDisplay.isEmpty()&&Glass.textWidth(searchDisplay)>available)
          searchDisplay=searchDisplay.substring(searchDisplay.offsetByCodePoints(0,1));
      } else searchDisplay=fit(value,available);
    }
    // The measured string and caret fit inside the field without another GUI scissor batch.
    StudioChrome.text(g,value.isEmpty()?"Search modules":searchDisplay,x+32,y+8,
        value.isEmpty()?Theme.muted():Theme.text());
    boolean caret=cfg().module("performance").text("animation").equals("Off")
        || (System.nanoTime()-searchCaretEpoch)%1_100_000_000L<700_000_000L;
    if(focused&&caret) Glass.rounded(g,x+32+(value.isEmpty()?0:Glass.textWidth(searchDisplay))+1,y+7,1,10,.5f,Theme.accent());
    hit(x,y,w,24,this::beginSearch);
    if(!value.isEmpty()) {
      float clearHover=anim("searchClear",inside(x+w-24,y+3,21,18)?1:0);
      Glass.rounded(g,x+w-23,y+4,18,16,7,Colors.alpha(0xFFB9C4D4,.05+clearHover*.09));
      StudioIcons.draw(g,"close",x+w-20,y+6,12,Colors.mix(Theme.muted(),Theme.text(),clearHover));
      hit(x+w-24,y+3,21,18,()->{search="";page=0;beginSearch();});
    }
  }

  private void card(DrawContext g, ModuleSpec spec, float x, float y) {
    var m = cfg().module(spec.id());
    boolean active = selected.equals(spec.id());
    int w=layout.cardWidth();
    boolean hover=inside(x,y,w,35);
    float hoverAmount=anim("rowHover"+spec.id(),hover?1:0);
    float selection=anim("rowSelected"+spec.id(),active?1:0);
    StudioChrome.row(g,x,y,w,selection,hoverAmount);
    float iconSize=20+(fullMotion()?hoverAmount:0);
    StudioIcons.draw(g,StudioIcons.module(spec.id(),spec.category()),x+22-iconSize/2,y+18-iconSize/2,iconSize,
        Colors.mix(Theme.muted(),Theme.accent(),anim("rowInk"+spec.id(),active||m.enabled?1:0)));
    StudioChrome.text(g,fit(spec.name(),w-109),x+44,y+13,Theme.text());
    Runnable open = () -> { finishEdit(); selected=spec.id(); scroll=0; dropdown=null; expandedInspector=false; };
    hit(x,y,w,35,open);
    moduleSettings.add(new Hit(x,y,w,35,open));
    favoriteIcon(g,x+w-55,y+12,12,m.favorite,"favorite"+spec.id());
    hit(x+w-60,y+4,23,27,()->{m.favorite=!m.favorite;dirty();});
    toggle(g,x+w-34,y+11,m.enabled,"enabled"+spec.id(),() -> toggleModule(spec.id()));
  }

  private void drawSideInspector(DrawContext g) {
    var spec=Modules.get(selected);var m=cfg().module(selected);
    if(!inspectorId.equals(selected)) {inspectorId=selected;allSettings=true;scroll=0;focus=-1;}
    float x=layout.inspectorX(),y=110,w=layout.inspectorWidth(),h=H-155;
    glassSurface(g,x,y,w,h,9,.94,false);
    Glass.rounded(g,x+18,y+1,w-36,1,0,Colors.alpha(Theme.accent(),.38));
    StudioIcons.draw(g,StudioIcons.module(spec.id(),spec.category()),x+18,y+22,29,Theme.accent());
    StudioChrome.scaled(g,fit(spec.name(),(int)((w-114)/1.12)),x+61,y+24,1.12f,Theme.text());
    iconButton(g,"expand",x+w-36,y+12,24,()->{expandedInspector=true;scroll=0;allSettings=true;});
    favoriteIcon(g,x+w-81,y+51,14,m.favorite,"sideFavorite"+spec.id());
    hit(x+w-87,y+44,28,27,()->{m.favorite=!m.favorite;dirty();});
    toggle(g,x+w-46,y+51,m.enabled,"sideEnabled",()->toggleModule(selected));
    if(!selected.equals("discord"))button(g,"Configs",x+61,y+49,70,21,()->openConfigs(selected));
    var description=descriptions.computeIfAbsent(spec.id(),id->{
      String summary=spec.description().split("(?<=[.!?])\\s+",2)[0];
      while(summary.length()>10 && textRenderer.wrapLines(Glass.label(summary),(int)w-36).size()>3)
        summary=summary.substring(0,summary.length()-5).stripTrailing()+"...";
      return textRenderer.wrapLines(Glass.label(summary),(int)w-36);
    });
    int lines=Math.min(3,description.size());
    for(int i=0;i<lines;i++) g.drawText(textRenderer,description.get(i),(int)x+18,(int)y+83+i*13,Theme.muted(),false);
    int settingsTop=(int)y+96+lines*13;
    g.fill((int)x+18,settingsTop-12,(int)(x+w)-18,settingsTop-11,0x207E819C);
    var shown=inspectorSettings(spec);
    int toolsHeight=moduleToolsHeight();
    clipTop=settingsTop;clipBottom=y+h-47;
    int contentHeight=toolsHeight+shown.size()*SETTING_ROW_HEIGHT;
    maxScroll=Math.max(0,contentHeight-(clipBottom-clipTop));scroll=Math.clamp(scroll,0,maxScroll);
    g.enableScissor((int)x+10,settingsTop,(int)(x+w)-10,(int)clipBottom);clippingSettings=true;
    drawModuleTools(g,m,x+18,(float)(settingsTop-scroll),w-40);
    for(int i=0;i<shown.size();i++) {float sy=(float)(settingsTop+toolsHeight+i*SETTING_ROW_HEIGHT-scroll);
      if(sy+40>clipTop && sy<clipBottom) setting(g,m,shown.get(i),x+18,sy,w-40);}
    g.disableScissor();clippingSettings=false;
    if(maxScroll>0) {
      float track=(float)(clipBottom-clipTop),thumb=Math.max(24,track*track/contentHeight);
      Glass.rounded(g,x+w-7,(float)clipTop,2,track,1,0x305B6378);
      Glass.rounded(g,x+w-7,(float)(clipTop+(track-thumb)*scroll/maxScroll),2,thumb,1,Theme.muted());
    }
    button(g,"Reset",x+16,y+h-34,81,23,()->XVisuals.STORE.resetModule(selected));
    if(!selected.equals("armorfx")&&!selected.equals("hud")&&spec.settings().size()>5)
      button(g,allSettings?"Show essentials":"All settings",x+106,y+h-34,w-122,23,()->{allSettings=!allSettings;scroll=0;});
  }

  private void drawInspector(DrawContext g) {
    if(docked() && !expandedInspector) { drawSideInspector(g); return; }
    var spec = Modules.get(selected);
    var m = cfg().module(selected);
    if (!inspectorId.equals(selected)) {
      inspectorId = selected;
      allSettings = true;
      scroll = 0;
      focus = -1;
    }
    float x = popupX();
    int y = (int) popupY(), w = POPUP_W, h = POPUP_H;
    SdfRenderer.rect(g, x - 5, y + 5, w + 10, h + 4, 12, 0x44000000, 1);
    glassSurface(g,x,y,w,h,9,.91,false);
    iconButton(g,"close",x+12,y+10,25,this::dismissInspector);
    StudioChrome.text(g, spec.name(), x + 50, y + 16, Theme.text());
    iconButton(g,"star",x+w-88,y+9,24,()->{m.favorite=!m.favorite;dirty();});
    favoriteIcon(g,x+w-82,y+15,12,m.favorite,"popupFavorite"+selected);
    toggle(
        g,
        x + w - 44,
        y + 15,
        m.enabled,
        "inspectEnabled",
        () -> toggleModule(selected));
    boolean discord = selected.equals("discord");
    boolean fakePlayer = selected.equals("fakeplayer");
    StudioChrome.text(g,spec.category(),x+17,y+42,Theme.muted());
    if(!discord)button(g,"Configs",x+w-91,y+36,74,20,()->openConfigs(selected));
    g.fill((int) x + 14, y + 60, (int) x + w - 14, y + 61, 0x14FFFFFF);
    int settingsTop = y + 70;
    List<Setting> shown = inspectorSettings(spec);
    int toolsHeight = moduleToolsHeight();
    clipTop = settingsTop;
    clipBottom = y + h - 40;
    int columns = workspace() && !discord && !fakePlayer && !selected.equals("hud") ? 2 : 1;
    int settingRows = (shown.size() + columns - 1) / columns;
    int contentHeight = toolsHeight + settingRows * SETTING_ROW_HEIGHT;
    maxScroll = Math.max(0, contentHeight - (clipBottom - clipTop));
    scroll = Math.max(0, Math.min(maxScroll, scroll));
    g.enableScissor((int) x + 9, settingsTop, (int) x + w - 9, (int) clipBottom);
    clippingSettings = true;
    drawModuleTools(g,m,x+20,(float)(settingsTop-scroll),w-48);
    float sy = (float) (settingsTop + toolsHeight + 1 - scroll);
    int settingIndex = 0;
    for (Setting s : shown) {
      int index = settingIndex++;
      sy = (float)(settingsTop + toolsHeight + 1 - scroll + (index / columns) * SETTING_ROW_HEIGHT);
      float cellX = x + 20 + (index % columns) * 222;
      float cellW = columns == 2 ? 208 : w - 48;
      if (sy + 40 > settingsTop && sy < clipBottom) {
        setting(g, m, s, cellX, sy, cellW);
        g.fill((int) x + 20, (int) sy + 42, (int) x + w - 28, (int) sy + 43, 0x0AFFFFFF);
      }

    }
    g.disableScissor();
    clippingSettings = false;
    if (maxScroll > 0) {
      float track = (float) (clipBottom - clipTop);
      float thumb = Math.max(22, track * track / contentHeight);
      Glass.rounded(g, x + w - 10, (float) clipTop, 3, track, 1, 0x203C4352);
      Glass.rounded(
          g,
          x + w - 10,
          (float) (clipTop + (track - thumb) * scroll / maxScroll),
          3,
          thumb,
          1,
          0xFF72798B);
    }
    if (!selected.equals("armorfx") && !selected.equals("hud") && spec.settings().size() > 5)
      button(
          g,
          allSettings ? "Show essentials" : "All settings (" + spec.settings().size() + ")",
          x + w - 165,
          y + h - 29,
          150,
          22,
          () -> {
            allSettings = !allSettings;
            scroll = 0;
            focus = -1;
          });
    button(g, "Reset", x + 15, y + h - 29, 55, 20,
        () -> XVisuals.STORE.resetModule(selected));
  }
  private enum ModuleTool {
    SKIN_IMAGE("Import skin PNG"), SKY_IMAGE("Import sky image"), INDICATOR("Edit indicator layout"), CROSSHAIR("Edit crosshair"), HUD("Edit HUD layout"),
    SPAWN("Spawn / reset"), POP("Pop totem"), KILL("Kill"), JUMP("Jump"), REMOVE("Remove"),
    RECONNECT("Reconnect"), HANDS("Edit hand placement"), PREVIEW("Preview"), WAYPOINTS("Manage waypoints");
    final String label;
    ModuleTool(String label) { this.label=label; }
  }

  /** One tool list feeds both inspectors so custom controls cannot disappear in the dock. */
  private List<ModuleTool> moduleTools() {
    return switch(selected) {
      case "smartwaypoints" -> List.of(ModuleTool.WAYPOINTS);
      case "viewmodel" -> List.of(ModuleTool.HANDS);
      case "skinchanger" -> List.of(ModuleTool.SKIN_IMAGE);
      case "cinematicsky", "dimensionskies" -> List.of(ModuleTool.SKY_IMAGE);
      case "attackindicator" -> List.of(ModuleTool.INDICATOR);
      case "crosshair" -> List.of(ModuleTool.CROSSHAIR);
      case "hud" -> List.of(ModuleTool.HUD);
      case "fakeplayer" -> List.of(ModuleTool.SPAWN,ModuleTool.POP,ModuleTool.KILL,ModuleTool.JUMP,ModuleTool.REMOVE);
      case "discord" -> List.of(ModuleTool.RECONNECT);
      case "totemparticles","totemtexture","totemsize","totemghost","deathghost","killanimations" -> List.of(ModuleTool.PREVIEW);
      default -> List.of();
    };
  }

  private List<Setting> inspectorSettings(ModuleSpec spec) {
    if(selected.equals("dimensionskies")){
      String dimension=cfg().module(selected).text("dimension");
      return spec.settings().stream().filter(s->!s.key().equals("image")&&!(dimension.equals("End")&&s.key().equals("netherPreset"))&&!(dimension.equals("Nether")&&s.key().equals("endPreset"))).toList();
    }
    if(selected.equals("crystals")){
      var m=cfg().module(selected);String section=m.text("lookSection");
      String prefix=switch(section){case "Obsidian"->"importedObsidian";case "Respawn anchor"->"importedAnchor";case "Glowstone"->"importedGlowstone";default->"importedCrystal";};
      boolean imported=false;
      return spec.settings().stream().filter(s->{
        if(s.key().equals("lookSection"))return true;
        if(!section.equals("Crystal"))return s.key().startsWith(prefix);
        if(s.key().startsWith("model"))return true;
        return imported?s.key().startsWith(prefix):!s.key().startsWith("imported");
      }).filter(s->!DesignPreviews.supports(selected,s.key())).toList();
    }
    if(selected.equals("totemtexture")){
      boolean imported=false;
      return spec.settings().stream().filter(s->imported?s.key().startsWith("importedTotem"):!s.key().startsWith("importedTotem"))
          .filter(s->!DesignPreviews.supports(selected,s.key())).toList();
    }
    if(selected.equals("pets"))return spec.settings().stream().filter(s->!DesignPreviews.supports(selected,s.key())&&!s.key().equals("importedVariant")).toList();
    if(selected.equals("viewmodel"))return spec.settings().stream().filter(s->Set.of("mainTilt","offTilt","hideEmpty","hideOffhand").contains(s.key())).toList();
    if(selected.equals("armorfx")) {
      var armor=cfg().module("armorfx");
      return pl.xvisuals.modules.armor.ArmorFXSettings.visible(spec,armor.text("section"),armor.flag("debugEnabled"));
    }
    if(Set.of("customswords","custompickaxes").contains(selected))return spec.settings().stream()
        .filter(s->!DesignPreviews.supports(selected,s.key())&&!s.key().equals("toolSection")).toList();
    List<Setting> shown;
    shown=allSettings||selected.equals("hud")||spec.settings().size()<=5?spec.settings():essentials(spec);
    shown=shown.stream().filter(s->!DesignPreviews.supports(selected,s.key())).toList();
    if(selected.equals("cinematicsky")){
      var m=cfg().module("cinematicsky");
      boolean layers=pl.xvisuals.modules.SkyScenes.layered(m.text("preset"))||m.text("preset").equals("Custom Image");
      shown=shown.stream().filter(s->!s.key().equals("image")&&(layers||!Set.of("depth3d","depth","veil").contains(s.key()))).toList();
    }
    return selected.equals("crosshair")?shown.stream().filter(s->!s.key().equals("pixels")).toList():shown;
  }

  private Setting gallerySetting(){
    var spec=Modules.get(selected);
    if(spec!=null&&selected.equals("totemtexture")){
      String key=false?totemGallery:"style";
      return spec.settings().stream().filter(s->s.key().equals(key)).findFirst().orElse(null);
    }
    if(spec!=null&&selected.equals("crystals")){
      String key=switch(cfg().module(selected).text("lookSection")){case "Obsidian"->"importedObsidianStyle";case "Respawn anchor"->"importedAnchorStyle";case "Glowstone"->"importedGlowstoneStyle";default->"skin";};
      return spec.settings().stream().filter(s->s.key().equals(key)).findFirst().orElse(null);
    }
    if(spec!=null&&Set.of("customswords","custompickaxes").contains(selected)){
      String key=itemGallery.equals("shape")?"style":itemGallery;
      return spec.settings().stream().filter(s->s.key().equals(key)).findFirst().orElse(null);
    }
    return spec==null?null:spec.settings().stream().filter(s->DesignPreviews.supports(selected,s.key()))
        .filter(s->!selected.equals("hitfx")||s.key().equals(criticalGallery?"critStyle":"style")).findFirst().orElse(null);
  }

  private static final int DESIGN_CARD_HEIGHT = 112;
  private static final int DESIGN_GALLERY_HEIGHT = 23 + 2 * (DESIGN_CARD_HEIGHT + 5) + 31;

  private void drawDesignCards(DrawContext g,VisualConfig.ModuleState m,float x,float y,float w){
    var setting=gallerySetting();if(setting==null)return;
    if(designPreviews==null||!previewModule.equals(selected)||!previewSetting.equals(setting.key())){
      if(designPreviews!=null)designPreviews.close();
      designPreviews=new DesignPreviews(selected,setting.choices());designPreviews.optionKey=setting.key();previewModule=selected;previewSetting=setting.key();
      designPreviews.critical=selected.equals("hitfx")&&criticalGallery;
      designPreviews.page=Math.max(0,setting.choices().indexOf(m.text(setting.key())))/4;
    }
    designPreviews.sync();
    var preview=designPreviews;var choices=setting.choices();int pages=(choices.size()+3)/4;
    preview.page=Math.clamp(preview.page,0,pages-1);
    StudioChrome.text(g,fit(setting.label(),(int)w-90),x,y+2,Theme.muted());
    if(selected.equals("hitfx"))button(g,criticalGallery?"Critical":"Hits",x+w-65,y,65,18,()->{criticalGallery=!criticalGallery;preview.page=0;});
    if(selected.equals("capes"))button(g,preview.wings?"Elytra":"Cape",x+w-65,y,65,18,()->preview.wings=!preview.wings);
    float cw=(w-8)/2;
    for(int slot=0;slot<4;slot++){
      int index=preview.page*4+slot;if(index>=choices.size())break;
      String design=choices.get(index);float bx=x+(slot%2)*(cw+8),by=y+23+(slot/2)*(DESIGN_CARD_HEIGHT+5);
      if(by+DESIGN_CARD_HEIGHT<=clipTop||by>=clipBottom)continue;
      boolean active=design.equals(m.text(setting.key()));
      glassSurface(g,bx,by,cw,DESIGN_CARD_HEIGHT,8,.8,active);
      boolean skyCard=selected.equals("cinematicsky")&&!design.equals("Custom Image");
      preview.preview(g,design,(int)bx+5,(int)by+3,(int)cw-10,skyCard?DESIGN_CARD_HEIGHT-6:DESIGN_CARD_HEIGHT-20);
      if(skyCard)g.fill((int)bx+5,(int)by+DESIGN_CARD_HEIGHT-23,
          (int)(bx+cw)-5,(int)by+DESIGN_CARD_HEIGHT-3,0xB0081018);
      String label=fit(displayName(design),(int)cw-12);
      StudioChrome.center(g,label,bx+cw/2,by+DESIGN_CARD_HEIGHT-14,active?Theme.accent():Theme.text());
      if(inside(bx,by,cw,DESIGN_CARD_HEIGHT))hoverHint=displayName(design)+(active?" (selected)":" \u2014 click to select");
      hit(bx,by,cw,DESIGN_CARD_HEIGHT,()->{m.values.put(setting.key(),design);if(selected.equals("pets")&&setting.key().equals("variant"))m.values.put("importedVariant",0);dirty();});
    }
    button(g,"\u2039",x,y+DESIGN_GALLERY_HEIGHT-27,28,20,()->{if(preview.page>0){preview.page--;pl.xvisuals.audio.CustomGuiSounds.play("page");}});
    StudioChrome.center(g,(preview.page+1)+" / "+pages,x+w/2,y+DESIGN_GALLERY_HEIGHT-21,Theme.muted());
    button(g,"\u203a",x+w-28,y+DESIGN_GALLERY_HEIGHT-27,28,20,()->{if(preview.page+1<pages){preview.page++;pl.xvisuals.audio.CustomGuiSounds.play("page");}});
  }

  private boolean hasModuleStatus() { return Set.of("fakeplayer","discord","cinematicsky","dimensionskies","music","skinchanger").contains(selected); }

  private int modulePreviewHeight() {
    return switch(selected) {case "enchantglint"->86;case "hud"->44;case "xp"->34;case "discord"->54;default->0;};
  }

  private int moduleToolsHeight() {
    int height=(selected.equals("custompickaxes")?44:0)+(Set.of("customswords","custompickaxes").contains(selected)?28:0)+(gallerySetting()!=null?DESIGN_GALLERY_HEIGHT:0)+(hasModuleStatus()?18:0)+modulePreviewHeight()+((moduleTools().size()+1)/2)*30;
    return height==0?0:height+8;
  }

  private void drawModuleTools(DrawContext g,VisualConfig.ModuleState m,float x,float y,float w) {
    if(moduleToolsHeight()==0||y>=clipBottom||y+moduleToolsHeight()<=clipTop)return;
    if(selected.equals("custompickaxes")){
      StudioChrome.text(g,"Tool type",x,y+2,Theme.muted());
      final float selectorY=y;
      button(g,m.text("toolSection")+"  ▾",x,y+15,w,22,()->{
        dropdown=null;
        dropdownOffset=0;
      });
      y+=44;
    }
    if(Set.of("customswords","custompickaxes").contains(selected)){
      String[] keys={"shape","textureStyle","skin","textureAnimation"};
      String[] labels={selected.equals("custompickaxes")&&m.text("toolSection").equals("Other tools")?"Item":"Shape","Texture","Palette","Motion"};
      float tabWidth=(w-12)/4;
      for(int i=0;i<keys.length;i++){
        final String key=keys[i];
        button(g,(itemGallery.equals(key)?"• ":"")+labels[i],x+i*(tabWidth+4),y,tabWidth,22,()->{itemGallery=key;previewSetting="";dirty();});
      }
      y+=28;
    }
    if(gallerySetting()!=null){drawDesignCards(g,m,x,y,w);y+=DESIGN_GALLERY_HEIGHT;}
    if(hasModuleStatus()) {
      String status=switch(selected) {
        case "dimensionskies"->pl.xvisuals.rendering.DimensionSkies.status();
        case "cinematicsky"->m.text("preset").equals("Custom Image")?pl.xvisuals.rendering.CustomSkyImage.status():pl.xvisuals.modules.SkyScenes.description(m.text("preset"));
        case "fakeplayer"->pl.xvisuals.modules.combat.FakePlayer.status();
        case "skinchanger"->pl.xvisuals.modules.cosmetics.LocalAppearance.status();
        default->"";
      };
      StudioChrome.text(g,fit(status,(int)w),x,y+2,Theme.muted());y+=18;
    }
    if(selected.equals("enchantglint"))pl.xvisuals.modules.glint.GlintPreview.draw(g,x,y,w);
    if(selected.equals("hud"))pl.xvisuals.hud.HudManager.preview(g,x,y+3);
    if(selected.equals("xp")) {
      double phase=m.flag("animated")&&!cfg().module("performance").text("animation").equals("Off")
          ? System.nanoTime()/1e9*m.number("speed"):0;
      pl.xvisuals.hud.ExperienceBarRenderer.draw(g,(int)x,(int)y+10,.65,m.text("theme"),phase,
          m.flag("custom"),m.color("color"),m.color("secondary"));
    }
    y+=modulePreviewHeight();
    var actions=moduleTools();float buttonWidth=(w-8)/2;
    for(int i=0;i<actions.size();i++) {
      var action=actions.get(i);float bx=x+(i%2)*(buttonWidth+8),by=y+(i/2)*30;
      if(by+24>clipTop&&by<clipBottom)button(g,action.label,
          bx,by,buttonWidth,24,()->runModuleTool(action,bx,by,buttonWidth));
    }
  }

  private void openChild(Screen next) {
    finishEdit();dragging=null;dropdown=null;
    if(worldPanel){pl.xvisuals.gui.world.WorldStudio.close();worldPanel=false;}
    client.setScreen(next);
  }

  private void runModuleTool(ModuleTool action,float x,float y,float width) {
    var m=cfg().module(selected);
    switch(action) {
      case WAYPOINTS -> openChild(new WaypointManagerScreen(this));
      case HANDS -> openChild(new HandPlacementScreen(this));
      case SKIN_IMAGE -> openChild(new SkinImageScreen(this));
      case SKY_IMAGE -> openChild(selected.equals("dimensionskies")?new DimensionSkyImageScreen(this):new SkyImageScreen(this));
      case INDICATOR -> openChild(new AttackIndicatorEditorScreen(this));
      case CROSSHAIR -> openChild(new CrosshairEditorScreen(this));
      case HUD -> openChild(new HudEditorScreen(this));
      case SPAWN -> {m.enabled=true;dirty();pl.xvisuals.modules.combat.FakePlayer.reset();}
      case POP -> pl.xvisuals.modules.combat.FakePlayer.pop();
      case KILL -> pl.xvisuals.modules.combat.FakePlayer.kill();
      case JUMP -> pl.xvisuals.modules.combat.FakePlayer.jump();
      case REMOVE -> {m.enabled=false;dirty();pl.xvisuals.modules.combat.FakePlayer.tick(client);}
      case RECONNECT -> {m.enabled=true;dirty();}
      case PREVIEW -> {
        m.enabled=true;dirty();
        if(selected.equals("totemparticles"))pl.xvisuals.modules.combat.TotemVisuals.preview();
        else if(selected.equals("killanimations")) pl.xvisuals.modules.motion.GhostEffects.previewKill();
        else if(selected.equals("totemghost")||selected.equals("deathghost"))
          pl.xvisuals.modules.motion.GhostEffects.preview(selected.equals("deathghost"));
        else if(client.player!=null)client.gameRenderer.showFloatingItem(new net.minecraft.item.ItemStack(net.minecraft.item.Items.TOTEM_OF_UNDYING));
      }
    }
  }

  private static List<Setting> essentials(ModuleSpec spec) {
    List<String> preferred =
        switch (spec.id()) {
          case "cinematicsky" -> List.of("depth3d", "depth", "veil", "brightness");
          case "pets" -> List.of("size", "distance", "importedVariant", "animated", "sleep");
          case "chinahat" -> List.of("radius", "height", "animated", "speed");
          case "capes" -> List.of("silky", "silkFinish", "color", "secondary");
          case "enchantglint" -> List.of("pattern", "mode", "color", "secondary");
          case "xp" -> List.of("theme", "animated", "speed", "custom");
          case "blocks" -> List.of("mode", "targetStyle", "color", "breakStyle", "breakColor", "breakOpacity");
          case "larp" -> List.of("amount", "size", "radius", "speed");
          case "footsteps" -> List.of("size", "duration", "spacing", "speed");
          case "playertrails" -> List.of("style", "density", "size", "lifetime");
          case "hitfx" -> List.of("style", "critStyle", "color", "criticalColor");
            case "totemparticles" -> List.of("style", "color", "secondary", "amount");
            case "fakeplayer" -> List.of("health", "damage", "totems", "autoRespawn");
          case "music" -> List.of("lyrics", "lyricStyle", "lyricFont", "lyricAnimation", "lyricColor", "lyricColorEnd");
          case "discord" -> List.of("server");
          case "viewmodel" -> List.of("linked", "mainX", "mainY", "mainZ", "offX", "offY", "offZ");
          case "freelook" -> List.of("key", "mode", "selfNametag", "distance", "sensitivity");
          case "crystals" -> List.of("skin", "animated", "customColors", "color", "secondary", "speed");
          default -> List.of("style", "preset", "color", "size", "opacity", "speed", "duration");
        };
    List<Setting> result = new ArrayList<>();
    for (String key : preferred)
      spec.settings().stream()
          .filter(s -> s.key().equals(key))
          .findFirst()
          .ifPresent(
              s -> {
                if (result.size() < 4) result.add(s);
              });
    for (Setting s : spec.settings()) if (result.size() < 4 && !result.contains(s)) result.add(s);
    return result;
  }

  private static String keyLabel(String key) {
    try {
      return InputUtil.fromTranslationKey(key).getLocalizedText().getString();
    } catch (RuntimeException e) {
      return "Choose a key";
    }
  }

  private void setting(
      DrawContext g, VisualConfig.ModuleState m, Setting s, float x, float y, float w) {
    if (inside(x, y, w, 14)) hoverHint = s.label();
    StudioChrome.text(g, fit(s.label(), (int)(w - (s.kind() == Setting.Kind.BOOLEAN ? 40 : 0))), x, y + 2, Theme.muted());
    switch (s.kind()) {
      case BOOLEAN ->
          toggle(
              g,
              x + w - 35,
              y + 7,
              m.flag(s.key()),
              selected + s.key(),
              () -> {
                m.values.put(s.key(), !m.flag(s.key()));
                dirty();
              });
      case NUMBER -> {
        double n = m.number(s.key()), f = (n - s.min()) / (s.max() - s.min());
        float sw = w - 58;
        float sliderHover=anim("slider"+selected+s.key(),inside(x-3,y+14,sw+7,22)||dragging!=null&&dragging.setting==s?1:0);
        StudioChrome.slider(g, x, y, sw, f, sliderHover);
        Glass.rounded(g, x + w - 51, y + 13, 51, 22, 6, 0x5007090D);
        StudioChrome.text(g, format(n), x + w - 46, y + 20, Theme.text());
        hit(
            x - 3,
            y + 14,
            sw + 7,
            22,
            () -> {
              dragging = new Slider(x, sw, s, m);
              setSlider(mx);
            });
        hit(
            x + w - 51,
            y + 12,
            51,
            25,
            () ->
                edit(
                    s.label(),
                    format(n),
                    v -> {
                      try {
                        double value = Double.parseDouble(v);
                        if (!Double.isFinite(value)) throw new NumberFormatException();
                        m.values.put(s.key(), Math.max(s.min(), Math.min(s.max(), value)));
                        dirty();
                      } catch (Exception e) {
                        notice = "Enter a finite number";
                      }
                    }));
      }
      case CHOICE ->
          button(
              g,
              displayName(m.text(s.key())) + "  \u25be",
              x,
              y + 15,
              w,
              22,
              () -> {
                  dropdown =
                      new Dropdown(
                          x,
                          Math.min(y + 39, H - 45 - s.choices().size() * 20),
                          w,
                          s.choices(),
                          v -> {
                            m.values.put(s.key(), v);
                            if(selected.equals("sounds"))pl.xvisuals.audio.CustomGuiSounds.play(s.key());
                            dirty();
                          });
              });
      case COLOR -> {
        Glass.rounded(g, x, y + 19, 14, 14, 6, m.color(s.key()));
        button(
            g,
            "Choose colour",
            x + 23,
            y + 14,
            w - 23,
            23,
            () ->
                editColor(
                    s.label(),
                    m.text(s.key()),
                    v -> {
                      if (v.matches("#?[0-9a-fA-F]{6}")) {
                        m.values.put(s.key(), v.startsWith("#") ? v : "#" + v);
                        if(m==cfg().module("xp"))m.values.put("custom",true);
                        if(m==cfg().module("playertrails"))
                          m.values.put(s.key().startsWith("other")?"otherCustomColors":"customColors",true);
                        if(m==cfg().module("explosionfx")) {
                          if(s.key().equals("secondary"))m.values.put("colorMode","Gradient");
                          else if(s.key().equals("color") && !m.text("colorMode").equals("Gradient"))m.values.put("colorMode","Static");
                          else if(s.key().endsWith("Color"))m.values.put("colorMode","Per-type");
                        }
                        dirty();
                      } else notice = "Use #RRGGBB";
                    }));
      }
      case KEY ->
          button(
              g,
              moduleBinding != null ? "Press a key... (Esc cancels)" : keyLabel(m.text(s.key())),
              x,
              y + 15,
              w,
              22,
              () ->
                  moduleBinding =
                      value -> {
                        m.values.put(s.key(), value);
                        dirty();
                      });
      case TEXT ->
          button(
              g,
              m.text(s.key()).isBlank() ? "Set..." : shorten(m.text(s.key()), 42),
              x,
              y + 15,
              w,
              22,
              () ->
                  edit(
                      s.label(),
                      m.text(s.key()),
                      v -> {
                        m.values.put(s.key(), v);
                        dirty();
                      }));
    }
  }

  private void themes(DrawContext g) {
    StudioChrome.text(g, "Material", 22, 116, Theme.muted());
    button(g,"Font: "+pl.xvisuals.gui.FontSelection.selected(),125,108,250,24,()->{
      dropdownOffset=0;
      dropdown=new Dropdown(125,133,250,pl.xvisuals.gui.FontSelection.NAMES,v->{
        var font=cfg().module("fontchanger");font.values.put("font",v);font.enabled=!v.equals("Classic");dirty();
      });
    });
    button(g,"Appearance: "+cfg().guiAppearance,390,108,210,24,()->{
      cfg().guiAppearance=switch(cfg().guiAppearance){case "Classic"->"Glass";case "Glass"->"Weathered Glass";default->"Classic";};
      dirty();
    });
    for (int i = 0; i < Theme.PRESETS.length; i++) {
      String[] p = Theme.PRESETS[i];
      float x = 19 + (i % 4) * 148, y = 139 + (i / 4) * 56;
      Glass.gradient(g, x, y, 140, 47, 8, Colors.mix(0xFF23272D, Colors.parse(p[1]), .14), Colors.mix(0xFF14171C, Colors.parse(p[2]), .07), "Vertical");
      Glass.dot(g, x + 20, y + 24, 11, Colors.parse(p[1]), 0);
      StudioChrome.text(g, p[0], x + 35, y + 18, Theme.text());
      if (cfg().theme.equals(p[0])) StudioChrome.text(g, "\u2713", x + 123, y + 18, Theme.accent());
      hit(
          x,
          y,
          140,
          47,
          () -> {
            Theme.apply(cfg(), p[0], p[1], p[2]);
            dirty();
          });
    }
    button(
        g,
        "Accent  " + cfg().accent,
        20,
        258,
        186,
        25,
        () -> editColor("Accent colour", cfg().accent, v -> setThemeColor(v, true)));
    button(
        g,
        "Secondary  " + cfg().secondary,
        217,
        258,
        186,
        25,
        () -> editColor("Secondary colour", cfg().secondary, v -> setThemeColor(v, false)));
    button(
        g,
        "Blur  " + (cfg().blur ? "on" : "off"),
        414,
        258,
        186,
        25,
        () -> {
          cfg().blur = !cfg().blur;
          dirty();
        });
    button(g, "Apply theme to visual effects: " + (cfg().themeEffects ? "On" : "Off"), 20, 299, 580, 25, () -> {
      cfg().themeEffects = !cfg().themeEffects;
      if (cfg().themeEffects) Theme.apply(cfg(), cfg().theme, cfg().accent, cfg().secondary);
      dirty();
    });
    StudioChrome.text(g, "Theme colors apply to combat effects.", 23, 338, Theme.muted());
  }

  private void setThemeColor(String v, boolean primary) {
    if (!v.matches("#[0-9a-fA-F]{6}")) {
      notice = "Use #RRGGBB";
      return;
    }
    if (primary) cfg().accent = v;
    else cfg().secondary = v;
    Theme.apply(cfg(), "Custom", cfg().accent, cfg().secondary);
    dirty();
  }

  private void hud(DrawContext g) {
    StudioChrome.text(g, "Overlay", 22, 116, Theme.muted());
    button(
        g, "Edit layout", 485, 109, 114, 24, () -> openChild(new HudEditorScreen(this)));
    int i = 0;
    for (var e : cfg().widgets.entrySet()) {
      String name = e.getKey();
      var state = e.getValue();
      int col = i / 6, row = i % 6;
      float x = 20 + col * 197, y = 140 + row * 25;
      StudioChrome.text(g, name, x + 10, y + 7, Theme.muted());
      toggle(
          g,
          x + 151,
          y + 5,
          pl.xvisuals.hud.HudManager.visible(name, true),
          "hud" + name,
          () -> {
            boolean visible = pl.xvisuals.hud.HudManager.visible(name, true);
            state.enabled = !visible;
            state.hidden = visible;
            if(name.equals("Now Playing")) pl.xvisuals.hud.MusicControls.setEnabled(cfg(),!visible);
            dirty();
          });
      i++;
    }
    hit(
        20,
        298,
        170,
        17,
        () -> {
          selected = "hud";
          scroll = 0;
        });
    StudioChrome.scaled(g, "Colors & gradients...", 30, 301, .8f, Theme.accent());
    hit(
        224,
        298,
        170,
        17,
        () -> {
          selected = "music";
          scroll = 0;
        });
    StudioChrome.scaled(g, "Music & lyrics settings...", 227, 301, .8f, Theme.quiet());
  }

  private void quickLooks(DrawContext g) {
    button(g, "Looks", 326, 107, 78, 23, () -> { lookHotkeys = false; lookColors = false; });
    button(g, "Colours", 412, 107, 86, 23, () -> { lookHotkeys = false; lookColors = true; });
    button(g, "Shortcuts", 506, 107, 92, 23, () -> { lookHotkeys = true; moduleBinding = null; });
    if (lookHotkeys) {
      StudioChrome.text(g, "LOOK SHORTCUTS", 22, 114, Theme.text());
      int i = 0;
      for (var action : QuickLookKeys.Action.values()) {
        float y = 145 + i++ * 31;
        StudioChrome.text(g, action.label, 26, y + 7, Theme.muted());
        button(g, action.binding.getBoundKeyLocalizedText().getString(), 362, y, 174, 25, () -> {
          notice = "Press a key; Delete clears it; Esc cancels";
          moduleBinding = key -> {
            var input = key.equals("key.keyboard.delete") || key.equals("key.keyboard.backspace")
                ? InputUtil.UNKNOWN_KEY : InputUtil.fromTranslationKey(key);
            action.binding.setBoundKey(input);
            KeyBinding.updateKeysByCode(); client.options.write();
            notice = "Shortcut saved: " + action.label;
          };
        });
        button(g, "Clear", 544, y, 54, 25, () -> {
          action.binding.setBoundKey(InputUtil.UNKNOWN_KEY);
          KeyBinding.updateKeysByCode(); client.options.write(); notice = "Shortcut cleared";
        });
      }
      StudioChrome.scaled(g, "Colour keys use the selected group and Solid / Gradient mode.", 24, 340, .8f, Theme.muted());
      return;
    }
    if (!lookColors) {
      StudioChrome.text(g, "Choose a look", 22, 114, Theme.text());
      StudioChrome.scaled(g, "Changes modules and colours. HUD layout and sizes stay unchanged.", 23, 139, .8f, Theme.quiet());
      for (int i = 0; i < QuickLooks.PRESETS.size(); i++) {
        String name = QuickLooks.PRESETS.get(i); float y = 157 + i * 31;
        StudioChrome.scaled(g, name, 29, y + 9, .9f, Theme.text());
        if(inside(24,y,330,25)) hoverHint=QuickLooks.caption(name);
        button(g, "Apply look", 486, y + 2, 104, 24,
            () -> attempt(() -> XVisuals.STORE.loadQuickPreset(name)));
        g.fill(24, (int)y + 29, 596, (int)y + 30, 0x162F3748);
      }
      if (XVisuals.STORE.canUndoQuick()) button(g, "Undo last change", 438, 353, 160, 23,
          () -> attempt(() -> XVisuals.STORE.undoQuick()));
      return;
    }
    StudioChrome.text(g, "Colour & intensity", 22, 114, Theme.text());
    StudioChrome.text(g, "Choose effects and colors", 23, 145, Theme.muted());
    StudioChrome.scaled(g, "EFFECT COLOURS", 23, 205, .8f, Theme.quiet());
    button(g, cfg().lookScope + "  \u25be", 404, 192, 194, 23, () ->
        dropdown = new Dropdown(404, 219, 194, QuickLooks.SCOPES, v -> { cfg().lookScope = v; dirty(); }));
    for (int i = 0; i < QuickLooks.PALETTES.size(); i++) {
      int index = i; var palette = QuickLooks.PALETTES.get(i); float x = 20 + i * 84;
      Glass.gradient(g, x, 224, 78, 3, 1, Colors.parse(palette.primary()), Colors.parse(palette.secondary()), "Horizontal");
      button(g, palette.name(), x, 229, 78, 23, () -> {
        attempt(() -> XVisuals.STORE.applyQuickColors(palette.primary(), palette.secondary()));
        cfg().lookPalette = index; dirty();
      });
    }
    button(g, cfg().lookMode + "  \u25be", 20, 262, 110, 26, () ->
        dropdown = new Dropdown(20, 292, 130, List.of("Solid", "Gradient"), v -> { cfg().lookMode = v; dirty(); }));
    button(g, "Primary colour", 140, 262, 124, 26, () ->
        editColor("Primary colour", cfg().lookPrimary, v -> setLookColor(v, true)));
    button(g, "Secondary colour", 274, 262, 124, 26, () ->
        editColor("Secondary colour", cfg().lookSecondary, v -> setLookColor(v, false)));
    button(g, "Apply custom colours", 408, 262, 190, 26, () ->
        attempt(() -> XVisuals.STORE.applyQuickColors(cfg().lookPrimary, cfg().lookSecondary)));
    StudioChrome.scaled(g, "INTENSITY", 23, 307, .8f, Theme.quiet());
    String[] levels = {"Subtle", "Balanced", "Vivid"};
    for (int i = 0; i < levels.length; i++) {
      String level = levels[i];
      button(g, level, 112 + i * 112, 299, 102, 24, () -> attempt(() -> XVisuals.STORE.quickIntensity(level)));
    }
    button(g, XVisuals.STORE.canUndoQuick() ? "Undo bulk change" : "Nothing to undo", 460, 299, 138, 24,
        () -> attempt(() -> XVisuals.STORE.undoQuick()));
  }

  private ConfigLibraryScreen configLibrary;
  private Screen configContent;
  boolean configsActive(){return tab.equals("Configs");}
  boolean isConfigPage(Screen page){return client.currentScreen==this&&configsActive()&&configContent==page;}
  void leaveConfigs(){if(configContent!=null)configContent.removed();tab="Visuals";}
  private void openConfigs(String module){
    finishEdit();selected="";expandedInspector=false;dropdown=null;tab="Configs";
    if(configContent!=null)configContent.removed();
    configLibrary=module.isEmpty()?new ConfigLibraryScreen(this):new ConfigLibraryScreen(this,module);
    configLibrary.embed(this);showConfigPage(configLibrary);
  }
  void showConfigPage(Screen screen){
    if(screen==this){leaveConfigs();return;}
    if(configContent!=null&&configContent!=screen)configContent.removed();
    configContent=screen;
    if(screen instanceof ConfigChoiceScreen choice)choice.host=this;
    screen.init(W-36,Math.max(240,windowHeight()-148));
  }
  private void localConfigs(DrawContext g) {
    if(configContent==null){configLibrary=new ConfigLibraryScreen(this);configLibrary.embed(this);showConfigPage(configLibrary);}
    int cw=W-36,ch=Math.max(240,windowHeight()-148);
    if(configContent.width!=cw||configContent.height!=ch)configContent.init(cw,ch);
    g.getMatrices().pushMatrix();g.getMatrices().translate(18,104);
    configContent.render(g,(int)(mx-18),(int)(my-104),0);
    g.getMatrices().popMatrix();
  }
  private Click configClick(Click c){return new Click((c.x()-ox)/scale-18,(c.y()-oy)/scale-104,c.buttonInfo());}
  @Override public void tick(){if(configsActive()&&configContent!=null)configContent.tick();}

  private void setLookColor(String value, boolean primary) {
    if (!value.startsWith("#")) value = "#" + value;
    if (!QuickLooks.validColor(value)) { notice = "Use a six-digit colour, e.g. #9EFF54"; return; }
    if (primary) cfg().lookPrimary = value.toUpperCase(Locale.ROOT);
    else cfg().lookSecondary = value.toUpperCase(Locale.ROOT);
    dirty(); notice = "Custom colour saved; press Apply or your shortcut";
  }

  private void author(DrawContext g) {
    StudioChrome.scaled(g, "Autor", 22, 112, 1.5f, Theme.text());
    StudioChrome.text(g, "Twórca X Visuals", 22, 134, Theme.muted());
    String[][] rows = {{"Autor", "HeyLittleBrother"}, {"TikTok", "uzzi.ae"}, {"Discord", "uzzi.ae"}};
    for (int i = 0; i < rows.length; i++) {
      float y = 158 + i * 58;
      glassSurface(g, 20, y, 581, 48, 10, .8, false);
      Glass.logo(g, 46, y + 24, 12, Theme.accent());
      StudioChrome.text(g, rows[i][0], 72, y + 10, Theme.muted());
      StudioChrome.scaled(g, rows[i][1], 72, y + 24, 1.25f, Theme.text());
    }
  }

  private void setup(DrawContext g) {
    StudioChrome.text(g, "Preferences", 22, 116, Theme.muted());
    button(g, "Custom Sounds", 318, 318, 281, 28, () -> {
      selected = "sounds"; scroll = 0;
    });
    button(
        g,
        binding
            ? "Press a key..."
            : "Shortcut  /  " + XVisuals.OPEN.getBoundKeyLocalizedText().getString(),
        20,
        139,
        281,
        28,
        () -> binding = true);
    button(
        g,
        "Performance  /  " + cfg().module("performance").text("quality"),
        318,
        139,
        281,
        28,
        () -> {
          selected = "performance";
          scroll = 0;
        });
    button(
        g,
        "Menu appearance",
        20,
        177,
        281,
        28,
        () -> {
          selected = "menu";
          scroll = 0;
        });
    button(
        g,
        "Config folder",
        318,
        177,
        281,
        28,
        () ->
            net.minecraft.util.Util.getOperatingSystem()
                .open(XVisuals.STORE.root().toFile()));
    StudioChrome.scaled(g, "PROFILE", 23, 220, .8f, Theme.quiet());
    button(
        g,
        "Duplicate",
        20,
        237,
        136,
        26,
        () ->
            edit("Profile name", "Custom", v -> attempt(() -> XVisuals.STORE.duplicate(v))));
    button(
        g,
        "Rename",
        167,
        237,
        136,
        26,
        () ->
            edit(
                "Rename profile",
                XVisuals.STORE.activeProfile,
                v -> attempt(() -> XVisuals.STORE.rename(v))));
    button(
        g,
        "Copy config",
        315,
        237,
        136,
        26,
        () -> {
          client.keyboard.setClipboard(XVisuals.STORE.exportText());
          notice = "Copied! Paste into a text file and send it to your friend.";
        });
    button(
        g,
        "Paste config",
        462,
        237,
        136,
        26,
        () -> attempt(() -> XVisuals.STORE.importText(client.keyboard.getClipboard())));
    StudioChrome.scaled(g, "Share: Copy config, then send the full text. Load: copy that text, then Paste config.", 23, 266, .65f, Theme.quiet());
    button(
        g,
        "GUI scale  /  " + Math.round(cfg().guiScale * 100) + "%",
        175,
        279,
        265,
        22,
        () ->
            edit(
                "GUI scale (65\u2013150%)",
                Long.toString(Math.round(cfg().guiScale * 100)),
                v -> {
                  try {
                    double value = Double.parseDouble(v);
                    if (!Double.isFinite(value)) return;
                    cfg().guiScale = Math.max(.65, Math.min(1.5, value / 100));
                    dirty();
                  } catch (NumberFormatException ignored) {
                    notice = "Enter a number from 65 to 150";
                  }
                }));
    button(
        g,
        "Delete profile",
        20,
        279,
        136,
        22,
        () ->
            dropdown =
                new Dropdown(
                    20,
                    220,
                    220,
                    List.of("Cancel", "Delete current profile"),
                    v -> {
                      if (v.startsWith("Delete")) attempt(() -> XVisuals.STORE.delete());
                    }));
    button(
        g,
        "Reset visuals",
        462,
        279,
        136,
        22,
        () ->
            dropdown =
                new Dropdown(
                    378,
                    220,
                    220,
                    List.of("Cancel", "Reset all visuals"),
                    v -> {
                      if (v.startsWith("Reset")) {
                        XVisuals.STORE.resetAll();
                        notice = "Visuals reset";
                      }
                    }));
  }

  private interface Operation {
    void run() throws Exception;
  }

  private void attempt(Operation action) {
    try {
      action.run();
      notice = XVisuals.STORE.message;
    } catch (Exception e) {
      notice = e.getMessage();
    }
  }

  private float anim(String id, double target) {
    var spring=animations.computeIfAbsent(id, k -> new Spring(target));
    return cfg().module("performance").text("animation").equals("Off") ? spring.snap(target) : spring.to(target);
  }

  private boolean fullMotion() { return cfg().module("performance").text("animation").equals("Full"); }

  private void favoriteIcon(DrawContext g,float x,float y,float size,boolean favorite,String id) {
    float hover=anim(id+"Hover",inside(x-4,y-4,size+8,size+8)?1:0);
    float extra=fullMotion()?hover*1.5f:0;
    if(favorite){
      Glass.rounded(g,x-4,y-4,size+8,size+8,5,Colors.alpha(Theme.accent(),.25));
      StudioIcons.filledStar(g,x-extra/2,y-extra/2,size+extra,Colors.mix(Theme.accent(),0xFFFFFFFF,.25));
    }else StudioIcons.draw(g,"star",x-extra/2,y-extra/2,size+extra,0xFF929BA9);
    if(inside(x-4,y-4,size+8,size+8))hoverHint=favorite?"Starred \u2014 click to remove":"Not starred \u2014 click to star";
  }

  private boolean inside(double x, double y, double w, double h) {
    return Glass.contains(mx, my, x, y, w, h);
  }

  private void toggle(DrawContext g, float x, float y, boolean on, String id, Runnable action) {
    float a = anim(id, on ? 1 : 0);
    StudioChrome.toggle(g, x, y, a);
    hit(x - 3, y - 5, 33, 24, action);
  }

  private void glassSurface(DrawContext g,float x,float y,float w,float h,float radius,double opacity,boolean accent) {
    StudioChrome.surface(g,x,y,w,h,radius,opacity,accent);
  }

  private void iconButton(DrawContext g,String icon,float x,float y,float size,Runnable action) {
    float hover=anim("control"+controlIndex++,inside(x,y,size,size)?1:0);
    glassSurface(g,x,y,size,size,8,.35+.29*hover,false);
    StudioIcons.draw(g,icon,x+6,y+6,size-12,Colors.mix(Theme.muted(),Theme.text(),hover));hit(x,y,size,size,action);
  }

  private static String fitLabel(String label, float width) {
    if (Glass.textWidth(label) <= width) return label;
    String suffix = "\u2026";
    int end = label.length();
    while (end > 0 && Glass.textWidth(label.substring(0, end) + suffix) > width)
      end = label.offsetByCodePoints(end, -1);
    return label.substring(0, end) + suffix;
  }

  private void button(
      DrawContext g, String label, float x, float y, float w, float h, Runnable action) {
    float hover = anim("control"+controlIndex++,inside(x,y,w,h)?1:0);
    glassSurface(g,x,y,w,h,7,.42+.24*hover,false);
    StudioChrome.center(g, fitLabel(label,Math.max(0,w-16)), x + w / 2, y + (h - 9) / 2, Theme.text());
    hit(x, y, w, h, action);
  }

  private void hit(double x, double y, double w, double h, Runnable action) {
    if (clippingSettings) {
      double bottom = Math.min(clipBottom, y + h);
      y = Math.max(clipTop, y);
      h = bottom - y;
      if (h <= 0) return;
    }
    float dx=contentX,dy=contentY;
    Runnable positioned=action;
    if(dx!=0 || dy!=0)positioned=()->{
      Dropdown before=dropdown;action.run();
      if(dropdown!=null && dropdown!=before) {
        var d=dropdown;dropdown=new Dropdown(d.x+dx,d.y+dy,d.width,d.choices,d.action);
      }
    };
    hits.add(new Hit(x+dx, y+dy, w, h, positioned));
  }

  private void editColor(String name, String value, Consumer<String> setter) {
    edit(name, value, setter);
    colourPicker = new ColourPicker(value);
  }

  private void edit(String name, String value, Consumer<String> setter) {
    colourPicker = null;
    editing = name;
    searchDisplayWidth = -1;
    buffer = value;
    commit = setter;
    dropdown = null;
  }

  private void finishEdit() {
    if (colourPicker != null) buffer = colourPicker.hex();
    colourPicker = null;
    if (commit != null) commit.accept(buffer);
    commit = null;
    editing = "";
  }

  private void drawDropdown(DrawContext g) {
    var d = dropdown;
    if (d != lastDropdown) {
      dropdownOffset = 0;
      lastDropdown = d;
    }
    float h = Math.min(320, d.choices.size() * 20 + 8), y = dropdownY(d, h), x = dropdownX(d);
    g.fill(0, 0, W, H, 0x42040810);
    glassSurface(g, x, y, d.width, h, 4, .98, false);
    for (int i = 0; i + dropdownOffset < d.choices.size() && i < 15; i++) {
      float sy = y + 4 + i * 20;
      if (inside(x + 4, sy, d.width - 8, 20))
        Glass.rounded(g, x + 4, sy, d.width - 8, 20, 6, Colors.alpha(Theme.accent(), .18));
      String label=displayName(d.choices.get(i+dropdownOffset));
      if(d.choices.equals(pl.xvisuals.gui.FontSelection.NAMES)){
        var sample=Text.literal(label).setStyle(net.minecraft.text.Style.EMPTY.withFont(pl.xvisuals.gui.FontSelection.preview(label)));
        var renderer=net.minecraft.client.MinecraftClient.getInstance().textRenderer;
        float fit=Math.min(1,(d.width-24)/Math.max(1,renderer.getWidth(sample)));
        g.getMatrices().pushMatrix();
        try{g.getMatrices().translate(x+12,sy+6);g.getMatrices().scale(fit,fit);g.drawText(renderer,sample,0,0,Theme.text(),false);}
        finally{g.getMatrices().popMatrix();}
      }else StudioChrome.text(g,label,x+12,sy+6,Theme.text());
    }
    if (d.choices.size() > 15) {
      float thumb=(h-8)*15/d.choices.size();
      Glass.rounded(g,x+d.width-4,y+4+(h-8-thumb)*dropdownOffset/(d.choices.size()-15f),2,thumb,1,Theme.muted());
    }
  }

  private float dropdownX(Dropdown d) {
    float left = (8 - ox) / scale, right = (width - 8 - ox) / scale - d.width;
    return Math.max(left, Math.min(Math.max(left, right), d.x));
  }

  private float dropdownY(Dropdown d, float h) {
    float top = (8 - oy) / scale, bottom = (height - 8 - oy) / scale - h;
    return Math.max(top, Math.min(Math.max(top, bottom), d.y));
  }

  private void drawEditor(DrawContext g) {
    if (colourPicker != null) { colourPicker.draw(g, editing); return; }
    g.fill(0, 0, W, H, 0xA0060A10);
    glassSurface(g, 118, 108, 384, 135, 7, .98, false);
    StudioChrome.text(g, editing, 136, 125, Theme.text());
    Glass.rounded(g, 135, 149, 350, 29, 8, 0xFF111419);
    StudioChrome.text(g, shorten(buffer, 48) + "|", 144, 159, Theme.text());
    StudioChrome.scaled(
        g, "Enter to apply \u00b7 Esc to cancel \u00b7 Ctrl+V to paste", 137, 192, .83f, Theme.muted());
    if (editing.toLowerCase(Locale.ROOT).contains("color"))
      for (int i = 0; i < 12; i++)
        Glass.rounded(g, 139 + i * 28, 218, 20, 12, 4, Colors.rainbow(i / 12.0));
  }

  @Override
  public boolean mouseClicked(Click c, boolean twice) {
    mx = (c.x() - ox) / scale;
    my = (c.y() - oy) / scale;
    if(configsActive()&&configContent!=null&&inside(18,104,W-36,windowHeight()-148))return configContent.mouseClicked(configClick(c),twice);
    if (c.button() == GLFW.GLFW_MOUSE_BUTTON_RIGHT) {
      if (!workspace() || expandedInspector || (!docked() && !selected.isEmpty()) || dropdown != null || (!editing.isEmpty() && !editing.equals("Search"))) return true;
      for (var h : moduleSettings) if (inside(h.x,h.y,h.w,h.h)) {
        runAction(h.action);
        return true;
      }
      return true;
    }
    if (c.button() != GLFW.GLFW_MOUSE_BUTTON_LEFT) return false;
    if (!editing.isEmpty() && !editing.equals("Search")) {
      if (colourPicker != null) {
        if (inside(365, 307, 110, 26)) finishEdit();
        else if (inside(245, 307, 110, 26)) { colourPicker = null; editing = ""; commit = null; }
        else colourPicker.press(mx, my);
      }
      return true;
    }
    if (dropdown != null) {
      var d = dropdown;
      float h = Math.min(320, d.choices.size() * 20 + 8), y = dropdownY(d, h), x = dropdownX(d);
      int i = (int) ((my - y - 4) / 20);
      dropdown = null;
      if (inside(x, y + 4, d.width, h - 8) && i >= 0 && i < d.choices.size() && i < 15)
        runAction(() -> d.action.accept(d.choices.get(i + dropdownOffset)));
      return true;
    }
    if (editing.equals("Search") && !inside(layout.searchX(),layout.searchY(),layout.searchWidth(),24)) finishEdit();
    if ((!docked() || expandedInspector) && !selected.isEmpty() && !inside(popupX(), popupY(), POPUP_W, POPUP_H)) {
      dismissInspector();
      return true;
    }
    if ((!docked() || expandedInspector) && !selected.isEmpty() && inside(popupX() + 43, popupY() + 5, POPUP_W - 139, 31)) {
      finishEdit();
      dragging = null;
      if (twice) {
        cfg().popupX = cfg().popupY = .5;
        movingPopup = false;
        dirty();
      } else {
        movingPopup = true;
        grabX = c.x() - (ox + popupX() * scale);
        grabY = c.y() - (oy + popupY() * scale);
      }
      return true;
    }
    if (titleDraggable() && inside(0, 0, W - 194, 54)) {
      finishEdit();
      if (twice) {
        cfg().studioX = .5;
        cfg().studioY = .5;
        dirty();
      } else {
        movingWindow = true;
        grabX = c.x() - ox;
        grabY = c.y() - oy;
      }
      return true;
    }
    for (int i = hits.size() - 1; i >= 0; i--) {
      var h = hits.get(i);
      if (inside(h.x, h.y, h.w, h.h)) {
        runAction(h.action);
        return true;
      }
    }
    return true;
  }

  private void setSlider(double x) {
    if (dragging == null) return;
    var d = dragging;
    double f = Math.max(0, Math.min(1, (x - d.x) / d.width)),
        v = d.setting.min() + f * (d.setting.max() - d.setting.min());
    v = Math.round(v / d.setting.step()) * d.setting.step();
    d.state.values.put(d.setting.key(), Math.max(d.setting.min(), Math.min(d.setting.max(), v)));
    dirty();
  }

  @Override
  public boolean mouseDragged(Click c, double dx, double dy) {
    if(configsActive()&&configContent!=null&&!movingWindow)return configContent.mouseDragged(configClick(c),dx/scale,dy/scale);
    if (colourPicker != null) { colourPicker.drag((c.x()-ox)/scale, (c.y()-oy)/scale); return true; }
    if (movingPopup) {
      cfg().popupX = Math.clamp((c.x() - grabX - 8) / Math.max(1, width - POPUP_W * scale - 16), 0, 1);
      cfg().popupY = Math.clamp((c.y() - grabY - 8) / Math.max(1, height - POPUP_H * scale - 16), 0, 1);
      dirty();
      return true;
    }
    if (movingWindow) {
      cfg().studioX =
          Math.max(0, Math.min(1, (c.x() - grabX) / Math.max(1, width - W * scale)));
      cfg().studioY =
          Math.max(0, Math.min(1, (c.y() - grabY) / Math.max(1, height - H * scale)));
      dirty();
      return true;
    }
    if (dragging != null) {
      setSlider((c.x() - ox) / scale);
      return true;
    }
    return false;
  }

  @Override
  public boolean mouseReleased(Click c) {
    if(configsActive()&&configContent!=null)configContent.mouseReleased(configClick(c));
    if (colourPicker != null) colourPicker.release();
    dragging = null;
    movingWindow = false;
    movingPopup = false;
    return true;
  }

  @Override
  public boolean mouseScrolled(double x, double y, double hx, double dy) {
    if(configsActive()&&configContent!=null)return configContent.mouseScrolled((x-ox)/scale-18,(y-oy)/scale-104,hx,dy);
    if (!editing.isEmpty() && !editing.equals("Search")) return true;
    if (dropdown != null) {
      dropdownOffset =
          Math.max(
              0,
              Math.min(
                  Math.max(0, dropdown.choices.size() - 15),
                  dropdownOffset - (int) Math.signum(dy)));
      return true;
    }
    if (workspace() && !expandedInspector && x>=ox && x<ox+catalogWidth()*scale && y>=oy+110*scale && y<oy+(H-40)*scale) { page = Math.max(0, page + (dy < 0 ? 1 : -1)); return true; }
    if (!selected.isEmpty()) {
      double px = ox + popupX() * scale, py = oy + popupY() * scale;
      int panelWidth=workspace() && !expandedInspector?layout.inspectorWidth():POPUP_W;
      if (x < px || x > px + panelWidth * scale || y < py || y > py + POPUP_H * scale) return false;
    } else if (x < ox || x > ox + W * scale || y < oy || y > oy + H * scale) return false;
    if (!selected.isEmpty()) scroll = Math.max(0, Math.min(maxScroll, scroll - dy * 30));
    else if (tab.equals("Visuals") || tab.equals("World") || tab.equals("Environment FX"))
      page = Math.max(0, page + (dy < 0 ? 1 : -1));
    return true;
  }

  @Override
  public boolean charTyped(CharInput c) {
    if(configsActive()&&configContent!=null)return configContent.charTyped(c);
    if (colourPicker != null) return true;
    if (!editing.isEmpty() && c.isValidChar() && buffer.length() < 2048) {
      buffer += c.asString();
      if (editing.equals("Search")) {
        search = buffer;
        page = 0;
        searchCaretEpoch=System.nanoTime();
      }
      return true;
    }
    return false;
  }

  @Override
  public boolean keyPressed(KeyInput k) {
    if(configsActive()&&configContent!=null)return configContent.keyPressed(k);
    if (moduleBinding != null) {
      if (k.key() != org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE)
        moduleBinding.accept(
            net.minecraft.client.util.InputUtil.Type.KEYSYM
                .createFromCode(k.key())
                .getTranslationKey());
      moduleBinding = null;
      return true;
    }
    if (binding) {
      binding = false;
      if (k.key() != GLFW.GLFW_KEY_ESCAPE) {
        XVisuals.OPEN.setBoundKey(InputUtil.Type.KEYSYM.createFromCode(k.key()));
        KeyBinding.updateKeysByCode();
        client.options.write();
        notice = "Shortcut saved";
      }
      return true;
    }
    if(workspace()&&!expandedInspector&&dropdown==null&&(editing.isEmpty()||editing.equals("Search"))
        &&k.key()==GLFW.GLFW_KEY_F&&(k.modifiers()&GLFW.GLFW_MOD_CONTROL)!=0) {
      beginSearch();return true;
    }
    if (!editing.isEmpty()) {
      if (k.key() == GLFW.GLFW_KEY_ESCAPE) {
        if(editing.equals("Search")){finishEdit();close();return true;}
        colourPicker = null;
        editing = "";
        commit = null;
        return true;
      }
      if (k.key() == GLFW.GLFW_KEY_ENTER) {
        finishEdit();
        return true;
      }
      if (colourPicker != null) return true;
      if (k.key() == GLFW.GLFW_KEY_BACKSPACE && !buffer.isEmpty())
        buffer = buffer.substring(0, buffer.offsetByCodePoints(buffer.length(), -1));
      if ((k.modifiers() & GLFW.GLFW_MOD_CONTROL) != 0 && k.key() == GLFW.GLFW_KEY_A) buffer = "";
      if ((k.modifiers() & GLFW.GLFW_MOD_CONTROL) != 0 && k.key() == GLFW.GLFW_KEY_V) {
        String paste = client.keyboard.getClipboard();
        buffer = paste.substring(0, Math.min(2048, paste.length()));
      }
      if (editing.equals("Search")) {
        search = buffer;
        page = 0;
        searchCaretEpoch=System.nanoTime();
      }
      return true;
    }
    if (k.key() == GLFW.GLFW_KEY_ESCAPE) {
      if (dropdown != null) {
        dropdown = null;
        return true;
      }
      close();return true;
    }
    if (k.key() == GLFW.GLFW_KEY_TAB) {
      focus = (focus + 1) % Math.max(1, hits.size());
      return true;
    }
    if (k.key() == GLFW.GLFW_KEY_ENTER && focus >= 0 && focus < hits.size()) {
      runAction(hits.get(focus).action);
      return true;
    }
    if (XVisuals.OPEN.matchesKey(k)) {
      close();
      return true;
    }
    return super.keyPressed(k);
  }

  @Override
  public void onFilesDropped(List<java.nio.file.Path> files) {
    if(configsActive()&&configContent!=null){configContent.onFilesDropped(files);return;}
    if(selected.equals("dimensionskies")) {var screen=new DimensionSkyImageScreen(this);openChild(screen);screen.load(files);return;}
    if(selected.equals("cinematicsky") && files.size()==1 && files.getFirst().toString().toLowerCase(Locale.ROOT).matches(".*\\.(png|jpe?g)$")) {
      var screen=new SkyImageScreen(this);openChild(screen);screen.load(files.getFirst());return;
    }

    if (files.size() == 1)
      attempt(
          () -> {
            var p = files.getFirst();
            if (java.nio.file.Files.size(p) > 1_048_576)
              throw new IllegalArgumentException("Profile exceeds 1 MB");
            XVisuals.STORE.importText(java.nio.file.Files.readString(p));
          });
  }

  private static String format(double v) {
    return Math.abs(v - Math.round(v)) < .001
        ? Long.toString(Math.round(v))
        : String.format(Locale.ROOT, "%.2f", v);
  }

  private static String shorten(String s, int n) {
    return s.length() > n ? s.substring(0, n - 1) + "\u2026" : s;
  }

  private static String displayName(String value) {
    return value.startsWith("Imported ")?value.substring("Imported ".length()):value;
  }

  private static String fit(String text, int pixels) {
    if (Glass.textWidth(text) <= pixels) return text;
    while (!text.isEmpty() && Glass.textWidth(text + "\u2026") > pixels)
      text = text.substring(0, text.offsetByCodePoints(text.length(), -1));
    return text + "\u2026";
  }
}


