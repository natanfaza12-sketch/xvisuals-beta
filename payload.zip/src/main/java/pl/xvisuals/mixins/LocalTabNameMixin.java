package pl.xvisuals.mixins;
import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.cosmetics.LocalAppearance;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerListHud.class)
public abstract class LocalTabNameMixin {
  @com.llamalad7.mixinextras.injector.ModifyExpressionValue(method="render",at=@At(value="FIELD",target="Lnet/minecraft/client/gui/hud/PlayerListHud;header:Lnet/minecraft/text/Text;"))
  private Text visuals$header(Text text){return LocalAppearance.protectText(text);}
  @com.llamalad7.mixinextras.injector.ModifyExpressionValue(method="render",at=@At(value="FIELD",target="Lnet/minecraft/client/gui/hud/PlayerListHud;footer:Lnet/minecraft/text/Text;"))
  private Text visuals$footer(Text text){return LocalAppearance.protectText(text);}
  @Inject(method="getPlayerName",at=@At("RETURN"),cancellable=true)
  private void visuals$localTabName(PlayerListEntry entry,CallbackInfoReturnable<Text> cir){
    var player=MinecraftClient.getInstance().player;
    if(XVisuals.ready()&&player!=null&&player.getUuid().equals(entry.getProfile().id()))
      cir.setReturnValue(LocalAppearance.displayName(cir.getReturnValue(),entry.getProfile().name()));
  }
}
