package pl.xvisuals.mixins;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(InGameHud.class)
public class PetDeathHudMixin {
 @Inject(method="render",at=@At("HEAD"),cancellable=true)
 private void visuals$petCinematic(CallbackInfo ci){if(pl.xvisuals.modules.pets.PetDeathScene.active()||net.minecraft.client.MinecraftClient.getInstance().currentScreen instanceof pl.xvisuals.gui.screens.HandPlacementScreen)ci.cancel();}
}
