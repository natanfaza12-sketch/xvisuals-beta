package pl.xvisuals.mixins;
import net.minecraft.client.Keyboard;
import net.minecraft.client.input.KeyInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(Keyboard.class)
public abstract class CreamyKeysMixin {
  @Inject(method="onKey",at=@At("HEAD"))
  private void visuals$creamyKeys(long window,int action,KeyInput input,CallbackInfo ci) {
    pl.xvisuals.audio.CreamyKeys.key(window,action,input);
  }
}
