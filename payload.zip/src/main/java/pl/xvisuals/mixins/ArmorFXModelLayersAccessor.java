package pl.xvisuals.mixins;
import net.minecraft.client.render.entity.model.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
@Mixin(EntityModelLayers.class)
public interface ArmorFXModelLayersAccessor {
 // Yarn 1.21.11 has two PLAYER_SLIM fields; the return descriptor selects equipment, not the skin layer.
 @Accessor("PLAYER_SLIM") static EquipmentModelData<EntityModelLayer> armorfx$slim(){throw new AssertionError();}
}
