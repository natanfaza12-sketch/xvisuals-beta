package pl.xvisuals.mixins;
import pl.xvisuals.modules.pets.PetDeathScene;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(value=Camera.class,priority=800)
public abstract class PetDeathCameraMixin {
 @Shadow protected abstract void setRotation(float yaw,float pitch);
 @Shadow protected abstract void setPos(Vec3d pos);
 @Inject(method="update",at=@At("TAIL"))
 private void visuals$petCamera(World world,Entity entity,boolean third,boolean inverse,float tick,CallbackInfo ci){
  if(!PetDeathScene.active())return;
  var eye=PetDeathScene.eye();var d=PetDeathScene.focus().subtract(eye);setPos(eye);
  setRotation((float)Math.toDegrees(Math.atan2(-d.x,d.z)),(float)-Math.toDegrees(Math.atan2(d.y,Math.hypot(d.x,d.z))));
 }
}
