package pl.xvisuals.mixins;

import java.util.List;
import net.minecraft.client.gl.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(PostEffectProcessor.class)
public interface PostProcessorAccessor {
  @Accessor("passes")
  List<PostEffectPass> visuals$passes();
}
