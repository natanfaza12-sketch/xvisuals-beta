package pl.xvisuals.mixins;

import net.minecraft.client.render.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(RenderLayer.class)
public interface RenderLayerAccessor {
  @Invoker("of")
  static RenderLayer visuals$of(String name, RenderSetup setup) {
    throw new AssertionError();
  }

  @Accessor("renderSetup")
  RenderSetup visuals$setup();
}
