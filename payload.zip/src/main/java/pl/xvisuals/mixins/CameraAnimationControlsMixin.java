package pl.xvisuals.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import pl.xvisuals.modules.motion.CameraAnimations;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public abstract class CameraAnimationControlsMixin {
  @Inject(method="render",at=@At("HEAD"))
  private void visuals$frame(CallbackInfo ci){CameraAnimations.frame();}
  @ModifyArg(method="tiltViewWhenHurt",at=@At(value="INVOKE",target="Lnet/minecraft/util/math/RotationAxis;rotationDegrees(F)Lorg/joml/Quaternionf;",ordinal=2))
  private float visuals$hurt(float value){return value*(float)CameraAnimations.value("hurtTilt",1);}
  @ModifyExpressionValue(method="bobView",at=@At(value="INVOKE",target="Lnet/minecraft/client/network/ClientPlayerLikeState;lerpMovement(F)F"))
  private float visuals$bob(float value){return value*(float)CameraAnimations.value("bob",1);}
  @Inject(method="tiltViewWhenHurt",at=@At("RETURN"))
  private void visuals$jump(MatrixStack matrices,float tick,CallbackInfo ci){CameraAnimations.apply(matrices);}
}
