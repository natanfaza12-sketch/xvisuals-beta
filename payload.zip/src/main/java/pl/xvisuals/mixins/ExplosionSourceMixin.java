package pl.xvisuals.mixins;

import pl.xvisuals.modules.explosion.ExplosionSources;
import pl.xvisuals.XVisuals;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;

@Mixin(ClientWorld.class)
public abstract class ExplosionSourceMixin {
  @Inject(method="handleBlockUpdate",at=@At("HEAD"))
  private void visuals$serverBlock(BlockPos pos,BlockState state,int flags,CallbackInfo ci) {
    pl.xvisuals.modules.explosion.AnchorEffects.block(pos,((ClientWorld)(Object)this).getBlockState(pos),state);
    if(XVisuals.config().on("explosionfx"))ExplosionSources.block(pos,((ClientWorld)(Object)this).getBlockState(pos),state);
  }
  @Inject(method="removeEntity",at=@At("HEAD"))
  private void visuals$removed(int id,Entity.RemovalReason reason,CallbackInfo ci) {
    if(XVisuals.config().on("explosionfx"))ExplosionSources.removed(((ClientWorld)(Object)this).getEntityById(id));
  }
  @Inject(method="setBlockState(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/BlockState;II)Z",at=@At("HEAD"))
  private void visuals$block(BlockPos pos,BlockState state,int flags,int depth,CallbackInfoReturnable<Boolean> ci) {
    pl.xvisuals.modules.explosion.AnchorEffects.block(pos,((ClientWorld)(Object)this).getBlockState(pos),state);
    if(XVisuals.config().on("explosionfx"))ExplosionSources.block(pos,((ClientWorld)(Object)this).getBlockState(pos),state);
  }
}
