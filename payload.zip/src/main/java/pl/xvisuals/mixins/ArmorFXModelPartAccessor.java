package pl.xvisuals.mixins;
import net.minecraft.client.model.ModelPart;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import java.util.*;
@Mixin(ModelPart.class)
public interface ArmorFXModelPartAccessor {
 @Accessor("cuboids") List<ModelPart.Cuboid> armorfx$cuboids();
 @Accessor("children") Map<String,ModelPart> armorfx$children();
}
