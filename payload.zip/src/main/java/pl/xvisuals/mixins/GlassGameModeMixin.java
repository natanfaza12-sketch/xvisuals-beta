package pl.xvisuals.mixins;

import pl.xvisuals.menu.GlassMenus;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.GameModeSwitcherScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameModeSwitcherScreen.class)
public abstract class GlassGameModeMixin {
  @Inject(method = "renderBackground", at = @At("HEAD"), cancellable = true)
  private void visuals$background(DrawContext g, int mx, int my, float dt, CallbackInfo ci) {
    if (!GlassMenus.active()) return;
    var screen = (Screen) (Object) this;
    g.fillGradient(0, 0, screen.width, screen.height, 0x46090D11, 0xA6090D11);
    ci.cancel();
  }
}
