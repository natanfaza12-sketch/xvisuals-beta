package pl.xvisuals.mixins;
import pl.xvisuals.modules.fire.FirePlus;
import net.minecraft.client.render.*;
import net.minecraft.client.render.command.FireCommandRenderer;
import net.minecraft.client.render.entity.state.*;
import net.minecraft.client.texture.*;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
@Mixin(FireCommandRenderer.class)
public class FirePlusEntityMixin {
 @Unique private boolean fireplus$player;
 @Inject(method="render(Lnet/minecraft/client/util/math/MatrixStack$Entry;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/client/render/entity/state/EntityRenderState;Lorg/joml/Quaternionf;Lnet/minecraft/client/texture/AtlasManager;)V",at=@At("HEAD"),cancellable=true)
 private void fireplus$select(MatrixStack.Entry matrix,VertexConsumerProvider consumers,EntityRenderState state,Quaternionf rotation,AtlasManager atlas,CallbackInfo ci){fireplus$player=state instanceof PlayerEntityRenderState&&FirePlus.players();if(FirePlus.hideEntity(state))ci.cancel();}
 // Scale only this queued fire entry; entity models and hitboxes are untouched.
 @ModifyArgs(method="render(Lnet/minecraft/client/util/math/MatrixStack$Entry;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/client/render/entity/state/EntityRenderState;Lorg/joml/Quaternionf;Lnet/minecraft/client/texture/AtlasManager;)V",at=@At(value="INVOKE",target="Lnet/minecraft/client/util/math/MatrixStack$Entry;scale(FFF)V"))
 private void fireplus$size(org.spongepowered.asm.mixin.injection.invoke.arg.Args args){if(fireplus$player){args.set(0,(float)args.get(0)*FirePlus.size("playerWidth"));args.set(1,(float)args.get(1)*FirePlus.size("playerHeight")*.78f);args.set(2,(float)args.get(2)*FirePlus.size("playerWidth"));}}
 @ModifyExpressionValue(method="render(Lnet/minecraft/client/util/math/MatrixStack$Entry;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/client/render/entity/state/EntityRenderState;Lorg/joml/Quaternionf;Lnet/minecraft/client/texture/AtlasManager;)V",at=@At(value="INVOKE",target="Lnet/minecraft/client/texture/AtlasManager;getSprite(Lnet/minecraft/client/util/SpriteIdentifier;)Lnet/minecraft/client/texture/Sprite;"))
 private Sprite fireplus$sprite(Sprite original){return fireplus$player?FirePlus.sprite(original.getContents().getId().getPath().endsWith("fire_1")):original;}
 @ModifyExpressionValue(method="render(Lnet/minecraft/client/util/math/MatrixStack$Entry;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/client/render/entity/state/EntityRenderState;Lorg/joml/Quaternionf;Lnet/minecraft/client/texture/AtlasManager;)V",at=@At(value="INVOKE",target="Lnet/minecraft/client/render/TexturedRenderLayers;getEntityCutout()Lnet/minecraft/client/render/RenderLayer;"))
 private RenderLayer fireplus$layer(RenderLayer original){return fireplus$player?RenderLayers.entityCutoutNoCull(FirePlus.playerTexture()):original;}
}
