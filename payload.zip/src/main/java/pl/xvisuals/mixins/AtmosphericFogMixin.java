package pl.xvisuals.mixins;

import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.fog.AtmosphericFogModifier;
import net.minecraft.client.render.fog.FogData;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pl.xvisuals.modules.world.RealisticFog;

@Mixin(AtmosphericFogModifier.class)
public abstract class AtmosphericFogMixin {
  @Shadow private float fogMultiplier;
  @Unique private ClientWorld visuals$fogWorld;

  @Inject(method = "applyStartEndModifier", at = @At("TAIL"))
  private void visuals$realisticFog(FogData data, Camera camera, ClientWorld world,
      float distance, RenderTickCounter counter, CallbackInfo ci) {
    RealisticFog.apply(data);
  }

  @Inject(method = "getFogColor", at = @At("RETURN"), cancellable = true)
  private void visuals$realisticFogColor(ClientWorld world, Camera camera, int distance,
      float tick, CallbackInfoReturnable<Integer> cir) {
    cir.setReturnValue(RealisticFog.color(cir.getReturnValue()));
  }

  @Inject(method = "applyStartEndModifier", at = @At("HEAD"))
  private void visuals$resetWeatherFog(FogData data, Camera camera, ClientWorld world,
      float distance, RenderTickCounter counter, CallbackInfo ci) {
    // The renderer outlives a world. Do not carry its close-range rain fog into a new one.
    if (visuals$fogWorld != world) {
      visuals$fogWorld = world;
      fogMultiplier = 0;
    }
  }
}
