package pl.xvisuals.mixins;

import pl.xvisuals.menu.GlassMenus;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.EntryListWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntryListWidget.class)
public abstract class GlassListMixin {
  @Inject(method = "drawMenuListBackground", at = @At("HEAD"), cancellable = true)
  private void visuals$list(DrawContext g, CallbackInfo ci) {
    if (!GlassMenus.active()) return;
    ci.cancel();
  }

  @Inject(method = "drawHeaderAndFooterSeparators", at = @At("HEAD"), cancellable = true)
  private void visuals$edges(DrawContext g, CallbackInfo ci) {
    if (GlassMenus.active()) ci.cancel();
  }

  @Inject(method = "renderEntry", at = @At("HEAD"))
  private void visuals$row(DrawContext g, int mx, int my, float dt, @Coerce net.minecraft.client.gui.widget.Widget row, CallbackInfo ci) {
    if (net.minecraft.client.MinecraftClient.getInstance().currentScreen instanceof pl.xvisuals.menu.CelestialServerScreen) return;
    if (!GlassMenus.active()) return;
    boolean hover = mx >= row.getX() && mx < row.getX() + row.getWidth()
        && my >= row.getY() && my < row.getY() + row.getHeight();
    GlassMenus.surface(g, row.getX(), row.getY() + 1, row.getWidth(), row.getHeight() - 2, hover, hover ? .85f : .48f);
  }

  @Inject(method = "drawSelectionHighlight", at = @At("HEAD"), cancellable = true)
  private void visuals$selected(DrawContext g, @Coerce net.minecraft.client.gui.widget.Widget row, int color, CallbackInfo ci) {
    if (net.minecraft.client.MinecraftClient.getInstance().currentScreen instanceof pl.xvisuals.menu.CelestialServerScreen) { ci.cancel(); return; }
    if (!GlassMenus.active()) return;
    GlassMenus.surface(g, row.getX(), row.getY() + 1, row.getWidth(), row.getHeight() - 2, true, 1);
    g.fill(row.getX() - 4, row.getY() + 5, row.getX() - 2, row.getY() + row.getHeight() - 5, 0xFFDCE6ED);
    ci.cancel();
  }
}

