package pl.xvisuals.mixins;
import pl.xvisuals.modules.pets.PetDeathScene;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(LivingEntity.class)
public class PetDeathParticlesMixin {
 @Inject(method="addDeathParticles",at=@At("HEAD"),cancellable=true)
 private void visuals$quietFarewell(CallbackInfo ci){
  if((Object)this==MinecraftClient.getInstance().player&&PetDeathScene.active())ci.cancel();
 }
}
