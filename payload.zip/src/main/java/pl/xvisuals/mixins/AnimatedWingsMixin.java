package pl.xvisuals.mixins;

import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.cosmetics.AnimatedCosmetics;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.ElytraEntityModel;
import net.minecraft.client.render.entity.state.*;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ElytraEntityModel.class)
public class AnimatedWingsMixin {
  @Shadow @Final private ModelPart leftWing;
  @Shadow @Final private ModelPart rightWing;
  @Inject(method = "setAngles(Lnet/minecraft/client/render/entity/state/BipedEntityRenderState;)V", at = @At("TAIL"))
  private void visuals$flutter(BipedEntityRenderState state, CallbackInfo ci) {
    if (!(state instanceof PlayerEntityRenderState p) || AnimatedCosmetics.wingSettings(p) == null) return;
    var m = AnimatedCosmetics.wingSettings(p);
    double t = state.age / 20d * m.number("speed");
    float flutter = (float) (Math.sin(t * (state.isGliding ? 5 : 2.4))
        * (state.isGliding ? .075 : .035) * m.number("motion"));
    leftWing.roll += flutter; rightWing.roll -= flutter;
    leftWing.pitch += flutter * .35f; rightWing.pitch += flutter * .35f;
  }
}
