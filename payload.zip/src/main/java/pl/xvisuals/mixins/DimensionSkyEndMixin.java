package pl.xvisuals.mixins;
import pl.xvisuals.rendering.DimensionSkies;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.SkyRendering;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(SkyRendering.class)
public abstract class DimensionSkyEndMixin {
 @Inject(method="close",at=@At("TAIL"))
 private void visuals$close(CallbackInfo ci){DimensionSkies.close();}
}
