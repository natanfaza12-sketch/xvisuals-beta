package pl.xvisuals.mixins;

import pl.xvisuals.modules.explosion.ExplosionCamera;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value=Camera.class,priority=900)
public abstract class ExplosionCameraMixin {
  @Shadow protected abstract void setRotation(float yaw,float pitch);
  @Shadow protected abstract void setPos(Vec3d pos);
  @Inject(method="update",at=@At("TAIL"))
  private void visuals$impact(World world,Entity entity,boolean third,boolean inverse,float tick,CallbackInfo ci) {
    ExplosionCamera.frame();var camera=(Camera)(Object)this;
    double landing=pl.xvisuals.modules.motion.Shockwave.shake();
    if(landing!=0)setRotation(camera.getYaw(),camera.getPitch()+(float)landing);
    if(ExplosionCamera.yaw!=0||ExplosionCamera.pitch!=0)
      setRotation(camera.getYaw()+(float)ExplosionCamera.yaw,camera.getPitch()+(float)ExplosionCamera.pitch);
    if(ExplosionCamera.roll!=0)camera.getRotation().rotateZ((float)Math.toRadians(ExplosionCamera.roll));
    if(ExplosionCamera.x!=0||ExplosionCamera.y!=0||ExplosionCamera.z!=0) {
      Vec3d from=camera.getCameraPos(),to=from.add(ExplosionCamera.x,ExplosionCamera.y,ExplosionCamera.z);
      if(world.raycast(new RaycastContext(from,to,RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,entity)).getType()==HitResult.Type.MISS)setPos(to);
    }
  }
}
