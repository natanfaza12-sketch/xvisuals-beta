package pl.xvisuals.mixins;
import pl.xvisuals.modules.glint.EnchantGlint;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.texture.*;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(RenderSetup.class)
public abstract class EnchantGlintTextureMixin {
  @Redirect(method="resolveTextures",at=@At(value="INVOKE",target="Lnet/minecraft/client/texture/TextureManager;getTexture(Lnet/minecraft/util/Identifier;)Lnet/minecraft/client/texture/AbstractTexture;"))
  private AbstractTexture visuals$glint(TextureManager manager,Identifier id) {
    return EnchantGlint.isGlint(id) && EnchantGlint.enabled()?EnchantGlint.texture():manager.getTexture(id);
  }
}
