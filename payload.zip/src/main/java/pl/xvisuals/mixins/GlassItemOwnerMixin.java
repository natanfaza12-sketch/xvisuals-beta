package pl.xvisuals.mixins;
import pl.xvisuals.modules.glass.GlassItemOwner;
import net.minecraft.client.item.ItemModelManager;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.item.*;
import net.minecraft.world.World;
import net.minecraft.util.HeldItemContext;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ItemModelManager.class)
public class GlassItemOwnerMixin {
 @Inject(method="update",at=@At("HEAD")) private void visuals$glassOwner(ItemRenderState state,ItemStack stack,ItemDisplayContext display,World world,HeldItemContext context,int seed,CallbackInfo ci){((GlassItemOwner)state).visuals$glassOwner(context!=null&&context.getEntity() instanceof PlayerEntity p?p.getId():-1);}
}
