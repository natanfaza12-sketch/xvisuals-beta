package pl.xvisuals.mixins;
import pl.xvisuals.gui.FontSelection;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.text.StyleSpriteSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(TextRenderer.class)
public abstract class FontSelectionMixin {
 @ModifyVariable(method="getGlyphs",at=@At("HEAD"),argsOnly=true)
 private StyleSpriteSource visuals$font(StyleSpriteSource source){return FontSelection.replace(source);}
}
