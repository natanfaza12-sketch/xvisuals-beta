package pl.xvisuals.mixins;

import pl.xvisuals.XVisuals;
import pl.xvisuals.gui.screens.StudioScreen;
import pl.xvisuals.menu.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameOptions.class)
public abstract class MenuBlurMixin {
  @Inject(method = "getMenuBackgroundBlurrinessValue", at = @At("RETURN"), cancellable = true)
  private void visuals$blur(CallbackInfoReturnable<Integer> cir) {
    if (!XVisuals.ready()) return;
    var s = MinecraftClient.getInstance().currentScreen;
    if (s instanceof XPauseScreen)
      cir.setReturnValue(0);
    else if (s instanceof ModsScreen)
      cir.setReturnValue(0);
    else if (s instanceof StudioScreen && XVisuals.config().blur) cir.setReturnValue(8);
  }
}
