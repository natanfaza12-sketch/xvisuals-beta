package pl.xvisuals.mixins;
import pl.xvisuals.menu.CelestialServerScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerServerListWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(MultiplayerServerListWidget.class)
public abstract class CelestialListMixin {
  @Inject(method="getRowWidth",at=@At("HEAD"),cancellable=true)
  private void visuals$width(CallbackInfoReturnable<Integer> cir) {
    if(MinecraftClient.getInstance().currentScreen instanceof CelestialServerScreen s) cir.setReturnValue(s.rowWidth());
  }
}
