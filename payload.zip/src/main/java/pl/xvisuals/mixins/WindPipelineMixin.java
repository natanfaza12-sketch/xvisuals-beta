package pl.xvisuals.mixins;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.client.gl.UniformType;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import java.util.Optional;
@Mixin(RenderPipeline.Builder.class)
public abstract class WindPipelineMixin {
 @Shadow private Optional<Identifier> vertexShader;
 @Inject(method="build",at=@At("HEAD"))
 private void visuals$wind(CallbackInfoReturnable<RenderPipeline> cir){if(pl.xvisuals.bootstrap.WindTerrainSupport.nativeTerrain()&&vertexShader.filter(id->id.equals(Identifier.ofVanilla("core/terrain"))).isPresent()){
  ((RenderPipeline.Builder)(Object)this).withVertexShader(Identifier.of("xvisuals","core/wind_terrain")).withUniform("VisualWind",UniformType.UNIFORM_BUFFER);
 }}
}
