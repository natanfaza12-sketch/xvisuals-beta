package pl.xvisuals.mixins.emote;

import pl.xvisuals.modules.emote.client.*;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.*;
import net.minecraft.util.*;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Overrides presentation while the emote runs; actual held items and use state remain untouched. */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    @Shadow public abstract void renderItem(net.minecraft.entity.LivingEntity entity,ItemStack stack,ItemDisplayContext mode,MatrixStack matrices,OrderedRenderCommandQueue queue,int light);
    @Shadow protected abstract void renderArmHoldingItem(MatrixStack matrices,OrderedRenderCommandQueue queue,int light,float equip,float swing,Arm arm);
    @Inject(method="renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V",at=@At("HEAD"),cancellable=true)
    private void smoking$emote(float delta,MatrixStack matrices,OrderedRenderCommandQueue queue,ClientPlayerEntity player,int packedLight,CallbackInfo ci){
        if(!SmokingClient.active())return;
        hand(player,delta,true,player.getMainArm(),matrices,queue,packedLight);
        if(SmokingClient.light(delta)>.01f)hand(player,delta,false,player.getMainArm().getOpposite(),matrices,queue,packedLight);
        // The replaced vanilla entrypoint also flushes its queued hand geometry before returning.
        var client=net.minecraft.client.MinecraftClient.getInstance();
        client.gameRenderer.getEntityRenderDispatcher().render();
        client.getBufferBuilders().getEntityVertexConsumers().draw();
        SmokingClient.renderedHands++;ci.cancel();
    }
    private void hand(ClientPlayerEntity player,float delta,boolean cigarette,Arm arm,MatrixStack matrices,OrderedRenderCommandQueue queue,int packedLight){
        int sign=arm==Arm.RIGHT?1:-1;float pose=cigarette?SmokingClient.raise(delta):SmokingClient.light(delta);
        matrices.push();
        float breath=(float)Math.sin((player.age+delta)*.09)*.004f;
        matrices.translate(sign*-.24*pose,(cigarette?.18:.09)*pose+breath,(cigarette?-.14:-.2)*pose);
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(sign*-8*pose));
        if(!cigarette)matrices.translate(0,-.8*(1-pose),0);
        if(!player.isInvisible()){
            matrices.push();matrices.scale(.83f,.83f,.83f);
            renderArmHoldingItem(matrices,queue,packedLight,0,0,arm);matrices.pop();
        }
        matrices.translate(sign*(cigarette?.38:.34),cigarette?-.27:-.34,-.68);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(sign*(cigarette?55:8)));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(cigarette?-8:-5));
        float scale=cigarette?.45f:.5f;matrices.scale(scale,scale,scale);
        renderItem(player,cigarette?EmoteProps.CIGARETTE:EmoteProps.LIGHTER,
            arm==Arm.RIGHT?ItemDisplayContext.FIRST_PERSON_RIGHT_HAND:ItemDisplayContext.FIRST_PERSON_LEFT_HAND,matrices,queue,packedLight);
        matrices.pop();
    }
}
