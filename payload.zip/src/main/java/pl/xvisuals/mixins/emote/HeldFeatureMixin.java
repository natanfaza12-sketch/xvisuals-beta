package pl.xvisuals.mixins.emote;
import pl.xvisuals.modules.emote.client.SmokingFeatureRenderer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.HeldItemFeatureRenderer;
import net.minecraft.client.render.entity.state.*;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(HeldItemFeatureRenderer.class) public class HeldFeatureMixin {
    @Inject(method="render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/ArmedEntityRenderState;FF)V",at=@At("HEAD"),cancellable=true)
    private void smoking$hideHeld(MatrixStack matrices,OrderedRenderCommandQueue queue,int light,ArmedEntityRenderState state,float yaw,float pitch,CallbackInfo ci){
        if(state instanceof PlayerEntityRenderState player&&SmokingFeatureRenderer.local(player))ci.cancel();
    }
}
