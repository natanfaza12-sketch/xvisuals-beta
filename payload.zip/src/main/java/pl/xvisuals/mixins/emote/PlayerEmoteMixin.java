package pl.xvisuals.mixins.emote;
import pl.xvisuals.modules.emote.client.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.util.Arm;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(PlayerEntityModel.class) public class PlayerEmoteMixin {
    @Inject(method="setAngles(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;)V",at=@At("TAIL"))
    private void smoking$pose(PlayerEntityRenderState state,CallbackInfo ci){
        if(!SmokingFeatureRenderer.local(state))return;
        var model=(PlayerEntityModel)(Object)this;float delta=MinecraftClient.getInstance().getRenderTickCounter().getTickProgress(false);
        boolean right=state.mainArm==Arm.RIGHT;var main=right?model.rightArm:model.leftArm;var off=right?model.leftArm:model.rightArm;
        float raise=SmokingClient.raise(delta),light=SmokingClient.light(delta);int sign=right?1:-1;
        main.pitch=-.25f+(-1.7f+model.head.pitch*.4f)*raise;main.yaw=-sign*.25f*raise;main.roll=sign*.16f*raise;
        if(light>.01){off.pitch=-1.55f*light;off.yaw=sign*.35f*light;off.roll=-sign*.25f*light;}
        // In 1.21.11 sleeves are children of the arm parts and inherit these transforms.
    }
}
