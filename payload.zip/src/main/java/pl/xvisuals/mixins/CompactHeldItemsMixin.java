package pl.xvisuals.mixins;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import pl.xvisuals.XVisuals;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.*;
import net.minecraft.registry.tag.ItemTags;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(HeldItemRenderer.class)
public abstract class CompactHeldItemsMixin {
 @WrapMethod(method="renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemDisplayContext;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V")
 private void visuals$compact(LivingEntity entity,ItemStack item,ItemDisplayContext context,MatrixStack matrices,OrderedRenderCommandQueue queue,int light,Operation<Void> original){
  matrices.push();
  try{
   if(XVisuals.ready()&&(context==ItemDisplayContext.FIRST_PERSON_LEFT_HAND||context==ItemDisplayContext.FIRST_PERSON_RIGHT_HAND)){
    var cfg=XVisuals.config();
    var type=net.minecraft.registry.Registries.ITEM.getId(item.getItem());
    String module=item.isIn(ItemTags.SWORDS)?"customswords":type.getPath().endsWith("_pickaxe")?"custompickaxes":"";
    if(!module.isEmpty()&&cfg.on(module)&&type.getNamespace().equals("minecraft")){
     var s=cfg.module(module);
     boolean matches=module.equals("customswords")?pl.xvisuals.modules.swords.CustomSwords.matches(type.getPath(),s.text("replace")):pl.xvisuals.modules.pickaxes.CustomPickaxes.matches(type.getPath(),s.text("replace"));
     if(matches){int sign=context==ItemDisplayContext.FIRST_PERSON_LEFT_HAND?-1:1;
      matrices.translate(sign*s.number("handX"),s.number("handY"),s.number("handZ"));
      matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Z.rotationDegrees((float)(sign*s.number("handTilt"))));
      matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_X.rotationDegrees((float)s.number("handPitch")));
      matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Y.rotationDegrees((float)(sign*s.number("handYaw"))));
      if(s.flag("hideHeldGlint")){
       item=item.copy();
       item.set(net.minecraft.component.DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE,false);
      }
      float size=(float)s.number("handScale");matrices.scale(size,size,size);
     }
    }
    if(item.isOf(Items.SHIELD)&&cfg.on("lowshield"))matrices.translate(0,-cfg.module("lowshield").number("amount"),0);
    if(item.isIn(ItemTags.AXES)&&cfg.on("lowaxe"))matrices.translate(0,-cfg.module("lowaxe").number("amount"),0);
    if(item.isIn(ItemTags.SWORDS)&&cfg.on("smallsword")){float scale=(float)cfg.module("smallsword").number("scale");matrices.scale(scale,scale,scale);}
   }
   original.call(entity,item,context,matrices,queue,light);
  }finally{matrices.pop();}
 }
}
