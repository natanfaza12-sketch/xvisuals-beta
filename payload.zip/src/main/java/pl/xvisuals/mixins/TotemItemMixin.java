package pl.xvisuals.mixins;

import pl.xvisuals.modules.combat.TotemVisuals;
import pl.xvisuals.modules.combat.TotemSizing;
import net.minecraft.client.item.ItemModelManager;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.HeldItemContext;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemModelManager.class)
public class TotemItemMixin {
  @ModifyVariable(method = "update", at = @At("HEAD"), argsOnly = true, ordinal = 0)
  private ItemStack visuals$skin(ItemStack stack) { return pl.xvisuals.modules.world.GlassierGlass.appearance(TotemVisuals.appearance(stack)); }

  @Inject(method = "update", at = @At("TAIL"))
  private void visuals$sizeContext(ItemRenderState state, ItemStack stack,
      ItemDisplayContext context, World world, HeldItemContext held, int seed, CallbackInfo ci) {
    ((TotemSizing.State) state).visuals$totemContext(stack.isOf(Items.TOTEM_OF_UNDYING), context);
  }
}
