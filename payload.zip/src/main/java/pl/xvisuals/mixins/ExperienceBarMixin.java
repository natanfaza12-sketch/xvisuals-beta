package pl.xvisuals.mixins;

import pl.xvisuals.hud.ExperienceBarRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.bar.ExperienceBar;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ExperienceBar.class)
public class ExperienceBarMixin {
  @Inject(method="renderBar",at=@At("HEAD"),cancellable=true)
  private void visuals$experience(DrawContext context,RenderTickCounter ticks,CallbackInfo ci) {
    if(ExperienceBarRenderer.render(context,ticks.getTickProgress(false))) ci.cancel();
  }
}
