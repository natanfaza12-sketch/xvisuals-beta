package pl.xvisuals.mixins;

import pl.xvisuals.hud.HudManager;
import net.minecraft.client.Mouse;
import net.minecraft.client.input.MouseInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public abstract class MouseMixin {
  @Redirect(
      method = "updateMouse",
      at =
          @At(
              value = "INVOKE",
              target = "Lnet/minecraft/client/network/ClientPlayerEntity;changeLookDirection(DD)V"))
  private void visuals$look(
      net.minecraft.client.network.ClientPlayerEntity player, double dx, double dy) {
    if (!pl.xvisuals.modules.motion.Freelook.mouse(dx, dy))
      player.changeLookDirection(dx, dy);
  }

  @Inject(method = "onMouseButton", at = @At("HEAD"))
  private void visuals$click(long window, MouseInput input, int action, CallbackInfo ci) {
    pl.xvisuals.audio.CreamyKeys.mouse(window,action);
    if (action == 1) HudManager.click(input.button());
  }
}
