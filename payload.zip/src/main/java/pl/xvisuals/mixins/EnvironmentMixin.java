package pl.xvisuals.mixins;

import pl.xvisuals.XVisuals;
import net.minecraft.world.attribute.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Only the camera's VISUAL attributes are overridden; gameplay attributes are untouched. */
@Mixin(EnvironmentAttributeInterpolator.class)
public abstract class EnvironmentMixin {
  @Inject(method = "get", at = @At("RETURN"), cancellable = true)
  private <T> void visuals$environment(
      EnvironmentAttribute<T> attribute, float tick, CallbackInfoReturnable<T> cir) {
    if ((pl.xvisuals.rendering.Storm.running() || pl.xvisuals.rendering.Lightning.flash() > 0)
        && (attribute == EnvironmentAttributes.SKY_COLOR_VISUAL
            || attribute == EnvironmentAttributes.CLOUD_COLOR_VISUAL)) {
      @SuppressWarnings("unchecked") T storm = (T) Integer.valueOf(
          pl.xvisuals.rendering.Lightning.skyColor(
              pl.xvisuals.rendering.Storm.skyColor((Integer) cir.getReturnValue())));
      cir.setReturnValue(storm);
      return;
    }
    double blizzard = pl.xvisuals.rendering.EnhancedWeather.whiteout();
    if (blizzard > .001) {
      Object weather = null;
      if (attribute == EnvironmentAttributes.FOG_COLOR_VISUAL) {
        int original = (Integer) cir.getReturnValue();
        int r = (int)(((original >> 16) & 255) * (1 - blizzard) + 192 * blizzard);
        int g = (int)(((original >> 8) & 255) * (1 - blizzard) + 213 * blizzard);
        int b = (int)((original & 255) * (1 - blizzard) + 229 * blizzard);
        weather = (r << 16) | (g << 8) | b;
      } else if (attribute == EnvironmentAttributes.FOG_START_DISTANCE_VISUAL) {
        weather = (float)(((Number)cir.getReturnValue()).floatValue() * (1 - blizzard));
      } else if (attribute == EnvironmentAttributes.FOG_END_DISTANCE_VISUAL) {
        float original = ((Number)cir.getReturnValue()).floatValue();
        weather = (float)(original + (Math.min(original, 28) - original) * blizzard);
      }
      if (weather != null) {
        @SuppressWarnings("unchecked") T cast = (T)weather;
        cir.setReturnValue(cast);
        return;
      }
    }
    if (!XVisuals.ready() || !XVisuals.config().on("atmosphere")) return;
    var s = XVisuals.config().module("atmosphere");
    boolean waterAttribute=attribute==EnvironmentAttributes.WATER_FOG_COLOR_VISUAL
        || attribute==EnvironmentAttributes.WATER_FOG_START_DISTANCE_VISUAL
        || attribute==EnvironmentAttributes.WATER_FOG_END_DISTANCE_VISUAL;
    // Preserve biome water and fluid/status fog unless underwater customisation is requested.
    if(waterAttribute && !s.flag("waterOverride")) return;
    if(!waterAttribute && !pl.xvisuals.rendering.CameraEnvironment.surface()) return;
    Object value = null;
    int sky = s.color("sky"), fog = s.color("fog");
    switch (s.text("preset")) {
      case "Lavender Dusk" -> {
        sky = 0x686991;
        fog = 0x8D7DA2;
      }
      case "Deep Space" -> {
        sky = 0x11152E;
        fog = 0x242745;
      }
      case "Arctic" -> {
        sky = 0x8FBED4;
        fog = 0xBCD7E0;
      }
      case "Golden Hour" -> {
        sky = 0x8097B4;
        fog = 0xD9B187;
      }
      case "Rose Dawn" -> {
        sky = 0xA09EC1;
        fog = 0xC598AB;
      }
      case "Emerald Night" -> {
        sky = 0x143333;
        fog = 0x2E555B;
      }
    }
    if (attribute == EnvironmentAttributes.SKY_COLOR_VISUAL && s.flag("skyOverride"))
      value = sky & 0xFFFFFF;
    else if (attribute == EnvironmentAttributes.FOG_COLOR_VISUAL && s.flag("fogOverride"))
      value = fog & 0xFFFFFF;
    else if (attribute == EnvironmentAttributes.FOG_START_DISTANCE_VISUAL && s.flag("fogOverride"))
      value = (float) Math.min(s.number("fogStart"), s.number("fogEnd") - 1);
    else if (attribute == EnvironmentAttributes.FOG_END_DISTANCE_VISUAL && s.flag("fogOverride"))
      value = (float) s.number("fogEnd");
    else if (attribute == EnvironmentAttributes.STAR_BRIGHTNESS_VISUAL)
      value = (float) s.number("stars");
    else if (attribute == EnvironmentAttributes.CLOUD_HEIGHT_VISUAL)
      value = (float) s.number("cloudHeight");
    else if (attribute == EnvironmentAttributes.CLOUD_COLOR_VISUAL) value = s.color("cloudColor");
    else if (attribute == EnvironmentAttributes.WATER_FOG_COLOR_VISUAL)
      value = s.color("waterFog") & 0xFFFFFF;
    else if (attribute == EnvironmentAttributes.WATER_FOG_START_DISTANCE_VISUAL)
      value = 0.0f;
    else if (attribute == EnvironmentAttributes.WATER_FOG_END_DISTANCE_VISUAL)
      value = (float) s.number("waterDistance");
    else if (attribute == EnvironmentAttributes.SUNRISE_SUNSET_COLOR_VISUAL)
      value = (s.color("sunset") & 0xFFFFFF) | (((Integer) cir.getReturnValue()) & 0xFF000000);
    else if (attribute == EnvironmentAttributes.SKY_LIGHT_FACTOR_VISUAL)
      value = (float) Math.max(((Number) cir.getReturnValue()).floatValue(), s.number("light"));
    else if (attribute == EnvironmentAttributes.SUN_ANGLE_VISUAL
        || attribute == EnvironmentAttributes.MOON_ANGLE_VISUAL
        || attribute == EnvironmentAttributes.STAR_ANGLE_VISUAL) {
      double angle = ((Number) cir.getReturnValue()).doubleValue();
      if (s.flag("timeOverride")) angle = (s.number("time") / 24000 - .25) * 360;
      value =
          (float)
              (angle
                  + (attribute == EnvironmentAttributes.MOON_ANGLE_VISUAL
                      ? s.number("moon")
                      : attribute == EnvironmentAttributes.SUN_ANGLE_VISUAL ? s.number("sun") : 0));
    }
    if (value != null) {
      @SuppressWarnings("unchecked")
      T cast = (T) value;
      cir.setReturnValue(cast);
    }
  }
}
