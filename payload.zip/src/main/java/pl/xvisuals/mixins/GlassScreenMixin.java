package pl.xvisuals.mixins;

import pl.xvisuals.menu.GlassMenus;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Screen.class)
public abstract class GlassScreenMixin {
  @org.spongepowered.asm.mixin.Unique
  private pl.xvisuals.menu.TerrainLoadingScene visuals$savingScene;
  @org.spongepowered.asm.mixin.Unique private long visuals$preparingStarted;

  @Inject(method = "render", at = @At("HEAD"), cancellable = true)
  private void visuals$savingWorld(DrawContext g, int mx, int my, float dt, CallbackInfo ci) {
    Screen screen = (Screen) (Object) this;
    if (!GlassMenus.themed(screen)
        || !(screen instanceof net.minecraft.client.gui.screen.MessageScreen)
        || !(screen.getTitle().getContent() instanceof net.minecraft.text.TranslatableTextContent text)) return;
    if (text.getKey().equals("selectWorld.resource_load")) {
      if (visuals$preparingStarted == 0) visuals$preparingStarted = System.nanoTime();
      pl.xvisuals.menu.LaunchArtwork.preparing(g, (System.nanoTime() - visuals$preparingStarted) / 1e9);
      ci.cancel();
      return;
    }
    if (!text.getKey().equals("menu.savingLevel")) return;
    if (visuals$savingScene == null)
      visuals$savingScene = new pl.xvisuals.menu.TerrainLoadingScene();
    visuals$savingScene.renderSaving(g, screen.width, screen.height);
    ci.cancel();
  }

  @Inject(method = "renderBackground", at = @At("HEAD"), cancellable = true)
  private void visuals$background(DrawContext g, int mx, int my, float dt, CallbackInfo ci) {
    Screen screen = (Screen) (Object) this;
    if (!GlassMenus.themed(screen)) return;
    GlassMenus.background(g, screen);
    MinecraftClient.getInstance().inGameHud.renderDeferredSubtitles();
    ci.cancel();
  }

  @Inject(method = "renderBackgroundTexture", at = @At("HEAD"), cancellable = true)
  private static void visuals$separators(DrawContext g, Identifier texture, int x, int y,
      float u, float v, int w, int h, CallbackInfo ci) {
    if (!GlassMenus.active()) return;
    if (texture.getPath().contains("separator")) {
      ci.cancel();
    } else if (texture.getNamespace().equals("minecraft")
        && (texture.getPath().contains("menu_background") || texture.getPath().contains("tab_header_background"))) {
      ci.cancel();
    }
  }
}
