package pl.xvisuals.mixins;
import pl.xvisuals.modules.swords.CustomSwords;
import net.minecraft.client.item.ItemModelManager;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(ItemModelManager.class)
public class SwordItemMixin {
 @ModifyVariable(method="update",at=@At("HEAD"),argsOnly=true,ordinal=0)
 private ItemStack visuals$sword(ItemStack stack){return CustomSwords.appearance(stack);}
}
