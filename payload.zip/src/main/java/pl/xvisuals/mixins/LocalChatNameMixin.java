package pl.xvisuals.mixins;
import pl.xvisuals.modules.cosmetics.LocalAppearance;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** Only the wrapped display copy changes; signed messages and original chat history remain intact. */
@Mixin(ChatHud.class)
public abstract class LocalChatNameMixin {
 @Shadow private void refresh() { throw new AssertionError(); }
 @Unique private String visuals$lastAlias="";
 @ModifyVariable(method="addVisibleMessage",at=@At("HEAD"),argsOnly=true)
 private net.minecraft.client.gui.hud.ChatHudLine visuals$chatName(net.minecraft.client.gui.hud.ChatHudLine line){
  Text display=LocalAppearance.protectText(line.content());
  return display==line.content()?line:new net.minecraft.client.gui.hud.ChatHudLine(line.creationTick(),display,line.signature(),line.indicator());
 }
 @Inject(method="render(Lnet/minecraft/client/gui/hud/ChatHud$Backend;IIZ)V",at=@At("HEAD"))
 private void visuals$refreshNames(CallbackInfo ci){
  var c=net.minecraft.client.MinecraftClient.getInstance();
  String real=c.player==null?c.getSession().getUsername():c.player.getGameProfile().name();
  String alias=LocalAppearance.protectText(Text.literal(real)).getString()+"|"+pl.xvisuals.gui.FontSelection.selected();
  if(!alias.equals(visuals$lastAlias)){visuals$lastAlias=alias;refresh();}
 }
}
