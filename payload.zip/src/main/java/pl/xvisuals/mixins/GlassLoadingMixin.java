package pl.xvisuals.mixins;

import pl.xvisuals.menu.GlassMenus;
import pl.xvisuals.menu.TerrainLoadingScene;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.world.LevelLoadingScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LevelLoadingScreen.class)
public abstract class GlassLoadingMixin {
  @Shadow private net.minecraft.client.world.ClientChunkLoadProgress chunkLoadProgress;
  @Shadow private long lastNarrationTime;
  @Unique private final TerrainLoadingScene visuals$terrain = new TerrainLoadingScene();

  @Inject(method = "render", at = @At("HEAD"), cancellable = true)
  private void visuals$loadingCard(DrawContext g, int mx, int my, float dt, CallbackInfo ci) {
    if (!GlassMenus.active()) return;
    Screen screen = (Screen) (Object) this;
    long now = net.minecraft.util.Util.getMeasuringTimeMs();
    if (now - lastNarrationTime > 2000) {
      lastNarrationTime = now;
      screen.narrateScreenIfNarrationEnabled(true);
    }
    visuals$terrain.render(g, screen.width, screen.height,
        chunkLoadProgress.hasProgress(), chunkLoadProgress.getLoadProgress());
    ci.cancel();
  }

  @Inject(method = "renderBackground", at = @At("HEAD"), cancellable = true)
  private void visuals$background(DrawContext g, int mx, int my, float dt, CallbackInfo ci) {
    // The replacement render owns its full-screen background.
    if (GlassMenus.active()) ci.cancel();
  }
}
