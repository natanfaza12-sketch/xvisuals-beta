package pl.xvisuals.mixins;

import pl.xvisuals.XVisuals;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WorldRenderer.class)
public abstract class CloudsMixin {
  @Inject(method = "renderClouds", at = @At("HEAD"), cancellable = true)
  private void visuals$clouds(CallbackInfo ci) {
    if (XVisuals.ready() && XVisuals.config().on("noclouds")) { ci.cancel(); return; }
    if (pl.xvisuals.rendering.CinematicSky.active()
        && !XVisuals.config().module("cinematicsky").flag("clouds")) {
      ci.cancel();
      return;
    }
    if (XVisuals.ready()
        && XVisuals.config().on("atmosphere")
        && !XVisuals.config().module("atmosphere").flag("clouds")) ci.cancel();
  }
}
