package pl.xvisuals.mixins;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(PlayerEntity.class)
public abstract class LocalNameMixin {
  @Inject(method="getDisplayName",at=@At("RETURN"),cancellable=true)
  private void visuals$name(CallbackInfoReturnable<Text> cir){
    if(pl.xvisuals.XVisuals.ready() && (Object)this==MinecraftClient.getInstance().player){
      cir.setReturnValue(pl.xvisuals.modules.cosmetics.LocalAppearance.displayName(
          cir.getReturnValue(),MinecraftClient.getInstance().player.getGameProfile().name()));
    }
  }
}
