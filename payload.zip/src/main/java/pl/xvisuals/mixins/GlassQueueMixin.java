package pl.xvisuals.mixins;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import pl.xvisuals.modules.glass.*;
import net.minecraft.client.model.*;
import net.minecraft.client.render.*;
import net.minecraft.client.render.command.*;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemDisplayContext;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(BatchingRenderCommandQueue.class)
public class GlassQueueMixin {
 @WrapMethod(method="submitModel") private <S> void visuals$glassModel(Model<? super S> model,S state,MatrixStack matrices,RenderLayer layer,int light,int overlay,int color,Sprite sprite,int outline,ModelCommandRenderer.CrumblingOverlayCommand cr,Operation<Void> original){
 layer=GlassMaterial.original(layer);if(GlassMode.player(state)||GlassMode.active()){if(layer.toString().toLowerCase(java.util.Locale.ROOT).contains("glint"))return;layer=GlassMaterial.layer(layer);color=0xffffffff;GlassMaterial.models++;}original.call(model,state,matrices,layer,light,overlay,color,sprite,outline,cr);}
 @WrapMethod(method="submitModelPart") private void visuals$glassPart(ModelPart model,MatrixStack matrices,RenderLayer layer,int light,int overlay,Sprite sprite,boolean glint,boolean solid,int color,ModelCommandRenderer.CrumblingOverlayCommand cr,int outline,Operation<Void> original){layer=GlassMaterial.original(layer);if(GlassMode.active()){if(layer.toString().toLowerCase(java.util.Locale.ROOT).contains("glint"))return;layer=GlassMaterial.layer(layer);color=0xffffffff;glint=false;GlassMaterial.parts++;}original.call(model,matrices,layer,light,overlay,sprite,glint,solid,color,cr,outline);}
 @WrapMethod(method="submitItem") private void visuals$glassItem(MatrixStack matrices,ItemDisplayContext display,int light,int overlay,int outline,int[] tints,java.util.List<BakedQuad> quads,RenderLayer layer,ItemRenderState.Glint glint,Operation<Void> original){layer=GlassMaterial.original(layer);if(GlassMode.active()&&GlassMode.items()){layer=GlassMaterial.layer(layer);glint=ItemRenderState.Glint.NONE;GlassMaterial.items++;}original.call(matrices,display,light,overlay,outline,tints,quads,layer,glint);}
}
