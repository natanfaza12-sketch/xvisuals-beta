package pl.xvisuals.mixins;

import pl.xvisuals.rendering.CinematicSky;
import net.minecraft.client.render.SkyRendering;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SkyRendering.class)
public abstract class CinematicSkyMixin {
  @Inject(method = "renderTopSky", at = @At("HEAD"), cancellable = true)
  private void visuals$sky(int color, CallbackInfo ci) {
    if (CinematicSky.active()) {
      CinematicSky.render();
      ci.cancel();
    }
  }

  @Inject(
      method = {"renderSkyDark", "renderGlowingSky"},
      at = @At("HEAD"),
      cancellable = true)
  private void visuals$hideVanilla(CallbackInfo ci) {
    if (CinematicSky.active()) ci.cancel();
  }

  @Inject(method="renderCelestialBodies",at=@At("HEAD"),cancellable=true)
  private void visuals$captureSun(net.minecraft.client.util.math.MatrixStack matrices,float sun,float moon,float stars,net.minecraft.world.MoonPhase phase,float alpha,float brightness,CallbackInfo ci){
    pl.xvisuals.rendering.shaders.VolumetricLight.capture(sun,moon,alpha);
    if(CinematicSky.active())ci.cancel();
  }

  @Inject(method = "close", at = @At("TAIL"))
  private void visuals$close(CallbackInfo ci) {
    CinematicSky.close();
  }
}
