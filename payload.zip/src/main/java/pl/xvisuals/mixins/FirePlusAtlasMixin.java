package pl.xvisuals.mixins;
import net.minecraft.client.texture.SpriteAtlasTexture;
import pl.xvisuals.modules.fire.FirePlus;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** Run only after vanilla animation passes have closed; no render pass or GPU state is left open. */
@Mixin(SpriteAtlasTexture.class)
public class FirePlusAtlasMixin {
 @Inject(method="tickAnimatedSprites",at=@At("TAIL")) private void fireplus$animate(CallbackInfo ci){FirePlus.atlasTick((SpriteAtlasTexture)(Object)this);pl.xvisuals.modules.world.BlockVisibility.tick((SpriteAtlasTexture)(Object)this);}
 @Inject(method="clear",at=@At("HEAD")) private void fireplus$clear(CallbackInfo ci){FirePlus.clear((SpriteAtlasTexture)(Object)this);pl.xvisuals.modules.world.BlockVisibility.clear((SpriteAtlasTexture)(Object)this);}
}
