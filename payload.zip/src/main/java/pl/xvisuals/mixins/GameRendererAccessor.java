package pl.xvisuals.mixins;

import net.minecraft.client.render.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(GameRenderer.class)
public interface GameRendererAccessor {
  @Invoker("getFov")
  float visuals$getFov(Camera camera, float tickProgress, boolean changingFov);
}
