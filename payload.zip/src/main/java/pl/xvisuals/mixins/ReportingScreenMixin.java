package pl.xvisuals.mixins;

import pl.xvisuals.menu.ReportingButtons;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ClickableWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Screen.class)
public abstract class ReportingScreenMixin {
  @Inject(method = {"addDrawableChild", "addSelectableChild"}, at = @At("HEAD"), cancellable = true)
  private void visuals$removeReporting(Element child, CallbackInfoReturnable<Element> cir) {
    if (child instanceof ClickableWidget button && ReportingButtons.matches(button.getMessage())) {
      button.visible = false; button.active = false;
      cir.setReturnValue(child);
    }
  }
}
