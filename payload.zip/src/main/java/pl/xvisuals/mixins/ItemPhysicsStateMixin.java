package pl.xvisuals.mixins;
import pl.xvisuals.rendering.ItemPhysics;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
@Mixin(ItemEntityRenderState.class)
public class ItemPhysicsStateMixin implements ItemPhysics.State {
 @Unique private ItemPhysics.Pose visuals$pose;
 public ItemPhysics.Pose visuals$getPose(){return visuals$pose;}
 public void visuals$setPose(ItemPhysics.Pose pose){visuals$pose=pose;}
}
