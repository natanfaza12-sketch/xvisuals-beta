package pl.xvisuals.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import pl.xvisuals.modules.motion.AnimationControls;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemDisplayContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;

@Mixin(HeldItemRenderer.class)
public abstract class HandAnimationControlsMixin {
  @ModifyArg(method="renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V",
      at=@At(value="INVOKE",target="Lnet/minecraft/client/render/item/HeldItemRenderer;renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V"),index=6)
  private float visuals$equip(float value){return AnimationControls.equip(value);}
  @ModifyArg(method="renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V",
      at=@At(value="INVOKE",target="Lnet/minecraft/util/math/RotationAxis;rotationDegrees(F)Lorg/joml/Quaternionf;"))
  private float visuals$sway(float value){return value*AnimationControls.hand("sway");}
  @ModifyExpressionValue(method="updateHeldItems",at=@At(value="INVOKE",target="Lnet/minecraft/client/network/ClientPlayerEntity;getHandEquippingProgress(F)F"))
  private float visuals$cooldown(float value){return AnimationControls.flag("handanimations","equip",true)&&AnimationControls.flag("handanimations","cooldown",true)?value:1;}
  @WrapOperation(method="applyEatOrDrinkTransformation",at=@At(value="INVOKE",target="Lnet/minecraft/client/util/math/MatrixStack;translate(FFF)V",ordinal=0))
  private void visuals$jiggle(MatrixStack m,float x,float y,float z,Operation<Void> original){float k=AnimationControls.hand("eatJiggle");original.call(m,x*k,y*k,z*k);}
  @WrapOperation(method="applyEatOrDrinkTransformation",at=@At(value="INVOKE",target="Lnet/minecraft/client/util/math/MatrixStack;translate(FFF)V",ordinal=1))
  private void visuals$lift(MatrixStack m,float x,float y,float z,Operation<Void> original){float k=AnimationControls.hand("eatLift");original.call(m,x*k,y*k,z*k);}
  @ModifyConstant(method="renderFirstPersonItem",constant=@Constant(floatValue=.004f))
  private float visuals$bow(float value){return value*AnimationControls.hand("bowShake");}
  @WrapOperation(method="renderFirstPersonItem",at=@At(value="INVOKE",target="Lnet/minecraft/client/render/item/HeldItemRenderer;renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemDisplayContext;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V"))
  private void visuals$block(HeldItemRenderer self,LivingEntity entity,ItemStack stack,ItemDisplayContext context,MatrixStack matrices,OrderedRenderCommandQueue queue,int light,Operation<Void> original){
    matrices.push();
    try {
      var player=net.minecraft.client.MinecraftClient.getInstance().player;
      if (player!=null && player.isUsingItem() && AnimationControls.flag("swing","onUse",false)) {
        boolean right=context==ItemDisplayContext.FIRST_PERSON_RIGHT_HAND;
        boolean first=right||context==ItemDisplayContext.FIRST_PERSON_LEFT_HAND;
        var arm=right?net.minecraft.util.Arm.RIGHT:net.minecraft.util.Arm.LEFT;
        var hand=arm==player.getMainArm()?net.minecraft.util.Hand.MAIN_HAND:net.minecraft.util.Hand.OFF_HAND;
        if(first && hand==player.getActiveHand())pl.xvisuals.modules.motion.SwingMotion.transform(matrices,arm);
      }
      AnimationControls.block(matrices,stack,context);original.call(self,entity,stack,context,matrices,queue,light);} finally {matrices.pop();}
  }
}
