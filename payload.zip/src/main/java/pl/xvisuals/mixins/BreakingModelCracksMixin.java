package pl.xvisuals.mixins;
import pl.xvisuals.modules.world.BreakingCracks;
import net.minecraft.client.render.*;
import net.minecraft.client.render.command.ModelCommandRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(ModelCommandRenderer.class)
public abstract class BreakingModelCracksMixin {
 @ModifyArg(method="render(Lnet/minecraft/client/render/command/OrderedRenderCommandQueueImpl$ModelCommand;Lnet/minecraft/client/render/RenderLayer;Lnet/minecraft/client/render/VertexConsumer;Lnet/minecraft/client/render/OutlineVertexConsumerProvider;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;)V",at=@At(value="INVOKE",target="Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;getBuffer(Lnet/minecraft/client/render/RenderLayer;)Lnet/minecraft/client/render/VertexConsumer;"),index=0)
 private RenderLayer visuals$cracks(RenderLayer original){return BreakingCracks.layer(original);}
}
