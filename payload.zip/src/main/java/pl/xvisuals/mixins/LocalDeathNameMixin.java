package pl.xvisuals.mixins;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import pl.xvisuals.modules.cosmetics.LocalAppearance;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
@Mixin(DeathScreen.class)
public abstract class LocalDeathNameMixin {
 @ModifyExpressionValue(method="drawTitles",at=@At(value="FIELD",target="Lnet/minecraft/client/gui/screen/DeathScreen;message:Lnet/minecraft/text/Text;"))
 private Text visuals$deathName(Text text){return LocalAppearance.protectText(text);}
}
