package pl.xvisuals.mixins;

import pl.xvisuals.modules.cosmetics.AnimatedCosmetics;
import net.minecraft.client.render.entity.feature.CapeFeatureRenderer;
import net.minecraft.client.render.entity.equipment.EquipmentModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(CapeFeatureRenderer.class)
public abstract class AnimatedCapeMixin extends net.minecraft.client.render.entity.feature.FeatureRenderer<PlayerEntityRenderState, net.minecraft.client.render.entity.model.PlayerEntityModel> {
  protected AnimatedCapeMixin(net.minecraft.client.render.entity.feature.FeatureRendererContext<PlayerEntityRenderState, net.minecraft.client.render.entity.model.PlayerEntityModel> context) { super(context); }

  @Shadow private boolean hasCustomModelForLayer(ItemStack stack, EquipmentModel.LayerType type) { throw new AssertionError(); }
  @Inject(method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/PlayerEntityRenderState;FF)V", at = @At("HEAD"), cancellable = true)
  private void visuals$cape(MatrixStack matrices, OrderedRenderCommandQueue queue, int light,
      PlayerEntityRenderState state, float yaw, float pitch, CallbackInfo ci) {
    if(state instanceof pl.xvisuals.gui.screens.WearablePreview)return;
    pl.xvisuals.modules.emote.client.SmokingFeatureRenderer.render(getContextModel(),matrices,queue,light,state,yaw,pitch);
    pl.xvisuals.modules.entity.PlayerAnimations.render(matrices,queue,state);
    pl.xvisuals.modules.cosmetics.Halo.render(matrices, queue, state, getContextModel().head);
    pl.xvisuals.modules.cosmetics.ChinaHat.render(matrices, queue, light, state, getContextModel().head);
    pl.xvisuals.modules.cosmetics.AngelWings.render(matrices, queue, light, state);
    if (!AnimatedCosmetics.applies("capes", state)) return;
    ci.cancel();
    if (!state.capeVisible || hasCustomModelForLayer(state.equippedChestStack, EquipmentModel.LayerType.WINGS)) return;
    AnimatedCosmetics.cape(matrices, queue, light, state,
        hasCustomModelForLayer(state.equippedChestStack, EquipmentModel.LayerType.HUMANOID));
  }
}
