package pl.xvisuals.mixins;
import pl.xvisuals.modules.glint.EnchantGlint;
import net.minecraft.client.render.TextureTransform;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(TextureTransform.class)
public abstract class EnchantGlintTransformMixin {
  @Inject(method="getGlintTransformation",at=@At("HEAD"),cancellable=true)
  private static void visuals$flow(float scale,CallbackInfoReturnable<Matrix4f> cir) {
    if(EnchantGlint.enabled())cir.setReturnValue(EnchantGlint.transform(scale));
  }
}
