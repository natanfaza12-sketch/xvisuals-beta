package pl.xvisuals.mixins;
import pl.xvisuals.menu.GlassMenus;
import pl.xvisuals.gui.components.Glass;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.tooltip.TooltipBackgroundRenderer;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(TooltipBackgroundRenderer.class)
public abstract class TooltipSurfaceMixin {
 @Inject(method="render",at=@At("HEAD"),cancellable=true)
 private static void visuals$surface(DrawContext g,int x,int y,int w,int h,Identifier texture,CallbackInfo ci){
  if(!GlassMenus.active()||texture!=null)return;
  Glass.rounded(g,x-5,y-2,w+12,h+11,5,0x28000000);
  Glass.rounded(g,x-6,y-5,w+12,h+10,5,0x604C5263);
  Glass.gradient(g,x-5,y-4,w+10,h+8,4,0xF0252933,0xF0181B24,"Vertical");
  ci.cancel();
 }
}
