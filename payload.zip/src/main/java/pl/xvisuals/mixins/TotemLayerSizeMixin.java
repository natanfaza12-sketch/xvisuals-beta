package pl.xvisuals.mixins;

import pl.xvisuals.modules.combat.TotemSizing;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemRenderState.LayerRenderState.class)
public abstract class TotemLayerSizeMixin {
  @Shadow @Final private ItemRenderState field_55345;
  @Inject(method="render", at=@At(value="INVOKE", target="Lnet/minecraft/client/render/model/json/Transformation;apply(ZLnet/minecraft/client/util/math/MatrixStack$Entry;)V", shift=At.Shift.AFTER))
  private void visuals$scaleModel(MatrixStack matrices, OrderedRenderCommandQueue queue,
      int light, int overlay, int outline, CallbackInfo ci) {
    float scale=((TotemSizing.State)field_55345).visuals$totemScale();
    if(scale==1)return;
    matrices.translate(.5,.5,.5);
    matrices.scale(scale,scale,scale);
    matrices.translate(-.5,-.5,-.5);
  }
}
