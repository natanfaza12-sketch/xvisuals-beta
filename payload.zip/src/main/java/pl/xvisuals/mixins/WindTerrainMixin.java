package pl.xvisuals.mixins;
import net.fabricmc.fabric.impl.client.indigo.renderer.render.TerrainRenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.*;
import net.minecraft.client.render.model.BlockStateModel;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(value=TerrainRenderContext.class,remap=false)
public abstract class WindTerrainMixin {
 @Unique private BlockState visuals$windState;@Unique private BlockPos visuals$windPos;
 @Inject(method="bufferModel",at=@At("HEAD"))
 private void visuals$plant(BlockStateModel model,BlockState state,BlockPos pos,CallbackInfo ci){visuals$windState=state;visuals$windPos=pos;}
 @Inject(method="getVertexConsumer",at=@At("RETURN"),cancellable=true)
 private void visuals$tag(BlockRenderLayer layer,CallbackInfoReturnable<VertexConsumer> cir){cir.setReturnValue(pl.xvisuals.rendering.WindVertices.wrap(cir.getReturnValue(),visuals$windState,visuals$windPos));}
}
