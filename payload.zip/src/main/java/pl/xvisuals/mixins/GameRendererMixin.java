package pl.xvisuals.mixins;

import pl.xvisuals.XVisuals;
import pl.xvisuals.rendering.shaders.ColorGrade;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.memory.ObjectPool;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
  @Shadow @Final private ObjectPool pool;

  @Inject(method = "render", at = @At("HEAD"))
  private void visuals$begin(RenderTickCounter ticks, boolean tick, CallbackInfo ci) {
    pl.xvisuals.rendering.WindFX.beginFrame();
    pl.xvisuals.menu.SmoothMenuText.beginFrame();
    pl.xvisuals.rendering.Projection.beginFrame();
    pl.xvisuals.rendering.shaders.VolumetricLight.beginFrame();


  }

  @Inject(method = "render", at = @At("TAIL"))
  private void visuals$end(RenderTickCounter ticks, boolean tick, CallbackInfo ci) {







  }

  @Inject(method = "renderWorld", at = @At("TAIL"))
  private void visuals$grade(RenderTickCounter ticks, CallbackInfo ci) {
    // Explosion haze is now textured world geometry.
    if (XVisuals.ready()) ColorGrade.render(pool);
  }

  @ModifyArgs(method = "renderWorld", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/WorldRenderer;render(Lnet/minecraft/client/util/memory/ObjectAllocator;Lnet/minecraft/client/render/RenderTickCounter;ZLnet/minecraft/client/render/Camera;Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lcom/mojang/blaze3d/buffers/GpuBufferSlice;Lorg/joml/Vector4f;Z)V"))
  private void visuals$captureProjection(org.spongepowered.asm.mixin.injection.invoke.arg.Args args) {
    Camera camera = args.get(3);
    pl.xvisuals.rendering.Projection.capture(args.get(4), args.get(5), camera.getCameraPos());
  }

  // World depth is cleared for the hand later in renderWorld; project floor light before that.
  @Inject(method = "renderWorld", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/WorldRenderer;render(Lnet/minecraft/client/util/memory/ObjectAllocator;Lnet/minecraft/client/render/RenderTickCounter;ZLnet/minecraft/client/render/Camera;Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lcom/mojang/blaze3d/buffers/GpuBufferSlice;Lorg/joml/Vector4f;Z)V", shift = At.Shift.AFTER))
  private void visuals$groundWave(RenderTickCounter ticks, CallbackInfo ci) {
    pl.xvisuals.rendering.shaders.DynamicReflections.render(pool);
    pl.xvisuals.rendering.shaders.VolumetricLight.render(pool);
    pl.xvisuals.rendering.shaders.EyeAdaptation.render(pool);
    pl.xvisuals.rendering.shaders.DepthOfField.render(pool);
    pl.xvisuals.rendering.shaders.HeatDistortion.render(pool);
    pl.xvisuals.rendering.shaders.PortalDistortion.render(pool);
    pl.xvisuals.rendering.shaders.RealityGlitch.render(pool);
    pl.xvisuals.rendering.RealisticRain.render(pool);
  }

  @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
  private void visuals$fov(
      Camera camera, float delta, boolean changing, CallbackInfoReturnable<Float> cir) {
    if (XVisuals.ready()) {
      cir.setReturnValue(
          pl.xvisuals.modules.motion.FovMotion.resolve(cir.getReturnValue(), changing)
              + (changing?pl.xvisuals.modules.motion.CameraAnimations.fov():0));
      if (XVisuals.config().on("customfov")) return;
    }
    if (XVisuals.ready() && XVisuals.config().on("lens"))
      cir.setReturnValue(
          (float)
              Math.max(
                  30,
                  Math.min(
                      140,
                      cir.getReturnValue()
                          + XVisuals.config().module("lens").number("fov"))));
  }

  @Inject(
      method = {"bobView", "tiltViewWhenHurt"},
      at = @At("HEAD"),
      cancellable = true)
  private void visuals$steady(MatrixStack matrices, float tick, CallbackInfo ci) {
    if (XVisuals.ready()
        && XVisuals.config().on("lens")
        && XVisuals.config().module("lens").flag("steady")) ci.cancel();
  }
}
