package pl.xvisuals.mixins;

import pl.xvisuals.gui.world.WorldStudio;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import net.minecraft.client.input.MouseInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Routes aimed panel interactions before Minecraft turns them into attacks or item use. */
@Mixin(value = Mouse.class, priority = 1100)
public abstract class WorldStudioInputMixin {
  @Inject(method = "onMouseButton", at = @At("HEAD"), cancellable = true)
  private void visuals$worldPanelClick(
      long window, MouseInput input, int action, CallbackInfo ci) {
    if (window == MinecraftClient.getInstance().getWindow().getHandle()
        && WorldStudio.mouseButton(input, action)) ci.cancel();
  }

  @Inject(method = "onMouseScroll", at = @At("HEAD"), cancellable = true)
  private void visuals$worldPanelScroll(
      long window, double horizontal, double vertical, CallbackInfo ci) {
    if (window == MinecraftClient.getInstance().getWindow().getHandle()
        && WorldStudio.scroll(vertical)) ci.cancel();
  }
}
