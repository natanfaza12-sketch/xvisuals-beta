package pl.xvisuals.mixins;
import pl.xvisuals.rendering.ItemPhysics;
import net.minecraft.client.render.entity.*;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.ItemEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ItemEntityRenderer.class)
public abstract class ItemPhysicsRendererMixin extends EntityRenderer<ItemEntity,ItemEntityRenderState> {
 protected ItemPhysicsRendererMixin(EntityRendererFactory.Context context){super(context);}
 @Inject(method="updateRenderState(Lnet/minecraft/entity/ItemEntity;Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;F)V",at=@At("TAIL"))
 private void visuals$pose(ItemEntity entity,ItemEntityRenderState state,float delta,CallbackInfo ci){ItemPhysics.update(entity,state,delta);}
 @Inject(method="render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",at=@At("HEAD"),cancellable=true)
 private void visuals$render(ItemEntityRenderState state,MatrixStack matrices,OrderedRenderCommandQueue queue,CameraRenderState camera,CallbackInfo ci){
  var pose=((ItemPhysics.State)state).visuals$getPose();
  if(!ItemPhysics.enabled()||pose==null)return;
  if(!state.itemRenderState.isEmpty()){ItemPhysics.render(state,pose,matrices,queue);super.render(state,matrices,queue,camera);}
  ci.cancel();
 }
}
