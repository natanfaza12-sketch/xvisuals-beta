package pl.xvisuals.mixins;
import pl.xvisuals.modules.misc.AutoReconnect;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.GameJoinS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class AutoReconnectJoinMixin {
  @Inject(method="onGameJoin",at=@At("TAIL"))
  private void visuals$joined(GameJoinS2CPacket packet,CallbackInfo ci) {AutoReconnect.joined();}
}
