package pl.xvisuals.mixins;

import pl.xvisuals.gui.world.WorldStudioTexture;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gui.render.GuiRenderer;
import net.minecraft.client.util.Window;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Redirects only this panel's renderer, for the duration of its offscreen render. */
@Mixin(GuiRenderer.class)
public abstract class WorldStudioGuiRendererMixin {
  @Redirect(
      method = "renderPreparedDraws",
      at =
          @At(
              value = "INVOKE",
              target =
                  "Lnet/minecraft/client/MinecraftClient;getFramebuffer()Lnet/minecraft/client/gl/Framebuffer;"))
  private Framebuffer visuals$target(MinecraftClient client) {
    Framebuffer target = WorldStudioTexture.target((GuiRenderer) (Object) this);
    return target == null ? client.getFramebuffer() : target;
  }

  @Redirect(
      method = "renderPreparedDraws",
      at =
          @At(
              value = "INVOKE",
              target = "Lnet/minecraft/client/util/Window;getFramebufferWidth()I"))
  private int visuals$width(Window window) {
    return WorldStudioTexture.target((GuiRenderer) (Object) this) == null
        ? window.getFramebufferWidth()
        : WorldStudioTexture.WIDTH * WorldStudioTexture.SCALE;
  }

  @Redirect(
      method = {"renderPreparedDraws", "enableScissor"},
      at =
          @At(
              value = "INVOKE",
              target = "Lnet/minecraft/client/util/Window;getFramebufferHeight()I"))
  private int visuals$height(Window window) {
    return WorldStudioTexture.target((GuiRenderer) (Object) this) == null
        ? window.getFramebufferHeight()
        : WorldStudioTexture.HEIGHT * WorldStudioTexture.SCALE;
  }

  @Redirect(
      method = {
        "renderPreparedDraws",
        "enableScissor",
        "getWindowScaleFactor",
        "prepareSpecialElements"
      },
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/Window;getScaleFactor()I"))
  private int visuals$scale(Window window) {
    return WorldStudioTexture.target((GuiRenderer) (Object) this) == null
        ? window.getScaleFactor()
        : WorldStudioTexture.SCALE;
  }
}
