package pl.xvisuals.mixins;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import pl.xvisuals.modules.combat.TotemSizing;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemDisplayContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemRenderState.class)
public class TotemSizeStateMixin implements TotemSizing.State {
  @Unique private boolean visuals$totem;
  @Unique private ItemDisplayContext visuals$context = ItemDisplayContext.NONE;

  @Override
  public void visuals$totemContext(boolean totem, ItemDisplayContext context) {
    visuals$totem = totem;
    visuals$context = context;
  }

  @Override
  public boolean visuals$isTotem() { return visuals$totem; }

  @Override
  public float visuals$totemScale() {
    String setting = TotemSizing.setting(visuals$context);
    return visuals$totem && setting != null ? TotemSizing.scale(setting) : 1;
  }

  @Inject(method = "clear", at = @At("TAIL"))
  private void visuals$clear(CallbackInfo ci) {
    visuals$totem = false;
    visuals$context = ItemDisplayContext.NONE;
  }

  @WrapMethod(method = "render")
  private void visuals$renderScaled(MatrixStack matrices, OrderedRenderCommandQueue queue,
      int light, int overlay, int outlineColor, Operation<Void> original) {
    float scale = visuals$totemScale();
    if (scale == 1) {
      original.call(matrices, queue, light, overlay, outlineColor);
      return;
    }
    matrices.push();
    try {
      if (visuals$context == ItemDisplayContext.FIRST_PERSON_LEFT_HAND
          || visuals$context == ItemDisplayContext.FIRST_PERSON_RIGHT_HAND)
        matrices.translate(0, .25f * Math.max(0, 1 - scale), 0);
      original.call(matrices, queue, light, overlay, outlineColor);
    } finally {
      matrices.pop();
    }
  }
}
