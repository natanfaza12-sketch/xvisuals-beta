package pl.xvisuals.mixins;
import net.minecraft.client.texture.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
@Mixin(SpriteContents.class)
public interface FirePlusImageAccessor {@Accessor("mipmapLevelsImages") NativeImage[] fireplus$images();}
