package pl.xvisuals.mixins;

import pl.xvisuals.XVisuals;
import pl.xvisuals.util.Colors;
import net.minecraft.client.render.*;
import net.minecraft.client.render.state.OutlineRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Reuses vanilla's world-space outline pass, including depth, camera bob and shape selection. */
@Mixin(WorldRenderer.class)
public abstract class BlockHighlightMixin {
  @Inject(method="drawBlockOutline",at=@At("HEAD"),cancellable=true)
  private void visuals$outline(MatrixStack matrices,VertexConsumer out,double cameraX,double cameraY,
      double cameraZ,OutlineRenderState state,int originalColor,float originalWidth,CallbackInfo ci) {
    var s=XVisuals.config().module("blocks");
    if(!s.enabled || s.text("mode").equals("Nearby blocks"))return;
    ci.cancel();
    double x=state.pos().getX()-cameraX,y=state.pos().getY()-cameraY,z=state.pos().getZ()-cameraZ;
    float width=(float)s.number("width");
    int color=Colors.alpha(s.color("color"),s.number("opacity"));
    String style=s.text("targetStyle");
    if(style.equals("Glowing")) {
      VertexRendering.drawOutline(matrices,out,state.shape(),x,y,z,Colors.alpha(color,s.number("opacity")*.10),width+3);
      VertexRendering.drawOutline(matrices,out,state.shape(),x,y,z,Colors.alpha(color,s.number("opacity")*.22),width+1.5f);
    }
    if(!style.equals("Corners")) {
      VertexRendering.drawOutline(matrices,out,state.shape(),x,y,z,color,width);return;
    }
    state.shape().forEachEdge((ax,ay,az,bx,by,bz)->{
      double dx=bx-ax,dy=by-ay,dz=bz-az,length=Math.sqrt(dx*dx+dy*dy+dz*dz);
      if(length<1e-6)return;
      double t=length<.22 ? .5 : Math.min(.22,.18/length);
      line(matrices,out,x+ax,y+ay,z+az,x+ax+dx*t,y+ay+dy*t,z+az+dz*t,color,width);
      line(matrices,out,x+bx-dx*t,y+by-dy*t,z+bz-dz*t,x+bx,y+by,z+bz,color,width);
    });
  }
  private static void line(MatrixStack m,VertexConsumer out,double ax,double ay,double az,
      double bx,double by,double bz,int color,float width) {
    float dx=(float)(bx-ax),dy=(float)(by-ay),dz=(float)(bz-az);
    float length=(float)Math.sqrt(dx*dx+dy*dy+dz*dz);if(length<1e-6)return;
    var e=m.peek();
    out.vertex(e,(float)ax,(float)ay,(float)az).color(color).normal(e,dx/length,dy/length,dz/length).lineWidth(width);
    out.vertex(e,(float)bx,(float)by,(float)bz).color(color).normal(e,dx/length,dy/length,dz/length).lineWidth(width);
  }
}
