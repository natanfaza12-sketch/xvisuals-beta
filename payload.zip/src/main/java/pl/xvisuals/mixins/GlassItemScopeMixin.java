package pl.xvisuals.mixins;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import pl.xvisuals.modules.glass.*;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.*;
@Mixin(ItemRenderState.class)
public class GlassItemScopeMixin implements GlassItemOwner {
 @Unique private int visuals$owner=-1;
 public void visuals$glassOwner(int id){visuals$owner=id;}public int visuals$glassOwner(){return visuals$owner;}
 @WrapMethod(method="render") private void visuals$glass(MatrixStack matrices,OrderedRenderCommandQueue queue,int light,int overlay,int outline,Operation<Void> original){int old=GlassMode.enter(GlassMode.owner()<0?visuals$owner:GlassMode.owner());try{original.call(matrices,queue,light,overlay,outline);}finally{GlassMode.restore(old);}}
}
