package pl.xvisuals.mixins;

import pl.xvisuals.modules.combat.HitEffects;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.entity.Entity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ParticleManager.class)
public class CriticalEmitterMixin {
  @Inject(method="addEmitter(Lnet/minecraft/entity/Entity;Lnet/minecraft/particle/ParticleEffect;)V",
      at=@At("HEAD"), cancellable=true)
  private void visuals$crit(Entity entity, ParticleEffect effect, CallbackInfo ci) {
    if(effect.getType()==ParticleTypes.CRIT && HitEffects.replaceCriticalParticles(entity)) ci.cancel();
  }
  @Inject(method="addEmitter(Lnet/minecraft/entity/Entity;Lnet/minecraft/particle/ParticleEffect;I)V",
      at=@At("HEAD"), cancellable=true)
  private void visuals$critAged(Entity entity, ParticleEffect effect, int age, CallbackInfo ci) {
    if(effect.getType()==ParticleTypes.CRIT && HitEffects.replaceCriticalParticles(entity)) ci.cancel();
  }
}
