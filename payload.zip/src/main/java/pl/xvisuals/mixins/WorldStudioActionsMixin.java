package pl.xvisuals.mixins;

import pl.xvisuals.gui.world.WorldStudio;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Also captures held and keyboard-bound actions while the panel owns interaction. */
@Mixin(MinecraftClient.class)
public abstract class WorldStudioActionsMixin {
  @Inject(method = "doAttack", at = @At("HEAD"), cancellable = true)
  private void visuals$worldPanelAttack(CallbackInfoReturnable<Boolean> cir) {
    if (WorldStudio.capturesActions()) cir.setReturnValue(false);
  }

  @Inject(method = "doItemUse", at = @At("HEAD"), cancellable = true)
  private void visuals$worldPanelUse(CallbackInfo ci) {
    if (WorldStudio.capturesActions()) ci.cancel();
  }

  @Inject(method = "handleBlockBreaking", at = @At("HEAD"), cancellable = true)
  private void visuals$worldPanelBreaking(boolean breaking, CallbackInfo ci) {
    if (WorldStudio.capturesActions()) ci.cancel();
  }
}
