package pl.xvisuals.mixins;
import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.world.ClearFluidFog;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.fog.*;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({WaterFogModifier.class,LavaFogModifier.class})
public abstract class ClearFluidFogMixin {
 @Inject(method="applyStartEndModifier",at=@At("TAIL"))
 private void visuals$clearFluidFog(FogData data,Camera camera,ClientWorld world,float distance,RenderTickCounter counter,CallbackInfo ci){
  if(!XVisuals.ready())return;
  String module=(Object)this instanceof WaterFogModifier?"clearwater":"clearlava";
  if(XVisuals.visualModule(module).enabled)ClearFluidFog.apply(data);
 }
}
