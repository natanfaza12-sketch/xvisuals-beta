package pl.xvisuals.mixins;
import pl.xvisuals.modules.misc.AutoReconnect;
import net.minecraft.client.gui.screen.DisconnectedScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.*;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(DisconnectedScreen.class)
public abstract class AutoReconnectScreenMixin extends Screen {
  @Shadow @Final private DirectionalLayoutWidget grid;
  @Unique private TextWidget visuals$countdown;
  @Unique private ButtonWidget visuals$now,visuals$cancel;
  protected AutoReconnectScreenMixin(Text title) {super(title);}

  @Inject(method="init",at=@At("TAIL"))
  private void visuals$controls(CallbackInfo ci) {
    if(!AutoReconnect.enter(this))return;
    var row=DirectionalLayoutWidget.horizontal().spacing(4);
    visuals$now=row.add(ButtonWidget.builder(Text.literal("Reconnect Now"),b->AutoReconnect.reconnect(this,true)).width(112).build());
    visuals$cancel=row.add(ButtonWidget.builder(Text.literal("Cancel Reconnect"),b->{AutoReconnect.cancel();visuals$refresh();}).width(112).build());
    grid.add(row);addDrawableChild(visuals$now);addDrawableChild(visuals$cancel);
    if(AutoReconnect.showCountdown()) {
      visuals$countdown=grid.add(new TextWidget(228,12,Text.empty(),textRenderer));
      addDrawableChild(visuals$countdown);
    }
    visuals$refresh();grid.refreshPositions();refreshWidgetPositions();
  }
  @Override public void tick() {
    super.tick();AutoReconnect.tick(this);visuals$refresh();
  }
  @Override public void removed() {AutoReconnect.left(this);super.removed();}
  @Unique private void visuals$refresh() {
    if(visuals$now==null)return;
    visuals$now.active=AutoReconnect.available();
    visuals$cancel.active=AutoReconnect.available() && AutoReconnect.waiting();
    if(visuals$countdown!=null) {
      visuals$countdown.visible=AutoReconnect.showCountdown();
      visuals$countdown.setMessage(Text.literal(AutoReconnect.waiting()
          ? "Reconnecting in "+AutoReconnect.secondsRemaining()+"s" : "Automatic reconnect stopped"));
    }
  }
}
