package pl.xvisuals.mixins;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.systems.RenderSystem;
import pl.xvisuals.rendering.DimensionSkies;
import net.minecraft.client.render.*;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(WorldRenderer.class)
public abstract class DimensionSkyWorldMixin {
 @Shadow @Final private DefaultFramebufferSet framebufferSet;
 @ModifyVariable(method="render",at=@At("HEAD"),argsOnly=true,ordinal=1)
 private boolean visuals$dimensionSkyEnabled(boolean vanilla){return vanilla||DimensionSkies.active();}
 @Inject(method="renderSky",at=@At("HEAD"),cancellable=true)
 private void visuals$netherSky(FrameGraphBuilder builder,Camera camera,GpuBufferSlice fog,CallbackInfo ci){
  if(!DimensionSkies.active())return;
  var pass=builder.createPass("visuals_dimension_sky");var target=pass.transfer(framebufferSet.mainFramebuffer);framebufferSet.mainFramebuffer=target;
  pass.setRenderer(()->{RenderSystem.setShaderFog(fog);DimensionSkies.render(target.get());});
  ci.cancel();
 }
}
