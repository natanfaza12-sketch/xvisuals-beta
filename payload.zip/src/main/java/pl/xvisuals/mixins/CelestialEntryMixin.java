package pl.xvisuals.mixins;
import pl.xvisuals.menu.CelestialServerScreen;
import pl.xvisuals.menu.ServerArtwork;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.screen.multiplayer.*;
import net.minecraft.client.gui.screen.world.WorldIcon;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.input.KeyInput;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(MultiplayerServerListWidget.ServerEntry.class)
public abstract class CelestialEntryMixin {
  @Shadow @Final private MultiplayerScreen screen;
  @Shadow @Final private ServerInfo server;
  @Shadow @Final private WorldIcon icon;
  @Shadow private byte[] favicon;
  @Shadow protected abstract boolean uploadFavicon(byte[] bytes);
  @Shadow public abstract void saveFile();
  // Vanilla queues its asynchronous ping before this first drawing call.
  @Inject(method="render",at=@At(value="INVOKE",target="Lnet/minecraft/client/gui/DrawContext;drawTextWithShadow(Lnet/minecraft/client/font/TextRenderer;Ljava/lang/String;III)V",ordinal=0),cancellable=true)
  private void visuals$row(DrawContext g,int mx,int my,boolean hovered,float dt,CallbackInfo ci) {
    if(!(screen instanceof CelestialServerScreen s)) return;
    byte[] bytes=server.getFavicon();
    if(!java.util.Arrays.equals(bytes,favicon)) {
      if(uploadFavicon(bytes)) favicon=bytes; else server.setFavicon(null);
      saveFile();
    }
    ServerArtwork.draw(g,(MultiplayerServerListWidget.ServerEntry)(Object)this,s,server,icon.getTextureId(),mx,my);
    ci.cancel();
  }
  @Inject(method="mouseClicked",at=@At("HEAD"),cancellable=true)
  private void visuals$click(Click click,boolean doubled,CallbackInfoReturnable<Boolean> cir) {
    if(screen instanceof CelestialServerScreen s && click.button()==0) {
      var entry=(MultiplayerServerListWidget.ServerEntry)(Object)this;
      double x=click.x()-entry.getX(),y=click.y()-entry.getY()-1;
      if(x>=0 && x<18 && y>=0 && y<32) s.move(entry,y<16?-1:1);
      else s.select(entry,doubled || x>=20 && x<52 && y>=0 && y<32);
      cir.setReturnValue(true);
    }
  }
  @Inject(method="keyPressed",at=@At("HEAD"),cancellable=true)
  private void visuals$key(KeyInput key,CallbackInfoReturnable<Boolean> cir) {
    if(screen instanceof CelestialServerScreen s && key.hasShift() && (key.key()==264 || key.key()==265)) {
      s.move((MultiplayerServerListWidget.ServerEntry)(Object)this,key.key()==265?-1:1);
      cir.setReturnValue(true);
    }
  }
  @Inject(method="swapEntries",at=@At("RETURN"))
  private void visuals$reordered(int from,int to,CallbackInfo ci) {
    if(screen instanceof CelestialServerScreen s) s.syncEntries();
  }
}
