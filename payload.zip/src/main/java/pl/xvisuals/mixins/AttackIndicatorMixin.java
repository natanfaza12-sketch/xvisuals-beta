package pl.xvisuals.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import pl.xvisuals.modules.combat.AttackIndicator;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/** Suppress vanilla's indicator only while our replacement is enabled; never change saved options. */
@Mixin(InGameHud.class)
public class AttackIndicatorMixin {
  @ModifyExpressionValue(method={"renderCrosshair", "renderHotbar"}, at=@At(value="INVOKE",
      target="Lnet/minecraft/client/option/SimpleOption;getValue()Ljava/lang/Object;"))
  private Object visuals$indicator(Object original) {
    return original instanceof net.minecraft.client.option.AttackIndicator && AttackIndicator.enabled()
        ? net.minecraft.client.option.AttackIndicator.OFF : original;
  }
}
