package pl.xvisuals.mixins;

import pl.xvisuals.XVisuals;
import pl.xvisuals.menu.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {
  @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
  private Screen visuals$screen(Screen screen) {
    pl.xvisuals.modules.misc.AutoReconnect.screenChanged(screen);
    if (!XVisuals.ready() || !XVisuals.config().on("menu")) return screen;
    var menu = XVisuals.config().module("menu");
    if (screen != null && screen.getClass() == net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen.class && menu.flag("glassPages"))
      return new CelestialServerScreen(((MultiplayerParentAccessor) screen).visuals$parent());
    if (screen instanceof GameMenuScreen pause && pause.shouldShowMenu() && menu.flag("pause"))
      return new XPauseScreen();
    return screen;
  }

  @Inject(method="disconnect(Lnet/minecraft/text/Text;)V",at=@At("HEAD"))
  private void visuals$manualDisconnect(net.minecraft.text.Text reason,
      org.spongepowered.asm.mixin.injection.callback.CallbackInfo ci) {
    pl.xvisuals.modules.misc.AutoReconnect.cancel();
  }
}
