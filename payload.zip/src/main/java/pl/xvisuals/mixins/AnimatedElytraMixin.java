package pl.xvisuals.mixins;

import pl.xvisuals.modules.cosmetics.AnimatedCosmetics;
import pl.xvisuals.XVisuals;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.entity.feature.ElytraFeatureRenderer;
import net.minecraft.client.render.entity.state.*;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ElytraFeatureRenderer.class)
public class AnimatedElytraMixin {
  @ModifyVariable(method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/BipedEntityRenderState;FF)V", at = @At("HEAD"), argsOnly = true, ordinal = 0)
  private int visuals$light(int value, MatrixStack matrices, OrderedRenderCommandQueue queue, int light,
      BipedEntityRenderState state, float yaw, float pitch) {
    return AnimatedCosmetics.wingSettings(state) != null
        && AnimatedCosmetics.wingSettings(state).flag("bright")
        ? LightmapTextureManager.MAX_LIGHT_COORDINATE : value;
  }
  @Inject(method = "getTexture", at = @At("HEAD"), cancellable = true)
  private static void visuals$texture(BipedEntityRenderState state, CallbackInfoReturnable<Identifier> cir) {
    Identifier texture = AnimatedCosmetics.wings(state);
    if (texture != null) cir.setReturnValue(texture);
  }
}
