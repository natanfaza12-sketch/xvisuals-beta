package pl.xvisuals.mixins;
import pl.xvisuals.modules.pets.PetDeathScene;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(GameRenderer.class)
public class PetDeathViewMixin {
 @Inject(method={"renderHand","tiltViewWhenHurt","bobView"},at=@At("HEAD"),cancellable=true)
 private void visuals$steadyPetCamera(CallbackInfo ci){if(PetDeathScene.active())ci.cancel();}
}
