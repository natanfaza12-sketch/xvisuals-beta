package pl.xvisuals.mixins;

import pl.xvisuals.modules.motion.SwingMotion;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public abstract class SwingRendererMixin {
  @Inject(
      method =
          "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V",
      at = @At("HEAD"))
  private void visuals$frame(CallbackInfo ci) {
    SwingMotion.frame();
  }

  @ModifyVariable(method = "renderFirstPersonItem", at = @At("HEAD"), argsOnly = true, ordinal = 2)
  private float visuals$progress(
      float value,
      AbstractClientPlayerEntity player,
      float tick,
      float pitch,
      Hand hand,
      float swing,
      net.minecraft.item.ItemStack item,
      float equip,
      MatrixStack matrices,
      net.minecraft.client.render.command.OrderedRenderCommandQueue queue,
      int light) {
    pl.xvisuals.modules.motion.SwingAfterimages.hand(hand);
    return SwingMotion.progress(hand, value);
  }

  @ModifyVariable(
      method =
          "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V",
      at = @At("HEAD"),
      argsOnly = true)
  private net.minecraft.client.render.command.OrderedRenderCommandQueue visuals$trail(
      net.minecraft.client.render.command.OrderedRenderCommandQueue queue) {
    return pl.xvisuals.modules.motion.SwingAfterimages.begin(queue);
  }

  @Inject(
      method =
          "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V",
      at = @At("TAIL"))
  private void visuals$trailEnd(CallbackInfo ci) {
    pl.xvisuals.modules.motion.SwingAfterimages.end();
  }

  @Inject(method = "renderArmHoldingItem", at = @At("HEAD"))
  private void visuals$hand(
      MatrixStack matrices,
      net.minecraft.client.render.command.OrderedRenderCommandQueue queue,
      int light,
      float equip,
      float swing,
      Arm arm,
      CallbackInfo ci) {
    if (SwingMotion.customActive())
      SwingMotion.transform(matrices, arm);
  }

  @ModifyVariable(method = "renderArmHoldingItem", at = @At("HEAD"), argsOnly = true, ordinal = 1)
  private float visuals$handProgress(float progress) {
    return SwingMotion.customActive() ? 0 : progress;
  }

  @Inject(method = "swingArm", at = @At("HEAD"), cancellable = true)
  private void visuals$transform(
      float progress, MatrixStack matrices, int sign, Arm arm, CallbackInfo ci) {
    if (SwingMotion.transform(matrices, arm)) ci.cancel();
  }
}
