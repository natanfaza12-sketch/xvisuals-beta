package pl.xvisuals.mixins;

import pl.xvisuals.modules.motion.SwingMotion;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public abstract class SwingTriggerMixin {
  @org.spongepowered.asm.mixin.Unique private boolean visuals$wasSwinging;
  @org.spongepowered.asm.mixin.Unique private int visuals$beforeTicks;
  @Inject(method = "swingHand", at = @At("HEAD"))
  private void visuals$beforeSwing(Hand hand,CallbackInfo ci) {
    var player=(ClientPlayerEntity)(Object)this;
    visuals$wasSwinging=player.handSwinging;visuals$beforeTicks=player.handSwingTicks;
  }
  @Inject(method = "swingHand", at = @At("TAIL"))
  private void visuals$swing(Hand hand, CallbackInfo ci) {
    var player=(ClientPlayerEntity)(Object)this;
    if(pl.xvisuals.modules.motion.SwingGate.accepted(visuals$wasSwinging,visuals$beforeTicks,player.handSwinging,player.handSwingTicks))
      SwingMotion.trigger(hand);
  }
}
