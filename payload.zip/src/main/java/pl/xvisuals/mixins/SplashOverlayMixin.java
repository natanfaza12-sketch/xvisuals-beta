package pl.xvisuals.mixins;

import pl.xvisuals.XVisuals;
import pl.xvisuals.menu.LaunchArtwork;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.SplashOverlay;
import net.minecraft.resource.ResourceReload;
import net.minecraft.util.Util;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Replaces artwork only. Vanilla tick still completes reloads and routes every reload failure. */
@Mixin(SplashOverlay.class)
public abstract class SplashOverlayMixin {
  @Shadow @Final private MinecraftClient client;
  @Shadow @Final private ResourceReload reload;
  @Shadow @Final private boolean reloading;
  @Shadow private float progress;
  @Shadow private long reloadCompleteTime;
  @Shadow private long reloadStartTime;
  @Unique private long visuals$opened;
  @Unique private long visuals$previous;
  @Unique private long visuals$finished = -1;

  // not final, not initialized inline: Mixin's constructor-splice for a @Unique
  // field initializer isn't reliably running before render() fires on this
  // target (observed: NPE on first use, every launch) -- lazily created in
  // visuals$loading instead of trusting the splice timing
  @Unique
  private pl.xvisuals.menu.LoadingProgress visuals$progress;

  @Inject(method = "render", at = @At("HEAD"), cancellable = true)
  private void visuals$loading(DrawContext g, int mx, int my, float dt, CallbackInfo ci) {
    if (XVisuals.ready()
        && (!XVisuals.config().on("menu")
            || !XVisuals.config().module("menu").flag("loading"))) return;
    if (visuals$progress == null) visuals$progress = new pl.xvisuals.menu.LoadingProgress(6);
    long now = Util.getMeasuringTimeMs();
    if (visuals$opened == 0) visuals$opened = now;
    if (reloading && reloadStartTime == -1) reloadStartTime = now;
    float finish = visuals$finished >= 0 ? (now - visuals$finished) / 1000f : -1;
    double seconds = (now - visuals$opened) / 1000.0;
    float alpha =
        finish >= .8f
            ? 1 - pl.xvisuals.menu.LoadingProgress.fade((finish - .8) / .65)
            : reloading ? pl.xvisuals.menu.LoadingProgress.fade(seconds / .25) : 1;
    // fades the screen behind the splash in early, before vanilla's own resource
    // reload (which this overlay exists to gate) is guaranteed done -- some
    // render paths (observed: Sodium panorama shader setup) aren't ready yet at
    // this point and throw. it's a cosmetic fade-in frame, not worth a crash.
    if (alpha < 1 && client.currentScreen != null) {
      try {
        client.currentScreen.renderWithTooltip(g, mx, my, dt);
      } catch (Exception ignored) {}
    }
    float actual = Math.max(0, Math.min(1, reload.getProgress()));
    double elapsed = visuals$previous == 0 ? 0 : (now - visuals$previous) / 1000.0;
    visuals$previous = now;
    boolean complete = reload.isComplete() && reloadCompleteTime >= 0;
    progress = visuals$progress.update(actual, complete, elapsed);
    if (complete && progress == 1 && visuals$finished < 0) visuals$finished = now;
    LaunchArtwork.draw(g, progress, alpha, seconds, reloading, complete);


    if (finish >= 1.45f && client.getOverlay() == (Object) this) client.setOverlay(null);
    ci.cancel();
  }
}
