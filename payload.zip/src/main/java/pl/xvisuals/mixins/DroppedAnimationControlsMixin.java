package pl.xvisuals.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import pl.xvisuals.modules.motion.AnimationControls;
import net.minecraft.client.render.entity.ItemEntityRenderer;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemEntityRenderer.class)
public abstract class DroppedAnimationControlsMixin {
  @ModifyExpressionValue(method="render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",at=@At(value="INVOKE",target="Lnet/minecraft/entity/ItemEntity;getRotation(FF)F"))
  private float visuals$spin(float value){return AnimationControls.vanillaDrops()?value*(float)AnimationControls.number("itemphysics","vanillaSpin",1):value;}
  @ModifyExpressionValue(method="render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",at=@At(value="INVOKE",target="Lnet/minecraft/util/math/MathHelper;sin(D)F"))
  private float visuals$bob(float value){return AnimationControls.vanillaDrops()?value*(float)AnimationControls.number("itemphysics","vanillaBob",1):value;}
  @Inject(method="render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",at=@At(value="INVOKE",target="Lnet/minecraft/client/render/entity/ItemEntityRenderer;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/ItemStackEntityRenderState;Lnet/minecraft/util/math/random/Random;Lnet/minecraft/util/math/Box;)V"))
  private void visuals$scale(ItemEntityRenderState state,MatrixStack matrices,OrderedRenderCommandQueue queue,CameraRenderState camera,CallbackInfo ci){
    if(AnimationControls.vanillaDrops()){float scale=(float)AnimationControls.number("itemphysics","scale",1);matrices.scale(scale,scale,scale);}
  }
}
