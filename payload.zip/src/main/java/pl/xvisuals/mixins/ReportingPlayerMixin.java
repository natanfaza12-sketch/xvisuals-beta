package pl.xvisuals.mixins;

import java.util.List;
import net.minecraft.client.gui.screen.multiplayer.SocialInteractionsPlayerListEntry;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SocialInteractionsPlayerListEntry.class)
public abstract class ReportingPlayerMixin {
  @Shadow private ButtonWidget reportButton;
  @Shadow @Final private List<ClickableWidget> buttons;
  @Shadow private boolean hasDraftReport;
  @Inject(method = {"<init>", "setShowButtonVisible"}, at = @At("TAIL"))
  private void visuals$removeReport(CallbackInfo ci) {
    if (reportButton != null) {
      reportButton.visible = false; reportButton.active = false;
      buttons.remove(reportButton);
    }
    hasDraftReport = false;
  }
  @Inject(method = "updateHasDraftReport", at = @At("TAIL"))
  private void visuals$hideDraft(CallbackInfo ci) { hasDraftReport = false; }
}
