package pl.xvisuals.mixins;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.TextureFormat;
import net.minecraft.client.font.TextDrawable;
import net.minecraft.client.gui.render.state.GlyphGuiElementRenderState;
import net.minecraft.client.texture.TextureSetup;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** GUI glyphs otherwise force nearest sampling, dropping thin strokes when scaled down. */
@Mixin(GlyphGuiElementRenderState.class)
public abstract class FontFilteringMixin {
  @Shadow public abstract TextDrawable renderable();

  @org.spongepowered.asm.mixin.Unique
  private boolean visuals$isChoice() {
    var view=renderable().textureView();
    return view!=null && view.texture().getFormat()==TextureFormat.RED8
        && pl.xvisuals.gui.FontMaterial.contains(view.texture());
  }

  @Inject(method="pipeline", at=@At("HEAD"), cancellable=true)
  private void visuals$coverage(CallbackInfoReturnable<com.mojang.blaze3d.pipeline.RenderPipeline> cir) {
    if(visuals$isChoice())cir.setReturnValue(pl.xvisuals.gui.FontMaterial.PIPELINE);
  }

  @Inject(method="textureSetup", at=@At("HEAD"), cancellable=true)
  private void visuals$smoothChoices(CallbackInfoReturnable<TextureSetup> cir) {
    var view=renderable().textureView();
    if(visuals$isChoice()) {
      cir.setReturnValue(TextureSetup.withLightmap(view,
          RenderSystem.getSamplerCache().get(FilterMode.LINEAR)));
    }
  }
}
