package pl.xvisuals.mixins;

import pl.xvisuals.gui.world.WorldStudio;
import net.minecraft.client.Keyboard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Leaves gameplay keys alone unless the world panel explicitly consumes them. */
@Mixin(Keyboard.class)
public abstract class WorldStudioKeyboardMixin {
  @Inject(method = "onKey", at = @At("HEAD"), cancellable = true)
  private void visuals$worldPanelKey(
      long window, int action, KeyInput input, CallbackInfo ci) {
    if (window == MinecraftClient.getInstance().getWindow().getHandle()
        && WorldStudio.key(input, action)) ci.cancel();
  }

  @Inject(method = "onChar", at = @At("HEAD"), cancellable = true)
  private void visuals$worldPanelCharacter(long window, CharInput input, CallbackInfo ci) {
    if (window == MinecraftClient.getInstance().getWindow().getHandle()
        && WorldStudio.character(input)) ci.cancel();
  }
}
