package pl.xvisuals.mixins;

import pl.xvisuals.XVisuals;
import net.minecraft.client.render.WeatherRendering;
import net.minecraft.client.render.state.WeatherRenderState;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WeatherRendering.class)
public abstract class WeatherMixin {
  @Inject(method="renderPrecipitation", at=@At("HEAD"))
  private void visuals$streaks(net.minecraft.client.render.VertexConsumerProvider buffers, Vec3d camera, WeatherRenderState state, CallbackInfo ci){
    pl.xvisuals.rendering.RealisticRain.renderStreaks(buffers,camera);
  }

  @Inject(method = "addParticlesAndSound", at = @At("HEAD"), cancellable = true)
  private void visuals$replaceSplashes(CallbackInfo ci) {
    if (pl.xvisuals.rendering.EnhancedWeather.replaces(
        net.minecraft.client.MinecraftClient.getInstance().world)) ci.cancel();
  }

  @Inject(method = "buildPrecipitationPieces", at = @At("TAIL"))
  private void visuals$weather(
      World world,
      int ticks,
      float delta,
      Vec3d camera,
      WeatherRenderState state,
      CallbackInfo ci) {
    if (pl.xvisuals.rendering.EnhancedWeather.replaces(world)) {
      state.rainPieces.clear();
      state.snowPieces.clear();
      return;
    }
    if (!XVisuals.ready() || !XVisuals.config().on("weatherfx")) return;
    var s = XVisuals.config().module("weatherfx");
    if (s.text("weather").equals("Snow") || s.text("weather").equals("Blizzard")) {
      state.snowPieces.addAll(state.rainPieces);
      state.rainPieces.clear();
    } else if (s.text("weather").equals("Rain") || s.text("weather").equals("Storm")) {
      state.rainPieces.addAll(state.snowPieces);
      state.snowPieces.clear();
    }
    state.intensity *= (float) s.number("intensity");
  }
}
