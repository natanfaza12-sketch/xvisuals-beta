package pl.xvisuals.mixins;
import pl.xvisuals.gui.ShulkerPreview;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.screen.slot.Slot;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;

@Mixin(HandledScreen.class)
public abstract class ShulkerPreviewMixin extends Screen {
 @Shadow protected Slot focusedSlot;
 @Unique private final ShulkerPreview visuals$preview=new ShulkerPreview();
 protected ShulkerPreviewMixin(Text title){super(title);}
 @Inject(method="drawMouseoverTooltip",at=@At("HEAD"),cancellable=true)
 private void visuals$preview(DrawContext g,int mx,int my,CallbackInfo ci){
  if(visuals$preview.render(g,focusedSlot,mx,my,width,height,((HandledScreen<?>)(Object)this).getScreenHandler().getCursorStack().isEmpty()))ci.cancel();
 }
 @Inject(method="mouseClicked",at=@At("HEAD"),cancellable=true)
 private void visuals$click(Click click,boolean doubled,CallbackInfoReturnable<Boolean> ci){if(visuals$preview.blocksInput(click.x(),click.y()))ci.setReturnValue(true);}
 @Inject(method="mouseDragged",at=@At("HEAD"),cancellable=true)
 private void visuals$drag(Click click,double x,double y,CallbackInfoReturnable<Boolean> ci){if(visuals$preview.blocksInput(click.x(),click.y()))ci.setReturnValue(true);}
 @Inject(method="mouseReleased",at=@At("HEAD"),cancellable=true)
 private void visuals$release(Click click,CallbackInfoReturnable<Boolean> ci){if(visuals$preview.blocksInput(click.x(),click.y()))ci.setReturnValue(true);}
 @Inject(method="mouseScrolled",at=@At("HEAD"),cancellable=true)
 private void visuals$scroll(double x,double y,double horizontal,double vertical,CallbackInfoReturnable<Boolean> ci){if(visuals$preview.blocksInput(x,y))ci.setReturnValue(true);}
 @Inject(method="keyPressed",at=@At("HEAD"),cancellable=true)
 private void visuals$key(KeyInput key,CallbackInfoReturnable<Boolean> ci){if(key.key()!=256&&visuals$preview.blocksInput())ci.setReturnValue(true);}
}
