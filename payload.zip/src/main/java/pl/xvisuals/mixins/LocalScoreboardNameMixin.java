package pl.xvisuals.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import pl.xvisuals.modules.cosmetics.LocalAppearance;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.text.Text;
import net.minecraft.text.MutableText;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/** Substitute render-local text before its width is measured; never change score owners. */
@Mixin(InGameHud.class)
public abstract class LocalScoreboardNameMixin {
 @ModifyExpressionValue(method="renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V",at=@At(value="INVOKE",target="Lnet/minecraft/scoreboard/ScoreboardObjective;getDisplayName()Lnet/minecraft/text/Text;"))
 private Text visuals$sidebarTitle(Text text){return LocalAppearance.protectText(text);}

 @ModifyExpressionValue(method="method_55439",at=@At(value="INVOKE",target="Lnet/minecraft/scoreboard/Team;decorateName(Lnet/minecraft/scoreboard/AbstractTeam;Lnet/minecraft/text/Text;)Lnet/minecraft/text/MutableText;"))
 private MutableText visuals$sidebarRow(MutableText text){return LocalAppearance.protectText(text).copy();}

 @ModifyExpressionValue(method="method_55439",at=@At(value="INVOKE",target="Lnet/minecraft/scoreboard/ScoreboardEntry;formatted(Lnet/minecraft/scoreboard/number/NumberFormat;)Lnet/minecraft/text/MutableText;"))
 private MutableText visuals$sidebarScore(MutableText text){return LocalAppearance.protectText(text).copy();}
}
