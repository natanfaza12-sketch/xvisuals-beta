package pl.xvisuals.mixins;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import pl.xvisuals.menu.GlassMenus;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(DrawContext.class)
public abstract class GlassWidgetsMixin {
  @ModifyVariable(method = "drawGuiTexture(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/util/Identifier;IIIII)V",
      at = @At("HEAD"), argsOnly = true, ordinal = 4)
  private int visuals$slotPlaceholder(int color, RenderPipeline pipeline, Identifier texture,
      int x, int y, int w, int h, int tint) {
    if (GlassMenus.active() && texture.getNamespace().equals("minecraft") && texture.getPath().startsWith("container/slot/"))
      return (Math.round((color >>> 24) * .4f) << 24) | 0x9B8DAD;
    return color;
  }
  @ModifyVariable(method = "drawTexture(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/util/Identifier;IIFFIIIIIII)V",
      at = @At("HEAD"), argsOnly = true)
  private RenderPipeline visuals$container(RenderPipeline pipeline, RenderPipeline original, Identifier texture,
      int x, int y, float u, float v, int w, int h, int regionW, int regionH, int textureW, int textureH, int color) {
    if (GlassMenus.active() && texture.getNamespace().equals("minecraft")
        && texture.getPath().startsWith("textures/gui/container/"))
      return pl.xvisuals.menu.GlassContainerMaterial.PIPELINE;
    return pipeline;
  }

  @ModifyVariable(method = {"drawText(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/Text;IIIZ)V",
      "drawText(Lnet/minecraft/client/font/TextRenderer;Ljava/lang/String;IIIZ)V",
      "drawText(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/OrderedText;IIIZ)V"},
      at = @At("HEAD"), argsOnly = true, ordinal = 2)
  private int visuals$containerText(int color) {
    if (GlassMenus.active()
        && net.minecraft.client.MinecraftClient.getInstance().currentScreen instanceof net.minecraft.client.gui.screen.ingame.HandledScreen<?>
        && (color & 0xFFFFFF) == 0x404040) return 0xFFE2DFF4;
    return color;
  }

  @Inject(method = "drawGuiTexture(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/util/Identifier;IIIII)V",
      at = @At("HEAD"), cancellable = true)
  private void visuals$sprite(RenderPipeline pipeline, Identifier texture, int x, int y, int w, int h,
      int color, CallbackInfo ci) {
    if (GlassMenus.sprite((DrawContext) (Object) this, texture, x, y, w, h, color)) ci.cancel();
  }
}
