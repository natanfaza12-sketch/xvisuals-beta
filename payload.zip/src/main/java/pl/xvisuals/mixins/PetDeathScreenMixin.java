package pl.xvisuals.mixins;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(MinecraftClient.class)
public class PetDeathScreenMixin {
 @Inject(method="setScreen",at=@At("HEAD"),cancellable=true)
 private void visuals$petFarewell(Screen screen,CallbackInfo ci){if(pl.xvisuals.modules.pets.PetDeathScene.intercept(screen))ci.cancel();}
}
