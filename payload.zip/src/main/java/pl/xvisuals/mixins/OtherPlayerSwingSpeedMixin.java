package pl.xvisuals.mixins;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import pl.xvisuals.modules.motion.AnimationControls;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
@Mixin(LivingEntity.class)
public abstract class OtherPlayerSwingSpeedMixin {
  @ModifyReturnValue(method="getHandSwingDuration",at=@At("RETURN"))
  private int visuals$remoteSpeed(int ticks){
    Object entity=this;
    if(entity!=MinecraftClient.getInstance().player && entity instanceof AbstractClientPlayerEntity && AnimationControls.flag("swingspeed","others",false))
      return Math.max(1,Math.round(ticks/(float)AnimationControls.number("swingspeed","speed",1)));
    return ticks;
  }
}
