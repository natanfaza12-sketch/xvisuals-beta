package pl.xvisuals.mixins;

import com.llamalad7.mixinextras.injector.wrapoperation.*;
import com.llamalad7.mixinextras.sugar.Local;
import pl.xvisuals.modules.armor.ArmorFXRenderer;
import net.minecraft.client.model.Model;
import net.minecraft.client.render.*;
import net.minecraft.client.render.command.*;
import net.minecraft.client.render.entity.equipment.*;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.equipment.EquipmentAsset;
import net.minecraft.registry.RegistryKey;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** 1.21.11 EquipmentRenderer: wrap only base, single glint and native trim submissions.
 * The caller already selected the correct slot model. The queued model/state and sprite stay intact.
 * No other Visual Client mixin targets this class. Optional injections permit safe vanilla fallback.
 */
@Mixin(EquipmentRenderer.class)
public class ArmorFXEquipmentMixin {
 private static final String R="render(Lnet/minecraft/client/render/entity/equipment/EquipmentModel$LayerType;Lnet/minecraft/registry/RegistryKey;Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/util/Identifier;II)V";
 private static final String SUBMIT="Lnet/minecraft/client/render/command/RenderCommandQueue;submitModel(Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/RenderLayer;IIILnet/minecraft/client/texture/Sprite;ILnet/minecraft/client/render/command/ModelCommandRenderer$CrumblingOverlayCommand;)V";
 @Inject(method=R,at=@At("HEAD"),require=0) private void armorfx$enter(CallbackInfo ci){ArmorFXRenderer.clear();}
 @Inject(method=R,at=@At("RETURN"),require=0) private void armorfx$exit(CallbackInfo ci){ArmorFXRenderer.clear();}
 @WrapOperation(method=R,at=@At(value="INVOKE",target=SUBMIT,ordinal=0),require=0)
 private void armorfx$base(RenderCommandQueue q,Model<?> m,Object s,MatrixStack x,RenderLayer l,int light,int overlay,int color,Sprite sprite,int outline,ModelCommandRenderer.CrumblingOverlayCommand cr,Operation<Void> op,
  @Local(argsOnly=true) ItemStack stack,@Local(argsOnly=true) EquipmentModel.LayerType type,@Local(argsOnly=true) RegistryKey<EquipmentAsset> asset){
  if(!ArmorFXRenderer.submit(0,q,m,s,x,l,light,overlay,color,sprite,outline,cr,stack,type,asset))op.call(q,m,s,x,l,light,overlay,color,sprite,outline,cr);
 }
 @WrapOperation(method=R,at=@At(value="INVOKE",target=SUBMIT,ordinal=1),require=0)
 private void armorfx$glint(RenderCommandQueue q,Model<?> m,Object s,MatrixStack x,RenderLayer l,int light,int overlay,int color,Sprite sprite,int outline,ModelCommandRenderer.CrumblingOverlayCommand cr,Operation<Void> op,
  @Local(argsOnly=true) ItemStack stack,@Local(argsOnly=true) EquipmentModel.LayerType type,@Local(argsOnly=true) RegistryKey<EquipmentAsset> asset){
  if(!ArmorFXRenderer.submit(1,q,m,s,x,l,light,overlay,color,sprite,outline,cr,stack,type,asset))op.call(q,m,s,x,l,light,overlay,color,sprite,outline,cr);
 }
 @WrapOperation(method=R,at=@At(value="INVOKE",target=SUBMIT,ordinal=2),require=0)
 private void armorfx$trim(RenderCommandQueue q,Model<?> m,Object s,MatrixStack x,RenderLayer l,int light,int overlay,int color,Sprite sprite,int outline,ModelCommandRenderer.CrumblingOverlayCommand cr,Operation<Void> op,
  @Local(argsOnly=true) ItemStack stack,@Local(argsOnly=true) EquipmentModel.LayerType type,@Local(argsOnly=true) RegistryKey<EquipmentAsset> asset){
  if(!ArmorFXRenderer.submit(2,q,m,s,x,l,light,overlay,color,sprite,outline,cr,stack,type,asset))op.call(q,m,s,x,l,light,overlay,color,sprite,outline,cr);
 }
}
