package pl.xvisuals.mixins;

import pl.xvisuals.XVisuals;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(World.class)
public abstract class WorldMixin {
  private boolean visuals$active() {
    return (Object) this instanceof ClientWorld
        && XVisuals.ready()
        && XVisuals.config().on("atmosphere");
  }

  @Inject(method = "getTimeOfDay", at = @At("HEAD"), cancellable = true)
  private void visuals$time(CallbackInfoReturnable<Long> cir) {
    if (visuals$active() && XVisuals.config().module("atmosphere").flag("timeOverride"))
      cir.setReturnValue((long) XVisuals.config().module("atmosphere").number("time"));
  }

  @Inject(method = "getRainGradient", at = @At("HEAD"), cancellable = true)
  private void visuals$rain(float delta, CallbackInfoReturnable<Float> cir) {
    if(pl.xvisuals.rendering.WeatherTransitions.sampling())return;
    if((Object)this instanceof ClientWorld && pl.xvisuals.rendering.WeatherTransitions.overrides()){
      cir.setReturnValue(pl.xvisuals.rendering.WeatherTransitions.rain());return;
    }
    String mode = visuals$weather();
    if (!mode.equals("Server")) cir.setReturnValue(mode.equals("Clear") ? 0f : 1f);
  }

  @Inject(method = "getThunderGradient", at = @At("HEAD"), cancellable = true)
  private void visuals$thunder(float delta, CallbackInfoReturnable<Float> cir) {
    if(pl.xvisuals.rendering.WeatherTransitions.sampling())return;
    if((Object)this instanceof ClientWorld && pl.xvisuals.rendering.WeatherTransitions.overrides()){
      cir.setReturnValue(pl.xvisuals.rendering.WeatherTransitions.thunder());return;
    }
    String mode = visuals$weather();
    if (!mode.equals("Server")) cir.setReturnValue(mode.equals("Storm") ? 1f : 0f);
  }

  private String visuals$weather() {
    if (!((Object) this instanceof ClientWorld) || !XVisuals.ready()) return "Server";
    if (XVisuals.config().on("weatherfx"))
      return XVisuals.config().module("weatherfx").text("weather");
    return visuals$active()
        ? XVisuals.config().module("atmosphere").text("weather")
        : "Server";
  }
}
