package pl.xvisuals.mixins;
import pl.xvisuals.modules.pickaxes.CustomPickaxes;
import net.minecraft.client.item.ItemModelManager;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(ItemModelManager.class)
public class PickaxeItemMixin {
 @ModifyVariable(method="update",at=@At("HEAD"),argsOnly=true,ordinal=0)
 private ItemStack visuals$pickaxe(ItemStack stack){return CustomPickaxes.appearance(stack);}
}
