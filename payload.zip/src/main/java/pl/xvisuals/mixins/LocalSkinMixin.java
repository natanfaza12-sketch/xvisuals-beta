package pl.xvisuals.mixins;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.SkinTextures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(AbstractClientPlayerEntity.class)
public abstract class LocalSkinMixin {
  @Inject(method="getSkin",at=@At("RETURN"),cancellable=true)
  private void visuals$skin(CallbackInfoReturnable<SkinTextures> cir){
    if(pl.xvisuals.XVisuals.ready() && (Object)this==MinecraftClient.getInstance().player)
      cir.setReturnValue(pl.xvisuals.modules.cosmetics.LocalAppearance.skin(cir.getReturnValue()));
  }
}
