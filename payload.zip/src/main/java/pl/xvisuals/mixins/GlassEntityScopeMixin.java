package pl.xvisuals.mixins;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import pl.xvisuals.modules.glass.GlassMode;
import net.minecraft.client.render.entity.EntityRenderManager;
import net.minecraft.client.render.entity.state.*;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(EntityRenderManager.class)
public class GlassEntityScopeMixin {
 @WrapMethod(method="render") private void visuals$glass(EntityRenderState state,CameraRenderState camera,double x,double y,double z,MatrixStack matrices,OrderedRenderCommandQueue queue,Operation<Void> original){int old=GlassMode.enter(state instanceof PlayerEntityRenderState p&&!p.invisible&&!p.spectator?p.id:-3);try{original.call(state,camera,x,y,z,matrices,queue);}finally{GlassMode.restore(old);}}
}
