package pl.xvisuals.mixins;
import pl.xvisuals.modules.misc.AutoReconnect;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.network.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ConnectScreen.class)
public abstract class AutoReconnectConnectMixin {
  @Inject(method="connect(Lnet/minecraft/client/gui/screen/Screen;Lnet/minecraft/client/MinecraftClient;Lnet/minecraft/client/network/ServerAddress;Lnet/minecraft/client/network/ServerInfo;ZLnet/minecraft/client/network/CookieStorage;)V",at=@At("HEAD"))
  private static void visuals$remember(Screen parent,MinecraftClient client,ServerAddress address,
      ServerInfo info,boolean quickPlay,CookieStorage cookies,CallbackInfo ci) {
    AutoReconnect.capture(parent,address,info);
  }
}
