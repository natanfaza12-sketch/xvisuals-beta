package pl.xvisuals.mixins;

import pl.xvisuals.hud.ChatHudEditor;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;

@Mixin(ChatScreen.class)
public abstract class ChatScreenMixin extends Screen {
  @Unique private final ChatHudEditor visuals$editor = new ChatHudEditor();

  protected ChatScreenMixin(Text title) {
    super(title);
  }

  @Inject(method = "render", at = @At("TAIL"))
  private void visuals$render(DrawContext g, int x, int y, float dt, CallbackInfo ci) {
    visuals$editor.render(g, x, y);
  }

  @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
  private void visuals$click(Click click, boolean twice, CallbackInfoReturnable<Boolean> cir) {
    if (visuals$editor.click(click.x(), click.y(), click.button())) cir.setReturnValue(true);
  }

  @Inject(method = "mouseScrolled", at = @At("HEAD"), cancellable = true)
  private void visuals$scroll(
      double x, double y, double horizontal, double vertical, CallbackInfoReturnable<Boolean> cir) {
    if (visuals$editor.scroll(x, y, vertical)) cir.setReturnValue(true);
  }

  @Override
  public boolean mouseDragged(Click click, double dx, double dy) {
    return visuals$editor.drag(click.x(), click.y()) || super.mouseDragged(click, dx, dy);
  }

  @Override
  public boolean mouseReleased(Click click) {
    return visuals$editor.release() || super.mouseReleased(click);
  }

  @Inject(method = "removed", at = @At("HEAD"))
  private void visuals$save(CallbackInfo ci) {
    visuals$editor.release();
    pl.xvisuals.XVisuals.STORE.save();
  }
}
