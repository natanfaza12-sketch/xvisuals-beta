package pl.xvisuals.mixins;

import pl.xvisuals.modules.explosion.ExplosionFX;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.llamalad7.mixinextras.injector.wrapoperation.*;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.*;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.collection.WeightedPool;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class ExplosionPacketMixin {
  @WrapOperation(method="onExplosion",at=@At(value="INVOKE",target="Lnet/minecraft/client/world/ClientWorld;playSoundClient(DDDLnet/minecraft/sound/SoundEvent;Lnet/minecraft/sound/SoundCategory;FFZ)V"))
  private void visuals$sound(ClientWorld world,double x,double y,double z,SoundEvent sound,SoundCategory category,float volume,float pitch,boolean distanceDelay,Operation<Void> original) {
    boolean replaced=ExplosionFX.replaceVanillaSound();

    if(!replaced)original.call(world,x,y,z,sound,category,volume,pitch,distanceDelay);
  }
  @WrapOperation(method="onExplosion",at=@At(value="INVOKE",target="Lnet/minecraft/client/world/ClientWorld;addParticleClient(Lnet/minecraft/particle/ParticleEffect;DDDDDD)V"))
  private void visuals$core(ClientWorld world,ParticleEffect effect,double x,double y,double z,double vx,double vy,double vz,Operation<Void> original) {
    if(!pl.xvisuals.modules.explosion.AnchorEffects.replaces(new Vec3d(x,y,z)) && !ExplosionFX.replaceParticles(new Vec3d(x,y,z)))original.call(world,effect,x,y,z,vx,vy,vz);
  }
  @WrapOperation(method="onExplosion",at=@At(value="INVOKE",target="Lnet/minecraft/client/world/ClientWorld;addBlockParticleEffects(Lnet/minecraft/util/math/Vec3d;FILnet/minecraft/util/collection/WeightedPool;)V"))
  private void visuals$debris(ClientWorld world,Vec3d origin,float radius,int blocks,WeightedPool<BlockParticleEffect> effects,Operation<Void> original) {
    if(!pl.xvisuals.modules.explosion.AnchorEffects.replaces(origin) && !ExplosionFX.replaceParticles(origin))original.call(world,origin,radius,blocks,effects);
  }
  @Inject(method="onExplosion",at=@At("TAIL"))
  private void visuals$explosion(ExplosionS2CPacket packet,CallbackInfo ci) {
    // Each module applies its own enable, source and distance settings. Anchor FX
    // replacing vanilla particles must not suppress the separate Explosion FX.
    ExplosionFX.packet(packet);
    pl.xvisuals.modules.explosion.AnchorEffects.explosion(packet.center());
  }
}
