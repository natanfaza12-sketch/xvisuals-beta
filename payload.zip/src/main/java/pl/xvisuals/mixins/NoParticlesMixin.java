package pl.xvisuals.mixins;

import pl.xvisuals.XVisuals;
import net.minecraft.client.particle.ParticleManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ParticleManager.class)
public abstract class NoParticlesMixin {
  @Inject(method="addToBatch", at=@At("HEAD"), cancellable=true)
  private void visuals$hideParticles(CallbackInfo ci) {
    if(XVisuals.ready() && XVisuals.config().on("noparticles"))ci.cancel();
  }
}
