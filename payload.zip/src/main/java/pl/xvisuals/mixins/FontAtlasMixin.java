package pl.xvisuals.mixins;

import java.util.function.Supplier;
import net.minecraft.client.font.GlyphAtlasTexture;
import net.minecraft.client.font.TextRenderLayerSet;
import net.minecraft.client.texture.AbstractTexture;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GlyphAtlasTexture.class)
public abstract class FontAtlasMixin {
  @Inject(method="<init>",at=@At("RETURN"))
  private void visuals$registerChoices(Supplier<String> name,TextRenderLayerSet layers,boolean color,CallbackInfo ci){
    // GPU debug labels may be replaced by numeric IDs, so retain the resource identity here.
    String font = name.get();
    if(!color && (font.startsWith("xvisuals:choices/")
        || font.startsWith("xvisuals:ui/")))
      pl.xvisuals.gui.FontMaterial.register(((AbstractTexture)(Object)this).getGlTexture());
  }
}
