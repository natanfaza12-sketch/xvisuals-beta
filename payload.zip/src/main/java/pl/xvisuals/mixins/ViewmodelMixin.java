package pl.xvisuals.mixins;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.motion.Viewmodel;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(HeldItemRenderer.class)
public abstract class ViewmodelMixin {
  @WrapMethod(method = "renderFirstPersonItem")
  private void visuals$position(AbstractClientPlayerEntity player, float tick, float pitch,
      Hand hand, float swing, ItemStack item, float equip, MatrixStack matrices,
      OrderedRenderCommandQueue queue, int light, Operation<Void> original) {
    if (XVisuals.config().on("viewmodel")) {
      var settings=XVisuals.config().module("viewmodel");
      if (hand==Hand.OFF_HAND && settings.flag("hideOffhand") || item.isEmpty() && settings.flag("hideEmpty")) return;
    }
    if(pl.xvisuals.modules.motion.SwordInspect.hideOther(hand))return;
    boolean inspecting=pl.xvisuals.modules.motion.SwordInspect.applies(hand);
    if (!XVisuals.config().on("viewmodel") && !inspecting) {
      original.call(player, tick, pitch, hand, swing, item, equip, matrices, queue, light);
      return;
    }
    matrices.push();
    try {
      if(XVisuals.config().on("viewmodel")&&!pl.xvisuals.modules.motion.SwordInspect.plunging())Viewmodel.apply(matrices, hand);
      if(inspecting)pl.xvisuals.modules.motion.SwordInspect.apply(matrices, hand);
      if(inspecting && !player.isInvisible()){
        matrices.push();
        try {
          var arm=hand==Hand.MAIN_HAND?player.getMainArm():player.getMainArm().getOpposite();
          pl.xvisuals.modules.motion.InspectGrip.render(player,item,arm,matrices,queue,light);
        } finally {matrices.pop();}
      }
      if(inspecting&&!player.isInvisible()&&pl.xvisuals.modules.motion.SwordInspect.support()>0){
        matrices.push();
        try{
          var arm=hand==Hand.MAIN_HAND?player.getMainArm():player.getMainArm().getOpposite();
          pl.xvisuals.modules.motion.InspectGrip.renderSupport(player,item,arm,matrices,queue,light,pl.xvisuals.modules.motion.SwordInspect.support());
        }finally{matrices.pop();}
      }
      original.call(player, tick, pitch, hand, inspecting?0f:swing, item, inspecting?0f:equip, matrices, queue, light);
    } finally {
      // Restore even for empty hands, maps and early returns; never shift the other hand/world.
      matrices.pop();
    }
  }
}
