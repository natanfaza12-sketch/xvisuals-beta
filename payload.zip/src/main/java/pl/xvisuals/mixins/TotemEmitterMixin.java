package pl.xvisuals.mixins;

import pl.xvisuals.modules.combat.TotemVisuals;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.entity.Entity;
import net.minecraft.particle.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ParticleManager.class)
public class TotemEmitterMixin {
  @Inject(method = "addEmitter(Lnet/minecraft/entity/Entity;Lnet/minecraft/particle/ParticleEffect;I)V",
      at = @At("HEAD"), cancellable = true)
  private void visuals$totem(Entity entity, ParticleEffect effect, int age, CallbackInfo ci) {
    if (effect.getType() == ParticleTypes.TOTEM_OF_UNDYING && TotemVisuals.burst(entity)) ci.cancel();
  }
}
