package pl.xvisuals.mixins;
import pl.xvisuals.menu.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.tooltip.OrderedTextTooltipComponent;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.text.OrderedText;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(OrderedTextTooltipComponent.class)
public abstract class TooltipTextMixin {
 @Shadow @Final private OrderedText text;
 @Inject(method="getWidth",at=@At("RETURN"),cancellable=true)
 private void visuals$width(TextRenderer font,CallbackInfoReturnable<Integer> ci){if(GlassMenus.active())ci.setReturnValue((int)Math.ceil(ci.getReturnValue()*TooltipStyle.SCALE));}
 @Inject(method="getHeight",at=@At("RETURN"),cancellable=true)
 private void visuals$height(TextRenderer font,CallbackInfoReturnable<Integer> ci){if(GlassMenus.active())ci.setReturnValue((int)Math.ceil(ci.getReturnValue()*TooltipStyle.SCALE));}
 @Inject(method="drawText",at=@At("HEAD"),cancellable=true)
 private void visuals$text(DrawContext g,TextRenderer font,int x,int y,CallbackInfo ci){
  if(!GlassMenus.active())return;
  OrderedText softened=visitor->text.accept((index,style,code)->visitor.accept(index,style.withColor(TooltipStyle.color(style.getColor()==null?0xFFFFFF:style.getColor().getRgb())),code));
  var matrices=g.getMatrices();matrices.pushMatrix();matrices.translate(x,y);matrices.scale(TooltipStyle.SCALE,TooltipStyle.SCALE);
  g.drawText(font,softened,0,0,0xFFF0F2F7,false);matrices.popMatrix();ci.cancel();
 }
}
