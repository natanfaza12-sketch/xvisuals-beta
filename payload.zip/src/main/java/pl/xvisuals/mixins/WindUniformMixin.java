package pl.xvisuals.mixins;
import com.mojang.blaze3d.systems.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(RenderSystem.class)
public abstract class WindUniformMixin {
 @Inject(method="bindDefaultUniforms",at=@At("TAIL"))
 private static void visuals$wind(RenderPass pass,CallbackInfo ci){pl.xvisuals.bootstrap.WindTerrainSupport.bind(pass);}
}
