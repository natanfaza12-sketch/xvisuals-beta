package pl.xvisuals.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import pl.xvisuals.XVisuals;
import net.minecraft.client.render.LightmapTextureManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(LightmapTextureManager.class)
public abstract class LightmapMixin {
  @ModifyExpressionValue(
      method = "update",
      at =
          @At(
              value = "INVOKE",
              target = "Lnet/minecraft/client/option/SimpleOption;getValue()Ljava/lang/Object;",
              ordinal = 2))
  private Object visuals$gamma(Object original) {
    if (!XVisuals.ready()) return original;
    double gamma = XVisuals.config().on("grading")
        ? XVisuals.config().module("grading").number("gamma")
        : (Double) original;
    if (XVisuals.config().on("fullbright")) {
      gamma = Math.max(gamma, XVisuals.config().module("fullbright").number("strength"));
    }
    return gamma;
  }

  @ModifyExpressionValue(
      method = "update",
      at = @At(value = "INVOKE",
          target = "Lnet/minecraft/client/option/SimpleOption;getValue()Ljava/lang/Object;",
          ordinal = 1))
  private Object visuals$fullbrightDarkness(Object original) {
    return XVisuals.ready() && XVisuals.config().on("fullbright")
        && XVisuals.config().module("fullbright").flag("suppressDarkness")
        ? Double.valueOf(0) : original;
  }
}
