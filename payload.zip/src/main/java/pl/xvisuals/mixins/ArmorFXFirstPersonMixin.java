package pl.xvisuals.mixins;
import pl.xvisuals.modules.armor.ArmorFXFirstPerson;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(PlayerEntityRenderer.class)
public class ArmorFXFirstPersonMixin {
 @Unique private ArmorFXFirstPerson armorfx$arms;
 @Inject(method="<init>",at=@At("TAIL")) private void armorfx$models(EntityRendererFactory.Context context,boolean slim,CallbackInfo ci){armorfx$arms=new ArmorFXFirstPerson(context,slim);}
 // Vanilla has just reset and posed the exact arm used by HeldItemRenderer, with camera/item transforms already on the stack.
 @Inject(method="renderArm",at=@At("TAIL"),require=0)
 private void armorfx$arm(MatrixStack matrices,OrderedRenderCommandQueue queue,int light,Identifier skin,ModelPart arm,boolean sleeve,CallbackInfo ci){
  armorfx$arms.render(matrices,queue,light,arm,arm==((PlayerEntityRenderer<?>)(Object)this).getModel().rightArm);
 }
}
