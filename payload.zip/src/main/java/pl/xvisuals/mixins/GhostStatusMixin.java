package pl.xvisuals.mixins;

import pl.xvisuals.modules.motion.GhostEffects;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.*;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class GhostStatusMixin {
  @Inject(method = "onEntityStatus", at = @At("TAIL"))
  private void visuals$status(EntityStatusS2CPacket packet, CallbackInfo ci) {
    var world = MinecraftClient.getInstance().world;
    if(world!=null&&packet.getStatus()==3){var entity=packet.getEntity(world);if(entity!=null)pl.xvisuals.modules.armor.ArmorFXCombat.death(entity.getId());}
    if (world != null && packet.getEntity(world) instanceof AbstractClientPlayerEntity player)
      GhostEffects.status(player, packet.getStatus());
  }

  @Inject(method = "onEntityDamage", at = @At("TAIL"))
  private void visuals$damage(net.minecraft.network.packet.s2c.play.EntityDamageS2CPacket packet, CallbackInfo ci) {
    pl.xvisuals.modules.armor.ArmorFXCombat.damage(packet);
  }
}
