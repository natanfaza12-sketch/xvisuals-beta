package pl.xvisuals.mixins;
import pl.xvisuals.modules.world.BreakingCracks;
import net.minecraft.client.render.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(WorldRenderer.class)
public abstract class BreakingCracksMixin {
 @ModifyArg(method="renderBlockDamage",at=@At(value="INVOKE",target="Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;getBuffer(Lnet/minecraft/client/render/RenderLayer;)Lnet/minecraft/client/render/VertexConsumer;"),index=0)
 private RenderLayer visuals$cracks(RenderLayer original){return BreakingCracks.layer(original);}
}
