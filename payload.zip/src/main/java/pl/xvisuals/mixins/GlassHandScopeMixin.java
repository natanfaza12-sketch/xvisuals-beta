package pl.xvisuals.mixins;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import pl.xvisuals.modules.glass.GlassMode;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(HeldItemRenderer.class)
public class GlassHandScopeMixin {
 @WrapMethod(method="renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V")
 private void visuals$glass(float tick,MatrixStack matrices,OrderedRenderCommandQueue queue,ClientPlayerEntity player,int light,Operation<Void> original){int old=GlassMode.enter(player.getId());try{original.call(tick,matrices,queue,player,light);}finally{GlassMode.restore(old);}}
}
