package pl.xvisuals.mixins;
import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.fire.FirePlus;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.texture.Sprite;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(InGameOverlayRenderer.class)
public class FirePlusOverlayMixin {
 @Inject(method="renderFireOverlay",at=@At("HEAD"),cancellable=true)
 private static void fireplus$hide(net.minecraft.client.util.math.MatrixStack matrices,net.minecraft.client.render.VertexConsumerProvider consumers,Sprite sprite,org.spongepowered.asm.mixin.injection.callback.CallbackInfo ci){if(FirePlus.hideOverlay())ci.cancel();}

 @ModifyVariable(method="renderFireOverlay",at=@At("HEAD"),argsOnly=true)
 private static Sprite fireplus$sprite(Sprite original){return FirePlus.overlay()?FirePlus.sprite():original;}
 @ModifyArg(method="renderFireOverlay",at=@At(value="INVOKE",target="Lnet/minecraft/client/util/math/MatrixStack;translate(FFF)V"),index=1)
 private static float fireplus$height(float original){return FirePlus.overlay()?original-(float)(1-XVisuals.config().module("fireplus").number("overlayHeight"))*.55f:original;}
 @ModifyArg(method="renderFireOverlay",at=@At(value="INVOKE",target="Lnet/minecraft/client/render/VertexConsumer;color(FFFF)Lnet/minecraft/client/render/VertexConsumer;"),index=3)
 private static float fireplus$opacity(float original){return FirePlus.overlay()?(float)XVisuals.config().module("fireplus").number("overlayOpacity"):original;}
}
