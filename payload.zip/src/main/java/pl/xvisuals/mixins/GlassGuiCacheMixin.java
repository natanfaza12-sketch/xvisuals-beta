package pl.xvisuals.mixins;

import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.glass.GlassMode;
import net.minecraft.client.gui.render.GuiRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Cached GUI item images must change when the material changes, not only on relog. */
@Mixin(GuiRenderer.class)
public abstract class GlassGuiCacheMixin {
  @Unique private long visuals$glassStamp;
  @Shadow protected abstract void onItemAtlasChanged();
  @Shadow protected abstract void clearOversizedItems();

  @Inject(method="prepare",at=@At("HEAD"))
  private void visuals$invalidateGlass(CallbackInfo ci) {
    long stamp=GlassMode.enabled()?1L+(XVisuals.config().module("glass").values.hashCode()&0xffffffffL):0;
    if(XVisuals.ready()){var glass=XVisuals.config().module("glassierglass");stamp=31*stamp+(glass.enabled?1L+(glass.values.hashCode()&0xffffffffL):0);}
    stamp=31*stamp+pl.xvisuals.modules.world.GlassierGlass.revision();
    if(stamp==visuals$glassStamp)return;
    visuals$glassStamp=stamp;
    onItemAtlasChanged();
    clearOversizedItems();
  }
}
