package pl.xvisuals.mixins;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import pl.xvisuals.modules.combat.TotemSizing;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(InGameOverlayRenderer.class)
public class TotemPopSizeMixin {
  @WrapOperation(method = "renderFloatingItem", at = @At(value = "INVOKE",
      target = "Lnet/minecraft/client/render/item/ItemRenderState;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;III)V"))
  private void visuals$scalePop(ItemRenderState state, MatrixStack matrices,
      OrderedRenderCommandQueue queue, int light, int overlay, int outlineColor,
      Operation<Void> original) {
    float scale = ((TotemSizing.State) state).visuals$isTotem() ? TotemSizing.scale("pop") : 1;
    matrices.push();
    try {
      matrices.scale(scale, scale, scale);
      if (((TotemSizing.State) state).visuals$isTotem()) TotemSizing.orientPop(matrices);
      original.call(state, matrices, queue, light, overlay, outlineColor);
    } finally {
      matrices.pop();
    }
  }
}
