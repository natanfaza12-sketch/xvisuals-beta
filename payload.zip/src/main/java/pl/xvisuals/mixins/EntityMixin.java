package pl.xvisuals.mixins;

import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.entity.EntityVisuals;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
  @Inject(method = "isGlowing", at = @At("HEAD"), cancellable = true)
  private void visuals$glow(CallbackInfoReturnable<Boolean> cir) {
    if (XVisuals.ready() && EntityVisuals.shouldGlow((Entity) (Object) this))
      cir.setReturnValue(true);
  }

  @Inject(method = "getTeamColorValue", at = @At("HEAD"), cancellable = true)
  private void visuals$color(CallbackInfoReturnable<Integer> cir) {
    if (XVisuals.ready() && EntityVisuals.shouldGlow((Entity) (Object) this))
      cir.setReturnValue(EntityVisuals.glowColor((Entity) (Object) this) & 0xFFFFFF);
  }
}
