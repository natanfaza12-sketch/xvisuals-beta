package pl.xvisuals.mixins;

import pl.xvisuals.modules.explosion.ExplosionCamera;
import net.minecraft.client.render.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value=GameRenderer.class,priority=900)
public abstract class ExplosionFovMixin {
  @Inject(method="getFov",at=@At("RETURN"),cancellable=true)
  private void visuals$impulse(Camera camera,float tick,boolean changing,CallbackInfoReturnable<Float> ci) {
    if(changing && pl.xvisuals.modules.explosion.ExplosionFX.settings().enabled)
      ci.setReturnValue((float)Math.clamp(ci.getReturnValue()+ExplosionCamera.fov,1,170));
  }
}
