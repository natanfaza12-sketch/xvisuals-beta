package pl.xvisuals.mixins;

import pl.xvisuals.modules.combat.HitEffects;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.EntityAnimationS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class HitEffectsMixin {
  @Inject(method = "onEntityAnimation", at = @At("TAIL"))
  private void visuals$critical(EntityAnimationS2CPacket packet, CallbackInfo ci) {
    var world = MinecraftClient.getInstance().world;
    // 4 is vanilla CRIT; 5 is enchanted damage and must not be treated as critical.
    if (world != null && packet.getAnimationId() == 4) {
      pl.xvisuals.modules.armor.ArmorFXCombat.critical(packet.getEntityId());
      HitEffects.critical(world.getEntityById(packet.getEntityId()));
    }
  }
}
