package pl.xvisuals.mixins;
import pl.xvisuals.modules.cosmetics.AnimatedCosmetics;
import pl.xvisuals.XVisuals;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(PlayerEntityModel.class)
public abstract class SkinLayersMixin {
  @Inject(method="setAngles(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;)V",at=@At("TAIL"))
  private void visuals$depth(PlayerEntityRenderState state,CallbackInfo ci){
    var model=(PlayerEntityModel)(Object)this;
    pl.xvisuals.gui.screens.GhostSkinPreview.pose(model,state);
    float depth=AnimatedCosmetics.applies("skinlayers",state)?(float)XVisuals.visualModule("skinlayers").number("depth"):0;
    // Absolute scales reset every player and frame; shared models must never retain another player's depth.
    for(ModelPart part:new ModelPart[]{model.hat,model.jacket,model.leftSleeve,model.rightSleeve,model.leftPants,model.rightPants}){
      if(state instanceof pl.xvisuals.gui.screens.GhostSkinPreview)continue;
      part.xScale=part.zScale=1+depth*.035f;part.yScale=1+depth*.012f;
    }
  }
}
