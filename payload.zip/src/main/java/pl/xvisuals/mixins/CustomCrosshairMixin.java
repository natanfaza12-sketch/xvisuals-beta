package pl.xvisuals.mixins;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.crosshair.CustomCrosshair;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Replace only the crosshair texture; vanilla retains visibility and attack-indicator logic. */
@Mixin(InGameHud.class)
public abstract class CustomCrosshairMixin {
  @Redirect(method="renderCrosshair",at=@At(value="INVOKE",target="Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/util/Identifier;IIII)V",ordinal=0))
  private void visuals$crosshair(DrawContext g,RenderPipeline pipeline,Identifier texture,int x,int y,int w,int h) {
    if(XVisuals.ready() && XVisuals.config().on("crosshair")) CustomCrosshair.render(g);
    else g.drawGuiTexture(pipeline,texture,x,y,w,h);
  }
}
