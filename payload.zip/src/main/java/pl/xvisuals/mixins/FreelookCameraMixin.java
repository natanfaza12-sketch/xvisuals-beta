package pl.xvisuals.mixins;

import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.motion.Freelook;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class FreelookCameraMixin {
  @Shadow private float cameraY;
  @Shadow private float lastCameraY;
  @Shadow
  protected abstract void setRotation(float yaw, float pitch);

  @Shadow
  protected abstract void setPos(Vec3d pos);

  @Shadow
  protected abstract void moveBy(float distance, float vertical, float horizontal);

  @Shadow
  private float clipToSpace(float distance) {
    throw new AssertionError();
  }

  @Inject(method = "update", at = @At("TAIL"))
  private void visuals$camera(
      World world,
      Entity entity,
      boolean thirdPerson,
      boolean inverse,
      float delta,
      CallbackInfo ci) {
    Freelook.frame();
    if (!Freelook.active()) return;
    setRotation(Freelook.yaw(), Freelook.pitch());
    setPos(
        entity
            .getLerpedPos(delta)
            // Match vanilla's interpolated crouch/stand eye-height transition.
            .add(0, MathHelper.lerp(delta, lastCameraY, cameraY), 0)
            .add(Freelook.offset()));
    float distance = (float) Freelook.distance();
    if (!XVisuals.config().module("freelook").flag("clip")) distance = clipToSpace(distance);
    moveBy(-distance, 0, 0);
  }
}
