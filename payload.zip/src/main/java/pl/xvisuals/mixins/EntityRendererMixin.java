package pl.xvisuals.mixins;

import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.entity.EntityVisuals;
import pl.xvisuals.modules.entity.EntityOverlayPolicy;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityRenderer.class)
public abstract class EntityRendererMixin {
  @Inject(method = "updateRenderState", at = @At("TAIL"))
  private void visuals$label(Entity entity, EntityRenderState state, float tick, CallbackInfo ci) {
    if (!XVisuals.ready()) return;
    var client = net.minecraft.client.MinecraftClient.getInstance();
    if (entity == client.player
        && pl.xvisuals.modules.motion.Freelook.active()
        && XVisuals.config().on("freelook")
        && XVisuals.config().module("freelook").flag("selfNametag")) {
      // Feed the vanilla label renderer its normal styled name and attachment.
      // Do not use the tab-list name: servers can format it differently from overhead ranks.
      if (!client.options.getPerspective().isFirstPerson()
          && !client.player.isSpectator() && !entity.isInvisibleTo(client.player)
          && !entity.hasPassengers()
          && state.squaredDistanceToCamera < (entity.isSneaky() ? 1024 : 4096)) {
        state.displayName = entity.getDisplayName();
        state.nameLabelPos = entity.getAttachments().getPointNullable(
            net.minecraft.entity.EntityAttachmentType.NAME_TAG, 0, entity.getLerpedYaw(tick));
      }
      return;
    }
    var target = EntityVisuals.target(entity);
    if (!XVisuals.config().on("nametags")) return;
    var s = XVisuals.config().module("nametags");
    if (target != null && EntityOverlayPolicy.replacesLabel(target.settings(), s,
        entity instanceof net.minecraft.entity.ItemEntity, target.distance, target.visible,
        client.options.hudHidden)) state.displayName = null;
  }
}
