package pl.xvisuals.mixins;

import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Kept separate from neutral wind setup so the injector gates it until activation. */
@Mixin(RenderSystem.class)
public abstract class WaterUniformMixin {
    @Inject(method = "bindDefaultUniforms", at = @At("TAIL"))
    private static void visuals$water(RenderPass pass, CallbackInfo ci) {
        pl.xvisuals.rendering.WaterSurface.bind(pass);
    }
}
