package pl.xvisuals.mixins;

import pl.xvisuals.modules.motion.Freelook;
import net.minecraft.client.input.*;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.Vec2f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardInput.class)
public abstract class FreelookInputMixin extends Input {
  @Inject(method = "tick", at = @At("TAIL"))
  private void visuals$cameraInput(CallbackInfo ci) {
    if (Freelook.capturesMovement()) {
      playerInput = PlayerInput.DEFAULT;
      movementVector = Vec2f.ZERO;
    }
  }
}
