package pl.xvisuals.mixins;
import pl.xvisuals.XVisuals;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.CloudRenderMode;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/** Suppress vanilla clouds before alternate renderers schedule them; never alter the saved option. */
@Mixin(GameOptions.class)
public abstract class CloudOptionMixin {
 @Inject(method="getCloudRenderModeValue",at=@At("HEAD"),cancellable=true)
 private void visuals$noClouds(CallbackInfoReturnable<CloudRenderMode> ci){
  if(XVisuals.ready() && XVisuals.config().on("noclouds"))ci.setReturnValue(CloudRenderMode.OFF);
 }
}
