package pl.xvisuals.mixins;

import java.util.*;
import net.minecraft.client.gui.*;
import net.minecraft.client.gui.render.state.GuiRenderState;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(DrawContext.class)
public abstract class DrawContextMixin implements pl.xvisuals.rendering.shaders.GuiAccess {
  @Unique private final Deque<ScreenRect> visuals$clips = new ArrayDeque<>();

  @Accessor("state")
  public abstract GuiRenderState visuals$state();

  public ScreenRect visuals$clip() {
    return visuals$clips.peek();
  }

  @Inject(method = "enableScissor", at = @At("HEAD"))
  private void visuals$push(int x1, int y1, int x2, int y2, CallbackInfo ci) {
    ScreenRect r =
        new ScreenRect(x1, y1, Math.max(0, x2 - x1), Math.max(0, y2 - y1))
            .transformEachVertex(((DrawContext) (Object) this).getMatrices());
    if (!visuals$clips.isEmpty()) {
      r = r.intersection(visuals$clips.peek());
      if (r == null) r = ScreenRect.empty();
    }
    visuals$clips.push(r);
  }

  @Inject(method = "disableScissor", at = @At("HEAD"))
  private void visuals$pop(CallbackInfo ci) {
    if (!visuals$clips.isEmpty()) visuals$clips.pop();
  }
}
