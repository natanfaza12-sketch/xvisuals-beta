package pl.xvisuals.gui.world;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTextureView;
import pl.xvisuals.gui.screens.StudioScreen;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.GlobalSettings;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.render.GuiRenderer;
import net.minecraft.client.gui.render.state.GuiRenderState;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.fog.FogRenderer;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.util.Identifier;

/** A retained, independently rendered GUI surface; never replaces the game's framebuffer. */
public final class WorldStudioTexture implements AutoCloseable {
  public static final int WIDTH = 800, HEIGHT = 540, SCALE = 2;
  public static final Identifier ID = Identifier.of("xvisuals", "world_studio");
  private static WorldStudioTexture rendering;
  private final MinecraftClient client = MinecraftClient.getInstance();
  private final Framebuffer framebuffer =
      new SimpleFramebuffer("Visuals world studio", WIDTH * SCALE, HEIGHT * SCALE, true);
  private final GuiRenderState state = new GuiRenderState();
  private final BufferAllocator allocator = new BufferAllocator(256 * 1024);
  private final VertexConsumerProvider.Immediate consumers = VertexConsumerProvider.immediate(allocator);
  private final net.minecraft.client.render.command.OrderedRenderCommandQueueImpl commands = new net.minecraft.client.render.command.OrderedRenderCommandQueueImpl();
  private final net.minecraft.client.render.command.RenderDispatcher dispatcher = new net.minecraft.client.render.command.RenderDispatcher(
      commands, client.getBlockRenderManager(), consumers, client.getAtlasManager(),
      new net.minecraft.client.render.OutlineVertexConsumerProvider(), consumers, client.textRenderer);
  private final GuiRenderer renderer =
      new GuiRenderer(
          state,
          consumers,
          commands,
          dispatcher,
          List.of());
  private final FogRenderer fog = new FogRenderer();
  private final GlobalSettings globals = new GlobalSettings();
  private long nextFrame;
  private boolean closed;

  public WorldStudioTexture() {
    client.getTextureManager().registerTexture(ID, new SurfaceTexture());
  }

  public static Framebuffer target(GuiRenderer candidate) {
    return rendering != null && rendering.renderer == candidate ? rendering.framebuffer : null;
  }

  public GpuTextureView textureView() {
    return framebuffer.getColorAttachmentView();
  }

  /** The cached texture stays valid between updates, including while the player walks around it. */
  public void render(StudioScreen screen, int mouseX, int mouseY, float delta) {
    long now = System.nanoTime();
    if (closed || now < nextFrame) return;
    nextFrame = now + 1_000_000_000L / 30;
    var projection = RenderSystem.getProjectionMatrixBuffer();
    var projectionType = RenderSystem.getProjectionType();
    var global = RenderSystem.getGlobalSettingsUniform();
    var shaderFog = RenderSystem.getShaderFog();
    var lights = RenderSystem.getShaderLights();
    var color = RenderSystem.outputColorTextureOverride;
    var depth = RenderSystem.outputDepthTextureOverride;
    var scissor = RenderSystem.getScissorStateForRenderTypeDraws();
    boolean clipped = scissor.isEnabled();
    int sx = scissor.getX(), sy = scissor.getY(), sw = scissor.getWidth(), sh = scissor.getHeight();
    RenderSystem.getModelViewStack().pushMatrix();
    rendering = this;
    try {
      RenderSystem.getModelViewStack().identity();
      RenderSystem.disableScissorForRenderTypeDraws();
      RenderSystem.outputColorTextureOverride = framebuffer.getColorAttachmentView();
      RenderSystem.outputDepthTextureOverride = framebuffer.getDepthAttachmentView();
      globals.set(
          WIDTH * SCALE,
          HEIGHT * SCALE,
          1,
          client.world == null ? 0 : client.world.getTime(),
          client.getRenderTickCounter(),
          0,
          client.gameRenderer.getCamera(),
          false);
      var noFog = fog.getFogBuffer(FogRenderer.FogType.NONE);
      RenderSystem.setShaderFog(noFog);
      RenderSystem.getDevice()
          .createCommandEncoder()
          .clearColorAndDepthTextures(
              framebuffer.getColorAttachment(), 0, framebuffer.getDepthAttachment(), 1);
      commands.onNextFrame();
      state.clear();
      DrawContext context = new DrawContext(client, state, mouseX, mouseY);
      screen.render(context, mouseX, mouseY, delta);
      context.drawDeferredElements();
      renderer.incrementFrame();
      renderer.render(noFog);
    } finally {
      rendering = null;
      state.clear();
      RenderSystem.outputColorTextureOverride = color;
      RenderSystem.outputDepthTextureOverride = depth;
      RenderSystem.setProjectionMatrix(projection, projectionType);
      RenderSystem.setGlobalSettingsUniform(global);
      RenderSystem.setShaderFog(shaderFog);
      RenderSystem.setShaderLights(lights);
      RenderSystem.getModelViewStack().popMatrix();
      if (clipped) RenderSystem.enableScissorForRenderTypeDraws(sx, sy, sw, sh);
      else RenderSystem.disableScissorForRenderTypeDraws();
    }
  }

  @Override
  public void close() {
    if (closed) return;
    closed = true;
    client.getTextureManager().destroyTexture(ID);
    renderer.close();
    dispatcher.close();
    allocator.close();
    fog.close();
    globals.close();
    framebuffer.delete();
  }

  private final class SurfaceTexture extends AbstractTexture {
    SurfaceTexture() {
      glTexture = framebuffer.getColorAttachment();
      glTextureView = framebuffer.getColorAttachmentView();
      sampler = RenderSystem.getSamplerCache().get(FilterMode.LINEAR);
    }

    @Override
    public void close() {
      /* The framebuffer owns both attachments. */
    }
  }
}
