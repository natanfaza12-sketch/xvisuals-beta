package pl.xvisuals.gui.world;

import net.minecraft.util.math.Vec3d;

/** Immutable world plane; ray coordinates use the same basis as its rendered vertices. */
public record PanelPlane(Vec3d center, Vec3d right, Vec3d up, double width, double height) {
  public record Hit(double x, double y, double distance, Vec3d point, boolean back) {}

  public Vec3d normal() {
    return right.crossProduct(up);
  }

  public Vec3d point(double u, double v) {
    return center.add(right.multiply((u - .5) * width)).add(up.multiply((.5 - v) * height));
  }

  public PanelPlane moved(Vec3d position) {
    return new PanelPlane(position, right, up, width, height);
  }

  public Hit intersect(Vec3d origin, Vec3d direction, double maxDistance, boolean bounded) {
    Vec3d normal = normal();
    double dot = direction.dotProduct(normal);
    if (Math.abs(dot) < 1e-6) return null;
    double distance = center.subtract(origin).dotProduct(normal) / dot;
    if (distance < .05 || distance > maxDistance) return null;
    Vec3d point = origin.add(direction.multiply(distance));
    Vec3d offset = point.subtract(center);
    boolean back = dot > 0;
    double x = .5 + offset.dotProduct(right) / width;
    double y = .5 - offset.dotProduct(up) / height;
    if (bounded && (x < 0 || x > 1 || y < 0 || y > 1)) return null;
    return new Hit(back ? 1 - x : x, y, distance, point, back);
  }
}
