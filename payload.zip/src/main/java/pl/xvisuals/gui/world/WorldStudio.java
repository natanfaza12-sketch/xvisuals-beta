package pl.xvisuals.gui.world;

import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.gui.screens.StudioScreen;
import pl.xvisuals.mixins.RenderLayerAccessor;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.gui.Click;
import net.minecraft.client.input.*;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.joml.Vector3f;
import org.lwjgl.glfw.GLFW;

/** A stationary world surface. The actual StudioScreen handles every module control. */
public final class WorldStudio {
  private static StudioScreen screen;
  private static WorldStudioTexture texture;
  private static PanelPlane plane;
  private static Object world;
  private static PanelPlane.Hit aim;
  private static int held = -1;
  private static int lastClickButton = -1;
  private static Vec3d grab;
  private static double lastX, lastY;
  private static long lastClick;
  private static double clickX, clickY;
  private static boolean typing, captured;
  private static final BufferAllocator ALLOCATOR = new BufferAllocator(4096);
  private static final VertexConsumerProvider.Immediate BUFFERS =
      VertexConsumerProvider.immediate(ALLOCATOR);
  private static final RenderLayer LAYER =
      RenderLayerAccessor.visuals$of(
          "xvisuals_world_studio",
          RenderSetup.builder(
                  RenderPipeline.builder()
                      .withLocation(Identifier.of("xvisuals", "pipeline/world_studio"))
                      .withVertexShader(Identifier.of("xvisuals", "core/world_studio"))
                      .withFragmentShader(Identifier.of("xvisuals", "core/world_studio"))
                      .withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
                      .withUniform("Projection", UniformType.UNIFORM_BUFFER)
                      .withSampler("Sampler0")
                      .withVertexFormat(
                          VertexFormats.POSITION_TEXTURE_COLOR, VertexFormat.DrawMode.QUADS)
                      .withBlend(BlendFunction.TRANSLUCENT)
                      .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                      .withDepthWrite(false)
                      .withCull(false)
                      .build())
              .texture("Sampler0", WorldStudioTexture.ID)
              .translucent()
              .expectedBufferSize(4096)
              .build());

  public static void init() {
    WorldRenderEvents.END_MAIN.register(context -> render(context.matrices()));
    net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING.register(c -> {
      close();
      ALLOCATOR.close();
    });
  }

  public static boolean active() {
    return screen != null;
  }

  public static PanelPlane plane() {
    return plane;
  }

  public static StudioScreen screen() {
    return screen;
  }

  public static void toggle() {
    if (active()) close();
    else open();
  }

  public static void open() {
    open(new StudioScreen(null));
  }

  public static void open(StudioScreen next) {
    var c = MinecraftClient.getInstance();
    if (c.world == null || c.player == null) return;
    close();
    world = c.world;
    Vector3f direction = new Vector3f(0, 0, -1).rotate(c.gameRenderer.getCamera().getRotation());
    double yaw = Math.atan2(-direction.x, direction.z);
    Vec3d right = new Vec3d(-Math.cos(yaw), 0, -Math.sin(yaw));
    plane =
        new PanelPlane(
            c.gameRenderer
                .getCamera()
                .getCameraPos()
                .add(new Vec3d(direction.x, direction.y, direction.z).multiply(3.2)),
            right,
            new Vec3d(0, 1, 0),
            4.4,
            4.4 * WorldStudioTexture.HEIGHT / WorldStudioTexture.WIDTH);
    c.setScreen(null);
    screen = next.asWorldPanel();
    screen.init(WorldStudioTexture.WIDTH, WorldStudioTexture.HEIGHT);
    lastClick = 0;
    c.mouse.lockCursor();
  }

  public static void close() {
    release();
    if (screen != null) screen.removed();
    screen = null;
    plane = null;
    world = null;
    aim = null;
    typing = captured = false;
    if (texture != null) {
      texture.close();
      texture = null;
    }
  }

  public static void tick(MinecraftClient c) {
    if (!active()) return;
    if (c.world != world
        || c.player == null
        || !c.player.isAlive()
        || plane.center().squaredDistanceTo(c.player.getEyePos()) > 64 * 64) {
      close();
      return;
    }
    if (c.currentScreen != null || !c.isWindowFocused()) {
      release();
      aim = null;
      return;
    }
    screen.tick();
    syncTyping();
  }

  private static void syncTyping() {
    boolean now = active() && screen.worldTyping();
    if (now != typing) KeyBinding.unpressAll();
    typing = now;
  }

  private static PanelPlane.Hit ray(boolean bounded) {
    var c = MinecraftClient.getInstance();
    if (!active() || c.world != world || c.player == null || c.currentScreen != null) return null;
    Vec3d origin = c.gameRenderer.getCamera().getCameraPos();
    Vector3f look = new Vector3f(0, 0, -1).rotate(c.gameRenderer.getCamera().getRotation());
    var hit = plane.intersect(origin, new Vec3d(look.x, look.y, look.z), 16, bounded);
    if (hit == null) return null;
    var block =
        c.world.raycast(
            new RaycastContext(
                origin,
                hit.point(),
                RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE,
                c.player));
    if (block.getType() != HitResult.Type.MISS
        && block.getPos().squaredDistanceTo(origin) + .0025 < hit.distance() * hit.distance())
      return null;
    return hit;
  }

  private static double x(PanelPlane.Hit hit) {
    return hit.x() * WorldStudioTexture.WIDTH;
  }

  private static double y(PanelPlane.Hit hit) {
    return hit.y() * WorldStudioTexture.HEIGHT;
  }

  private static Click click(double x, double y) {
    return new Click(x, y, new MouseInput(Math.max(0, held), 0));
  }

  public static boolean capturesActions() {
    if (!active() || MinecraftClient.getInstance().currentScreen != null) return false;
    var hit = ray(true);
    return held >= 0 || typing || hit != null && screen.worldSurfaceAt(x(hit), y(hit));
  }

  public static boolean mouseButton(MouseInput input, int action) {
    if (!active() || MinecraftClient.getInstance().currentScreen != null || input.button() > 1)
      return false;
    if (action == GLFW.GLFW_RELEASE && input.button() == held) {
      release();
      return true;
    }
    if (action != GLFW.GLFW_PRESS) return false;
    var hit = ray(true);
    if (hit == null || !screen.worldSurfaceAt(x(hit), y(hit))) return typing;
    if (held >= 0) return true;
    held = input.button();
    lastX = x(hit);
    lastY = y(hit);
    var c = MinecraftClient.getInstance();
    c.options.attackKey.setPressed(false);
    c.options.useKey.setPressed(false);
    if (c.interactionManager != null) c.interactionManager.cancelBlockBreaking();
    if (held == GLFW.GLFW_MOUSE_BUTTON_LEFT && screen.worldTitleAt(lastX, lastY)) {
      grab = hit.point().subtract(plane.center());
    } else {
      long now = System.nanoTime();
      boolean twice =
          held == lastClickButton && now - lastClick < 300_000_000 && Math.hypot(lastX - clickX, lastY - clickY) < 6;
      lastClick = now;
      lastClickButton = held;
      clickX = lastX;
      clickY = lastY;
      screen.mouseClicked(click(lastX, lastY), twice);
      syncTyping();
    }
    return true;
  }

  private static void release() {
    if (held >= 0 && screen != null) screen.mouseReleased(click(lastX, lastY));
    held = -1;
    grab = null;
  }

  public static boolean scroll(double amount) {
    var hit = ray(true);
    if (hit == null || !screen.worldSurfaceAt(x(hit), y(hit))) return false;
    screen.mouseScrolled(x(hit), y(hit), 0, amount);
    return true;
  }

  public static boolean key(KeyInput input, int action) {
    var c = MinecraftClient.getInstance();
    if (!active() || c.currentScreen != null) return false;
    if (typing) {
      if (action != GLFW.GLFW_RELEASE) screen.keyPressed(input);
      syncTyping();
      return true;
    }
    if (input.key() == GLFW.GLFW_KEY_ESCAPE
        || input.key() == GLFW.GLFW_KEY_ENTER && screen.worldColourEditing()) {
      if (action == GLFW.GLFW_PRESS) screen.keyPressed(input);
      return true;
    }
    return false;
  }

  public static boolean character(CharInput input) {
    if (!active() || MinecraftClient.getInstance().currentScreen != null || !typing) return false;
    screen.charTyped(input);
    return true;
  }

  private static void render(MatrixStack matrices) {
    var c = MinecraftClient.getInstance();
    if (!active() || c.world != world || c.player == null) return;
    aim = ray(held < 0);
    if (held >= 0 && aim != null) {
      if (grab != null) plane = plane.moved(aim.point().subtract(grab));
      else {
        double px = Math.clamp(x(aim), 0, WorldStudioTexture.WIDTH);
        double py = Math.clamp(y(aim), 0, WorldStudioTexture.HEIGHT);
        screen.mouseDragged(click(px, py), px - lastX, py - lastY);
        lastX = px;
        lastY = py;
      }
    }
    boolean target = aim != null && screen.worldSurfaceAt(x(aim), y(aim));
    if (target && !captured && c.interactionManager != null)
      c.interactionManager.cancelBlockBreaking();
    captured = target;
    if (texture == null) texture = new WorldStudioTexture();
    texture.render(
        screen,
        aim == null ? -10000 : (int) x(aim),
        aim == null ? -10000 : (int) y(aim),
        c.getRenderTickCounter().getTickProgress(false));
    Vec3d camera = c.gameRenderer.getCamera().getCameraPos();
    boolean back = camera.subtract(plane.center()).dotProduct(plane.normal()) < 0;
    var out = BUFFERS.getBuffer(LAYER);
    vertex(out, matrices, camera, 0, 0, back);
    vertex(out, matrices, camera, 0, 1, back);
    vertex(out, matrices, camera, 1, 1, back);
    vertex(out, matrices, camera, 1, 0, back);
    BUFFERS.draw();
  }

  private static void vertex(
      VertexConsumer out, MatrixStack matrices, Vec3d camera, float u, float v, boolean back) {
    Vec3d p = plane.point(u, v).subtract(camera);
    out.vertex(matrices.peek().getPositionMatrix(), (float) p.x, (float) p.y, (float) p.z)
        .texture(back ? 1 - u : u, 1 - v)
        .color(0xFFFFFFFF);
  }

  private WorldStudio() {}
}
