package pl.xvisuals.gui.screens;
import pl.xvisuals.XVisuals;
import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.modules.entity.PlayerAnimationShapes;
import pl.xvisuals.util.Colors;
import net.minecraft.client.gui.DrawContext;
/** Projects the same paths used by the worn effects. */
final class PlayerAnimationPreview {
 static void draw(DrawContext g,String name,int x,int y,int w,int h){
  var s=XVisuals.config().module("enemyanimations");
  double time=XVisuals.config().module("performance").text("animation").equals("Off")?0:System.nanoTime()/1e9*s.number("speed");
  double unit=Math.min(h/2.3,w/3.5),cx=x+w*.5,feet=y+h*.92,size=s.number("size");
  int style=PlayerAnimationShapes.index(name);
  g.enableScissor(x,y,x+w,y+h);
  try{
   for(int layer=0;layer<2;layer++){
    if(layer==1){
     box(g,cx-unit*.16,feet-unit*1.8,unit*.32,unit*.32);
     box(g,cx-unit*.2,feet-unit*1.45,unit*.4,unit*.63);
     box(g,cx-unit*.34,feet-unit*1.44,unit*.12,unit*.62);
     box(g,cx+unit*.22,feet-unit*1.44,unit*.12,unit*.62);
     box(g,cx-unit*.19,feet-unit*.79,unit*.17,unit*.79);
     box(g,cx+unit*.02,feet-unit*.79,unit*.17,unit*.79);
    }
    double[] a=new double[3],b=new double[3];
    for(int strand=0;strand<PlayerAnimationShapes.strands(style);strand++)for(int i=0;i<32;i++){
     double u=i/32.;
     PlayerAnimationShapes.point(style,strand,u,time,a);
     PlayerAnimationShapes.point(style,strand,(i+1)/32.,time,b);
     if(((a[2]+b[2])>0?0:1)!=layer)continue;
     int tint=Colors.alpha(Colors.mix(s.color("color"),s.color("secondary"),.5+.5*Math.sin(u*3+time)),s.number("opacity"));
     CraftedGui.line(g,cx+a[0]*unit*size,feet-(a[1]-a[2]*.22)*unit*size,cx+b[0]*unit*size,feet-(b[1]-b[2]*.22)*unit*size,Math.max(.7,PlayerAnimationShapes.width(style,u)*unit*2),tint);
    }
   }
  }finally{g.disableScissor();}
 }
 private static void box(DrawContext g,double x,double y,double w,double h){g.fill((int)x,(int)y,(int)(x+w),(int)(y+h),0xFF414955);}
 private PlayerAnimationPreview(){}
}
