package pl.xvisuals.gui.screens;

import pl.xvisuals.gui.components.StudioChrome;
import pl.xvisuals.gui.themes.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import java.util.function.BooleanSupplier;

/** Small destructive-action dialog; cancellation is the initial keyboard focus. */
final class WaypointDeleteScreen extends Screen {
  private final Screen parent;
  private final String name;
  private final BooleanSupplier available;
  private final Runnable confirm;
  private WaypointControl delete;
  private int left,top,w;
  WaypointDeleteScreen(Screen parent,String name,BooleanSupplier available,Runnable confirm) {
    super(Text.literal("Delete waypoint?"));this.parent=parent;this.name=name;this.available=available;this.confirm=confirm;
  }
  @Override protected void init() {
    w=Math.min(360,width-48);left=(width-w)/2;top=(height-136)/2;
    var cancel=addDrawableChild(new WaypointControl("Keep waypoint",left+12,top+100,(w-30)/2,24,false,this::close));
    delete=addDrawableChild(new WaypointControl("Delete waypoint",left+18+(w-30)/2,top+100,(w-30)/2,24,false,()->{
      if(available.getAsBoolean()){confirm.run();close();}
    }));
    setInitialFocus(cancel);tick();
  }
  @Override public void tick(){delete.active=available.getAsBoolean();}
  @Override public void renderBackground(DrawContext g,int mx,int my,float delta){}
  @Override public boolean shouldPause(){return false;}
  @Override public void render(DrawContext g,int mx,int my,float delta) {
    g.fill(0,0,width,height,0xB8080B10);StudioChrome.surface(g,left,top,w,136,14,.97,false);
    StudioChrome.text(g,title.getString(),left+16,top+17,Theme.text());
    StudioChrome.text(g,ConfigUi.fit(name,w-32),left+16,top+42,Theme.accent());
    StudioChrome.scaled(g,ConfigUi.fit(delete.active?"This removes the saved location and its navigation.":"World changed. Return and reopen the manager.",(int)((w-32)/.8f)),left+16,top+68,.8f,Theme.muted());
    super.render(g,mx,my,delta);
  }
  @Override public void close(){client.setScreen(parent);}
}
