package pl.xvisuals.gui.screens;

import pl.xvisuals.XVisuals;
import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.modules.combat.ImpactStyles;
import pl.xvisuals.modules.explosion.ExplosionMath;
import pl.xvisuals.util.Colors;
import net.minecraft.client.gui.DrawContext;

/** Isolated gallery diagrams: no entities, world particles, camera impulses or sounds. */
final class EffectGalleryPreview {
  static void draw(DrawContext g,String module,String design,int x,int y,int w,int h,boolean critical){
    var s=XVisuals.config().module(module);
    boolean moving=!XVisuals.config().module("performance").text("animation").equals("Off");
    double time=moving?System.nanoTime()/1e9:1.2;
    double cx=x+w*.5,cy=y+h*.53,unit=Math.min(w/3.6,h/2.8);
    int color=s.color("color");
    g.enableScissor(x,y,x+w,y+h);
    try{
      if(module.equals("hitfx")){
        double duration=s.number("duration"),t=moving?(time%(duration+.12))/duration:.25;
        if(t>1)return;
        int style=ImpactStyles.hit(design),frame=ImpactStyles.frame(t),count=Math.clamp((int)Math.ceil(s.number("count")/3),1,3);
        int tint=!s.flag("customColors")?0xFFFFFFFF:s.color(critical?"criticalColor":"color");
        for(int i=count-1;i>=0;i--){
          var p=critical?ImpactStyles.criticalParticle(style,i,count,t):ImpactStyles.particle(style,i,count,t);
          double size=Math.min(w,h)*(i==0?.55:.18)*(critical?1.1:1)*(.8+.2*Math.sin(Math.PI*t));
          var matrices=g.getMatrices();matrices.pushMatrix();
          matrices.translate((float)(cx+p.x()*h*.32),(float)(cy-p.y()*h*.32));
          matrices.rotate((float)((i==0?0:Math.PI*2*i/count)+ImpactStyles.rotation(style,t)*(i==0?1:3)));matrices.scale((float)size/128,(float)size/128);
          g.drawTexture(net.minecraft.client.gl.RenderPipelines.GUI_TEXTURED,ImpactStyles.texture(design),-64,-64,(frame%6)*128,(frame/6)*128,128,128,128,128,768,512,Colors.alpha(tint,ImpactStyles.opacity(t)*s.number("opacity")));
          matrices.popMatrix();
        }
      }else if(module.equals("playertrails")){
        int primary=s.flag("customColors")?color:switch(design){case "Hearts"->0xFFFF5294;case "Soul Mist"->0xFF32DFC8;case "Embers"->0xFFFF7030;case "Stardust"->0xFFBBA0FF;default->0xFF7B899E;};
        int secondary=s.flag("customColors")?s.color("secondary"):0xFFE1E7EE;
        int count=design.equals("Ribbon")?48:Math.max(8,(int)(18*s.number("density")));
        double lastX=0,lastY=0;
        for(int i=0;i<count;i++){
          double t=i/(double)(count-1),phase=time*s.number("speed")-t*4;
          double px=x+w*.12+t*w*.76,py=cy+Math.sin(phase)*h*.15-(1-t)*s.number("rise")*h*.1;
          int tint=Colors.alpha(design.equals("Ribbon")&&s.flag("rainbow")?Colors.rainbow(time*.1-t*.6):Colors.mix(secondary,primary,t),(.15+.85*t)*s.number("opacity"));
          double size=Math.min(10,2+s.number("size")*2);
          if(design.equals("Ribbon")){if(i>0)CraftedGui.line(g,lastX,lastY,px,py,size,tint);}
          else glyph(g,px,py,design.equals("Embers")?2:size,design.equals("Hearts")?10:design.equals("Stardust")?16:15,tint);
          lastX=px;lastY=py;
        }
      }else{
        var preset=ExplosionMath.preset(design);
        double duration=s.number("lifetime"),age=moving?time%(duration+.65):duration*.3;
        double fade=ExplosionMath.fade(age,duration),r=ExplosionMath.radius(age,duration)*unit*.75*preset.size();
        int tint=Colors.alpha(design.equals("Cyber")?Colors.mix(color,0xFF68DFFF,.65):color,Math.min(1,fade*preset.energy()));
        if(s.flag("primary"))ellipse(g,cx,cy,r,r*.36,tint);
        if(s.flag("pressure"))ellipse(g,cx,cy,r*.7,r*.7,tint);
        if(s.flag("secondaryWave")&&age>s.number("delay")/1000){double q=ExplosionMath.radius(age-s.number("delay")/1000,duration)*unit*.55;ellipse(g,cx,cy,q,q*.3,tint);}
        if(s.flag("column")&&preset.column())CraftedGui.glowLine(g,cx,cy,cx,cy-r*.95,2,tint,.3);
        if(s.flag("sparks"))for(int i=0;i<(int)(18*preset.fragments());i++){
          double a=i*2.399963,dist=r*(.6+(i%3)*.2);
          CraftedGui.line(g,cx+Math.cos(a)*dist*.75,cy+Math.sin(a)*dist*.75,cx+Math.cos(a)*dist,cy+Math.sin(a)*dist,1,tint);
        }
      }
    }finally{g.disableScissor();}
  }
  private static void ellipse(DrawContext g,double x,double y,double rx,double ry,int color){
    for(int i=0;i<40;i++){double a=i*Math.PI/20,b=(i+1)*Math.PI/20;CraftedGui.line(g,x+Math.cos(a)*rx,y+Math.sin(a)*ry,x+Math.cos(b)*rx,y+Math.sin(b)*ry,1,color);}
  }
  private static void glyph(DrawContext g,double x,double y,double r,int shape,int color){
    if(shape==10){for(int i=0;i<24;i++){double a=i*Math.PI/12,b=(i+1)*Math.PI/12;CraftedGui.line(g,x+r*Math.pow(Math.sin(a),3),y-r*(13*Math.cos(a)-5*Math.cos(2*a)-2*Math.cos(3*a)-Math.cos(4*a))/16,x+r*Math.pow(Math.sin(b),3),y-r*(13*Math.cos(b)-5*Math.cos(2*b)-2*Math.cos(3*b)-Math.cos(4*b))/16,1,color);}return;}
    if(shape==7){ellipse(g,x,y,r,r,color);return;}
    if(shape==14){g.fill((int)(x-r/2),(int)(y-r/2),(int)(x+r/2+1),(int)(y+r/2+1),color);return;}
    if(shape==8){CraftedGui.line(g,x-r,y+r,x+r,y-r,1,color);return;}
    if(shape==15){CraftedGui.dot(g,x,y,r,color,.2);return;}
    for(int i=0;i<4;i++){double a=i*Math.PI/2,b=(i+1)*Math.PI/2;CraftedGui.line(g,x+Math.cos(a)*r*.7,y+Math.sin(a)*r,x+Math.cos(b)*r*.7,y+Math.sin(b)*r,1,color);}
  }
  private EffectGalleryPreview(){}
}
