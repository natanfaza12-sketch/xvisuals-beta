package pl.xvisuals.gui.screens;
import pl.xvisuals.config.VisualConfig.ModuleState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.model.ModelPart;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.player.SkinTextures;
import org.joml.Quaternionf;
import org.joml.Vector3f;
/** Native skinned player preview, isolated from player state and world ghost spawning. */
public final class GhostSkinPreview extends WearablePreview {
 private String style;private double progress,phase;
 public static void draw(DrawContext g,String style,double t,double phase,double vertical,ModuleState settings,int x,int y,int w,int h){
  var c=MinecraftClient.getInstance();var id=c.getSession().getUuidOrNull();
  var skin=c.player!=null?c.player.getSkin():id==null?net.minecraft.client.util.DefaultSkinHelper.getSteve():net.minecraft.client.util.DefaultSkinHelper.getSkinTextures(id);
  var state=new GhostSkinPreview();state.style=style;state.progress=t;state.phase=phase;
  state.entityType=EntityType.PLAYER;state.id=Integer.MIN_VALUE;
  state.skinTextures=new SkinTextures(skin.body(),null,null,skin.model(),skin.secure());
  state.baseScale=state.ageScale=1;state.height=1.8f;state.width=.6f;
  state.pose=EntityPose.STANDING;state.bodyYaw=155;state.light=0xF000F0;
  state.hatVisible=state.jacketVisible=state.leftSleeveVisible=state.rightSleeveVisible=state.leftPantsLegVisible=state.rightPantsLegVisible=true;
  state.limbAmplitudeInverse=1;
  var bounds=new ScreenRect(x,y,w,h).transformEachVertex(g.getMatrices());
  if(bounds.width()<=0||bounds.height()<=0)return;
  float scale=(float)(Math.min(bounds.height()/2.7,bounds.width()/2.8)*Math.min(1.3,settings.number("scale")));
  // Keep ascending models inside the card; burial still moves below the visible floor.
  float shift=(float)Math.clamp(vertical,-1.8,.5);
  g.addEntity(state,scale,new Vector3f(0,.92f-shift,0),new Quaternionf().rotationZ((float)Math.PI),null,bounds.getLeft(),bounds.getTop(),bounds.getRight(),bounds.getBottom());
 }
 public static void pose(PlayerEntityModel model,PlayerEntityRenderState state){
  ModelPart[] parts={model.head,model.body,model.rightArm,model.leftArm,model.rightLeg,model.leftLeg};
  for(var p:parts)p.xScale=p.yScale=p.zScale=1;
  if(!(state instanceof GhostSkinPreview g))return;
  for(int i=0;i<parts.length;i++){
   var p=parts[i];double t=g.progress,limb=Math.clamp((t-.25-i*.055)*1.7,0,1);
   switch(g.style){
    case "Afterglow","Soul","Clean Ascension"->{p.roll+=(float)(Math.sin(g.phase*1.3+i)*.055*t);if(i==2||i==3)p.roll+=(i==2?-1:1)*t*.22f;}
    case "Collapse"->{p.originY+=limb*12;p.roll+=(i%2==0?1:-1)*limb*1.8;p.pitch+=limb*.8;}
    case "Glitch"->{double j=Math.sin(Math.floor(g.phase*12)+i*19);p.originX+=j*limb*3;p.yaw+=j*limb*.4;}
    case "Freeze / Shatter","Prismatic Burst"->{p.originX+=(i%2==0?-1:1)*limb*6;p.originY+=limb*limb*12;p.roll+=(i%2==0?-1:1)*limb;}
    case "Ash"->p.originY+=limb*6;
   }
   double end=Math.clamp((t-.65)/.35,0,1);float remaining=(float)(1-end*end*(3-2*end));
   p.xScale=p.yScale=p.zScale=remaining;
  }
  // Outer layers are children in 1.21.11 and inherit their parent pose.
  for(var layer:new ModelPart[]{model.hat,model.jacket,model.leftSleeve,model.rightSleeve,model.leftPants,model.rightPants})layer.resetTransform();
 }
}
