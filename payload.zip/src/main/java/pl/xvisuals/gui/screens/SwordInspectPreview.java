package pl.xvisuals.gui.screens;

import pl.xvisuals.XVisuals;
import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.gui.themes.Theme;
import pl.xvisuals.modules.motion.SwordInspectMotion;
import pl.xvisuals.util.Colors;
import net.minecraft.client.gui.DrawContext;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/** Projected 3D sword diagram driven by the same poses as first-person inspection. */
final class SwordInspectPreview {
  private String randomStyle="Showcase";
  private long lastCycle=Long.MIN_VALUE;
  private final java.util.Random random=new java.util.Random();
  void draw(DrawContext g,String design,int x,int y,int w,int h){
    var s=XVisuals.config().module("swordinspect");
    boolean animated=!XVisuals.config().module("performance").text("animation").equals("Off");
    double duration=s.number("duration"),time=System.nanoTime()/1e9,period=duration+.45;
    long cycle=(long)(time/period);
    if(design.equals("Random")&&cycle!=lastCycle&&animated){
      randomStyle=SwordInspectMotion.select("Random",randomStyle,random);lastCycle=cycle;
    }
    String style=design.equals("Random")?randomStyle:design;
    double t=animated?Math.min(1,(time%period)/duration):.4;
    var p=SwordInspectMotion.pose(style,t);
    boolean plunge=style.equals("Ground Plunge");
    float unit=(float)Math.min(w/3.5,h/3.3),cx=x+w*.5f,cy=y+h*.55f;
    Matrix4f pose=new Matrix4f().translation((float)(plunge?0:p.x()),(float)p.y(),(float)p.z())
        .rotateZ((float)Math.toRadians(p.roll())).rotateY((float)Math.toRadians(p.yaw())).rotateX((float)Math.toRadians(p.pitch()));
    int accent=Theme.accent(),steel=0xFFE3EAF2;
    g.enableScissor(x,y,x+w,y+h);
    try{
      // Extruded blade edges make yaw and pitch distinguishable from a flat spin.
      for(float z:new float[]{-.045f,.045f}){
        line(g,pose,cx,cy,unit,-.09f,.2f,z,-.075f,.85f,z,2,steel);
        line(g,pose,cx,cy,unit,.09f,.2f,z,.075f,.85f,z,2,steel);
        line(g,pose,cx,cy,unit,-.075f,.85f,z,0,1.03f,z,2,steel);
        line(g,pose,cx,cy,unit,.075f,.85f,z,0,1.03f,z,2,steel);
      }
      line(g,pose,cx,cy,unit,0,.23f,.05f,0,.87f,.05f,2,accent);
      line(g,pose,cx,cy,unit,-.23f,.18f,0,.23f,.18f,0,3,accent);
      line(g,pose,cx,cy,unit,0,-.24f,0,0,.18f,0,4,0xFF58616F);
      line(g,pose,cx,cy,unit,-.07f,-.26f,0,.07f,-.26f,0,3,accent);
      var grip=project(pose,0,-.04f,0,cx,cy,unit);
      Glass.line(g,grip.x,grip.y,cx+unit*.85,cy+unit*.70,5,0x887C8794);
      if(plunge){
        double support=SwordInspectMotion.support(t);
        var second=project(pose,0,-.18f,0,cx,cy,unit);
        Glass.line(g,second.x,second.y,cx-unit*.85,cy+unit*.70,5,Colors.alpha(0xFF7C8794,support*.65));
        if(t>=.49&&t<.72)for(int i=0;i<6;i++){
          double age=(t-.49)/.23;
          Glass.dot(g,cx+Math.cos(i*2.4)*unit*age*.6,cy+unit*.9-age*unit*.35,2+age*3,Colors.alpha(0xFFABB2BA,(1-age)*.28),0);
        }
      }
    }finally{g.disableScissor();}
  }
  private static Vector3f project(Matrix4f m,float x,float y,float z,float cx,float cy,float unit){
    Vector3f p=m.transformPosition(new Vector3f(x,y,z));float depth=3f/(3f-p.z);
    return new Vector3f(cx+p.x*unit*depth,cy-p.y*unit*depth,p.z);
  }
  private static void line(DrawContext g,Matrix4f m,float cx,float cy,float u,float x,float y,float z,float xx,float yy,float zz,double width,int color){
    var a=project(m,x,y,z,cx,cy,u);var b=project(m,xx,yy,zz,cx,cy,u);Glass.line(g,a.x,a.y,b.x,b.y,width,color);
  }
}
