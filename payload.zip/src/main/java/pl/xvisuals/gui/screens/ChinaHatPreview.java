package pl.xvisuals.gui.screens;
import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.cosmetics.ChinaHat;
import pl.xvisuals.rendering.shaders.GuiAccess;
import pl.xvisuals.util.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.TextureSetup;
import org.joml.Matrix4f;
import org.joml.Vector3f;
/** Hat-only textured cone; fixed scale makes size/height changes visible in the picker. */
public final class ChinaHatPreview {
 record Point(float x,float y,float z,float u,float v,int color){}
 record Face(Point[] points,double depth){}
 public static void draw(DrawContext g,String theme,int x,int y,int w,int h){
  var s=XVisuals.config().module("chinahat");
  double time=s.flag("animated")&&!XVisuals.config().module("performance").text("animation").equals("Off")?System.nanoTime()/1e9*s.number("speed")*.18:0;
  double radius=s.number("radius"),height=s.number("height"),uv=s.flag("rim")?.445:.375;
  int primary=ChinaHat.tint(theme,s,true),secondary=ChinaHat.tint(theme,s,false);
  var faces=new java.util.ArrayList<Face>();
  for(int i=0;i<ChinaHat.SEGMENTS;i++){
   double a=i*Math.PI*2/ChinaHat.SEGMENTS,b=(i+1)*Math.PI*2/ChinaHat.SEGMENTS;
   int ca=Colors.alpha(Colors.mix(primary,secondary,(Math.cos(a)+1)*.5),s.number("opacity"));
   int cb=Colors.alpha(Colors.mix(primary,secondary,(Math.cos(b)+1)*.5),s.number("opacity"));
   Point tip=new Point(0,(float)-height,0,.5f,.5f,Colors.alpha(Colors.mix(primary,secondary,.5),s.number("opacity")));
   Point pa=point(a,radius,time,uv,ca),pb=point(b,radius,time,uv,cb);
   faces.add(new Face(new Point[]{tip,tip,pa,pb},(pa.z+pb.z)/3));
  }
  faces.sort(java.util.Comparator.comparingDouble(Face::depth).reversed());
  var pose=g.getMatrices();var matrix=new Matrix4f().m00(pose.m00()).m01(pose.m01()).m10(pose.m10()).m11(pose.m11()).m30(pose.m20()).m31(pose.m21());
  float unit=Math.min(w/2.6f,h/1.35f);
  matrix.translate(x+w*.5f,y+h*.62f,0).scale(unit,unit,0).rotateX(.28f);
  var bounds=new ScreenRect(x,y,w,h).transformEachVertex(pose);var access=(GuiAccess)g;
  if(access.visuals$clip()!=null){bounds=bounds.intersection(access.visuals$clip());if(bounds==null)return;}
  var texture=MinecraftClient.getInstance().getTextureManager().getTexture(ChinaHat.texture(theme));
  access.visuals$state().addSimpleElement(new Mesh(matrix,java.util.List.copyOf(faces),bounds,TextureSetup.of(texture.getGlTextureView(),texture.getSampler())));
 }
 private static Point point(double a,double r,double rotation,double uv,int color){return new Point((float)(Math.cos(a)*r),0,(float)(Math.sin(a)*r),(float)(.5+Math.cos(a+rotation)*uv),(float)(.5+Math.sin(a+rotation)*uv),color);}
 record Mesh(Matrix4f matrix,java.util.List<Face> faces,ScreenRect bounds,TextureSetup textureSetup) implements SimpleGuiElementRenderState {
  public com.mojang.blaze3d.pipeline.RenderPipeline pipeline(){return RenderPipelines.GUI_TEXTURED;}
  public ScreenRect scissorArea(){return bounds;}
  public void setupVertices(VertexConsumer out){for(var face:faces)for(var p:face.points)out.vertex(matrix,p.x,p.y,p.z).texture(p.u,p.v).color(p.color);}
 }
 private ChinaHatPreview(){}
}
