package pl.xvisuals.gui.screens;

import pl.xvisuals.XVisuals;
import pl.xvisuals.config.VisualConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.Perspective;
import net.minecraft.text.Text;
import pl.xvisuals.gui.components.Glass;
import net.minecraft.util.Arm;
import org.lwjgl.glfw.GLFW;
import java.util.Locale;

/** Edits the actual first-person transforms; it never replaces inventory stacks. */
public final class HandPlacementScreen extends Screen {
 private final Screen parent;
 private Perspective perspective;
 private boolean oldHud,dragging,right=true,restored;
 private String dragPrefix;
 private double startX,startY,baseX,baseY,baseZ;
 private boolean depthDrag;
 public HandPlacementScreen(Screen parent){super(Text.literal("Hand placement"));this.parent=parent;}
 private VisualConfig.ModuleState state(){return XVisuals.config().module("viewmodel");}
 private String prefix(boolean right){boolean main=client.player==null||((client.player.getMainArm()==Arm.RIGHT)==right);return main||state().flag("linked")?"main":"off";}
 private void save(){if(XVisuals.STORE!=null)XVisuals.STORE.save();}
 @Override protected void init(){
  if(perspective==null){perspective=client.options.getPerspective();oldHud=client.options.hudHidden;}
  client.options.setPerspective(Perspective.FIRST_PERSON);client.options.hudHidden=false;state().enabled=true;
  int top=44,bw=Math.min(110,(width-54)/4);
  addDrawableChild(ButtonWidget.builder(Text.literal("Reset selected"),b->{reset(prefix(right));save();}).dimensions(18,top,bw,20).build());
  addDrawableChild(ButtonWidget.builder(Text.literal("Reset both"),b->{reset("main");reset("off");save();}).dimensions(24+bw,top,bw,20).build());
  addDrawableChild(ButtonWidget.builder(Text.literal(state().flag("linked")?"Linked: on":"Linked: off"),b->{state().values.put("linked",!state().flag("linked"));b.setMessage(Text.literal(state().flag("linked")?"Linked: on":"Linked: off"));save();}).dimensions(30+bw*2,top,bw,20).build());
  addDrawableChild(ButtonWidget.builder(Text.literal("Save & done"),b->close()).dimensions(width-18-bw,top,bw,20).build());
 }
 private void reset(String p){for(String axis:new String[]{"X","Y","Z"})state().values.put(p+axis,0d);state().values.put(p+"Scale",1d);}
 private boolean canvas(double x,double y){return x>=0&&x<width&&y>=86&&y<height-48;}
 private double sensitivity(){return 2.5/Math.max(200,height);}
 @Override public boolean shouldPause(){return false;}
 @Override public void renderBackground(DrawContext g,int x,int y,float dt){}
 @Override public void render(DrawContext g,int mx,int my,float dt){
  g.fill(0,0,width,80,0xe9161b24);g.fill(0,height-48,width,height,0xe9161b24);
  Glass.text(g,"HAND PLACEMENT",18,14,0xfff0ecff);
  Glass.text(g,"Live first-person editor",18,28,0xffa6adbf);
  boolean hover=canvas(mx,my);boolean focus=dragging?right:mx>=width/2;
  for(boolean side:new boolean[]{false,true}){
   int left=side?width/2+6:12,end=side?width-12:width/2-6;
   int tint=(hover&&focus==side)||dragging&&right==side?0xffbca0ff:0xff687384;
   g.fill(left,87,end,88,tint);g.fill(left,87,left+1,103,tint);g.fill(end-1,87,end,103,tint);
   String p=prefix(side);String label=(side?"RIGHT":"LEFT")+"  "+Math.round(state().number(p+"Scale")*100)+"%";
   Glass.center(g,label,(left+end)/2,96,tint);
  }
  String p=prefix(right);
  Glass.center(g,"Drag to move  |  Scroll to resize  |  Shift + drag for depth",width/2,height-37,0xffe4dcf6);
  Glass.center(g,String.format(Locale.ROOT,"%s selected   X %.2f   Y %.2f   Depth %.2f   Size %d%%",right?"Right":"Left",state().number(p+"X"),state().number(p+"Y"),state().number(p+"Z"),Math.round(state().number(p+"Scale")*100)),width/2,height-21,0xffaab7ca);
  if(client.player==null)Glass.center(g,"Join a world to see your hands. Your settings still save.",width/2,height/2,0xffffffff);
  for(var child:children())if(child instanceof ButtonWidget b){
   boolean hot=mx>=b.getX()&&mx<b.getX()+b.getWidth()&&my>=b.getY()&&my<b.getY()+b.getHeight();
   Glass.rounded(g,b.getX(),b.getY(),b.getWidth(),b.getHeight(),5,hot?0xff4a3c66:0xff2b303d);
   Glass.center(g,b.getMessage().getString(),b.getX()+b.getWidth()/2f,b.getY()+6,0xffede7f8);
  }
 }
 @Override public boolean mouseClicked(Click c,boolean twice){
  if(super.mouseClicked(c,twice))return true;
  if(c.button()!=0||!canvas(c.x(),c.y()))return false;
  right=c.x()>=width/2;dragPrefix=prefix(right);dragging=true;depthDrag=(c.modifiers()&GLFW.GLFW_MOD_SHIFT)!=0;
  startX=c.x();startY=c.y();baseX=state().number(dragPrefix+"X");baseY=state().number(dragPrefix+"Y");baseZ=state().number(dragPrefix+"Z");return true;
 }
 @Override public boolean mouseDragged(Click c,double dx,double dy){
  if(!dragging)return super.mouseDragged(c,dx,dy);
  if(depthDrag)state().values.put(dragPrefix+"Z",Math.clamp(baseZ-(c.y()-startY)*sensitivity(),-1.5,1.5));
  else{state().values.put(dragPrefix+"X",Math.clamp(baseX+(c.x()-startX)*sensitivity(),-1.5,1.5));state().values.put(dragPrefix+"Y",Math.clamp(baseY-(c.y()-startY)*sensitivity(),-1.5,1.5));}
  return true;
 }
 @Override public boolean mouseReleased(Click c){if(dragging){dragging=false;save();return true;}return super.mouseReleased(c);}
 @Override public boolean mouseScrolled(double x,double y,double hx,double dy){
  if(!canvas(x,y))return super.mouseScrolled(x,y,hx,dy);right=x>=width/2;String p=prefix(right);
  state().values.put(p+"Scale",Math.clamp(state().number(p+"Scale")+dy*.05,.25,2));return true;
 }
 @Override public void close(){save();client.setScreen(parent);}
 @Override public void removed(){save();if(!restored&&perspective!=null){client.options.setPerspective(perspective);client.options.hudHidden=oldHud;restored=true;}dragging=false;}
}
