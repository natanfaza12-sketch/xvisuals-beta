package pl.xvisuals.gui.screens;
import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.combat.AttackIndicator;
import pl.xvisuals.gui.components.Glass;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import java.util.LinkedHashMap;
/** Free canvas for the actual HUD indicator, using the gameplay transform. */
public final class AttackIndicatorEditorScreen extends Screen {
 private final Screen parent;private final java.util.Map<String,Object> original;
 private int mode;private double grabX,grabY;
 public AttackIndicatorEditorScreen(Screen parent){super(Text.literal("Attack indicator editor"));this.parent=parent;original=new LinkedHashMap<>(s().values);}
 private pl.xvisuals.config.VisualConfig.ModuleState s(){return XVisuals.config().module("attackindicator");}
 private double baseX(){return width/2.+(s().text("position").equals("Hotbar")?104:0);}
 private double baseY(){return s().text("position").equals("Hotbar")?height-20:height/2.+22;}
 private double x(){return baseX()+s().number("offsetX");}private double y(){return baseY()+s().number("offsetY");}
 private double radius(){return 19*s().number("scale")+5;}
 @Override protected void init(){
  addDrawableChild(ButtonWidget.builder(Text.literal("Done"),b->close()).dimensions(width-66,8,58,20).build());
  addDrawableChild(ButtonWidget.builder(Text.literal("Cancel"),b->{s().values=new LinkedHashMap<>(original);close();}).dimensions(width-132,8,60,20).build());
  addDrawableChild(ButtonWidget.builder(Text.literal("Reset layout"),b->{put("offsetX",0);put("offsetY",0);put("rotation",0);put("scale",1);}).dimensions(8,8,90,20).build());
 }
 @Override public boolean shouldPause(){return false;}
 @Override public void renderBackground(DrawContext g,int mx,int my,float dt){}
 @Override public void render(DrawContext g,int mx,int my,float dt){
  if(client.world==null)g.fill(0,0,width,height,0xff161c24);
  AttackIndicator.preview(g);
  double r=radius();int accent=0xffd5a1f1;
  g.drawStrokedRectangle((int)(x()-r),(int)(y()-r),(int)(r*2),(int)(r*2),0xaaaab3c4);
  Glass.line(g,x(),y()-r,x(),y()-r-15,1,accent);
  Glass.dot(g,x(),y()-r-15,4,accent,0);
  Glass.rounded(g,(float)(x()+r-4),(float)(y()+r-4),8,8,2,accent);
  g.drawCenteredTextWithShadow(textRenderer,"Drag to move • square: resize • circle: rotate • wheel: resize",width/2,height-30,0xffffffff);
  g.drawCenteredTextWithShadow(textRenderer,String.format(java.util.Locale.ROOT,"Size %.1f   Rotation %.0f°",s().number("scale"),s().number("rotation")),width/2,height-17,0xffd5a1f1);
  super.render(g,mx,my,dt);
 }
 private void put(String key,double value){s().values.put(key,value);XVisuals.STORE.dirty();}
 @Override public boolean mouseClicked(Click c,boolean twice){
  if(super.mouseClicked(c,twice))return true;if(c.button()!=0)return false;
  double r=radius();
  if(Math.hypot(c.x()-x(),c.y()-(y()-r-15))<9)mode=3;
  else if(Math.hypot(c.x()-(x()+r),c.y()-(y()+r))<11)mode=2;
  else if(Math.abs(c.x()-x())<=r&&Math.abs(c.y()-y())<=r){mode=1;grabX=c.x()-x();grabY=c.y()-y();}
  return mode!=0;
 }
 @Override public boolean mouseDragged(Click c,double dx,double dy){
  if(mode==1){put("offsetX",Math.clamp(c.x()-grabX-baseX(),-200,200));put("offsetY",Math.clamp(c.y()-grabY-baseY(),-150,150));}
  if(mode==2)put("scale",Math.clamp((Math.max(Math.abs(c.x()-x()),Math.abs(c.y()-y()))-5)/19,.5,3));
  if(mode==3){double degrees=Math.toDegrees(Math.atan2(c.y()-y(),c.x()-x()))+90;put("rotation",(degrees+540)%360-180);}
  return mode!=0;
 }
 @Override public boolean mouseReleased(Click c){if(mode!=0){mode=0;XVisuals.STORE.save();return true;}return super.mouseReleased(c);}
 @Override public boolean mouseScrolled(double x,double y,double horizontal,double vertical){put("scale",Math.clamp(s().number("scale")+vertical*.1,.5,3));return true;}
 @Override public void close(){XVisuals.STORE.save();client.setScreen(parent);}
 @Override public void removed(){XVisuals.STORE.save();}
}
