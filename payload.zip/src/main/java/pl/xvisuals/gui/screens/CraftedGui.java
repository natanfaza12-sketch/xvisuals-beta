package pl.xvisuals.gui.screens;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gl.RenderPipelines;
import pl.xvisuals.rendering.CraftedSprites;
/** Gallery samples of the same artwork used by the world meshes. */
final class CraftedGui {
 static void sprite(DrawContext g,double x,double y,double w,double h,int mode,int frame,int tint){
  if(w<=0||h<=0)return;var m=g.getMatrices();m.pushMatrix();m.translate((float)x,(float)y);m.scale((float)w/64,(float)h/64);
  g.drawTexture(RenderPipelines.GUI_TEXTURED,CraftedSprites.ATLAS,-32,-32,mode*64,Math.floorMod(frame,8)*64,64,64,64,64,1536,512,tint);m.popMatrix();
 }
 static void line(DrawContext g,double x,double y,double u,double v,double width,int tint){
  double length=Math.hypot(u-x,v-y);if(length<.001||width<=0)return;
  var m=g.getMatrices();m.pushMatrix();m.translate((float)((x+u)*.5),(float)((y+v)*.5));m.rotate((float)(Math.atan2(v-y,u-x)-Math.PI/2));
  sprite(g,0,0,width*2,length,10,0,tint);m.popMatrix();
 }
 static void glowLine(DrawContext g,double x,double y,double u,double v,double width,int tint,double glow){line(g,x,y,u,v,width,tint);}
 static void dot(DrawContext g,double x,double y,double r,int tint,double glow){sprite(g,x,y,r*2,r*2,5,0,tint);}
 private CraftedGui(){}
}
