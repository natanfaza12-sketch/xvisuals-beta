package pl.xvisuals.gui.screens;

import pl.xvisuals.gui.components.Glass;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/** Fit instructional lines without truncating file requirements or other important guidance. */
final class ScreenText {
  static float scale(double measuredWidth, int availableWidth) {
    return (float)Math.min(1, Math.max(1, availableWidth) / Math.max(1, measuredWidth));
  }
  static void center(DrawContext g, TextRenderer font, String text, int x, int y, int width, int color) {
    float scale = scale(font.getWidth(text), width);
    g.getMatrices().pushMatrix();
    try {
      g.getMatrices().translate(x, y);
      g.getMatrices().scale(scale, scale);
      g.drawCenteredTextWithShadow(font, text, 0, 0, color);
    } finally { g.getMatrices().popMatrix(); }
  }
  static void glassCenter(DrawContext g, String text, int x, int y, int width, int color) {
    float scale = scale(Glass.textWidth(text), width);
    g.getMatrices().pushMatrix();
    try {
      g.getMatrices().translate(x, y);
      g.getMatrices().scale(scale, scale);
      Glass.center(g, text, 0, 0, color);
    } finally { g.getMatrices().popMatrix(); }
  }
  private ScreenText() {}
}
