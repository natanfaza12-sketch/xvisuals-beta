package pl.xvisuals.gui.screens;

import pl.xvisuals.gui.components.ColourPicker;
import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.gui.components.StudioChrome;
import pl.xvisuals.gui.themes.Theme;
import pl.xvisuals.modules.waypoints.*;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import java.util.*;

final class WaypointEditorScreen extends Screen {
  private final Screen parent;
  private final Waypoint original;
  private final WaypointStore origin;
  private final WaypointSession session;
  private final String scope, openedDimension, dimension;
  private final double coordinateScale;
  private TextFieldWidget name,x,y,z,color;
  private final List<WaypointControl> mutations=new ArrayList<>();
  private boolean enabled;
  private String error="";
  private ColourPicker picker;
  private WaypointLayout layout;

  WaypointEditorScreen(Screen parent,Waypoint original) {
    super(Text.literal(original==null?"New waypoint":"Edit waypoint"));this.parent=parent;this.original=original;
    SmartWaypoints.context();origin=SmartWaypoints.store();scope=SmartWaypoints.scope();openedDimension=SmartWaypoints.dimension();
    session=new WaypointSession(origin,scope,openedDimension);
    dimension=original==null?openedDimension:original.dimension();
    coordinateScale=original==null?SmartWaypoints.dimensionScale():original.coordinateScale();enabled=original==null||original.enabled();
  }
  private boolean valid() {
    SmartWaypoints.context();
    return session.matches(SmartWaypoints.store(),SmartWaypoints.scope(),SmartWaypoints.dimension());
  }
  @Override protected void init() {
    String oldName=name==null?null:name.getText(),oldX=x==null?null:x.getText(),oldY=y==null?null:y.getText(),oldZ=z==null?null:z.getText(),oldColor=color==null?null:color.getText();
    mutations.clear();layout=WaypointLayout.editor(width,height);
    int w=layout.width(),left=layout.left(),top=layout.top(),third=(w-12)/3;
    name=field(left,top+53,w,"Waypoint name");name.setMaxLength(48);
    x=field(left,top+108,third,"X");y=field(left+third+6,top+108,third,"Y");z=field(left+2*(third+6),top+108,w-2*(third+6),"Z");
    color=field(left,top+157,w-98,"#RRGGBB");color.setMaxLength(7);
    button("Pick colour",left+w-92,top+159,92,true,()->{
      if(valid())picker=new ColourPicker(color.getText().matches("#[0-9a-fA-F]{6}")?color.getText():"#FFFFFF");
    });
    button("Use my position",left+w-110,top+82,110,true,this::position);
    var toggle=new WaypointControl(enabled?"Visible: On":"Visible: Off",left+w-96,top+11,96,22,enabled,()->{
      if(valid()){enabled=!enabled;clearAndInit();}
    });
    mutations.add(addDrawableChild(toggle));
    int bottom=top+layout.height()-29;
    button("Cancel",left,bottom,(w-6)/2,false,this::close);
    button("Save waypoint",left+(w+6)/2,bottom,(w-6)/2,true,this::save);
    if(oldName!=null){name.setText(oldName);x.setText(oldX);y.setText(oldY);z.setText(oldZ);color.setText(oldColor);}
    else if(original!=null){name.setText(original.name());x.setText(number(original.x()));y.setText(number(original.y()));z.setText(number(original.z()));color.setText(String.format("#%06X",original.color()));}
    else {name.setText("Waypoint");color.setText("#B9A5FF");position();}
    setInitialFocus(name);tick();
  }
  private static String number(double value){return Double.toString(value);}
  private TextFieldWidget field(int x,int y,int w,String label) {
    var field=addDrawableChild(new ConfigUi.Field(x,y,w,label));field.setMaxLength(32);return field;
  }
  private WaypointControl button(String label,int x,int y,int w,boolean mutates,Runnable action) {
    var button=addDrawableChild(new WaypointControl(label,x,y,w,22,label.equals("Save waypoint"),()->{if(!mutates||valid())action.run();}));
    if(mutates)mutations.add(button);return button;
  }
  private void position() {
    if(!valid()||client.player==null){error="World changed. Reopen the editor.";return;}
    var pos=client.player.getEntityPos();
    x.setText(String.format(Locale.ROOT,"%.2f",WaypointMath.scaled(pos.x,SmartWaypoints.dimensionScale(),coordinateScale)));
    y.setText(String.format(Locale.ROOT,"%.2f",pos.y));
    z.setText(String.format(Locale.ROOT,"%.2f",WaypointMath.scaled(pos.z,SmartWaypoints.dimensionScale(),coordinateScale)));
  }
  private void save() {
    if(!valid()){error="World changed. Reopen the editor.";return;}
    try {
      if(original!=null&&origin.points().stream().noneMatch(p->p.id().equals(original.id())))throw new IllegalArgumentException("Waypoint was deleted. Reopen the editor.");
      if(!color.getText().matches("#[0-9a-fA-F]{6}"))throw new IllegalArgumentException("Use a colour in #RRGGBB format.");
      var point=new Waypoint(original==null?UUID.randomUUID().toString():original.id(),name.getText().strip(),
          Integer.parseInt(color.getText().substring(1),16),Double.parseDouble(x.getText().strip()),Double.parseDouble(y.getText().strip()),Double.parseDouble(z.getText().strip()),dimension,coordinateScale,enabled);
      origin.put(point);close();
    } catch(NumberFormatException invalid){error="Enter valid numeric coordinates.";}
    catch(IllegalArgumentException|java.io.IOException failure){error=failure.getMessage();}
  }
  @Override public void tick() {
    boolean available=valid();for(var button:mutations)button.active=available;
    for(var field:List.of(name,x,y,z,color))field.setEditable(available);
    if(!available){picker=null;error="World changed. Reopen the editor.";}
  }
  private float pickerScale(){return Math.min(width/620f,height/410f);}
  private double pickerX(double x){return (x-(width-620*pickerScale())/2)/pickerScale();}
  private double pickerY(double y){return (y-(height-410*pickerScale())/2)/pickerScale();}
  @Override public boolean mouseClicked(Click click,boolean doubled) {
    if(picker==null)return super.mouseClicked(click,doubled);
    double x=pickerX(click.x()),y=pickerY(click.y());
    if(click.button()!=0)return true;
    if(x>=365&&x<=475&&y>=307&&y<=333){color.setText(picker.hex());picker=null;}
    else if(x>=245&&x<=355&&y>=307&&y<=333)picker=null;
    else picker.press(x,y);return true;
  }
  @Override public boolean mouseDragged(Click click,double dx,double dy) {
    if(picker==null)return super.mouseDragged(click,dx,dy);picker.drag(pickerX(click.x()),pickerY(click.y()));return true;
  }
  @Override public boolean mouseReleased(Click click){if(picker!=null){picker.release();return true;}return super.mouseReleased(click);}
  @Override public boolean mouseScrolled(double x,double y,double horizontal,double vertical){return picker!=null||super.mouseScrolled(x,y,horizontal,vertical);}
  @Override public boolean keyPressed(KeyInput key) {
    if(picker!=null){if(key.key()==256)picker=null;else if(key.key()==257){color.setText(picker.hex());picker=null;}return true;}
    return super.keyPressed(key);
  }
  @Override public boolean charTyped(net.minecraft.client.input.CharInput input){return picker!=null||super.charTyped(input);}
  @Override public void renderBackground(DrawContext g,int mx,int my,float delta){}
  @Override public boolean shouldPause(){return false;}
  @Override public void render(DrawContext g,int mx,int my,float delta) {
    layout.draw(g,width,height);int left=layout.left(),top=layout.top(),w=layout.width(),third=(w-12)/3;
    StudioChrome.text(g,title.getString(),left,top+12,Theme.text());
    StudioChrome.scaled(g,ConfigUi.fit(WaypointManagerScreen.dimensionName(dimension),w-108),left,top+28,.8f,Theme.muted());
    StudioChrome.text(g,"Name",left,top+41,Theme.muted());
    StudioChrome.text(g,"Coordinates",left,top+89,Theme.muted());
    StudioChrome.text(g,"Colour",left,top+145,Theme.muted());
    super.render(g,mx,my,delta);
    if(color.getText().matches("#[0-9a-fA-F]{6}"))Glass.dot(g,left+48,top+149,6,0xFF000000|Integer.parseInt(color.getText().substring(1),16),0);
    // X/Y/Z remain labelled even after their placeholders are replaced by numbers.
    for(int i=0;i<3;i++)StudioChrome.scaled(g,List.of("X","Y","Z").get(i),left+i*(third+6)+2,top+136,.7f,Theme.quiet());
    StudioChrome.scaled(g,ConfigUi.fit(error,(int)(w/.75f)),left,top+layout.height()-39,.75f,0xFFFFB8C5);
    if(picker!=null){
      g.fill(0,0,width,height,0xA0060A10);var matrices=g.getMatrices();matrices.pushMatrix();
      float scale=pickerScale();matrices.translate((width-620*scale)/2,(height-410*scale)/2);matrices.scale(scale,scale);
      picker.draw(g,"Waypoint colour");matrices.popMatrix();
    }
  }
  @Override public void close(){client.setScreen(parent);}
}
