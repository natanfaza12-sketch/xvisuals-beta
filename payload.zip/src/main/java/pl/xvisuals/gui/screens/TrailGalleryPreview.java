package pl.xvisuals.gui.screens;
import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.motion.PlayerTrails;
import pl.xvisuals.modules.motion.TrailMotion;
import pl.xvisuals.rendering.shaders.GuiAccess;
import pl.xvisuals.util.Colors;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.TextureSetup;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

final class TrailGalleryPreview {
  private record Puff(Vec3d position,double size,double phase,double age){}
  static void draw(DrawContext g,String style,int x,int y,int w,int h){
    var s=XVisuals.config().module("playertrails");
    boolean moving=!XVisuals.config().module("performance").text("animation").equals("Off");
    double time=moving?System.nanoTime()/1e9:2,life=s.number("lifetime"),speed=s.number("speed");
    double spacing=.19/s.number("density"),travel=1.3;
    int count=Math.min(64,Math.max(3,(int)(life*travel/spacing)));
    var puffs=new java.util.ArrayList<Puff>();
    for(int i=0;i<count;i++){
      var sample=TrailPreviewTiming.sample(time,spacing/travel,i);
      double age=sample.age();
      if(age>=life)continue;
      double phase=Math.floorMod(sample.identity(),4096)*2.399963,swirl=age*speed*2,curl=style.equals("Soul Mist")?.34:style.equals("Embers")?.07:.17;
      puffs.add(new Puff(new Vec3d(1.1-age*travel+(Math.sin(phase+swirl)-Math.sin(phase))*curl,
          .18+age*s.number("rise")*(style.equals("Embers")?1.1:.45),
          (Math.cos(phase+swirl)-Math.cos(phase))*curl),(.16+Math.floorMod(sample.identity(),5)*.02)*s.number("size"),phase,age));
    }
    puffs.sort(java.util.Comparator.comparingDouble(p->p.position.z));
    int primary=s.flag("customColors")?s.color("color"):switch(style){case "Hearts"->0xFFFF5294;case "Soul Mist"->0xFF32DFC8;case "Embers"->0xFFFF7030;case "Stardust"->0xFFBBA0FF;default->0xFF7B899E;};
    int secondary=s.flag("customColors")?s.color("secondary"):switch(style){case "Hearts"->0xFFFFCEE4;case "Soul Mist"->0xFFD3BCFF;case "Embers"->0xFFFFE8A0;case "Stardust"->0xFFE8F7FF;default->0xFFE1E7EE;};
    var pose=g.getMatrices();
    Matrix4f matrix=new Matrix4f().m00(pose.m00()).m01(pose.m01()).m10(pose.m10()).m11(pose.m11()).m30(pose.m20()).m31(pose.m21());
    // Fit the whole lifetime, not this frame's particles: avoids zooming and recentering
    // whenever a particle is emitted or expires.
    double margin=.24*s.number("size")*TrailMotion.expansion(1)*(style.equals("Stardust")?2.1:1.8);
    double curl=style.equals("Soul Mist")?.34:style.equals("Embers")?.07:.17;
    double rise=life*s.number("rise")*(style.equals("Embers")?1.1:.45);
    double minX=1.1-life*travel-2*curl-margin,maxX=1.1+2*curl+margin;
    double minY=.18+Math.min(0,rise)-margin,maxY=.18+Math.max(0,rise)+margin;
    if(puffs.isEmpty())return;
    float unit=(float)Math.min((w-8)/Math.max(2.8,maxX-minX),(h-8)/Math.max(1.5,maxY-minY));
    matrix.translate(x+w*.5f,y+h*.5f,0).scale(unit,-unit,0)
        .translate((float)(-(minX+maxX)*.5),(float)(-(minY+maxY)*.5),0);
    var access=(GuiAccess)g;
    ScreenRect bounds=new ScreenRect(x,y,w,h).transformEachVertex(pose);
    if(access.visuals$clip()!=null){bounds=bounds.intersection(access.visuals$clip());if(bounds==null)return;}
    final var meshMatrix=matrix;final int first=primary,second=secondary;
    double opacity=s.number("opacity");
    access.visuals$state().addSimpleElement(new Mesh(meshMatrix,java.util.List.copyOf(puffs),style,life,speed,first,second,opacity,bounds));
  }
  private record Mesh(Matrix4f matrix,java.util.List<Puff> puffs,String style,double life,double speed,int primary,int secondary,double opacity,ScreenRect bounds) implements SimpleGuiElementRenderState {
    public com.mojang.blaze3d.pipeline.RenderPipeline pipeline(){return RenderPipelines.GUI_TEXTURED;}
    public TextureSetup textureSetup(){var t=net.minecraft.client.MinecraftClient.getInstance().getTextureManager().getTexture(pl.xvisuals.rendering.CraftedSprites.ATLAS);return TextureSetup.of(t.getGlTextureView(),t.getSampler());}
    public ScreenRect scissorArea(){return bounds;}
    public void setupVertices(VertexConsumer out){for(var p:puffs)PlayerTrails.previewPuff(out,matrix,style,p.position,p.size,p.phase,p.age,life,speed,primary,secondary,TrailMotion.fade(p.age,life)*opacity);}
  }
  private TrailGalleryPreview(){}
}
