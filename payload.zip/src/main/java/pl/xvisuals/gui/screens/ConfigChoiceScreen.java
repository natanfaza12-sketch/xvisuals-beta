package pl.xvisuals.gui.screens;
import java.util.*;
import java.util.function.Consumer;
import pl.xvisuals.gui.components.StudioChrome;
import pl.xvisuals.gui.themes.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

/** Searchable choices using the same Studio controls as the config library. */
final class ConfigChoiceScreen extends Screen {
 record Option(String id,String label) {}
 private final Screen parent;private final List<Option> options;private final Consumer<String> chosen;private final String selected;
 StudioScreen host;
 private String query="";private int page;private TextFieldWidget search;
 ConfigChoiceScreen(Screen parent,String title,List<Option> options,String selected,Consumer<String> chosen){super(Text.literal(title));this.parent=parent;this.options=List.copyOf(options);this.selected=selected;this.chosen=chosen;}
 @Override protected void init(){int w=Math.min(460,width-48);search=new ConfigUi.Field((width-w)/2,32,w,"Search options");search.setMaxLength(80);search.setText(query);search.setChangedListener(v->{query=v;page=0;layout();});layout();}
 private void button(String label,int x,int y,int w,boolean active,Runnable run){addDrawableChild(new ConfigUi.Button(label,null,x,y,w,22,active,run));}
 private void layout(){clearChildren();addDrawableChild(search);setInitialFocus(search);
  int w=Math.min(460,width-48),x=(width-w)/2;
  var filtered=options.stream().filter(o->(o.label()+" "+o.id()).toLowerCase(Locale.ROOT).contains(query.toLowerCase(Locale.ROOT))).toList();
  int rows=Math.max(1,(height-104)/27),pages=Math.max(1,(filtered.size()+rows-1)/rows);page=Math.min(page,pages-1);
  for(int i=0;i<rows&&page*rows+i<filtered.size();i++){var o=filtered.get(page*rows+i);button(o.label(),x,66+i*27,w,selected.equals(o.id()),()->{chosen.accept(o.id());if(host==null?client.currentScreen==this:host.isConfigPage(this))close();});}
  button("<",x,height-30,26,false,()->{page=Math.max(0,page-1);layout();});button((page+1)+" / "+pages,x+30,height-30,58,false,()->{});button(">",x+92,height-30,26,false,()->{page=Math.min(pages-1,page+1);layout();});button("Back",x+w-60,height-30,60,false,this::close);
 }
 @Override public void renderBackground(DrawContext g,int mx,int my,float d){}
 @Override public void render(DrawContext g,int mx,int my,float d){ConfigUi.panel(g,width,height);StudioChrome.center(g,ConfigUi.fit(title.getString(),width-48),width/2f,16,Theme.text());super.render(g,mx,my,d);}
 @Override public void close(){if(host!=null)host.showConfigPage(parent);else client.setScreen(parent);}
 @Override public boolean shouldPause(){return false;}
}
