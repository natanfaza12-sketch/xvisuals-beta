package pl.xvisuals.gui.screens;
import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.larp.*;
import pl.xvisuals.util.Colors;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.item.*;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.util.Identifier;
final class LarpPreview {
 private static final ItemStack STACK=stack();
 private static ItemStack stack(){var s=new ItemStack(Items.STICK);s.set(DataComponentTypes.ITEM_MODEL,Identifier.of("xvisuals","totem/money"));return s;}
 static void draw(DrawContext g,String style,int x,int y,int w,int h){
  var s=XVisuals.config().module("larp");double t=XVisuals.config().module("performance").text("animation").equals("Off")?2:System.nanoTime()/1e9*s.number("speed");
  double r=s.number("radius");float unit=(float)Math.min(w/(2*r+1),h/3.8);var m=g.getMatrices();
  m.pushMatrix();m.translate(x+w*.5f,y+h*.66f);m.scale(2.2f,2.2f);g.drawItem(STACK,-8,-8);m.popMatrix();
  for(int i=0;i<Math.min(24,s.integer("amount"));i++){var p=LarpDesigns.note(style,i,t,r);float px=x+w*.5f+(float)(p.x()+p.z()*.2)*unit,py=y+h*.93f-(float)p.y()*unit;float width=(float)(.58*s.number("size")*unit*Math.max(.18,Math.abs(Math.cos(p.spin())))),height=(float)(.29*s.number("size")*unit);
   m.pushMatrix();m.translate(px,py);m.rotate((float)(Math.sin(p.spin())*.28));m.scale(width/64,height/32);g.drawTexture(RenderPipelines.GUI_TEXTURED,LarpEffects.texture("banknote"),-32,-16,0,0,64,32,64,32,Colors.alpha(0xffffffff,p.alpha()));m.popMatrix();
  }
  if(s.flag("coins"))for(int i=0;i<6;i++){double a=t*.8+i*Math.PI/3;float size=(float)(12*s.number("size"));m.pushMatrix();m.translate(x+w*.5f+(float)Math.cos(a)*w*.27f,y+h*.63f+(float)Math.sin(a)*h*.16f);m.scale(size/24*(float)Math.max(.2,Math.abs(Math.cos(t*2+i))),size/24);g.drawTexture(RenderPipelines.GUI_TEXTURED,LarpEffects.texture("coin"),-12,-12,0,0,24,24,24,24);m.popMatrix();}
 }
 private LarpPreview(){}
}
