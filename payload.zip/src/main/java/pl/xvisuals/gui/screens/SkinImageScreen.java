package pl.xvisuals.gui.screens;

import pl.xvisuals.XVisuals;
import pl.xvisuals.rendering.CustomSkyImage;
import pl.xvisuals.menu.CustomBackgroundImport;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import java.nio.file.Path;
import java.util.List;

public final class SkinImageScreen extends Screen {
  private final Screen parent;
  private String status="Choose an image or drag it onto this screen.";
  private boolean importing;
  public SkinImageScreen(Screen parent){super(Text.literal("Import skin PNG"));this.parent=parent;}
  @Override protected void init(){
    addDrawableChild(ButtonWidget.builder(Text.literal("Choose PNG"),b->choose()).dimensions(width/2-100,height/2,200,24).build());
    addDrawableChild(ButtonWidget.builder(Text.literal("Done"),b->close()).dimensions(width/2-70,height/2+72,140,22).build());
  }
  private void choose(){
    if(importing)return;
    try(var stack=org.lwjgl.system.MemoryStack.stackPush()) {
      var filters=stack.mallocPointer(1);filters.put(stack.UTF8("*.png")).flip();
      String file=org.lwjgl.util.tinyfd.TinyFileDialogs.tinyfd_openFileDialog("Choose local skin",null,filters,"PNG skin",false);
      if(file!=null)load(Path.of(file));
    }catch(Exception e){status="File picker unavailable. Drag an image here instead.";}
  }
  public void load(Path file){
    if(importing)return;
    importing=true;status="Importing image...";
    var game=net.minecraft.client.MinecraftClient.getInstance();
    var config=XVisuals.config();
    java.util.concurrent.CompletableFuture.runAsync(()->{
      try {
        pl.xvisuals.modules.cosmetics.SkinImageValidation.validate(file);
        Path imported=CustomBackgroundImport.importImage(file,net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("xvisuals/skins"),4096L,1024*1024);
        var skinImage=javax.imageio.ImageIO.read(imported.toFile());
        boolean valid=skinImage!=null && skinImage.getWidth()==64 && skinImage.getHeight()==64;
        if(skinImage!=null)skinImage.flush();
        if(!valid){java.nio.file.Files.deleteIfExists(imported);throw new java.io.IOException("Use a 64 x 64 skin");}
        game.execute(()->{
          importing=false;
          if(XVisuals.config()!=config){status="Profile changed. Please import again.";return;}
          var sky=config.module("skinchanger");sky.values.put("image",imported.toString());
          sky.values.put("source","Local PNG");
          sky.enabled=true;
          
          status=XVisuals.STORE.save()?"Skin imported and saved.":"Applied; settings could not be saved.";
        });
      }catch(Exception e){game.execute(()->{importing=false;status="Import failed: "+e.getMessage();});}
    });
  }
  @Override public void onFilesDropped(List<Path> files){if(files.size()==1)load(files.getFirst());else status="Drop one image at a time.";}
  @Override public void renderBackground(DrawContext g,int x,int y,float d){}
  @Override public void render(DrawContext g,int mx,int my,float d){
    g.fillGradient(0,0,width,height,0xEF101827,0xEF241A38);
    int y=height/2;
    g.drawCenteredTextWithShadow(textRenderer,"IMPORT LOCAL SKIN",width/2,y-78,0xFFFFFFFF);
    g.drawCenteredTextWithShadow(textRenderer,"Use a 64 x 64 PNG Minecraft skin.",width/2,y-56,0xFFBCCBDD);
    g.drawCenteredTextWithShadow(textRenderer,"Select Classic or Slim arms in the module settings.",width/2,y-40,0xFFBCCBDD);
    g.drawCenteredTextWithShadow(textRenderer,textRenderer.trimToWidth(status,width-24),width/2,y+36,0xFFFFFFFF);
    g.drawCenteredTextWithShadow(textRenderer,"Only you see this skin. Your account skin stays unchanged.",width/2,y+54,0xFFBCCBDD);
    super.render(g,mx,my,d);
  }
  @Override public void close(){client.setScreen(parent);}
  @Override public boolean shouldPause(){return false;}
}
