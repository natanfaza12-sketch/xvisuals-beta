package pl.xvisuals.gui.screens;

import pl.xvisuals.XVisuals;
import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.gui.components.StudioChrome;
import pl.xvisuals.gui.themes.Theme;
import pl.xvisuals.modules.waypoints.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import java.io.IOException;
import java.util.*;

/** Studio materials, native keyboard focus, and a world-bound, paginated waypoint library. */
public final class WaypointManagerScreen extends Screen {
  private final Screen parent;
  private final String scope, dimension;
  private final WaypointStore origin;
  private final WaypointSession session;
  private String selected="", query="", message="";
  private boolean allDimensions, wasValid;
  private int page;
  private WaypointLayout layout;
  private TextFieldWidget search;
  private List<Waypoint> shown=List.of();

  public WaypointManagerScreen(Screen parent) {
    super(Text.literal("Waypoints"));this.parent=parent;SmartWaypoints.context();
    scope=SmartWaypoints.scope();dimension=SmartWaypoints.dimension();origin=SmartWaypoints.store();
    session=new WaypointSession(origin,scope,dimension);
    if(origin!=null)selected=Objects.requireNonNullElse(origin.selected(dimension),"");
  }
  private boolean valid() {
    SmartWaypoints.context();
    return session.matches(SmartWaypoints.store(),SmartWaypoints.scope(),SmartWaypoints.dimension());
  }
  private Waypoint chosen() {return !valid()?null:origin.points().stream().filter(p->p.id().equals(selected)).findFirst().orElse(null);}
  @Override protected void init() {
    layout=WaypointLayout.manager(width,height);
    search=new ConfigUi.Field(layout.left(),layout.top()+38,layout.width()-112,"Search waypoints");
    search.setMaxLength(80);search.setText(query);
    search.setChangedListener(value->{query=value;page=0;rebuild();});
    rebuild();
  }
  private WaypointControl button(String label,int x,int y,int w,boolean enabled,boolean accent,Runnable action) {
    var button=addDrawableChild(new WaypointControl(label,x,y,w,22,accent,action));button.active=enabled;return button;
  }
  private void rebuild() {
    var focus=getFocused();clearChildren();addDrawableChild(search);
    if(focus==search)setFocused(search);
    wasValid=valid();int x=layout.left(),w=layout.width(),top=layout.top(),footer=layout.footer();
    var module=XVisuals.config().module("smartwaypoints");
    button(module.enabled?"Markers on":"Markers off",x+w-194,top+10,88,wasValid,module.enabled,()->{
      if(!valid())return;module.enabled=!module.enabled;XVisuals.STORE.dirty();rebuild();
    });
    button("+ New waypoint",x+w-100,top+10,100,wasValid,true,()->{if(valid())client.setScreen(new WaypointEditorScreen(this,null));});
    button(allDimensions?"All dimensions":"This dimension",x+w-106,top+40,106,wasValid,allDimensions,()->{
      allDimensions=!allDimensions;page=0;selected="";rebuild();
    });
    String match=query.strip().toLowerCase(Locale.ROOT);
    var points=!wasValid?List.<Waypoint>of():origin.points().stream()
        .filter(p->allDimensions||p.dimension().equals(dimension))
        .filter(p->(p.name()+" "+dimensionName(p.dimension())).toLowerCase(Locale.ROOT).contains(match))
        .sorted(Comparator.comparing(Waypoint::name,String.CASE_INSENSITIVE_ORDER).thenComparing(Waypoint::id)).toList();
    int rows=layout.rows(),pages=Math.max(1,(points.size()+rows-1)/rows);page=Math.clamp(page,0,pages-1);
    shown=points.subList(page*rows,Math.min(points.size(),(page+1)*rows));
    if(points.stream().noneMatch(p->p.id().equals(selected)))selected="";
    for(int i=0;i<shown.size();i++) {
      var p=shown.get(i);
      String status=!p.enabled()?"Hidden":p.id().equals(origin.selected(dimension))?"Navigating":"Visible";
      if(!p.dimension().equals(dimension)&&!SmartWaypoints.sharing())status="Other dimension";
      String subtitle=String.format(Locale.ROOT,"%.0f, %.0f, %.0f · %s · %s",p.x(),p.y(),p.z(),dimensionName(p.dimension()),status);
      addDrawableChild(new ConfigUi.Button(p.name(),subtitle,x,layout.listTop()+i*39,w,35,p.id().equals(selected),()->{
        selected=p.id();message="";rebuild();
      }));
    }
    button("<",x,footer+30,24,page>0,false,()->{page--;rebuild();});
    button(">",x+28,footer+30,24,page+1<pages,false,()->{page++;rebuild();});
    pageLabel=(page+1)+" / "+pages+" · "+points.size()+" saved";
    var p=chosen();int bw=(w-118)/3;
    if(p!=null){
      button("Edit",x,footer,bw,true,false,()->{var point=chosen();if(point!=null)client.setScreen(new WaypointEditorScreen(this,point));});
      button(p.enabled()?"Hide":"Show",x+bw+6,footer,bw,true,false,()->{
        var point=chosen();if(point!=null)write(()->origin.put(point.enabled(!point.enabled())),point.enabled()?"Waypoint hidden.":"Waypoint visible.");
      });
      button("Delete",x+2*(bw+6),footer,bw,true,false,this::confirmDelete);
    }
    boolean navigating=p!=null&&p.id().equals(origin.selected(dimension));
    boolean canNavigate=p!=null&&p.enabled()&&(p.dimension().equals(dimension)||SmartWaypoints.sharing());
    if(p!=null)button(navigating?"Stop route":"Navigate",x+w-100,footer,100,canNavigate,true,()->{
      var point=chosen();if(point==null)return;
      boolean stopping=point.id().equals(origin.selected(dimension));
      write(()->origin.select(dimension,stopping?null:point.id()),stopping?"Navigation stopped.":
          module.enabled?"Navigation selected. Close this screen to see your route.":"Navigation saved. Turn Markers on above to display it.");
    });
    button("Done",x+w-66,footer+30,66,true,false,this::close);
  }
  private String pageLabel="";
  private void confirmDelete() {
    var p=chosen();if(p==null)return;
    client.setScreen(new WaypointDeleteScreen(this,p.name(),this::valid,
        ()->write(()->origin.delete(p.id()),"Waypoint deleted.")));
  }
  private interface Write {void run() throws IOException;}
  private void write(Write action,String success) {
    if(!valid())return;
    try {action.run();message=success;}catch(IOException failure){message="Could not save: "+failure.getMessage();}
    rebuild();
  }
  @Override public void tick(){if(valid()!=wasValid)rebuild();}
  // Minecraft 1.21.11 renders the background before render(). Never enqueue a second blur.
  @Override public void renderBackground(DrawContext g,int mx,int my,float delta){}
  @Override public boolean shouldPause(){return false;}
  @Override public void render(DrawContext g,int mx,int my,float delta) {
    layout.draw(g,width,height);
    StudioChrome.text(g,"Waypoints",layout.left(),layout.top()+10,Theme.text());
    StudioChrome.scaled(g,dimensionName(dimension),layout.left(),layout.top()+25,.8f,Theme.muted());
    super.render(g,mx,my,delta);
    for(int i=0;i<shown.size();i++)Glass.dot(g,layout.left()+5,layout.listTop()+i*39+12,3,0xFF000000|shown.get(i).color(),0);
    StudioChrome.scaled(g,pageLabel,layout.left()+60,layout.footer()+37,.8f,Theme.muted());
    if(shown.isEmpty()) {
      float emptyY=layout.listTop()+Math.max(8,(layout.footer()-layout.listTop())/2f-16);
      StudioChrome.center(g,wasValid?(query.isBlank()?"No waypoints yet":"No matches"):"No world available",width/2f,emptyY,Theme.text());
      String hint=wasValid?(query.isBlank()?"Save a place with + New waypoint":"Try another name or dimension"):"Join a world to save places";
      StudioChrome.center(g,ConfigUi.fit(hint,layout.width()-24),width/2f,emptyY+18,Theme.muted());
    }
    String status=message;
    if(!wasValid)status=SmartWaypoints.error().isEmpty()?"World changed. Reopen this manager.":SmartWaypoints.error();
    else if(status.isEmpty()&&!XVisuals.config().module("smartwaypoints").enabled)status="Markers are off. Turn them on above to see your waypoints.";
    else if(status.isEmpty())status="Saved for this world. Select a place to navigate.";
    StudioChrome.scaled(g,ConfigUi.fit(status,(int)(layout.width()/.8f)),layout.left(),layout.footer()+60,.8f,Theme.muted());
  }
  static String dimensionName(String id) {
    return switch(id){case "minecraft:overworld"->"Overworld";case "minecraft:the_nether"->"Nether";case "minecraft:the_end"->"The End";case ""->"No world";default->id.substring(id.indexOf(':')+1).replace('_',' ');};
  }
  @Override public void close(){XVisuals.STORE.save();client.setScreen(parent);}
}
