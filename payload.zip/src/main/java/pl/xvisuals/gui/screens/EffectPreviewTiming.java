package pl.xvisuals.gui.screens;
/** A representative frozen pose, or a loop with a short gap between impacts. */
public final class EffectPreviewTiming {
  public static double progress(double seconds,double duration,boolean animated){
    if(!animated)return .4;
    if(!Double.isFinite(seconds)||!Double.isFinite(duration)||duration<=0)return .4;
    return (seconds%(duration+.45))/duration;
  }
  private EffectPreviewTiming(){}
}
