package pl.xvisuals.gui.screens;
import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.motion.LandingDesigns;
import pl.xvisuals.modules.motion.JumpCircles;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gl.RenderPipelines;
/** Same textured frames, colour, expansion and separated layers used in world rendering. */
final class JumpCirclePreview {
 static void draw(DrawContext g,String style,int x,int y,int w,int h){
  var s=XVisuals.config().module("jumpcircles");
  boolean animated=!XVisuals.config().module("performance").text("animation").equals("Off");
  double duration=s.number("duration")/s.number("speed"),now=animated?System.nanoTime()/1e9:0;
  double t=animated?(now%(duration+.12))/duration:.3;if(t>=1)return;
  int frame=LandingDesigns.frame(t),layers=Math.clamp(s.integer("layers"),1,3);
  float base=(float)Math.min(w*.83,h*1.4),cx=x+w*.5f,cy=y+h*.58f;
  for(int l=0;l<layers;l++){
   float size=(float)(base*LandingDesigns.radius(t)*LandingDesigns.layerScale(l));
   var m=g.getMatrices();m.pushMatrix();m.translate(cx,cy-(float)(LandingDesigns.lift(l,t,s.number("depth"))*base*.35));
   m.scale(1,.5f);m.rotate((float)LandingDesigns.rotation(style,l,t));m.scale(size/LandingDesigns.CELL,size/LandingDesigns.CELL);
   double alpha=LandingDesigns.opacity(t)*s.number("opacity")*LandingDesigns.layerOpacity(l);
   int strips=s.flag("rainbow")||!s.flag("designColors")&&s.flag("gradient")?12:1,sw=LandingDesigns.CELL/strips;
   for(int col=0;col<strips;col++)g.drawTexture(RenderPipelines.GUI_TEXTURED,LandingDesigns.texture(style),-LandingDesigns.CELL/2+col*sw,-LandingDesigns.CELL/2,(frame%6)*LandingDesigns.CELL+col*sw,(frame/6)*LandingDesigns.CELL,sw,LandingDesigns.CELL,sw,LandingDesigns.CELL,LandingDesigns.WIDTH,LandingDesigns.HEIGHT,JumpCircles.tint(s,strips==1?.5:col/(double)(strips-1),now,alpha));
   m.popMatrix();
  }
 }
 private JumpCirclePreview(){}
}
