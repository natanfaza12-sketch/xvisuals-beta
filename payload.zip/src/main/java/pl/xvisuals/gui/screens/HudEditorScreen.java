package pl.xvisuals.gui.screens;

import pl.xvisuals.XVisuals;
import pl.xvisuals.config.*;
import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.hud.*;
import java.util.*;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.*;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** A free canvas with a movable inspector and bounds shared with the live HUD. */
public final class HudEditorScreen extends Screen {
  private static final int TEXT=0xffededed, MUTED=0xff919191, ACCENT=0xffeeeeee;
  private final Screen parent;
  private final List<Hit> hits=new ArrayList<>();
  private final Deque<String> undo=new ArrayDeque<>(), redo=new ArrayDeque<>();
  private String selected="FPS", dragging, field="", buffer="", tab="Arrange";
  private boolean controls=true, resizing, panelDrag, resetPending, showGrid;
  private int listOffset;
  private float ui=1, px=-1, py=42;
  private double grabX,grabY,startScale;
  private record Hit(float x,float y,float w,float h,Runnable action) {}
  public HudEditorScreen(Screen parent) { super(Text.literal("HUD studio")); this.parent=parent; }
  private VisualConfig cfg() { return XVisuals.config(); }
  private VisualConfig.HudState state() { return cfg().widgets.get(selected); }
  @Override public boolean shouldPause() { return false; }
  @Override public void renderBackground(DrawContext g,int x,int y,float dt) {}
  @Override protected void init() {
    layout(); HudManager.layout(width,height);
    // Preserve the appearance once, then every widget is independently positioned.
    for(var e:cfg().widgets.entrySet()) if(e.getValue().row>=0) detach(e.getKey());
  }
  private void layout() {
    // Keep editor controls compact even when Minecraft uses a large GUI scale.
    float density=(float)client.getWindow().getScaleFactor();
    ui=Math.max(.25f,Math.min(Math.min(1.15f,2.4f/density),Math.min((width-16f)/360,(height-24f)/326)));
    if(px<0) px=width-212*ui-8;
    px=Math.clamp(px,0,Math.max(0,width-212*ui));
    py=Math.clamp(py,34*ui,Math.max(34*ui,height-292*ui));
  }
  @Override public void close() { commitField(); XVisuals.STORE.save(); client.setScreen(parent); }
  @Override public void removed() { XVisuals.STORE.save(); }
  private void dirty() { XVisuals.STORE.dirty(); }
  private void toggleVisibility(String name) {
    change(()->{var h=cfg().widgets.get(name);boolean visible=HudManager.visible(name,true);h.enabled=!visible;h.hidden=visible;if(name.equals("Now Playing"))pl.xvisuals.hud.MusicControls.setEnabled(cfg(),!visible);});
  }
  private String snapshot() { return HudEditorSnapshot.capture(cfg()); }
  private void remember() { undo.push(snapshot()); if(undo.size()>60) undo.removeLast(); redo.clear(); }
  private void change(Runnable action) { remember(); action.run(); dirty(); }
  private void history(boolean forward) {
    var from=forward?redo:undo; var to=forward?undo:redo;
    if(from.isEmpty()) return;
    to.push(snapshot()); HudEditorSnapshot.restore(cfg(),from.pop());
    dragging=null; field=""; resetPending=false; dirty();
  }
  private void detach(String name) {
    var h=cfg().widgets.get(name); var b=HudManager.bounds(name,width,height);
    h.x=b.x()/width; h.y=b.y()/height; h.scale=b.scale(); h.row=-1;
  }
  private void move(double x,double y,boolean snap) {
    var h=state(); h.row=-1;
    h.x=HudPlacement.position(x,HudManager.widgetWidth(selected)*h.scale,width,snap,cfg().module("hud").number("grid"))/width;
    h.y=HudPlacement.position(y,HudManager.widgetHeight(selected)*h.scale,height,snap,cfg().module("hud").number("grid"))/height;
  }
  private void resize(double scale) {
    if(state().row>=0)detach(selected);
    state().scale=HudPlacement.scale(scale,state().x*width,state().y*height,
        HudManager.widgetWidth(selected),HudManager.widgetHeight(selected),width,height);
  }
  private void align(int horizontal,int vertical) {
    if(state().locked) return;
    change(() -> { detach(selected); var b=HudManager.bounds(selected,width,height);
      move(horizontal<0?b.x():(width-b.width())*horizontal/2,vertical<0?b.y():(height-b.height())*vertical/2,false); });
  }
  @Override public void render(DrawContext g,int mx,int my,float dt) {
    layout(); hits.clear();
    if(client.world==null) pl.xvisuals.menu.MenuBackdrop.draw(g,width,height);
    if(showGrid && controls) {
      int step=Math.max(4,(int)cfg().module("hud").number("grid"));
      for(int x=0;x<width;x+=step) for(int y=0;y<height;y+=step) g.fill(x,y,x+1,y+1,0x406b7b96);
    }
    HudManager.render(g,true);
    if(controls || dragging!=null) for(String name:cfg().widgets.keySet()) {
      if(!HudManager.visible(name,true)) continue;
      var b=HudManager.bounds(name,width,height); boolean active=name.equals(selected);
      outline(g,b,active?ACCENT:0x555e738f);
      if(active) {
        if(!state().locked) Glass.rounded(g,(float)(b.x()+b.width()-4),(float)(b.y()+b.height()-4),7,7,2,ACCENT);
      }
    }
    if(dragging!=null) {
      var b=HudManager.bounds(selected,width,height);
      if(Math.abs(b.x()+b.width()/2-width/2d)<1) g.fill(width/2,0,width/2+1,height,0x8898e6d8);
      if(Math.abs(b.y()+b.height()/2-height/2d)<1) g.fill(0,height/2,width,height/2+1,0x8898e6d8);
      return;
    }
    if(!controls) return;
    g.getMatrices().pushMatrix(); g.getMatrices().scale(ui,ui);
    float cx=width/ui/2;
    Glass.rounded(g,cx-176,6,352,27,6,0xee141414);
    Glass.scaled(g,"HUD",cx-166,16,.8f,TEXT);
    button(g,mx,my,cx-129,10,43,19,"Undo",!undo.isEmpty(),()->history(false));
    button(g,mx,my,cx-82,10,43,19,"Redo",!redo.isEmpty(),()->history(true));
    button(g,mx,my,cx-35,10,58,19,"Grid",showGrid,()->showGrid=!showGrid);
    button(g,mx,my,cx+27,10,83,19,"Preview [Tab]",false,()->controls=false);
    button(g,mx,my,cx+114,10,54,19,"Done",true,this::close);
    g.getMatrices().translate(px/ui,py/ui);
    Glass.rounded(g,0,0,212,292,6,0xed141414);
    Glass.scaled(g,"HUD editor",12,12,.9f,TEXT);
    Glass.scaled(g,"Position · size · appearance",12,27,.65f,MUTED);
    for(int i=0;i<3;i++) { String t=List.of("Widgets","Arrange","Style").get(i);
      local(g,mx,my,8+i*66,43,62,22,t,tab.equals(t),()->{commitField();tab=t;}); }
    if(tab.equals("Widgets")) widgets(g,mx,my); else {
      Glass.scaled(g,selected,12,76,.9f,TEXT);
      local(g,mx,my,8,94,94,21,HudManager.visible(selected,true)?"Visible":"Hidden",HudManager.visible(selected,true),()->toggleVisibility(selected));
      local(g,mx,my,108,94,96,21,state().locked?"Locked":"Unlocked",state().locked,()->change(()->state().locked=!state().locked));
      if(tab.equals("Arrange")) arrange(g,mx,my); else style(g,mx,my);
    }
    Glass.scaled(g,field.isEmpty()?"Arrows: 1px / Shift-drag: grid":"Enter: apply / Esc: cancel",10,274,.72f,MUTED);
    g.getMatrices().popMatrix();

  }
  private void widgets(DrawContext g,int mx,int my) {
    Glass.scaled(g,"Select a block, then arrange it",12,76,.72f,MUTED);
    var names=new ArrayList<>(cfg().widgets.keySet());
    listOffset=Math.clamp(listOffset,0,Math.max(0,names.size()-6));
    for(int i=0;i<6 && i+listOffset<names.size();i++) {
      String name=names.get(i+listOffset); var h=cfg().widgets.get(name); int y=93+i*23;
      local(g,mx,my,8,y,149,21,name,name.equals(selected),()->{selected=name;tab="Arrange";});
      local(g,mx,my,161,y,43,21,HudManager.visible(name,true)?"On":"Off",HudManager.visible(name,true),()->toggleVisibility(name));
    }
    local(g,mx,my,8,238,58,22,"Previous",false,()->listOffset=Math.max(0,listOffset-6));
    local(g,mx,my,71,238,58,22,"Next",false,()->listOffset=Math.min(names.size()-6,listOffset+6));
    local(g,mx,my,134,238,70,22,"HUD "+(cfg().on("hud")?"on":"off"),cfg().on("hud"),()->change(()->cfg().module("hud").enabled=!cfg().on("hud")));
  }
  private void arrange(DrawContext g,int mx,int my) {
    var b=HudManager.bounds(selected,width,height);
    number(g,mx,my,8,123,94,"X",b.x()); number(g,mx,my,108,123,96,"Y",b.y());
    number(g,mx,my,8,151,94,"Scale",Math.round(state().scale*100));
    local(g,mx,my,108,151,96,22,"Free movement",true,()->showGrid=!showGrid);
    for(int i=0;i<3;i++) { int n=i;
      local(g,mx,my,8+i*66,181,62,21,List.of("Left","Center X","Right").get(i),false,()->align(n,-1));
      local(g,mx,my,8+i*66,207,62,21,List.of("Top","Center Y","Bottom").get(i),false,()->align(-1,n)); }
    local(g,mx,my,8,239,94,22,"Bring forward",false,()->layer(true));
    local(g,mx,my,108,239,96,22,"Send back",false,()->layer(false));
  }
  private void style(DrawContext g,int mx,int my) {
    var h=state();
    local(g,mx,my,8,123,94,22,"Background",h.glass,()->change(()->h.glass=!h.glass));
    local(g,mx,my,108,123,96,22,"Accent",h.accent,()->change(()->h.accent=!h.accent));
    if(selected.equals("Keystrokes"))
      local(g,mx,my,8,151,94,22,"Mouse clicks",h.mouseButtons,()->change(()->h.mouseButtons=!h.mouseButtons));
    else local(g,mx,my,8,151,94,22,"Icons",h.icons,()->change(()->h.icons=!h.icons));
    number(g,mx,my,108,151,96,"Opacity",Math.round(h.opacity*100));
    local(g,mx,my,8,184,196,23,"HUD colors and gradients",true,()->client.setScreen(new StudioScreen(this).hudAppearance()));
    local(g,mx,my,8,214,196,22,"Reset selected block",false,()->change(()->{
      var fresh=new VisualConfig.HudState(); fresh.enabled=true; fresh.x=.5-HudManager.widgetWidth(selected)*fresh.scale/(2*width); fresh.y=.5;
      cfg().widgets.put(selected,fresh); }));
    local(g,mx,my,8,241,196,22,resetPending?"Click again to reset entire layout":"Reset entire layout",false,()->{
      if(resetPending) { change(()->{cfg().applyHudLayout();HudManager.layout(width,height);for(String n:cfg().widgets.keySet()) detach(n);});resetPending=false; }
      else resetPending=true; });
  }
  private void layer(boolean front) {
    change(()->{var h=cfg().widgets.remove(selected);
      if(front) cfg().widgets.put(selected,h);
      else {var map=new LinkedHashMap<String,VisualConfig.HudState>();map.put(selected,h);map.putAll(cfg().widgets);cfg().widgets=map;}});
  }
  private void number(DrawContext g,int mx,int my,float x,float y,float w,String key,double value) {
    String suffix=key.equals("Scale") || key.equals("Opacity")?"%":"";
    String display=value==Math.rint(value)?Long.toString(Math.round(value)):String.format(Locale.ROOT,"%.2f",value);
    local(g,mx,my,x,y,w,22,key+": "+(field.equals(key)?buffer+"_":display+suffix),field.equals(key),()->{commitField();field=key;buffer="";});
  }
  private void commitField() {
    if(field.isEmpty()) return;
    try {
      double value=Double.parseDouble(buffer); String key=field;
      if(Double.isFinite(value) && (!state().locked || key.equals("Opacity"))) change(()->{
        detach(selected);var b=HudManager.bounds(selected,width,height);
        switch(key) {
          case "X" -> move(value,b.y(),false); case "Y" -> move(b.x(),value,false);
          case "Scale" -> resize(value/100); case "Opacity" -> state().opacity=Math.clamp(value/100,.05,1);
        }
      });
    } catch(NumberFormatException ignored) {} field="";buffer="";
  }
  private void local(DrawContext g,int mx,int my,float x,float y,float w,float h,String s,boolean on,Runnable action) {
    paintButton(g,(mx-px)/ui,(my-py)/ui,x,y,w,h,s,on);hits.add(new Hit(px+x*ui,py+y*ui,w*ui,h*ui,action));
  }
  private void button(DrawContext g,int mx,int my,float x,float y,float w,float h,String s,boolean on,Runnable action) {
    paintButton(g,mx/ui,my/ui,x,y,w,h,s,on);hits.add(new Hit(x*ui,y*ui,w*ui,h*ui,action));
  }
  private void paintButton(DrawContext g,double mx,double my,float x,float y,float w,float h,String s,boolean on) {
    boolean hover=Glass.contains(mx,my,x,y,w,h);
    Glass.rounded(g,x,y,w,h,3,hover?0xff363636:on?0xff303030:0xff202020);
    float size=Math.min(.75f,(w-10)/Math.max(1,Glass.textWidth(s)));
    Glass.scaled(g,s,x+5,y+(h-9*size)/2,size,on?0xffffffff:TEXT);
  }
  private void outline(DrawContext g,HudBounds b,int color) {
    int x=(int)b.x(),y=(int)b.y(),r=(int)Math.ceil(b.x()+b.width()),d=(int)Math.ceil(b.y()+b.height());
    g.fill(x-1,y-1,r+1,y,color);g.fill(x-1,d,r+1,d+1,color);g.fill(x-1,y,x,d,color);g.fill(r,y,r+1,d,color);
  }
  private String at(double x,double y) {
    var names=new ArrayList<>(cfg().widgets.keySet()); Collections.reverse(names);
    for(String n:names) if(HudManager.visible(n,true)) {var b=HudManager.bounds(n,width,height);
      if(Glass.contains(x,y,b.x(),b.y(),b.width()+3,b.height()+3)) return n;}
    return null;
  }
  @Override public boolean mouseClicked(Click c,boolean twice) {
    if(c.button()!=0) return false;layout();
    if(controls) {
      for(Hit hit:hits) if(Glass.contains(c.x(),c.y(),hit.x,hit.y,hit.w,hit.h)) {commitField();hit.action.run();return true;}
      if(Glass.contains(c.x(),c.y(),px,py,212*ui,40*ui)) {panelDrag=true;grabX=c.x()-px;grabY=c.y()-py;return true;}
      if(Glass.contains(c.x(),c.y(),px,py,212*ui,292*ui)) {commitField();return true;}
    }
    commitField();String n=at(c.x(),c.y());if(n==null) return false;
    selected=n;if(state().locked) return true;
    remember();detach(n);dragging=n;var b=HudManager.bounds(n,width,height);
    grabX=c.x()-b.x();grabY=c.y()-b.y();startScale=state().scale;
    resizing=grabX>=b.width()-5 && grabY>=b.height()-5;return true;
  }
  @Override public boolean mouseDragged(Click c,double dx,double dy) {
    if(panelDrag) {px=(float)(c.x()-grabX);py=(float)(c.y()-grabY);layout();return true;}
    if(dragging==null) return false;
    if(resizing) {double x=c.x()-state().x*width,y=c.y()-state().y*height;
      resize(startScale*(x*grabX+y*grabY)/Math.max(1,grabX*grabX+grabY*grabY));
    } else move(c.x()-grabX,c.y()-grabY,(c.modifiers()&GLFW.GLFW_MOD_SHIFT)!=0);
    dirty();return true;
  }
  @Override public boolean mouseReleased(Click c) {
    boolean used=dragging!=null || panelDrag;dragging=null;panelDrag=false;if(used) XVisuals.STORE.save();return used;
  }
  @Override public boolean mouseScrolled(double x,double y,double hx,double dy) {
    if(controls && Glass.contains(x,y,px,py,212*ui,292*ui)) {
      if(tab.equals("Widgets")) listOffset=Math.clamp(listOffset-(int)Math.signum(dy),0,Math.max(0,cfg().widgets.size()-6));return true;
    }
    String n=at(x,y);if(n==null) return false;commitField();selected=n;
    if(!state().locked) change(()->resize(state().scale+dy*.05));return true;
  }
  @Override public boolean charTyped(CharInput c) {
    if(field.isEmpty()) return false;
    String s=c.asString();if(buffer.length()<9 && s.matches("[0-9.\\-]")) buffer+=s;return true;
  }
  @Override public boolean keyPressed(KeyInput k) {
    if(!field.isEmpty()) {
      if(k.key()==GLFW.GLFW_KEY_ENTER || k.key()==GLFW.GLFW_KEY_KP_ENTER) commitField();
      else if(k.key()==GLFW.GLFW_KEY_ESCAPE) {field="";buffer="";}
      else if(k.key()==GLFW.GLFW_KEY_BACKSPACE && !buffer.isEmpty()) buffer=buffer.substring(0,buffer.length()-1);
      return true;
    }
    boolean ctrl=(k.modifiers()&GLFW.GLFW_MOD_CONTROL)!=0,shift=(k.modifiers()&GLFW.GLFW_MOD_SHIFT)!=0;
    if(ctrl && (k.key()==GLFW.GLFW_KEY_Z || k.key()==GLFW.GLFW_KEY_Y)) {history(k.key()==GLFW.GLFW_KEY_Y || shift);return true;}
    if(k.key()==GLFW.GLFW_KEY_TAB) {controls=!controls;return true;}
    if(k.key()==GLFW.GLFW_KEY_DELETE) {change(()->{state().enabled=false;state().hidden=true;if(selected.equals("Now Playing"))MusicControls.setEnabled(cfg(),false);});return true;}
    int dx=k.key()==GLFW.GLFW_KEY_LEFT?-1:k.key()==GLFW.GLFW_KEY_RIGHT?1:0;
    int dy=k.key()==GLFW.GLFW_KEY_UP?-1:k.key()==GLFW.GLFW_KEY_DOWN?1:0;
    if(dx!=0 || dy!=0) {if(!state().locked) change(()->{detach(selected);move(state().x*width+dx*(shift?10:1),state().y*height+dy*(shift?10:1),false);});return true;}
    return super.keyPressed(k);
  }
}
