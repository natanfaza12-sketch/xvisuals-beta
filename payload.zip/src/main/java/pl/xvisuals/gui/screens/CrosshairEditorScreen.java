package pl.xvisuals.gui.screens;

import pl.xvisuals.XVisuals;
import pl.xvisuals.config.VisualConfig.ModuleState;
import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.modules.crosshair.*;
import java.util.*;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

/** Preset builder and freehand canvas. Every stroke is a single undo operation. */
public final class CrosshairEditorScreen extends Screen {
  private final Screen parent;
  private final List<Hit> hits=new ArrayList<>();
  private final Deque<Map<String,Object>> undo=new ArrayDeque<>(), redo=new ArrayDeque<>();
  private record Hit(float x,float y,float w,float h,Runnable action) {}
  private float scale,ox,oy;
  private boolean drawing;
  private char ink='1',strokeInk;
  private int lastX,lastY;
  private TextFieldWidget primary,secondary;
  public CrosshairEditorScreen(Screen parent) { super(Text.literal("Crosshair editor")); this.parent=parent; }
  private ModuleState state() { return XVisuals.config().module("crosshair"); }
  private void layout() {
    scale=Math.min((width-12f)/680,(height-12f)/420);
    ox=(width-680*scale)/2; oy=(height-420*scale)/2;
  }
  @Override protected void init() {
    layout();
    primary=colour("color",280,353);
    secondary=colour("secondary",460,353);
  }
  private TextFieldWidget colour(String key,int x,int y) {
    var field=new TextFieldWidget(textRenderer,(int)(ox+x*scale),(int)(oy+y*scale),
        (int)(164*scale),Math.max(14,(int)(21*scale)),Text.literal(key.equals("color")?"Primary hex colour":"Secondary hex colour"));
    field.setMaxLength(7); field.setText(state().text(key));
    field.setChangedListener(value -> {
      if(value.matches("#[0-9a-fA-F]{6}")) { state().values.put(key,value); XVisuals.STORE.dirty(); }
    });
    return addDrawableChild(field);
  }
  @Override public boolean shouldPause() { return false; }
  @Override public void renderBackground(DrawContext g,int x,int y,float delta) {}
  @Override public void close() { XVisuals.STORE.save(); client.setScreen(parent); }
  @Override public void removed() { XVisuals.STORE.save(); }
  private void remember() {
    undo.push(new LinkedHashMap<>(state().values)); if(undo.size()>40) undo.removeLast(); redo.clear();
  }
  private void change(Runnable action) { remember(); action.run(); XVisuals.STORE.dirty(); }
  private void history(boolean forward) {
    var from=forward?redo:undo; var to=forward?undo:redo;
    if(from.isEmpty()) return;
    to.push(new LinkedHashMap<>(state().values)); state().values=new LinkedHashMap<>(from.pop());
    primary.setText(state().text("color")); secondary.setText(state().text("secondary"));
    XVisuals.STORE.dirty();
  }
  @Override public void render(DrawContext g,int mx,int my,float delta) {
    layout(); hits.clear();
    g.fillGradient(0,0,width,height,0xFF0C0917,0xFF241934);
    g.getMatrices().pushMatrix(); g.getMatrices().translate(ox,oy); g.getMatrices().scale(scale,scale);
    Glass.text(g,"CROSSHAIR STUDIO",22,17,0xFFF6F0FF);
    button(g,state().enabled?"Enabled":"Enable",465,10,88,24,() -> { state().enabled=!state().enabled; XVisuals.STORE.dirty(); });
    button(g,"Done",563,10,88,24,this::close);
    Glass.text(g,"DRAW YOUR OWN",22,52,0xFFC7AFE8);
    String pixels=CustomCrosshair.design(state());
    for(int y=0;y<31;y++) for(int x=0;x<31;x++) {
      char pixel=pixels.charAt(y*31+x);
      int color=pixel=='0'?((x+y)%2==0?0xFF252032:0xFF2E273C):state().color(pixel=='2'?"secondary":"color");
      g.fill(22+x*7,78+y*7,28+x*7,84+y*7,color);
    }
    g.drawStrokedRectangle(22+15*7,78+15*7,7,7,0x88B88CFF);
    for(int i=0;i<8;i++) {
      String preset=CrosshairDesign.PRESETS[i];
      button(g,(state().text("preset").equals(preset)?"• ":"")+preset,280+(i%4)*90,44+(i/4)*26,84,22,
          () -> change(() -> state().values.put("preset",preset)));
    }
    Glass.rounded(g,280,103,354,84,6,0xFF393148);
    g.fill(457,104,633,186,0xFFBCB2C9);
    CustomCrosshair.draw(g,pixels,368,145,state());
    CustomCrosshair.draw(g,pixels,545,145,state());
    Glass.text(g,"LIVE PREVIEW / DARK + LIGHT",280,192,0xFFBEACD5);
    adjust(g,"Length","length",280,214,1,1,12);
    adjust(g,"Gap","gap",460,214,1,0,10);
    adjust(g,"Thickness","thickness",280,242,1,1,5);
    adjust(g,"Scale","scale",460,242,.25,.5,3);
    adjust(g,"Rotation","rotation",280,270,15,0,360);
    adjust(g,"Opacity","opacity",460,270,.1,.1,1);
    button(g,"Dot: "+(state().flag("dot")?"on":"off"),280,302,164,22,() -> change(() -> state().values.put("dot",!state().flag("dot"))));
    button(g,"Outline: "+(state().flag("outline")?"on":"off"),460,302,164,22,() -> change(() -> state().values.put("outline",!state().flag("outline"))));
    Glass.text(g,"Primary hex colour",280,338,0xFFC7AFE8);
    Glass.text(g,"Secondary hex colour",460,338,0xFFC7AFE8);
    button(g,ink=='1'?"[Ink 1]":"Ink 1",22,308,66,22,() -> ink='1');
    button(g,ink=='2'?"[Ink 2]":"Ink 2",94,308,66,22,() -> ink='2');
    button(g,ink=='0'?"[Erase]":"Erase",166,308,73,22,() -> ink='0');
    button(g,"Mirror X: "+(state().flag("mirrorX")?"on":"off"),22,336,105,22,() -> change(() -> state().values.put("mirrorX",!state().flag("mirrorX"))));
    button(g,"Mirror Y: "+(state().flag("mirrorY")?"on":"off"),133,336,106,22,() -> change(() -> state().values.put("mirrorY",!state().flag("mirrorY"))));
    button(g,"Undo",22,364,66,22,() -> history(false));
    button(g,"Redo",94,364,66,22,() -> history(true));
    button(g,"Clear",166,364,73,22,() -> change(() -> { state().values.put("preset","Custom"); state().values.put("pixels","0".repeat(961)); }));
    button(g,"Custom drawing",280,381,164,22,() -> change(() -> state().values.put("preset","Custom")));
    Glass.text(g,"Drag to draw / Right-drag erases",22,401,0xFFB3A3C8);
    Glass.text(g,"Shape controls apply to presets",460,390,0xFFB3A3C8);
    g.getMatrices().popMatrix();
    super.render(g,mx,my,delta);
  }
  private void adjust(DrawContext g,String label,String key,int x,int y,double step,double min,double max) {
    double value=state().number(key);
    Glass.text(g,label+": "+String.format(Locale.ROOT,"%.2f",value).replaceAll("0+$","").replaceAll("\\.$",""),x,y+7,0xFFE9DFF7);
    button(g,"−",x+112,y,22,22,() -> change(() -> state().values.put(key,Math.max(min,value-step))));
    button(g,"+",x+140,y,22,22,() -> change(() -> state().values.put(key,Math.min(max,value+step))));
  }
  private void button(DrawContext g,String text,float x,float y,float w,float h,Runnable action) {
    Glass.rounded(g,x,y,w,h,4,0xFF39294F); Glass.center(g,text,x+w/2,y+7,0xFFF1E8FF);
    hits.add(new Hit(x,y,w,h,action));
  }
  private int cellX(double x) { return (int)Math.floor(((x-ox)/scale-22)/7); }
  private int cellY(double y) { return (int)Math.floor(((y-oy)/scale-78)/7); }
  private boolean canvas(int x,int y) { return x>=0 && y>=0 && x<31 && y<31; }
  @Override public boolean mouseClicked(Click c,boolean twice) {
    layout(); int x=cellX(c.x()),y=cellY(c.y());
    if((c.button()==0 || c.button()==1) && canvas(x,y)) {
      primary.setFocused(false); secondary.setFocused(false); setFocused(null);
      remember(); String pixels=CustomCrosshair.design(state());
      state().values.put("pixels",pixels); state().values.put("preset","Custom");
      drawing=true; strokeInk=c.button()==1?'0':ink; lastX=x; lastY=y; paint(x,y); return true;
    }
    if(c.button()==0) for(Hit h:hits) if(Glass.contains((c.x()-ox)/scale,(c.y()-oy)/scale,h.x,h.y,h.w,h.h)) { h.action.run(); return true; }
    return super.mouseClicked(c,twice);
  }
  private void paint(int x,int y) {
    char[] pixels=CrosshairDesign.normalize(state().text("pixels")).toCharArray();
    CrosshairDesign.stroke(pixels,lastX,lastY,x,y,strokeInk,state().flag("mirrorX"),state().flag("mirrorY"));
    state().values.put("pixels",new String(pixels)); lastX=x; lastY=y; XVisuals.STORE.dirty();
  }
  @Override public boolean mouseDragged(Click c,double dx,double dy) {
    if(!drawing) return super.mouseDragged(c,dx,dy);
    int x=cellX(c.x()),y=cellY(c.y());
    if(canvas(x,y)) paint(x,y); return true;
  }
  @Override public boolean mouseReleased(Click c) {
    if(drawing) { drawing=false; XVisuals.STORE.dirty(); return true; }
    return super.mouseReleased(c);
  }
}
