package pl.xvisuals.gui.screens;

import pl.xvisuals.XVisuals;
import pl.xvisuals.rendering.CustomSkyImage;
import pl.xvisuals.menu.CustomBackgroundImport;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import java.nio.file.Path;
import java.util.List;

public final class SkyImageScreen extends Screen {
  private final Screen parent;
  private String status="Choose an image or drag it onto this screen.";
  private boolean importing;
  public SkyImageScreen(Screen parent){super(Text.literal("Import sky image"));this.parent=parent;}
  @Override protected void init(){
    addDrawableChild(ButtonWidget.builder(Text.literal("Choose PNG / JPEG"),b->choose()).dimensions(width/2-100,height/2,200,24).build());
    addDrawableChild(ButtonWidget.builder(Text.literal("Done"),b->close()).dimensions(width/2-70,height/2+72,140,22).build());
  }
  private void choose(){
    if(importing)return;
    try(var stack=org.lwjgl.system.MemoryStack.stackPush()) {
      var filters=stack.mallocPointer(3);filters.put(stack.UTF8("*.png")).put(stack.UTF8("*.jpg")).put(stack.UTF8("*.jpeg")).flip();
      String file=org.lwjgl.util.tinyfd.TinyFileDialogs.tinyfd_openFileDialog("Choose sky panorama",null,filters,"PNG / JPEG",false);
      if(file!=null)load(Path.of(file));
    }catch(Exception e){status="File picker unavailable. Drag an image here instead.";}
  }
  public void load(Path file){
    if(importing)return;
    importing=true;status="Importing image...";
    var game=net.minecraft.client.MinecraftClient.getInstance();
    var config=XVisuals.config();
    java.util.concurrent.CompletableFuture.runAsync(()->{
      try {
        Path imported=CustomBackgroundImport.importImage(file,CustomSkyImage.directory(),33_554_432L,128L*1024*1024);
        game.execute(()->{
          importing=false;
          if(XVisuals.config()!=config){status="Profile changed. Please import again.";return;}
          var sky=config.module("cinematicsky");sky.values.put("image",imported.toString());
          sky.values.put("preset","Custom Image");sky.enabled=true;
          CustomSkyImage.close();
          status=XVisuals.STORE.save()?"Sky applied and saved.":"Applied; settings could not be saved.";
        });
      }catch(Exception e){game.execute(()->{importing=false;status="Import failed: "+e.getMessage();});}
    });
  }
  @Override public void onFilesDropped(List<Path> files){if(files.size()==1)load(files.getFirst());else status="Drop one image at a time.";}
  @Override public void renderBackground(DrawContext g,int x,int y,float d){}
  @Override public void render(DrawContext g,int mx,int my,float d){
    g.fillGradient(0,0,width,height,0xEF101827,0xEF241A38);
    int y=height/2;
    g.drawCenteredTextWithShadow(textRenderer,"IMPORT SKY IMAGE",width/2,y-78,0xFFFFFFFF);
    ScreenText.center(g,textRenderer,"Use a 2:1 panorama for a seamless surrounding sky.",width/2,y-56,width-24,0xFFBCCBDD);
    ScreenText.center(g,textRenderer,"Best: 4096 x 2048 or 8192 x 4096. PNG/JPEG up to 128 MB.",width/2,y-40,width-24,0xFFBCCBDD);
    g.drawCenteredTextWithShadow(textRenderer,textRenderer.trimToWidth(status,width-24),width/2,y+36,0xFFFFFFFF);
    ScreenText.center(g,textRenderer,"Config sharing does not include the image. Send it separately.",width/2,y+54,width-24,0xFFBCCBDD);
    super.render(g,mx,my,d);
  }
  @Override public void close(){client.setScreen(parent);}
  @Override public boolean shouldPause(){return false;}
}
