package pl.xvisuals.gui.screens;

/** Stable particle identities across emissions, so older preview particles do not jump. */
public final class TrailPreviewTiming {
  public record Sample(long identity, double age) {}
  public static Sample sample(double seconds, double interval, int offset) {
    double emission = seconds / interval;
    long newest = (long)Math.floor(emission);
    return new Sample(newest - offset, (emission - newest + offset) * interval);
  }
  private TrailPreviewTiming() {}
}
