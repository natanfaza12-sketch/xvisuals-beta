package pl.xvisuals.gui.screens;
import pl.xvisuals.XVisuals;
import pl.xvisuals.rendering.particles.PvpStyle;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gl.RenderPipelines;
/** Actual animated asset sheets, shared poses and timing; isolated from world simulation. */
final class PlayerEffectPreview {
 static void draw(DrawContext g,String style,int x,int y,int w,int h){
  double t=XVisuals.config().module("performance").text("animation").equals("Off")?2:System.nanoTime()/1e9;
  double unit=Math.min(h/2.6,w/3.4),cx=x+w*(w>140?.64:.5),feet=y+h*.91;
  var settings=XVisuals.config().module("playerfx");int tint=settings.flag("customColors")?settings.color("color"):0xFFFFFFFF;
  if(w>140){int f=PvpStyle.frame(t,0),size=(int)(h*.7);g.drawTexture(RenderPipelines.GUI_TEXTURED,PvpStyle.texture(style),(int)(x+w*.22-size*.5),(int)(y+(h-size)*.5),(f%6)*128,(f/6)*128,size,size,128,128,768,512,tint);}
  int body=0x667C8794;
  g.fill((int)(cx-unit*.15),(int)(feet-unit*1.8),(int)(cx+unit*.15),(int)(feet-unit*1.5),body);
  g.fill((int)(cx-unit*.27),(int)(feet-unit*1.46),(int)(cx+unit*.27),(int)(feet-unit*.8),body);
  g.fill((int)(cx-unit*.18),(int)(feet-unit*.8),(int)(cx-unit*.025),(int)feet,body);
  g.fill((int)(cx+unit*.025),(int)(feet-unit*.8),(int)(cx+unit*.18),(int)feet,body);
  for(int i=0;i<PvpStyle.count(style);i++){
   var p=PvpStyle.point(style,t,i);int frame=PvpStyle.frame(t,i);float scale=(float)Math.max(10,PvpStyle.size(style,t,i)*unit)/128f;
   var m=g.getMatrices();m.pushMatrix();m.translate((float)(cx+p.x()*unit),(float)(feet-p.y()*unit+p.z()*unit*.18));m.rotate((float)PvpStyle.angle(style,t,i));m.scale(scale,scale);
   g.drawTexture(RenderPipelines.GUI_TEXTURED,PvpStyle.texture(style),-64,-64,(frame%6)*128,(frame/6)*128,128,128,128,128,768,512,pl.xvisuals.util.Colors.alpha(tint,PvpStyle.opacity(style,t,i)));
   m.popMatrix();
  }
 }
 private PlayerEffectPreview(){}
}
