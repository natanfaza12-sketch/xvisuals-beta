package pl.xvisuals.gui.screens;

import pl.xvisuals.XVisuals;
import pl.xvisuals.gui.components.*;
import pl.xvisuals.gui.themes.Theme;
import pl.xvisuals.modules.cosmetics.*;
import pl.xvisuals.hud.ExperienceThemes;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.texture.*;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.*;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import java.util.*;
import java.util.function.Consumer;

/** Preview resources owned by the existing module inspector, not a separate screen. */
public final class DesignPreviews implements AutoCloseable {
  private final net.minecraft.client.MinecraftClient client=net.minecraft.client.MinecraftClient.getInstance();
  private final String module;
  private final List<String> choices;
  private final Map<String,Identifier> textures=new HashMap<>();
  private final Map<String,ItemStack> items=new HashMap<>();
  private final SwingPreview swingPreview=new SwingPreview();
  private final SwordInspectPreview inspectPreview=new SwordInspectPreview();
  public String optionKey="style";
  public boolean wings,critical;
  public int page;
  private int settingsHash;
  public DesignPreviews(String module,List<String> choices){this.module=module;this.choices=choices;}
  public static boolean supports(String module,String key){
    if(module.equals("totemtexture")&&Set.of("importedTotemStyle","importedTotemAnimation").contains(key))return true;
    if(module.equals("crystals")&&Set.of("importedObsidianStyle","importedAnchorStyle","importedGlowstoneStyle").contains(key))return true;
    if(Set.of("custompickaxes","customswords").contains(module)&&Set.of("otherTool","axeShape","shovelShape","hoeShape","textureStyle","textureAnimation","skin").contains(key))return true;
    return module.equals("pets")&&key.equals("variant")||module.equals("chinahat")&&key.equals("theme")||module.equals("swing")&&key.equals("preset")||module.equals("crystals")&&key.equals("skin")||module.equals("hitfx")&&key.equals("critStyle")||key.equals("style")&&Set.of("larp","halo","custompickaxes","customswords","capes","totemtexture","footsteps","jumpcircles","anchorshader","attackindicator","playerfx","enemyanimations","playertrails","hitfx","killanimations","totemghost","deathghost","swordinspect").contains(module)
        ||module.equals("explosionfx")&&key.equals("preset")||module.equals("cinematicsky")&&key.equals("preset")||module.equals("xp")&&key.equals("theme");
  }
  public void sync(){int hash=XVisuals.config().module(module).values.hashCode();if(hash!=settingsHash){close();settingsHash=hash;}}
  public void preview(DrawContext g,String design,int x,int y,int w,int h){
    if(w<=0||h<=0)return;
    g.enableScissor(x,y,x+w,y+h);
    try{drawPreview(g,design,x,y,w,h);}finally{g.disableScissor();}
  }
  private void drawPreview(DrawContext g,String design,int x,int y,int w,int h){
    if(module.equals("pets")){PetPreview.draw(g,design,x,y,w,h);return;}
    if(module.equals("larp")){LarpPreview.draw(g,design,x,y,w,h);return;}
    if(module.equals("chinahat")){ChinaHatPreview.draw(g,design,x,y,w,h);return;}
    if(module.equals("crystals")){CrystalPreview.draw(g,design,x,y,w,h);return;}
    if(module.equals("swing")){swingPreview.draw(g,design,x,y,w,h);return;}
    if(module.equals("halo")){HaloPreview.draw(g,design,x,y,w,h);return;}
    if(module.equals("footsteps")){FootstepPreview.draw(g,design,x,y,w,h);return;}
    if(module.equals("jumpcircles")){JumpCirclePreview.draw(g,design,x,y,w,h);return;}
    if(module.equals("enemyanimations")){PlayerAnimationPreview.draw(g,design,x,y,w,h);return;}
    if(module.equals("playertrails")&&!design.equals("Ribbon")){TrailGalleryPreview.draw(g,design,x,y,w,h);return;}
    if(module.equals("swordinspect")){inspectPreview.draw(g,design,x,y,w,h);return;}
    if(Set.of("killanimations","totemghost","deathghost").contains(module)){
      GhostGalleryPreview.draw(g,module,design,x,y,w,h);return;
    }
    if(module.equals("capes")){
      String key=design+(wings?"/wings":"/cape");
      Identifier texture=textures.computeIfAbsent(key,k->makeWearableTexture(design,wings));
      WearablePreview.draw(g,texture,wings,x,y,w,h);return;
    }
    if(Set.of("playertrails","hitfx","explosionfx").contains(module)){
      EffectGalleryPreview.draw(g,module,design,x,y,w,h,critical);return;
    }
    if(module.equals("playerfx")){PlayerEffectPreview.draw(g,design,x,y,w,h);return;}
    if(module.equals("attackindicator")){
      var s=XVisuals.config().module(module);
      boolean animated=!XVisuals.config().module("performance").text("animation").equals("Off");
      float charge=animated?(float)Math.min(1,(System.nanoTime()/1e9%2.8)/2):.7f;
      float size=Math.min(w,h)/46f*(float)Math.min(1.3,s.number("scale"));
      g.getMatrices().pushMatrix();
      try{
        g.getMatrices().translate(x+w/2f,y+h/2f);
        g.getMatrices().rotate((float)Math.toRadians(s.number("rotation")));
        g.getMatrices().scale(s.flag("flipX")?-size:size,s.flag("flipY")?-size:size);
        pl.xvisuals.modules.combat.AttackIndicator.draw(g,design,charge,
            pl.xvisuals.util.Colors.alpha(s.color(charge>=1?"readyColor":"color"),s.number("opacity")),
            pl.xvisuals.util.Colors.alpha(s.color("background"),s.number("opacity")*.65),s.flag("reverseFill"));
      }finally{g.getMatrices().popMatrix();}
      return;
    }
    if(module.equals("custompickaxes")||module.equals("customswords")||module.equals("totemtexture")){
      ItemStack stack=items.computeIfAbsent(design,name->{
        // A neutral carrier prevents gameplay model-substitution mixins overriding the preview.
        ItemStack item=new ItemStack(Items.STICK);
        String id=name.toLowerCase(Locale.ROOT).replace(' ','_');
        item.set(DataComponentTypes.ITEM_MODEL,Identifier.of("xvisuals",module.equals("custompickaxes")?"pickaxes/"+id+"/0":module.equals("customswords")?"swords/"+id+"/0":"totem/"+id));
        if(module.equals("totemtexture")){
          var settings=XVisuals.config().module(module);
          List<Integer> colors=settings.flag("customTint")?List.of(settings.color("color"),settings.color("secondary")):List.of(0xFFFFFF,0xFFFFFF);
          if(id.equals("custom_vanilla"))colors=pl.xvisuals.modules.combat.VanillaTotemEyes.colors(settings.text("eyeMode"),settings.color("eyeColor"),settings.color("eyeSecondary"),0);
          item.set(DataComponentTypes.CUSTOM_MODEL_DATA,new net.minecraft.component.type.CustomModelDataComponent(List.of(),List.of(),List.of(),colors));
        }
        return item;
      });
      if(module.equals("totemtexture"))stack.set(DataComponentTypes.ITEM_MODEL,Identifier.of("xvisuals","totem/"+pl.xvisuals.modules.combat.TotemDesigns.path(design)));
      float size=Math.max(8,Math.min(w,h)-8),scale=size/16;
      g.getMatrices().pushMatrix();g.getMatrices().translate(x+(w-size)/2f,y+(h-size)/2f);g.getMatrices().scale(scale,scale);g.drawItem(stack,0,0);g.getMatrices().popMatrix();return;
    }
    if(design.equals("Custom Image")){StudioChrome.center(g,"Import your panorama",x+w/2f,y+h/2f,Theme.muted());return;}
    Identifier texture;
    int tw,th;
    if(module.equals("anchorshader")){
      int frame=XVisuals.config().module("performance").text("animation").equals("Off")?0:Math.floorMod((int)(System.nanoTime()/1e9*8),8);
      int size=Math.min(w,h)-8;
      g.drawTexture(RenderPipelines.GUI_TEXTURED,Identifier.of("xvisuals","textures/crafted/anchors.png"),x+(w-size)/2,y+(h-size)/2,choices.indexOf(design)*64,(24+frame)*64,size,size,64,64,384,2560);
      return;
    }else if(module.equals("cinematicsky")){
      String art=pl.xvisuals.modules.SkyScenes.artwork(design);
      texture=Identifier.of("xvisuals","textures/gui/skies/layered/"+pl.xvisuals.modules.SkyScenes.shaderId(design)+".png");tw=384;th=216;
      if(pl.xvisuals.modules.SkyScenes.shaderId(design)>=31){texture=Identifier.of("xvisuals","textures/skies/layered/"+art+".png");tw=1774;th=887;}
    }else{
      texture=textures.computeIfAbsent(design,this::makeTexture);tw=module.equals("xp")?182:64;th=module.equals("xp")?12:96;

    }
    if(module.equals("cinematicsky")){
      // Cover the card without stretching the sky or leaving empty side bars.
      float cover=Math.max(w/(float)tw,h/(float)th);
      int sw=Math.max(1,Math.min(tw,Math.round(w/cover)));
      int sh=Math.max(1,Math.min(th,Math.round(h/cover)));
      boolean newSpace=pl.xvisuals.modules.SkyScenes.shaderId(design)>=35;
      double time=XVisuals.config().module("performance").text("animation").equals("Off")?0:System.nanoTime()/1e9;
      float drift=newSpace?(float)Math.sin(time*.08)*(tw-sw)*.12f:0;
      g.drawTexture(RenderPipelines.GUI_TEXTURED,texture,x,y,(tw-sw)/2f+drift,(th-sh)/2f,w,h,sw,sh,tw,th);
      if(newSpace){
        var veil=Identifier.of("xvisuals","textures/skies/layered/"+pl.xvisuals.modules.SkyScenes.veil(design)+".png");
        for(int layer=0;layer<2;layer++){
          float offset=(float)Math.sin(time*(.11+layer*.04)+layer*2)*(tw-sw)*.25f;
          g.drawTexture(RenderPipelines.GUI_TEXTURED,veil,x,y,(tw-sw)/2f+offset,(th-sh)/2f,w,h,sw,sh,tw,th,layer==0?0x55ffffff:0x33ffffff);
        }
      }
      return;
    }
    float scale=Math.min(w/(float)tw,h/(float)th);int dw=Math.max(1,(int)(tw*scale)),dh=Math.max(1,(int)(th*scale));
    g.drawTexture(RenderPipelines.GUI_TEXTURED,texture,x+(w-dw)/2,y+(h-dh)/2,0,0,dw,dh,tw,th,tw,th);
  }
  private Identifier makeWearableTexture(String design,boolean wing){
    int width=256,height=128;
    NativeImage image=new NativeImage(width,height,false);
    var m=XVisuals.config().module("capes");
    int p=CosmeticThemes.primary(design,m.color("color"),!m.text("palette").equals("Custom"));
    int a=CosmeticThemes.accent(design,m.color("secondary"),!m.text("palette").equals("Custom"));
    var artwork=pl.xvisuals.modules.cosmetics.WearableArtwork.frame(design,4,p,a);
    for(int yy=0;yy<height;yy++)for(int xx=0;xx<width;xx++){
      if(wing?!ElytraSilhouette.contains(xx,yy,width,height):xx>=88||yy>=68){image.setColorArgb(xx,yy,0);continue;}
      image.setColorArgb(xx,yy,artwork.pixel(xx*256d/width,yy*128d/height,wing));
    }
    Identifier id=Identifier.of("xvisuals","gallery/capes/"+choices.indexOf(design)+(wing?"_wings":"_cape"));
    client.getTextureManager().registerTexture(id,new NativeImageBackedTexture(()->"Wearable preview",image));return id;
  }
  private Identifier makeTexture(String design){
    boolean xp=module.equals("xp");int w=xp?182:64,h=xp?12:96;
    NativeImage image=new NativeImage(w,h,false);
    var m=XVisuals.config().module(module);
    int a=xp?ExperienceThemes.color(ExperienceThemes.index(design),0):CosmeticThemes.primary(design,m.color("color"),!m.text("palette").equals("Custom"));
    int b=xp?ExperienceThemes.color(ExperienceThemes.index(design),1):CosmeticThemes.accent(design,m.color("secondary"),!m.text("palette").equals("Custom"));
    for(int y=0;y<h;y++)for(int x=0;x<w;x++)image.setColorArgb(x,y,xp?ExperienceThemes.pixel(ExperienceThemes.index(design),x,y*5./h,4,a,b):CosmeticPatterns.pixel(design,x/(double)(w-1),y/(double)(h-1),4,a,b));
    Identifier id=Identifier.of("xvisuals","gallery/"+module+"/"+choices.indexOf(design));
    client.getTextureManager().registerTexture(id,new NativeImageBackedTexture(()->"Design preview",image));return id;
  }
  @Override public void close(){for(Identifier id:textures.values())client.getTextureManager().destroyTexture(id);textures.clear();items.clear();}
}
