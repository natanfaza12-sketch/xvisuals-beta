package pl.xvisuals.gui.screens;
import pl.xvisuals.rendering.shaders.GuiAccess;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.TextureSetup;
import org.joml.Matrix3x2f;
import java.util.ArrayList;
import java.util.List;
/** Three visible faces per voxel, with stable spatial breakup instead of striped rows. */
final class GhostPreviewModel {
 record Face(float[] points,int color){}
 static int shade(int c,double shade){return (c&0xff000000)|((int)(((c>>16)&255)*shade)<<16)|((int)(((c>>8)&255)*shade)<<8)|(int)((c&255)*shade);}
 static void part(DrawContext g,double x,double y,double w,double h,double depth,double dissolve,int seed,int tint,double floor){
  var faces=new ArrayList<Face>();
  if(dissolve<.01)cube(faces,x,y,w,h,depth,tint,floor);
  else{
   int cols=4,rows=Math.max(4,(int)(h/w*4));
   for(int row=0;row<rows;row++)for(int col=0;col<cols;col++){
    int hash=(row*73428767)^(col*912931)^(seed*19349663);hash^=hash>>>13;hash*=1274126177;hash^=hash>>>16;
    double threshold=(hash&0xffff)/65535.;
    if(threshold<dissolve)continue;
    double edge=Math.clamp((threshold-dissolve)*12,0,1);
    cube(faces,x+col*w/cols,y+row*h/rows,w/cols,h/rows,depth,shade(tint,.72+.28*edge),floor);
   }
  }
  var access=(GuiAccess)g;var pose=new Matrix3x2f(g.getMatrices());
  var bounds=new ScreenRect((int)Math.floor(x-depth*.6),(int)Math.floor(y-depth*.4),(int)Math.ceil(w+depth+2),(int)Math.ceil(h+depth+2)).transformEachVertex(pose);
  if(access.visuals$clip()!=null){bounds=bounds.intersection(access.visuals$clip());if(bounds==null)return;}
  access.visuals$state().addSimpleElement(new Mesh(pose,List.copyOf(faces),bounds));
 }
 static void cube(List<Face> faces,double x,double y,double w,double h,double d,int color,double floor){
  double bottom=Math.min(y+h,floor);if(bottom<=y)return;
  double dx=d*.52,dy=-d*.30;
  faces.add(new Face(new float[]{(float)x,(float)y,(float)(x+dx),(float)(y+dy),(float)(x+w+dx),(float)(y+dy),(float)(x+w),(float)y},shade(color,1)));
  faces.add(new Face(new float[]{(float)(x+w),(float)y,(float)(x+w+dx),(float)(y+dy),(float)(x+w+dx),(float)Math.min(bottom+dy,floor),(float)(x+w),(float)bottom},shade(color,.48)));
  faces.add(new Face(new float[]{(float)x,(float)y,(float)(x+w),(float)y,(float)(x+w),(float)bottom,(float)x,(float)bottom},shade(color,.80)));
 }
 record Mesh(Matrix3x2f pose,List<Face> faces,ScreenRect bounds) implements SimpleGuiElementRenderState{
  public com.mojang.blaze3d.pipeline.RenderPipeline pipeline(){return RenderPipelines.GUI;}
  public TextureSetup textureSetup(){return TextureSetup.empty();}
  public ScreenRect scissorArea(){return bounds;}
  public void setupVertices(VertexConsumer out){for(var face:faces)for(int i=0;i<8;i+=2){float x=face.points[i],y=face.points[i+1];out.vertex(pose.m00()*x+pose.m10()*y+pose.m20(),pose.m01()*x+pose.m11()*y+pose.m21(),0).color(face.color);}}
 }
 private GhostPreviewModel(){}
}
