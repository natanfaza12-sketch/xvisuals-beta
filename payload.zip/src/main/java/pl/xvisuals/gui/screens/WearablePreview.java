package pl.xvisuals.gui.screens;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.AssetInfo;
import net.minecraft.util.Identifier;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/** Dedicated render state: real vanilla cape/elytra models without changing the live player. */
public class WearablePreview extends PlayerEntityRenderState {
  public static void draw(DrawContext g,Identifier texture,boolean wings,int x,int y,int w,int h){
    var client=MinecraftClient.getInstance();
    var uuid=client.getSession().getUuidOrNull();
    var fallback=uuid==null?net.minecraft.client.util.DefaultSkinHelper.getSteve():net.minecraft.client.util.DefaultSkinHelper.getSkinTextures(uuid);
    var skin=client.player==null?fallback:client.player.getSkin();var asset=new AssetInfo.TextureAssetInfo(texture,texture);
    var state=new WearablePreview();
    state.entityType=EntityType.PLAYER;state.id=Integer.MIN_VALUE;
    state.skinTextures=new SkinTextures(skin.body(),wings?null:asset,wings?asset:null,skin.model(),skin.secure());
    state.baseScale=1;state.ageScale=1;state.height=1.8f;state.width=.6f;
    state.pose=EntityPose.STANDING;state.bodyYaw=0;state.light=0xF000F0;
    state.capeVisible=true;state.hatVisible=true;state.jacketVisible=true;
    state.leftSleeveVisible=true;state.rightSleeveVisible=true;
    state.leftPantsLegVisible=true;state.rightPantsLegVisible=true;
    state.leftWingPitch=.2618f;state.leftWingRoll=-.40f;
    state.equippedChestStack=wings?new ItemStack(Items.ELYTRA):ItemStack.EMPTY;
    // Unlike ordinary GUI elements, addEntity does not consume the matrix stack.
    // Convert both its viewport and model scale to screen coordinates before submission.
    var bounds=new net.minecraft.client.gui.ScreenRect(x,y,w,h).transformEachVertex(g.getMatrices());
    float scale=Math.min(bounds.height()/2.15f,bounds.width()/2.1f);
    if(bounds.width()<=0||bounds.height()<=0)return;
    g.addEntity(state,scale,new Vector3f(0,.92f,0),
        new Quaternionf().rotationZ((float)Math.PI),null,
        bounds.getLeft(),bounds.getTop(),bounds.getRight(),bounds.getBottom());
  }
}
