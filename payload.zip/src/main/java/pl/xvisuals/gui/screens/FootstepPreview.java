package pl.xvisuals.gui.screens;
import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.motion.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gl.RenderPipelines;
/** Animated alternating steps using the same atlas frames and lifetime fade as the world decals. */
final class FootstepPreview {
 static void draw(DrawContext g,String style,int x,int y,int w,int h){
  var s=XVisuals.config().module("footsteps");boolean animated=!XVisuals.config().module("performance").text("animation").equals("Off");
  double duration=s.number("duration"),now=animated?System.nanoTime()/1e9:duration*.4;
  float size=Math.min(w*.24f,h*.42f);
  for(int i=0;i<4;i++){
   double age=(now+i*duration*.22)%duration;int frame=FootstepDesigns.frame(age,s.number("speed"));
   float px=x+w*(.27f+i*.15f)+(i%2==0?-size*.15f:size*.15f),py=y+h*(.76f-i*.17f);
   var m=g.getMatrices();m.pushMatrix();m.translate(px,py);m.rotate(.4f);m.scale(size/128,size/128);
   if(FootstepDesigns.isImported(style))g.drawTexture(RenderPipelines.GUI_TEXTURED,FootstepDesigns.texture(style,i%2==0),-64,-64,0,0,128,128,32,32,32,32,Footsteps.tint(s,FootstepDesigns.opacity(age/duration)));
   else g.drawTexture(RenderPipelines.GUI_TEXTURED,FootstepDesigns.texture(style),-64,-64,(frame%6+(i%2==0?1:0))*128,(frame/6)*128,128,128,i%2==0?-128:128,128,768,512,Footsteps.tint(s,FootstepDesigns.opacity(age/duration)));m.popMatrix();
  }
 }
 private FootstepPreview(){}
}
