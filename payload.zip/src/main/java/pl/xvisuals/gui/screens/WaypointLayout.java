package pl.xvisuals.gui.screens;

import pl.xvisuals.gui.components.StudioChrome;
import net.minecraft.client.gui.DrawContext;

/** Coordinates are in Minecraft GUI units; even the minimum 320 x 240 GUI fits. */
record WaypointLayout(int left,int top,int width,int height) {
  static WaypointLayout manager(int screenWidth,int screenHeight) {
    int w=Math.min(520,screenWidth-48),h=Math.min(340,screenHeight-24);
    return new WaypointLayout((screenWidth-w)/2,(screenHeight-h)/2,w,h);
  }
  static WaypointLayout editor(int screenWidth,int screenHeight) {
    int w=Math.min(380,screenWidth-48),h=Math.min(252,screenHeight-16);
    return new WaypointLayout((screenWidth-w)/2,(screenHeight-h)/2,w,h);
  }
  int listTop(){return top+72;}
  int footer(){return top+height-70;}
  int rows(){return Math.max(1,Math.min(8,(footer()-listTop()-5)/39));}
  void draw(DrawContext g,int screenWidth,int screenHeight) {
    g.fill(0,0,screenWidth,screenHeight,0xA6080B10);
    StudioChrome.surface(g,left-12,top,width+24,height,14,.96,false);
  }
}
