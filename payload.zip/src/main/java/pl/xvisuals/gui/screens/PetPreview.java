package pl.xvisuals.gui.screens;
import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.pets.SlimeModel;
import pl.xvisuals.rendering.shaders.GuiAccess;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.TextureSetup;
import org.joml.Matrix4f;
/** Same textured mesh and bounce as the world pet, with no scene background. */
public final class PetPreview {
 record Face(float[][] vertices,double depth){}
 public static void draw(DrawContext g,String variant,int x,int y,int w,int h){var s=XVisuals.config().module("pets");double time=System.nanoTime()/1e9;var pose=SlimeModel.pose(time,false,false,s.flag("animated"));double turn=Math.sin(time*.65)*.25;var faces=new java.util.ArrayList<Face>();
 for(var q:SlimeModel.mesh()){float[][] points=new float[4][5];double depth=0;for(int i=0;i<4;i++){var v=q[i];double px=v[0]*pose.width(),pz=v[2]*pose.width(),py=v[1]*pose.height()+pose.lift();double xx=px*Math.cos(turn)-pz*Math.sin(turn),zz=px*Math.sin(turn)+pz*Math.cos(turn);points[i]=new float[]{(float)xx,(float)(-py*.96-zz*.28),(float)(zz*.96-py*.28),v[3],v[4]};depth+=points[i][2];}double nx=0,ny=0,nz=0;for(var v:q){nx+=v[0]/(.48*.48);ny+=v[1]/(.66*.66);nz+=v[2]/(.48*.48);}double facing=(nx*Math.sin(turn)+nz*Math.cos(turn))*.96-ny*.28;if(facing<0&&ny>0)faces.add(new Face(points,depth/4));}faces.sort(java.util.Comparator.comparingDouble(Face::depth).reversed());
 var m=g.getMatrices();var matrix=new Matrix4f().m00(m.m00()).m01(m.m01()).m10(m.m10()).m11(m.m11()).m30(m.m20()).m31(m.m21());float unit=Math.min(w*.74f,h*.92f);matrix.translate(x+w*.5f,y+h*.84f,0).scale(unit,unit,0);
 var access=(GuiAccess)g;var bounds=new ScreenRect(x,y,w,h).transformEachVertex(m);if(access.visuals$clip()!=null){bounds=bounds.intersection(access.visuals$clip());if(bounds==null)return;}
 var tex=MinecraftClient.getInstance().getTextureManager().getTexture(SlimeModel.texture(variant,pose.expression()));access.visuals$state().addSimpleElement(new Mesh(matrix,java.util.List.copyOf(faces),bounds,TextureSetup.of(tex.getGlTextureView(),tex.getSampler())));
 }
 record Mesh(Matrix4f matrix,java.util.List<Face> faces,ScreenRect bounds,TextureSetup textureSetup) implements SimpleGuiElementRenderState {public com.mojang.blaze3d.pipeline.RenderPipeline pipeline(){return RenderPipelines.GUI_TEXTURED;}public ScreenRect scissorArea(){return bounds;}public void setupVertices(VertexConsumer out){for(var f:faces)for(int i=3;i>=0;i--){var v=f.vertices[i];out.vertex(matrix,v[0],v[1],0).texture(v[3],v[4]).color(0xffffffff);}}}
 private PetPreview(){}
}
