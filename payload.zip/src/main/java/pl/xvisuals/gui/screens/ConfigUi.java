package pl.xvisuals.gui.screens;

import pl.xvisuals.gui.components.*;
import pl.xvisuals.gui.themes.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.*;
import net.minecraft.client.gui.widget.*;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

/** Config controls share Studio's materials and typography, with native input semantics. */
final class ConfigUi {
 static String fit(String value,int width){if(Glass.textWidth(value)<=width)return value;while(!value.isEmpty()&&Glass.textWidth(value+"…")>width)value=value.substring(0,value.length()-1);return value+"…";}
 static void panel(DrawContext g,int width,int height){if(MinecraftClient.getInstance().currentScreen instanceof StudioScreen studio&&studio.configsActive())return;g.fill(0,0,width,height,0xA6080B10);int w=Math.min(744,width-12);StudioChrome.surface(g,(width-w)/2f,6,w,height-12,16,.96,false);}
 static final class Button extends ClickableWidget {
  private final Runnable run;private final boolean selected;private final String subtitle;private final Spring hover=new Spring(0);
  Button(String label,String subtitle,int x,int y,int w,int h,boolean selected,Runnable run){super(x,y,w,h,Text.literal(label));this.subtitle=subtitle;this.selected=selected;this.run=run;}
  @Override protected void renderWidget(DrawContext g,int mx,int my,float dt){float over=hover.to(isHovered()||isFocused()?1:0);
   if(subtitle!=null){StudioChrome.row(g,getX(),getY(),width,selected?1:0,over);StudioChrome.text(g,fit(getMessage().getString(),width-24),getX()+12,getY()+6,Theme.text());StudioChrome.scaled(g,fit(subtitle,(int)((width-24)/.8)),getX()+12,getY()+21,.8f,Theme.muted());}
   else{StudioChrome.surface(g,getX(),getY(),width,height,6,.85,selected||isFocused());if(over>0)Glass.rounded(g,getX()+1,getY()+1,width-2,height-2,6,pl.xvisuals.util.Colors.alpha(Theme.accent(),over*.09));StudioChrome.center(g,fit(getMessage().getString(),width-12),getX()+width/2f,getY()+(height-9)/2f,active?Theme.text():Theme.quiet());}
  }
  @Override public void onClick(Click click,boolean doubled){if(active)run.run();}
  @Override public boolean keyPressed(KeyInput key){if(active&&(key.key()==257||key.key()==32)){run.run();return true;}return super.keyPressed(key);}
  @Override protected void appendClickableNarrations(NarrationMessageBuilder b){appendDefaultNarrations(b);}
 }
 static final class Field extends TextFieldWidget {
  Field(int x,int y,int w,String hint){super(MinecraftClient.getInstance().textRenderer,x+8,y+7,w-16,16,Text.literal(hint));setDrawsBackground(false);setPlaceholder(Glass.label(hint));setEditableColor(Theme.text());}
  @Override public void renderWidget(DrawContext g,int mx,int my,float dt){StudioChrome.surface(g,getX()-8,getY()-7,width+16,26,7,.9,isFocused());super.renderWidget(g,mx,my,dt);}
 }
 private ConfigUi(){}
}
