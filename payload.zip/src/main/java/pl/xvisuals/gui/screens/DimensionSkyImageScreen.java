package pl.xvisuals.gui.screens;
import pl.xvisuals.XVisuals;
import pl.xvisuals.menu.DimensionSkyImport;
import pl.xvisuals.rendering.DimensionSkyTexture;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import java.nio.file.Path;
import java.util.List;
public final class DimensionSkyImageScreen extends Screen {
 private final Screen parent;private boolean importing;private String status="Choose a PNG or drag your files here.";
 public DimensionSkyImageScreen(Screen parent){super(Text.literal("Custom dimension sky"));this.parent=parent;}
 @Override protected void init(){
  addDrawableChild(ButtonWidget.builder(Text.literal("Choose PNG files"),b->choose()).dimensions(width/2-100,height/2,200,24).build());
  addDrawableChild(ButtonWidget.builder(Text.literal("Done"),b->close()).dimensions(width/2-70,height/2+73,140,22).build());
 }
 private void choose(){if(importing)return;try(var stack=org.lwjgl.system.MemoryStack.stackPush()){
  var filters=stack.mallocPointer(1).put(stack.UTF8("*.png")).flip();String result=org.lwjgl.util.tinyfd.TinyFileDialogs.tinyfd_openFileDialog("PNG panorama, atlas, or six cubemap faces",null,filters,"PNG",true);
  if(result!=null)load(java.util.Arrays.stream(result.split("\\|")).map(Path::of).toList());
 }catch(Exception ex){status="File picker unavailable. Drag files here instead.";}}
 public void load(List<Path> files){if(importing)return;importing=true;status="Importing sky";var game=net.minecraft.client.MinecraftClient.getInstance();var config=XVisuals.config();
  java.util.concurrent.CompletableFuture.runAsync(()->{try{var path=DimensionSkyImport.importImages(files,DimensionSkyTexture.directory());game.execute(()->{
   importing=false;if(config!=XVisuals.config()){status="Profile changed. Import again.";return;}
   var s=config.module("dimensionskies");s.values.put("image",path.toString());
   if(!s.text("dimension").equals("End"))s.values.put("netherPreset","Custom Image");
   if(!s.text("dimension").equals("Nether"))s.values.put("endPreset","Custom Image");
   s.enabled=true;status=XVisuals.STORE.save()?"Sky imported and saved.":"Sky imported; could not save settings.";
  });}catch(Exception ex){game.execute(()->{importing=false;status="Import failed: "+ex.getMessage();});}});
 }
 @Override public void onFilesDropped(List<Path> files){load(files);}
 @Override public void renderBackground(DrawContext g,int x,int y,float delta){}
 @Override public void render(DrawContext g,int x,int y,float delta){
  g.fillGradient(0,0,width,height,0xF0101422,0xF0251935);int cy=height/2;
  g.drawCenteredTextWithShadow(textRenderer,"CUSTOM DIMENSION SKY",width/2,cy-90,0xFFFFFFFF);
  ScreenText.center(g,textRenderer,"2:1 panorama, 6:1 / 1:6 strip, 4:3 cross or 3:2 atlas",width/2,cy-67,width-24,0xFFBCCBDD);
  ScreenText.center(g,textRenderer,"Six faces: px.png, nx.png, py.png, ny.png, pz.png, nz.png",width/2,cy-51,width-24,0xFFBCCBDD);
  ScreenText.center(g,textRenderer,"Strips / atlas use that order. Cross: +Y above +Z; -Y below.",width/2,cy-35,width-24,0xFFBCCBDD);
  g.drawCenteredTextWithShadow(textRenderer,textRenderer.trimToWidth(status,width-24),width/2,cy+37,0xFFFFFFFF);
  ScreenText.center(g,textRenderer,"PNG only. 8K / 32 MP maximum; separate faces up to 2K.",width/2,cy+54,width-24,0xFFBCCBDD);
  super.render(g,x,y,delta);
 }
 @Override public void close(){client.setScreen(parent);}
 @Override public boolean shouldPause(){return false;}
}
