package pl.xvisuals.gui.screens;

import pl.xvisuals.XVisuals;
import pl.xvisuals.config.ConfigStore;
import pl.xvisuals.gui.components.StudioChrome;
import pl.xvisuals.gui.themes.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import java.nio.file.*;
import java.util.*;

/** Local config storage and portable files. No account or network integration. */
public final class ConfigLibraryScreen extends Screen {
 private final Screen parent;
 private final String moduleId;
 private StudioScreen host;
 private String selected="",search="",name="",status="Save, load or share a local JSON file.";
 private TextFieldWidget nameField,searchField;
 private int left,span,page;
 private boolean confirmDelete;
 public ConfigLibraryScreen(Screen parent){this(parent,"");}
 public ConfigLibraryScreen(Screen parent,String moduleId){super(Text.literal("Local configs"));this.parent=parent;this.moduleId=moduleId;}
 void embed(StudioScreen host){this.host=host;}
 private ConfigStore store(){return XVisuals.STORE;}
 private interface Action{void run()throws Exception;}
 private void act(Action action){try{action.run();status=store().message;}catch(Exception e){status=e.getMessage()==null?"Could not complete this action.":e.getMessage();}init();}
 private void button(String text,int x,int y,int w,Runnable action){addDrawableChild(new ConfigUi.Button(text,null,x,y,w,22,false,action));}
 @Override protected void init(){
  clearChildren();span=Math.min(700,Math.max(240,width-36));left=(width-span)/2;
  if(host==null)button("Back",left+span-52,14,52,this::close);
  searchField=new ConfigUi.Field(left,45,span/2-4,"Search local configs");searchField.setText(search);searchField.setChangedListener(v->{search=v;page=0;init();setFocused(searchField);});addDrawableChild(searchField);
  nameField=new ConfigUi.Field(left+span/2+4,45,span/2-4,"Config name");nameField.setMaxLength(48);nameField.setText(name);nameField.setChangedListener(v->name=v);addDrawableChild(nameField);
  List<String> all;
  try{all=store().localConfigs().stream().filter(n->n.toLowerCase(Locale.ROOT).contains(search.toLowerCase(Locale.ROOT))).toList();}
  catch(Exception e){all=List.of();status=e.getMessage();}
  int rows=Math.max(1,(height-180)/36),pages=Math.max(1,(all.size()+rows-1)/rows);page=Math.clamp(page,0,pages-1);
  for(int i=0;i<rows&&page*rows+i<all.size();i++){
   String entry=all.get(page*rows+i),scope="";try{scope=store().localModule(entry);}catch(Exception ignored){}
   String details=scope.isEmpty()?"Global config":"Module: "+scope;
   addDrawableChild(new ConfigUi.Button(entry,details,left,83+i*36,span,32,entry.equals(selected),()->{selected=entry;name=entry;confirmDelete=false;init();}));
  }
  int bottom=height-83,w=(span-18)/4;
  button("Save new",left,bottom,w,()->act(()->{store().saveLocal(name,false,moduleId);selected=name;}));
  button("Load",left+w+6,bottom,w,()->act(()->{requireSelected();store().loadLocal(selected);}));
  button("Overwrite",left+(w+6)*2,bottom,w,()->act(()->{requireSelected();store().saveLocal(selected,true,moduleId);}));
  button(confirmDelete?"Confirm delete":"Delete",left+(w+6)*3,bottom,w,()->{if(!confirmDelete){confirmDelete=true;status="Click Confirm delete to remove the selected config.";init();}else act(()->{requireSelected();store().deleteLocal(selected);selected="";confirmDelete=false;});});
  bottom+=28;
  button("Import file",left,bottom,w,this::importFile);
  button("Export file",left+w+6,bottom,w,()->act(()->{requireSelected();var file=store().exportLocalFile(selected);status="Exported "+file.getFileName();}));
  button("Copy JSON",left+(w+6)*2,bottom,w,()->act(()->{requireSelected();client.keyboard.setClipboard(store().exportLocal(selected));}));
  button("Paste JSON",left+(w+6)*3,bottom,w,()->act(()->store().importLocal(name,client.keyboard.getClipboard())));
  button("‹",left,height-26,26,()->{if(page>0){page--;init();}});
  final int last=pages;button("›",left+32,height-26,26,()->{if(page+1<last){page++;init();}});
 }
 private void requireSelected(){if(selected.isEmpty())throw new IllegalStateException("Select a local config first.");}
 private void importFile(){
  try(var stack=org.lwjgl.system.MemoryStack.stackPush()){
   var filters=stack.mallocPointer(1);filters.put(stack.UTF8("*.json")).flip();
   String file=org.lwjgl.util.tinyfd.TinyFileDialogs.tinyfd_openFileDialog("Import local config",null,filters,"JSON config",false);
   if(file!=null)onFilesDropped(List.of(Path.of(file)));
  }catch(Exception e){status="Use Paste JSON or drop a config file here.";}
 }
 @Override public void onFilesDropped(List<Path> files){if(files.size()==1)act(()->{Path file=files.getFirst();String n=file.getFileName().toString().replaceFirst("\\.visual\\.json$|\\.json$","");store().importLocalFile(n,file);selected=n;name=n;});}
 @Override public void renderBackground(DrawContext g,int mx,int my,float dt){}
 @Override public void render(DrawContext g,int mx,int my,float dt){
  if(host==null)ConfigUi.panel(g,width,height);
  StudioChrome.text(g,"Local configs",left,21,Theme.text());super.render(g,mx,my,dt);
  StudioChrome.text(g,ConfigUi.fit(status==null?"":status,span-70),left+70,height-18,Theme.muted());
 }
 @Override public void close(){if(host!=null)host.leaveConfigs();else client.setScreen(parent);}
 @Override public boolean shouldPause(){return false;}
}
