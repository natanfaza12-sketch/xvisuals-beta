package pl.xvisuals.gui.screens;

import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.gui.components.StudioChrome;
import pl.xvisuals.gui.themes.Theme;
import pl.xvisuals.util.Colors;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

/** Compact Studio controls for the waypoint library. */
final class WaypointControl extends ClickableWidget {
 private final Runnable action;
 private final boolean accent;
 WaypointControl(String label,int x,int y,int w,int h,boolean accent,Runnable action){
  super(x,y,w,h,Text.literal(label));this.accent=accent;this.action=action;
 }
 @Override protected void renderWidget(DrawContext g,int mx,int my,float dt){
  boolean hover=active&&(isHovered()||isFocused());
  Glass.rounded(g,getX(),getY(),width,height,5,Colors.alpha(accent?Theme.accent():Theme.text(),active?(hover?.23:accent?.16:.055):.025));
  StudioChrome.center(g,ConfigUi.fit(getMessage().getString(),width-10),getX()+width/2f,getY()+(height-9)/2f,active?(accent?Theme.accent():Theme.text()):Theme.quiet());
 }
 @Override public void onClick(Click click,boolean doubled){if(active)action.run();}
 @Override public boolean keyPressed(KeyInput key){if(active&&(key.key()==257||key.key()==32)){action.run();return true;}return super.keyPressed(key);}
 @Override protected void appendClickableNarrations(NarrationMessageBuilder b){appendDefaultNarrations(b);}
}
