package pl.xvisuals.gui.screens;
import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.cosmetics.HaloDesigns;
import pl.xvisuals.rendering.shaders.GuiAccess;
import pl.xvisuals.util.Colors;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.TextureSetup;
import org.joml.Matrix4f;
final class HaloPreview {
 record Face(HaloDesigns.Point[] points,int color,double depth){}
 static void draw(DrawContext g,String style,int x,int y,int w,int h){
  var s=XVisuals.config().module("halo");
  double time=XVisuals.config().module("performance").text("animation").equals("Off")?0:System.nanoTime()/1e9*s.number("speed");
  var faces=new java.util.ArrayList<Face>();
  HaloDesigns.draw(style,s.number("radius"),s.number("thickness"),time,(a,b,c,d,phase,shade)->{
   int color=s.flag("rainbow")?Colors.rainbow(phase+time):Colors.mix(s.color("color"),s.color("secondary"),.5+.5*Math.sin(phase*Math.PI*2-time));
   int tint=(int)(s.number("opacity")*255)<<24;
   for(int shift=0;shift<=16;shift+=8)tint|=(int)(((color>>shift)&255)*shade)<<shift;
   faces.add(new Face(new HaloDesigns.Point[]{a,b,c,d},tint,(a.z()+b.z()+c.z()+d.z())/4));
  });
  faces.sort(java.util.Comparator.comparingDouble(Face::depth));
  var pose=g.getMatrices();
  var matrix=new Matrix4f().m00(pose.m00()).m01(pose.m01()).m10(pose.m10()).m11(pose.m11()).m30(pose.m20()).m31(pose.m21());
  float unit=(float)(Math.min(w*.40,h*.62)/Math.max(.5,s.number("radius")+.10));
  matrix.translate(x+w*.5f,y+h*.57f,0).scale(unit,unit,0).rotateX(.58f);
  var access=(GuiAccess)g;var bounds=new ScreenRect(x,y,w,h).transformEachVertex(pose);
  if(access.visuals$clip()!=null){bounds=bounds.intersection(access.visuals$clip());if(bounds==null)return;}
  access.visuals$state().addSimpleElement(new Mesh(matrix,java.util.List.copyOf(faces),bounds));
 }
 record Mesh(Matrix4f matrix,java.util.List<Face> faces,ScreenRect bounds) implements SimpleGuiElementRenderState{
  public com.mojang.blaze3d.pipeline.RenderPipeline pipeline(){return RenderPipelines.GUI_TEXTURED;}
  public TextureSetup textureSetup(){var t=net.minecraft.client.MinecraftClient.getInstance().getTextureManager().getTexture(net.minecraft.util.Identifier.of("xvisuals","textures/crafted/metal.png"));return TextureSetup.of(t.getGlTextureView(),t.getSampler());}
  public ScreenRect scissorArea(){return bounds;}
  public void setupVertices(VertexConsumer out){for(var face:faces){int corner=0;for(var p:face.points)out.vertex(matrix,(float)p.x(),(float)p.y(),(float)p.z()).texture((corner==1||corner==2)?1:0,corner++>=2?1:0).color(face.color);}}
 }
 private HaloPreview(){}
}
