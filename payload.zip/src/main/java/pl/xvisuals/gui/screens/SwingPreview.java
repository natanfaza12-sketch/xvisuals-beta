package pl.xvisuals.gui.screens;
import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.motion.*;
import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.rendering.shaders.GuiAccess;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.TextureSetup;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.joml.Matrix3x2f;
import org.joml.Vector3f;
import org.joml.Vector2f;
/** Independent gallery clocks; uses the exact held-item pose without triggering player actions. */
final class SwingPreview {
 private static final class Clock {double previous,pulse,arc;}
 private final java.util.Map<String,Clock> clocks=new java.util.HashMap<>();
 record Face(Vector3f[] points,int color,double depth){}
 void draw(DrawContext g,String design,int x,int y,int w,int h){
  var s=XVisuals.config().module("swing");var speed=XVisuals.config().module("swingspeed");
  boolean animated=!XVisuals.config().module("performance").text("animation").equals("Off");
  double duration=s.number("duration")*switch(design){case "Snappy"->.7;case "Slow"->1.6;case "Cinematic"->1.25;default->1;};
  duration=Math.max(.03,duration/(speed.enabled?speed.number("speed"):1));
  double now=System.nanoTime()/1e9,elapsed=now%(duration+.5),t=animated?Math.min(1,elapsed/duration):.4;
  String curve=s.text("easing");if(curve.equals("Preset"))curve=switch(design){case "Vanilla"->"Linear";case "Snappy"->"Ease Out";case "Slow"->"Smoothstep";default->"Sine";};
  double progress=s.flag("custom")?Easing.bezier(t,s.number("control1"),s.number("control2")):Easing.apply(curve,t);
  double pulse=Math.pow(Math.sin(Math.PI*progress),2),arc=Math.sin(progress*Math.PI*2)*pulse;
  var clock=clocks.computeIfAbsent(design,k->new Clock());double dt=clock.previous==0?1./60:Math.clamp(now-clock.previous,0,.1);clock.previous=now;
  double damping=35/(.15+s.number("smoothness"));
  clock.pulse=!animated||s.number("smoothness")<.01?pulse:Easing.damp(clock.pulse,pulse,damping,dt);
  clock.arc=!animated||s.number("smoothness")<.01?arc:Easing.damp(clock.arc,arc,damping,dt);
  var stack=new MatrixStack();SwingPose.apply(stack,design,1,progress,clock.pulse,clock.arc,s.number("strength"),s.number("distance"),s.number("followThrough"));
  Matrix4f matrix=new Matrix4f(stack.peek().getPositionMatrix()).rotateY(-.35f);
  float unit=Math.min(w/3f,h/2.5f),cx=x+w*.54f,cy=y+h*.72f;
  var hand=project(matrix,0,-.13f,0,cx,cy,unit);
  Glass.line(g,cx+unit*.85,cy+unit*.6,hand.x,hand.y,unit*.23,0xFF9D7259);
  var faces=new java.util.ArrayList<Face>();
  box(faces,matrix,cx,cy,unit,-.105f,.16f,-.045f,.105f,1.12f,.045f,0xFF95E8EA);
  box(faces,matrix,cx,cy,unit,-.055f,1.12f,-.035f,.055f,1.24f,.035f,0xFFDCF9FA);
  box(faces,matrix,cx,cy,unit,-.022f,.22f,.046f,.022f,1.1f,.06f,0xFF2D8C9B);
  box(faces,matrix,cx,cy,unit,-.24f,.1f,-.09f,.24f,.19f,.09f,0xFFC3A45D);
  box(faces,matrix,cx,cy,unit,-.06f,-.27f,-.065f,.06f,.1f,.065f,0xFF503C30);
  box(faces,matrix,cx,cy,unit,-.13f,-.24f,-.1f,.14f,.045f,.12f,0xFFD8A783);
  faces.sort(java.util.Comparator.comparingDouble(Face::depth));
  var pose=new Matrix3x2f(g.getMatrices());var access=(GuiAccess)g;
  var bounds=new ScreenRect(x,y,w,h).transformEachVertex(pose);if(access.visuals$clip()!=null){bounds=bounds.intersection(access.visuals$clip());if(bounds==null)return;}
  access.visuals$state().addSimpleElement(new Mesh(pose,java.util.List.copyOf(faces),bounds));
 }
 static Vector3f project(Matrix4f m,float x,float y,float z,float cx,float cy,float unit){var p=m.transformPosition(new Vector3f(x,y,z));float depth=3/Math.max(1.2f,3-p.z);return new Vector3f(cx+p.x*unit*depth,cy-p.y*unit*depth,p.z);}
 static void box(java.util.List<Face> faces,Matrix4f m,float cx,float cy,float unit,float x,float y,float z,float X,float Y,float Z,int color){
  Vector3f[] v=new Vector3f[8];for(int i=0;i<8;i++)v[i]=project(m,(i&1)==0?x:X,(i&2)==0?y:Y,(i&4)==0?z:Z,cx,cy,unit);
  int[][] indices={{0,1,3,2},{4,6,7,5},{0,4,5,1},{2,3,7,6},{0,2,6,4},{1,5,7,3}};
  for(int i=0;i<6;i++){var q=indices[i];double shade=new double[]{.65,1,.7,.95,.78,.88}[i];int tint=0xFF000000;for(int shift=0;shift<=16;shift+=8)tint|=(int)(((color>>shift)&255)*shade)<<shift;
   faces.add(new Face(new Vector3f[]{v[q[0]],v[q[1]],v[q[2]],v[q[3]]},tint,(v[q[0]].z+v[q[1]].z+v[q[2]].z+v[q[3]].z)/4));}
 }
 record Mesh(Matrix3x2f pose,java.util.List<Face> faces,ScreenRect bounds) implements SimpleGuiElementRenderState {
  public com.mojang.blaze3d.pipeline.RenderPipeline pipeline(){return RenderPipelines.GUI;}
  public TextureSetup textureSetup(){return TextureSetup.empty();}
  public ScreenRect scissorArea(){return bounds;}
  public void setupVertices(VertexConsumer out){for(var f:faces)for(var p:f.points){var q=pose.transformPosition(p.x,p.y,new Vector2f());out.vertex(q.x,q.y,0).color(f.color);}}
 }
}
