package pl.xvisuals.gui.screens;
import pl.xvisuals.XVisuals;
import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.util.Colors;
import net.minecraft.client.gui.DrawContext;

/** Shaded three-dimensional silhouettes with bounded, isolated animation playback. */
final class GhostGalleryPreview {
  private static double smooth(double t){t=Math.clamp(t,0,1);return t*t*(3-2*t);}
  static void draw(DrawContext g,String module,String style,int x,int y,int w,int h){
    var s=XVisuals.config().module(module);
    boolean animated=!XVisuals.config().module("performance").text("animation").equals("Off");
    double duration=s.number("duration")/Math.max(.1,s.number("animation"));
    double age=animated?duration*(.12+.76*((System.nanoTime()/1e9%(duration+1.0))/(duration+1.0))):duration*.3;
    double t=Math.min(1,age/duration),a=age*s.number("animation");
    double fade=Math.pow(1-smooth((t-.55)/.45),s.number("fade"))*smooth(t/.06);
    boolean afterglow=style.equals("Afterglow");
    int base=afterglow&&(s.color("color")&0xffffff)==0xffffff?0xffD994FF:style.equals("Clean Ascension")?0xFFF1F8FF:s.color("color"),tint=Colors.alpha(base,s.number("opacity")*fade);
    double u=Math.min(w/3.2,h/2.7)*Math.min(1.3,s.number("scale")),cx=x+w*.5,feet=y+h*.87;
    boolean kill=module.equals("killanimations"),burial=kill&&!style.equals("Prismatic Burst")&&!afterglow;
    boolean soul=style.equals("Soul")||style.equals("Clean Ascension");
    double vertical=burial?-2.15*smooth((t-.24)/.62):soul?a*s.number("rise"):style.equals("Ash")?-t*t*s.number("fall"):0;
    g.enableScissor(x,y,x+w,y+h);
    try{
      if(burial){
        double radius=u*.9*Math.min(1,t*6)*Math.min(1,(1-t)*6);
        ring(g,cx,feet,radius,radius*.25,Colors.alpha(base,fade*.6));
        for(int i=0;i<8;i++){double angle=i*Math.PI/4;CraftedGui.line(g,cx+Math.cos(angle)*radius*.6,feet+Math.sin(angle)*radius*.15,cx+Math.cos(angle)*radius*1.4,feet+Math.sin(angle)*radius*.35,1,tint);}
      }
      GhostSkinPreview.draw(g,style,t,a,vertical,s,x,y,w,h);
      if(style.equals("Chain Burial"))for(int side=-1;side<=1;side+=2)for(int i=0;i<16;i++){
        double yy=feet-u*(i*.14-2.15*smooth((t-.24)/.62));
        if(yy<feet)ring(g,cx+side*u*.38,yy,u*.085,u*.11,Colors.alpha(0xffc7d5e8,fade));
      }
      if(afterglow){
        for(int i=0;i<24;i++){double start=(i%7)*.045,life=(t-start)/(.8-start);if(life<=0||life>=1)continue;double angle=i*2.399963,px=cx+Math.cos(angle+life*.65)*u*.45,py=feet-u*(.4+(i%5)*.25+life*1.4),alpha=fade*Math.sin(Math.PI*life);
         for(int layer=4;layer>=1;layer--)CraftedGui.dot(g,px,py,layer*1.5,Colors.alpha(layer==1?0xfffff5ff:base,alpha*(layer==1?.95:.12)),0);
        }
      }
      if(!afterglow&&!style.equals("Clean Ascension"))for(int i=0;i<(int)(s.number("fragments")*s.number("density"));i++){
        double angle=i*2.399963,r=u*(.15+t*(kill?1.25:.6)),px=cx+Math.cos(angle)*r;
        double py=feet-u*(.6+Math.sin(angle)*t*.7+vertical*.4-t*t*s.number("gravity")*.25);
        if(style.equals("Prismatic Burst"))CraftedGui.sprite(g,px,py,5,9,18,(int)(a*8),Colors.alpha(Colors.mix(base,0xffe6f5ff,(i%4)/4.),fade*Math.sin(Math.PI*t)));
        else CraftedGui.dot(g,px,py,1,Colors.alpha(base,fade*t*.6),.1);
      }
    }finally{g.disableScissor();}
  }
  private static void ring(DrawContext g,double x,double y,double rx,double ry,int tint){for(int i=0;i<24;i++){double a=i*Math.PI/12,b=(i+1)*Math.PI/12;CraftedGui.line(g,x+Math.cos(a)*rx,y+Math.sin(a)*ry,x+Math.cos(b)*rx,y+Math.sin(b)*ry,1,tint);}}
  private GhostGalleryPreview(){}
}
