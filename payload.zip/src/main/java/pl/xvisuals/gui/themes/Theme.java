package pl.xvisuals.gui.themes;

import pl.xvisuals.XVisuals;
import pl.xvisuals.util.Colors;

public final class Theme {
  public static final int TEXT = 0xFFF0EEF7, MUTED = 0xFFC5CCDA, QUIET = 0xFFABB4C4;
  public static final String[][] PRESETS = {
    {"Monochrome", "#FFFFFF", "#000000"},
    {"Amethyst", "#B88CFF", "#79D8FF"},
    {"Glacier", "#80DCEE", "#ABBFFF"},
    {"Pearl", "#DDDBED", "#ABCAC7"},
    {"Ember", "#EDAA87", "#DB92AD"},
    {"Rose", "#E8A2C3", "#BAAAED"},
    {"Mint", "#91D6B9", "#8FBCCF"}
  };

  public static void apply(pl.xvisuals.config.VisualConfig config, String name, String primary, String secondary) {
    if (config.themeEffects) {
      pl.xvisuals.config.QuickLooks.themeColors(config, primary, secondary);
      config.lookPrimary = primary; config.lookSecondary = secondary; config.lookMode = "Gradient";
    }
    config.theme = name; config.accent = primary; config.secondary = secondary;
  }

  private static String cachedAccent, cachedSecondary;
  private static int primary, secondary, surface, surfaceEnd, text, muted, quiet;

  private static void refresh() {
    var c = XVisuals.config();
    if (java.util.Objects.equals(cachedAccent, c.accent)
        && java.util.Objects.equals(cachedSecondary, c.secondary)) return;
    cachedAccent = c.accent; cachedSecondary = c.secondary;
    primary = Colors.parse(c.accent); secondary = Colors.parse(c.secondary);
    boolean neutral = c.accent.equalsIgnoreCase("#FFFFFF") && c.secondary.equalsIgnoreCase("#000000");
    surface = Colors.mix(neutral ? 0xFF141414 : 0xFF121620, primary, .055);
    surfaceEnd = Colors.mix(neutral ? 0xFF101010 : 0xFF0E121A, secondary, .025);
    text = 0xFFF4F6FC;
    muted = 0xFFC5CCDA;
    quiet = 0xFFABB4C4;
    primary = readableAccent(primary); secondary = readableAccent(secondary);
  }

  private static int readableAccent(int color) {
    double brightness = .2126 * ((color >> 16) & 255)
        + .7152 * ((color >> 8) & 255) + .0722 * (color & 255);
    return brightness < 145 ? Colors.mix(color, 0xFFFFFFFF, .65) : color;
  }

  public static int accent() { refresh(); return primary; }
  public static int secondary() { refresh(); return secondary; }
  public static int surface() { refresh(); return surface; }
  public static int surfaceEnd() { refresh(); return surfaceEnd; }
  public static int text() { refresh(); return text; }
  public static int muted() { refresh(); return muted; }
  public static int quiet() { refresh(); return quiet; }

  private Theme() {}
}
