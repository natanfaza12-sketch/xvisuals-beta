package pl.xvisuals.gui;
public record ShulkerPreviewLayout(double x,double y,double scale,int height) {
 public static final int WIDTH=174;
 public static ShulkerPreviewLayout place(int mx,int my,int screenWidth,int screenHeight,double desired,int height){
  double scale=Math.min(desired,Math.min(Math.max(1,screenWidth-8)/(double)WIDTH,Math.max(1,screenHeight-8)/(double)height));
  double w=WIDTH*scale,h=height*scale,x=mx+12,y=my-12;
  if(x+w>screenWidth-4)x=mx-w-12;
  x=Math.max(0,Math.min(x,screenWidth-w));y=Math.max(0,Math.min(y,screenHeight-h));
  return new ShulkerPreviewLayout(x,y,scale,height);
 }
 public boolean contains(double mx,double my){return mx>=x&&mx<x+WIDTH*scale&&my>=y&&my<y+height*scale;}
 public int slot(double mx,double my,int top){double xx=(mx-x)/scale-6,yy=(my-y)/scale-top;if(xx<0||xx>=162||yy<0||yy>=54)return -1;return (int)(yy/18)*9+(int)(xx/18);}
}
