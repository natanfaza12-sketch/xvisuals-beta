package pl.xvisuals.gui;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.util.Identifier;

public final class FontMaterial {
  private static final java.util.Set<com.mojang.blaze3d.textures.GpuTexture> textures=
      java.util.Collections.newSetFromMap(new java.util.WeakHashMap<>());
  public static void register(com.mojang.blaze3d.textures.GpuTexture texture){textures.add(texture);}
  public static boolean contains(com.mojang.blaze3d.textures.GpuTexture texture){return textures.contains(texture);}
  public static final RenderPipeline PIPELINE=RenderPipeline.builder(
      RenderPipelines.GUI_TEXT_SNIPPET,RenderPipelines.FOG_SNIPPET)
      .withLocation(Identifier.of("xvisuals","pipeline/font_choices"))
      .withVertexShader("core/rendertype_text_intensity")
      .withFragmentShader(Identifier.of("xvisuals","core/font_choices"))
      .withSampler("Sampler0").withSampler("Sampler2").build();
  private FontMaterial(){}
}
