package pl.xvisuals.gui;
import pl.xvisuals.XVisuals;
import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.gui.components.StudioChrome;
import pl.xvisuals.util.Colors;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.collection.DefaultedList;
import org.lwjgl.glfw.GLFW;

/** Screen-local, read-only preview. Never opens containers or sends inventory actions. */
public final class ShulkerPreview {
 private Slot source;
 private ShulkerPreviewLayout layout;
 private boolean over;
 private long lastHover;
 private int anchorX,anchorY;
 public static boolean shulker(ItemStack stack){return !stack.isEmpty()&&stack.getItem() instanceof BlockItem item&&item.getBlock() instanceof ShulkerBoxBlock;}
 private boolean enabled(){return XVisuals.ready()&&XVisuals.visualModule("shulkerpreview").enabled;}
 private boolean permitted(){
  if(!enabled())return false;
  var s=XVisuals.visualModule("shulkerpreview");if(s.text("mode").equals("Hover"))return true;
  long window=MinecraftClient.getInstance().getWindow().getHandle();return GLFW.glfwGetKey(window,GLFW.GLFW_KEY_LEFT_SHIFT)==GLFW.GLFW_PRESS||GLFW.glfwGetKey(window,GLFW.GLFW_KEY_RIGHT_SHIFT)==GLFW.GLFW_PRESS;
 }
 private void clear(){source=null;layout=null;over=false;}
 private static String fit(String text,int width){while(!text.isEmpty()&&Glass.textWidth(text)>width)text=text.substring(0,text.length()-1);return text;}
 public boolean blocksInput(double x,double y){return source!=null&&layout!=null&&layout.contains(x,y)&&permitted();}
 public boolean blocksInput(){return over&&source!=null&&permitted();}
 public boolean render(DrawContext g,Slot focused,int mx,int my,int width,int height,boolean cursorEmpty){
  if(!permitted()||!cursorEmpty){clear();return false;}
  long now=System.nanoTime();boolean inside=layout!=null&&layout.contains(mx,my);
  if(source!=null&&!shulker(source.getStack()))clear();
  if(!inside&&focused!=null&&shulker(focused.getStack())&&focused!=source){source=focused;anchorX=mx;anchorY=my;lastHover=now;}
  if(source==null)return false;
  if(focused==source||inside)lastHover=now;
  // A short grace interval lets the pointer cross the gap into the inspection panel.
  if(now-lastHover>400_000_000L){clear();return false;}
  var c=MinecraftClient.getInstance();var s=XVisuals.visualModule("shulkerpreview");var stack=source.getStack();
  var data=stack.get(DataComponentTypes.CONTAINER);var contents=DefaultedList.ofSize(27,ItemStack.EMPTY);if(data!=null)data.copyTo(contents);
  int top=s.flag("name")?30:8,panelHeight=top+54+8+(data==null?12:0);
  layout=ShulkerPreviewLayout.place(anchorX,anchorY,width,height,s.number("scale"),panelHeight);over=layout.contains(mx,my);
  int hovered=over?layout.slot(mx,my,top):-1;
  int tint=0x9F82B5;
  if(s.flag("color")&&stack.getItem() instanceof BlockItem item&&item.getBlock() instanceof ShulkerBoxBlock block&&block.getColor()!=null)tint=block.getColor().getEntityColor();
  int alpha=(int)(255*s.number("opacity"));
  var m=g.getMatrices();m.pushMatrix();m.translate((float)layout.x(),(float)layout.y());m.scale((float)layout.scale(),(float)layout.scale());
  double opacity=Math.clamp(s.number("opacity"),0,1);
  Glass.rounded(g,1,3,172,panelHeight,8,Colors.alpha(0xFF000000,opacity*.24));
  Glass.rounded(g,0,0,174,panelHeight,7,Colors.alpha(0xFF000000|(tint&0xFFFFFF),opacity*.42));
  Glass.rounded(g,1,1,172,panelHeight-2,6,(alpha<<24)|0x191C23);
  if(s.flag("name")){
   g.drawItem(stack,7,6);
   StudioChrome.scaled(g,fit(stack.getName().getString(),162),28,6,.85f,0xFFF1F0F7);
   long occupied=contents.stream().filter(item->!item.isEmpty()).count();
   StudioChrome.scaled(g,data==null?"Contents unavailable":occupied+" / 27 slots",28,18,.65f,0xFF989CA9);
   g.fill(7,26,167,27,Colors.alpha(0xFFFFFFFF,opacity*.055));
  }
  for(int i=0;i<27;i++){
   var item=contents.get(i);int x=6+(i%9)*18,y=top+(i/9)*18;
   if(s.flag("empty")||!item.isEmpty()){
    Glass.rounded(g,x,y,17,17,2,Colors.alpha(0xFFFFFFFF,opacity*(item.isEmpty()?.035:.07)));
    if(!item.isEmpty())Glass.rounded(g,x,y+15,17,2,1,Colors.alpha(0xFF000000|tint,opacity*.20));
   }
   if(!item.isEmpty()){g.drawItem(item,x+1,y+1);g.drawStackOverlay(c.textRenderer,item,x+1,y+1,s.flag("counts")?null:"");}
   if(i==hovered)Glass.rounded(g,x,y,17,17,2,Colors.alpha(0xFF000000|tint,.22));
  }
  if(data==null)StudioChrome.scaled(g,"No contents supplied by server",7,top+58,.7f,0xFFAAA4B1);
  m.popMatrix();
  if(hovered>=0&&s.flag("tooltips")&&!contents.get(hovered).isEmpty())g.drawItemTooltip(c.textRenderer,contents.get(hovered),mx,my);
  return true;
 }
}
