package pl.xvisuals.gui.components;

import pl.xvisuals.gui.themes.Theme;
import pl.xvisuals.util.Colors;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;

public final class GlassButton extends ClickableWidget {
  private final Runnable action;
  private final Spring hover = new Spring(0);
  private boolean compact;

  public GlassButton compact() {
    compact = true;
    return this;
  }

  public GlassButton(int x, int y, int w, int h, String text, Runnable action) {
    super(x, y, w, h, Glass.label(text));
    this.action = action;
  }

  @Override
  protected void renderWidget(DrawContext g, int mx, int my, float dt) {
    float a = hover.to(isHovered() || isFocused() ? 1 : 0);
    if (compact) {
      Glass.rounded(g, getX(), getY(), width, height, 2, Colors.alpha(0xC4D2DE, a * .09 * alpha));
      String label = getMessage().getString();
      float scale = height <= 18 ? .73f : .81f;
      Glass.scaled(
          g,
          label,
          getX() + (width - Glass.textWidth(label) * scale) / 2,
          getY() + (height - 9 * scale) / 2,
          scale,
          Colors.alpha(Colors.mix(0xFFCFD6DF, 0xFFF4F6FA, a), alpha));
      return;
    }
    pl.xvisuals.rendering.shaders.SdfRenderer.rect(
        g,
        getX() - a * .5f,
        getY(),
        width + a,
        height,
        4,
        Colors.alpha(0x202A38, (.28 + a * .18) * alpha),
        1);
    if (a > .01)
      Glass.rounded(
          g,
          getX() + width * .32f,
          getY() + height - 1,
          width * .36f,
          1,
          0,
          Colors.alpha(Theme.accent(), a * .55 * alpha));
    String label = getMessage().getString();
    float textScale = .87f;
    Glass.scaled(
        g,
        label,
        getX() + width / 2f - Glass.textWidth(label) * textScale / 2,
        getY() + (height - 8) / 2f,
        textScale,
        Colors.alpha(Colors.mix(0xFFD0D2DB, Theme.text(), a), alpha));
  }

  @Override
  public void onClick(Click click, boolean doubled) {
    action.run();
  }

  @Override
  public void playDownSound(net.minecraft.client.sound.SoundManager manager) {
  }

  @Override
  protected void appendClickableNarrations(NarrationMessageBuilder builder) {
    appendDefaultNarrations(builder);
  }
}
