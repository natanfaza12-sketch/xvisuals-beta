package pl.xvisuals.gui.components;

import pl.xvisuals.gui.themes.Theme;
import pl.xvisuals.rendering.shaders.SdfRenderer;
import pl.xvisuals.util.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Studio-only materials. Theme colours are reserved for interaction and selection. */
public final class StudioChrome {
  private StudioChrome() {}
  public static boolean glassTheme() {
    return !"Classic".equals(pl.xvisuals.XVisuals.config().guiAppearance);
  }
  private static void bubble(DrawContext g,float x,float y,float w,float h,float radius,boolean selected) {
    float r=Math.min(h/2,radius);
    boolean weathered="Weathered Glass".equals(pl.xvisuals.XVisuals.config().guiAppearance);
    if(weathered){weatheredSurface(g,x,y,w,h,r,selected);return;}
    int tint=Colors.mix(0xFF132222,Theme.accent(),selected?.13:.035);
    Glass.gradient(g,x,y,w,h,r,Colors.alpha(tint,h>100?.66:.38),Colors.alpha(0xFF090F12,h>100?.79:.53),"Vertical");
    SdfRenderer.rect(g,x,y,w,h,r,selected?Colors.alpha(Theme.accent(),.48):0x389AC5C1,22);
    SdfRenderer.rect(g,x+1.4f,y+1.4f,w-2.8f,h-2.8f,Math.max(1,r-1.4f),0x12FFFFFF,22);
    Glass.gradient(g,x+r,y+1,w-r*2,Math.min(h*.28f,24),3,0x16DFFAF5,0x00DFFAF5,"Vertical");
    Glass.rounded(g,x+r,y+.8f,w-r*2,.7f,0,0x32E5FFF9);
  }

  private static void weatheredSurface(DrawContext g,float x,float y,float w,float h,float r,boolean selected){
    boolean panel=h>100;
    // A smoked blue-grey material: broad shading rather than stacked glowing outlines.
    int top=Colors.mix(0xFF303E48,Theme.accent(),selected?.10:.02);
    Glass.gradient(g,x,y,w,h,r,Colors.alpha(top,panel?.89:.76),
        Colors.alpha(0xFF121A23,panel?.94:.86),"Vertical");
    SdfRenderer.rect(g,x,y,w,h,r,selected?Colors.alpha(Theme.accent(),.65):0x407D939F,22);
    if(w>2*r+4)Glass.gradient(g,x+r,y+1,w-2*r,Math.min(16,h*.22f),3,
        0x16E1EEF2,0x00E1EEF2,"Vertical");
    if(!panel)return;
    // A low-contrast veil hugs the sides; the centre stays clear for text and controls.
    float edge=Math.min(22,w*.045f),body=Math.max(1,h-2*r);
    Glass.gradient(g,x+2,y+r,edge,body,5,0x147FA7B8,0x007FA7B8,"Horizontal");
    Glass.gradient(g,x+w-edge-2,y+r,edge,body,5,0x007FA7B8,0x147FA7B8,"Horizontal");
    // Only the outer window gets condensation, avoiding repeated droplets on nested panels.
    if(w<500||h<300)return;
    var c=MinecraftClient.getInstance();
    float wet=c.world==null?0:c.world.getRainGradient(1);
    boolean motion=!pl.xvisuals.XVisuals.config().module("performance").text("animation").equals("Off");
    double time=!motion||c.world==null?0:(c.world.getTime()+c.getRenderTickCounter().getTickProgress(false))/20.;
    for(int i=0;i<8;i++){
      double phase=(i*.381966+time*.002*wet)%1;
      float dx=(i%2==0?x+7:x+w-9)+(i%3)*.7f;
      float dy=y+r+8+(float)phase*(h-2*r-16);
      float size=1.2f+(i%3)*.35f;
      double fade=Math.min(1,Math.min(phase,1-phase)*10);
      double alpha=(.18+wet*.08)*fade;
      Glass.rounded(g,dx,dy,size*1.6f,size*2.4f,size*.8f,Colors.alpha(0xFF081119,alpha));
      SdfRenderer.rect(g,dx,dy,size*1.6f,size*2.4f,size*.8f,Colors.alpha(0xFF9CB8C5,alpha),22);
      Glass.dot(g,dx+size*.45,dy+size*.6,.65,Colors.alpha(0xFFE8F2F6,alpha),0);
    }
  }

  public static void surface(DrawContext g, float x, float y, float w, float h,
      float radius, double opacity, boolean selected) {
    if(glassTheme()){bubble(g,x,y,w,h,h>100?24:Math.max(radius,12),selected);return;}
    float r = Math.min(h / 2, Math.max(radius, h > 100 ? 12 : 6));
    int top = selected ? Colors.mix(0xFF25292F, Theme.accent(), .09) : 0xFF25292F;
    Glass.gradient(g, x, y, w, h, r, Colors.alpha(top, opacity),
        Colors.alpha(0xFF14171C, Math.min(.98, opacity + .08)), "Vertical");
    SdfRenderer.rect(g, x, y, w, h, r, selected ? 0x4DABB4C0 : 0x268F9AA8, 22);
    Glass.rounded(g, x + r, y + .7f, w - r * 2, .6f, 0, 0x14FFFFFF);
  }

  public static void navigation(DrawContext g, float x, float y, float w, float h,
      float selected, float hover) {
    float amount = Math.max(selected, hover);
    if (amount > .01f) Glass.gradient(g, x, y, w, h, 8,
        Colors.alpha(0xFFBBC5D5, amount * .035),
        Colors.alpha(Colors.mix(0xFFBBC5D5, Theme.accent(), selected), amount * .12), "Vertical");
    if (selected > .01f) {
      float line = (w - 22) * (.6f + .4f * selected);
      Glass.rounded(g, x + (w - line) / 2, y + h - 2, line, 1.6f, .8f,
          Colors.alpha(Theme.accent(), selected));
    }
  }

  public static void row(DrawContext g, float x, float y, float w,
      float selected, float hover) {
    if(glassTheme()){bubble(g,x,y,w,35,13,selected>.01f);
      if(hover>.01f)Glass.rounded(g,x+1,y+1,w-2,33,12,Colors.alpha(0xFFD5FFF4,hover*.055));return;}
    int base = Colors.mix(Colors.mix(0xFF23272D, 0xFF30353D, hover), Theme.accent(), selected * .13);
    Glass.rounded(g, x, y, w, 35, 8, Colors.alpha(base, .76 + .16 * Math.max(selected, hover)));
    if (selected + hover > .01f) SdfRenderer.rect(g, x, y, w, 35, 8,
        Colors.alpha(Colors.mix(0xFF9DA8B9, Theme.accent(), selected), .07 * hover + .17 * selected), 22);
    if (selected > .01f) Glass.rounded(g, x + 1, y + 10, 2, 15, 1,
        Colors.alpha(Theme.accent(), selected));
  }

  public static void toggle(DrawContext g, float x, float y, float amount) {
    Glass.rounded(g, x, y, 27, 14, 7, Colors.mix(0xFF171B22, Theme.accent(), amount * .64));
    SdfRenderer.rect(g, x, y, 27, 14, 7, Colors.mix(0xFF454D59, Theme.accent(), amount * .72), 22);
    Glass.dot(g, x + 7 + amount * 13, y + 7, 10,
        Colors.mix(0xFF9CA6B5, 0xFFF4F6FC, amount), 0);
  }

  public static void slider(DrawContext g, float x, float y, float width, double fraction, float hover) {
    float end = x + width * (float) Math.clamp(fraction, 0, 1);
    Glass.rounded(g, x, y + 23, width, 3, 1.5f, 0xFF3A414B);
    Glass.rounded(g, x, y + 23, end - x, 3, 1.5f, Colors.alpha(Theme.accent(), .90));
    Glass.dot(g, end, y + 24.5, 12 + hover * 2, Colors.alpha(Theme.accent(), .08 + hover * .14), 0);
    Glass.dot(g, end, y + 24.5, 7 + hover * 2, 0xFFF1F4F9, 0);
  }

  public static void search(DrawContext g, float x, float y, float width, float hover, float focus) {
    if(glassTheme()){bubble(g,x,y,width,24,12,focus>.01f);return;}
    Glass.gradient(g, x, y, width, 24, 10, Colors.mix(0xFF1B1F26, 0xFF292E38, hover * .5 + focus * .25),
        0xFF171B22, "Vertical");
    SdfRenderer.rect(g, x, y, width, 24, 10,
        Colors.alpha(Colors.mix(0xFF9DA8B9, Theme.accent(), focus), .22 + hover * .10 + focus * .44), 22);
    if (focus > .01f) SdfRenderer.rect(g, x - 2, y - 2, width + 4, 28, 12,
        Colors.alpha(Theme.accent(), focus * .10), 22);
  }

  // Shadowless UI typography stays crisp on the deliberately dark materials.
  public static void text(DrawContext g, String text, float x, float y, int color) {
    g.drawText(MinecraftClient.getInstance().textRenderer, Glass.ordered(text),
        Math.round(x), Math.round(y), color, false);
  }

  public static void center(DrawContext g, String text, float x, float y, int color) {
    text(g, text, x - Glass.textWidth(text) / 2f, y, color);
  }

  public static void scaled(DrawContext g, String text, float x, float y, float scale, int color) {
    g.getMatrices().pushMatrix();
    g.getMatrices().translate(x, y);
    g.getMatrices().scale(scale, scale);
    text(g, text, 0, 0, color);
    g.getMatrices().popMatrix();
  }
}
