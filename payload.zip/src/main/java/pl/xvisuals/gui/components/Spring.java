package pl.xvisuals.gui.components;

/** Critically damped integration with a bounded step after window stalls. */
public final class Spring {
  private double value, velocity;
  private long last = System.nanoTime();

  public Spring(double value) {
    this.value = value;
  }

  public float snap(double target) {
    value = target;
    velocity = 0;
    last = System.nanoTime();
    return (float) target;
  }

  public float to(double target) {
    long now = System.nanoTime();
    double dt = Math.min(.04, (now - last) / 1e9);
    last = now;
    double f = 18, delta = value - target, e = Math.exp(-f * dt);
    value = target + (delta + (velocity + f * delta) * dt) * e;
    velocity = (velocity - f * (velocity + f * delta) * dt) * e;
    return (float) value;
  }
}
