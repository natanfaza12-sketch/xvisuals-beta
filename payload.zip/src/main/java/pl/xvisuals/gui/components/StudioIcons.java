package pl.xvisuals.gui.components;

import java.util.*;
import net.minecraft.client.gui.DrawContext;

/** Original vector icons on a 24-unit grid. Geometry is built once, independent of fonts. */
public final class StudioIcons {
  private static final Map<String,float[]> ICONS=new HashMap<>();
  static {
    put("spark",path(12,2).q(14,10,22,12).q(14,14,12,22).q(10,14,2,12).q(10,10,12,2).points());
    put("folder",rounded(2,6,8,6,11,9,22,9,22,20,2,20),p(4,5,9,5));
    put("world",rounded(12,2,21,7,21,17,12,22,3,17,3,7),p(3,7,12,12,21,7),p(12,12,12,22));
    put("hud",box(2,3,20,14,2),p(8,21,16,21),p(12,17,12,21),p(6,8,10,8),p(6,12,16,12));
    put("style",path(12,2).c(6,2,2,6,2,12).c(2,18,6,22,11,22).q(14,22,14,19).q(11,15,16,15).c(22,16,24,10,20,6).q(17,2,12,2).points(),
        circle(7,9,.9f),circle(12,6,.9f),circle(17,9,.9f),circle(6,14,.9f));
    put("settings",rounded(9,3,15,3,16,6,19,7,21,11,19,14,19,18,15,21,12,19,9,21,5,18,5,14,3,11,5,7,8,6),circle(12,12,3));
    put("config",p(5,3,5,9),p(5,15,5,21),p(12,3,12,15),p(12,21,12,21.1f),p(19,3,19,5),p(19,11,19,21),box(2.5f,9,5,5,1.5f),box(9.5f,15,5,5,1.5f),box(16.5f,5,5,5,1.5f));
    put("tool",path(14,3).q(9,2,8,7).q(7,10,10,13).l(3,20).q(2,22,5,22).l(13,14).q(18,17,21,12).q(23,9,21,6).l(17,10).l(13,9).l(12,6).l(15,3).points());
    put("search",circle(10.5f,10.5f,6.5f),p(15.5f,15.5f,21,21));
    put("close",p(6,6,18,18),p(18,6,6,18));
    put("play",rounded(6,3,21,12,6,21));
    put("mods",box(3,3,7,7,1.6f),box(14,3,7,7,1.6f),box(3,14,7,7,1.6f),box(14,14,7,7,1.6f));
    put("logout",path(10,3).l(5,3).q(3,3,3,5).l(3,19).q(3,21,5,21).l(10,21).points(),p(9,12,22,12),p(17,7,22,12,17,17));
    put("pickaxe",p(5,4,12,3,19,7,22,13),p(4,7,10,6,17,10,19,16),p(14,9,4,22,2,20,12,7));
    put("star",rounded(12,2,15,8.5f,22,9.5f,17,14.5f,18,22,12,18.5f,6,22,7,14.5f,2,9.5f,9,8.5f));
    put("expand",path(8,3).l(5,3).q(3,3,3,5).l(3,8).points(),path(16,3).l(19,3).q(21,3,21,5).l(21,8).points(),path(3,16).l(3,19).q(3,21,5,21).l(8,21).points(),path(21,16).l(21,19).q(21,21,19,21).l(16,21).points());
    put("reset",path(4,9).c(6,1,19,1,21,10).c(24,21,8,26,4,17).points(),p(3,3,3,10,10,10));
    put("leaf",path(5,19).c(0,10,10,4,21,3).c(20,16,14,22,5,19).points(),path(3,22).q(8,13,17,8).points());
    put("cash",box(2,5,20,14,2.5f),ellipse(12,12,3,4),p(5,9,5,15),p(19,9,19,15));
    put("sword",rounded(8,14,18,3,21,3,21,6,11,17),p(5,11,15,21),p(8,17,3,22),p(2,20,4,22));
    put("flower",circle(12,12,2),path(10,8).c(4,1,19,0,14,8).points(),path(16,10).c(23,4,24,19,16,14).points(),path(14,16).c(20,23,5,24,10,16).points(),path(8,14).c(1,20,0,5,8,10).points());
    put("snow",p(12,2,12,22),p(3,7,21,17),p(3,17,21,7),p(8,4,12,8,16,4),p(8,20,12,16,16,20),p(3,11,7,9,7,5),p(17,19,17,15,21,13),p(3,13,7,15,7,19),p(17,5,17,9,21,11));
    put("fire",path(12,2).c(13,8,6,9,7,14).q(3,13,4,10).c(-1,22,22,28,21,14).q(20,9,17,7).q(18,13,15,14).q(18,7,12,2).points(),path(9,21).q(7,17,12,14).q(17,18,14,22).points());
    put("bubbles",circle(7,15,5),circle(17,6,5),circle(19,20,3));
    put("crystal",rounded(12,2,20,8,18,19,12,22,6,19,4,8),p(4,8,20,8),p(8,8,12,22,16,8),p(8,8,12,2,16,8));
    put("moon",path(15,2).c(1,1,-1,20,12,22).q(19,23,22,16).c(10,21,6,8,15,2).points());
    put("lantern",path(9,5).l(9,3).q(12,-1,15,3).l(15,5).points(),box(5,8,14,14,2),rounded(5,8,8,5,16,5,19,8),p(9,12,9,18),p(15,12,15,18));
    put("ghost",path(3,21).l(3,11).c(3,-1,21,-1,21,11).l(21,21).q(19,18,17,21).q(15,23,13,21).q(11,18,9,21).q(7,23,5,21).q(4,20,3,21).points(),circle(8,10,1),circle(16,10,1));
    put("wings",path(12,19).c(7,24,1,19,6,14).c(-1,10,1,1,5,3).q(11,5,12,12).q(13,5,19,3).c(23,1,25,10,18,14).c(23,19,17,24,12,19).points(),p(12,8,12,20));
    put("ring",ellipse(12,12,10,5));
    put("crosshair",circle(12,12,5),p(12,1,12,8),p(12,16,12,23),p(1,12,8,12),p(16,12,23,12));
    put("anchor",circle(12,4,3),p(12,7,12,22),p(5,10,19,10),p(2,14,4,18,12,22,20,18,22,14),p(2,14,2,19),p(22,14,22,19));
    put("eye",path(2,12).q(12,-2,22,12).q(12,26,2,12).points(),circle(12,12,3.5f));
    put("player",circle(12,6,3.5f),path(4,22).l(4,19).q(4,14,9,14).l(15,14).q(20,14,20,19).l(20,22).points());
    put("trail",path(3,7).c(7,1,19,2,20,8).c(21,15,5,9,5,16).q(5,21,12,21).points(),p(2,11,6,11),p(1,15,2,15),circle(18,18,2));
    put("heart",path(12,21).c(-7,9,4,-4,12,6).c(20,-4,31,9,12,21).points());
    put("music",path(8,19).l(8,6).q(8,4,10,4).l(21,2).l(21,17).points(),p(8,9,21,7),ellipse(5,20,3,2),ellipse(18,18,3,2));
    put("rain",path(6,14).c(-1,14,0,5,7,6).c(9,-1,18,1,18,7).c(25,6,25,14,19,14).points(),p(6,17,4,22),p(13,17,11,22),p(20,17,18,22));
    put("motion",p(3,6,17,6,13,2),p(17,6,13,10),p(21,18,7,18,11,14),p(7,18,11,22));
    put("shield",path(12,2).q(17,5,21,5).c(22,15,18,20,12,23).c(6,20,2,15,3,5).q(7,5,12,2).points(),p(7,12,11,16,17,9));
    put("bars",box(2,14,4,8,1),box(10,8,4,14,1),box(18,2,4,20,1));
    put("xp",box(2,17,20,5,2),p(5,19.5f,13,19.5f),path(12,2).q(13,7,17,8).q(13,9,12,13).q(11,9,7,8).q(11,7,12,2).points());
    put("vortex",path(21,8).c(17,-1,1,3,3,14).c(5,25,23,22,20,12).c(18,5,8,6,8,12).q(8,17,14,16).q(18,13,12,11).points());
  }
  private static float[] p(float... values) { return values; }
  private static Path path(float x,float y) { return new Path(x,y); }
  private static float[] box(float x,float y,float w,float h,float r) {
    return path(x+r,y).l(x+w-r,y).q(x+w,y,x+w,y+r).l(x+w,y+h-r)
        .q(x+w,y+h,x+w-r,y+h).l(x+r,y+h).q(x,y+h,x,y+h-r).l(x,y+r).q(x,y,x+r,y).points();
  }
  /** Small corner fillets retain crisp geometric silhouettes without spiky joins. */
  private static float[] rounded(float... points) {
    int n=points.length/2;Path result=null;float startX=0,startY=0;
    for(int i=0;i<n;i++) {
      int prev=(i+n-1)%n,next=(i+1)%n;float x=points[i*2],y=points[i*2+1];
      float inX=x+(points[prev*2]-x)*.12f,inY=y+(points[prev*2+1]-y)*.12f;
      float outX=x+(points[next*2]-x)*.12f,outY=y+(points[next*2+1]-y)*.12f;
      if(result==null){result=path(inX,inY);startX=inX;startY=inY;}else result.l(inX,inY);
      result.q(x,y,outX,outY);
    }
    return result.l(startX,startY).points();
  }
  private static final class Path {
    private final List<Float> points=new ArrayList<>();
    private float x,y;
    Path(float x,float y){l(x,y);}
    Path l(float x,float y){this.x=x;this.y=y;points.add(x);points.add(y);return this;}
    Path q(float cx,float cy,float endX,float endY) {
      float ax=x,ay=y;
      for(int i=1;i<=6;i++){float t=i/6f,u=1-t;l(u*u*ax+2*u*t*cx+t*t*endX,u*u*ay+2*u*t*cy+t*t*endY);}
      return this;
    }
    Path c(float c1x,float c1y,float c2x,float c2y,float endX,float endY) {
      float ax=x,ay=y;
      for(int i=1;i<=10;i++){float t=i/10f,u=1-t;l(u*u*u*ax+3*u*u*t*c1x+3*u*t*t*c2x+t*t*t*endX,u*u*u*ay+3*u*u*t*c1y+3*u*t*t*c2y+t*t*t*endY);}
      return this;
    }
    float[] points(){float[] result=new float[points.size()];for(int i=0;i<result.length;i++)result[i]=points.get(i);return result;}
  }
  private static float[] circle(float x,float y,float r) {return ellipse(x,y,r,r);}
  private static float[] ellipse(float x,float y,float rx,float ry) {
    float[] points=new float[50]; for(int i=0;i<=24;i++){double a=i*Math.PI/12;points[i*2]=x+(float)Math.cos(a)*rx;points[i*2+1]=y+(float)Math.sin(a)*ry;}return points;
  }
  private static void put(String name,float[]... paths) {
    int count=0;for(var p:paths)count+=p.length/2-1;
    float[] strokes=new float[count*9];int at=0;
    for(float[] path:paths)for(int i=2;i<path.length;i+=2){
      float dx=path[i]-path[i-2],dy=path[i+1]-path[i-1],len=(float)Math.sqrt(dx*dx+dy*dy);
      if(len<.01)continue;
      float ux=dx/len,uy=dy/len,ax=path[i-2]-.8f*ux,ay=path[i-1]-.8f*uy,bx=path[i]+.8f*ux,by=path[i+1]+.8f*uy;
      strokes[at++]=ax+.8f*uy;strokes[at++]=ay-.8f*ux;
      strokes[at++]=ax-.8f*uy;strokes[at++]=ay+.8f*ux;
      strokes[at++]=bx-.8f*uy;strokes[at++]=by+.8f*ux;
      strokes[at++]=bx+.8f*uy;strokes[at++]=by-.8f*ux;strokes[at++]=len+1.6f;
    }
    ICONS.put(name,Arrays.copyOf(strokes,at));
  }
  public static String navigation(String tab) {return switch(tab){case "Presets"->"folder";case "Configs"->"config";case "World"->"world";case "Environment FX"->"rain";case "HUD"->"hud";case "Style"->"style";case "Setup"->"tool";case "Autor"->"ghost";default->"spark";};}
  public static String module(String id,String category) {
    String s=id.toLowerCase(Locale.ROOT);
    if(s.equals("playertrails")) return "trail";
    if(s.equals("larp")) return "cash";
    if(s.contains("sword")) return "sword";
    if(s.contains("cherry") || s.contains("bloom") || s.contains("petal")) return "flower";
    if(s.contains("frost") || s.contains("snow")) return "snow";
    if(s.contains("ember") || s.contains("fire")) return "fire";
    if(s.contains("bubble")) return "bubbles";
    if(s.contains("crystal") || s.contains("shard")) return "crystal";
    if(s.contains("lantern")) return "lantern";
    if(s.contains("ghost") || s.contains("soul")) return "ghost";
    if(s.contains("wing") || s.contains("moth") || s.contains("cape") || s.contains("elytra")) return "wings";
    if(s.contains("ring")) return "ring";
    if(s.contains("dust") || s.contains("spark")) return "spark";
    if(s.contains("pillar")) return "bars";
    if(s.contains("vortic")) return "vortex";
    if(s.contains("relic")) return "ring";
    if(s.contains("ley")) return "motion";
    if(s.contains("leaf") || s.contains("leaves")) return "leaf";
    if(s.contains("anchor")) return "anchor";
    if(s.contains("glint")) return "spark";
    if(s.contains("crosshair")) return "crosshair";
    if(s.contains("music") || s.contains("sound") || s.contains("party")) return "music";
    if(s.contains("weather")) return "rain";
    if(s.contains("sky") || s.contains("moon")) return "moon";
    if(s.contains("hit") || s.contains("damage")) return "heart";
    if(s.contains("totem")) return "shield";
    if(s.equals("xp")) return "xp";
    if(s.contains("look") || s.contains("camera")) return "eye";
    if(s.equals("custompickaxes")) return "pickaxe";
    return switch(category){case "Entities"->"eye";case "Player"->"player";case "Motion"->"motion";case "HUD"->"hud";case "Settings"->"settings";case "World"->"world";case "Environment FX"->"rain";default->"spark";};
  }
  /** Scan-converted solid star, independent of font glyph availability. */
  public static void filledStar(DrawContext g,float x,float y,float size,int color){
    float[] points={12,2,15,8.5f,22,9.5f,17,14.5f,18,22,12,18.5f,6,22,7,14.5f,2,9.5f,9,8.5f};
    for(float row=2;row<22;row+=.5f){
      float scan=row+.25f;float[] crossings=new float[10];int count=0;
      for(int i=0,j=9;i<10;j=i++){
        float ax=points[j*2],ay=points[j*2+1],bx=points[i*2],by=points[i*2+1];
        if((ay<=scan&&by>scan)||(by<=scan&&ay>scan))crossings[count++]=ax+(scan-ay)*(bx-ax)/(by-ay);
      }
      Arrays.sort(crossings,0,count);
      for(int i=0;i+1<count;i+=2)Glass.rounded(g,x+crossings[i]*size/24,y+row*size/24,
          (crossings[i+1]-crossings[i])*size/24,.6f*size/24,0,color);
    }
  }

  public static void draw(DrawContext g,String name,float x,float y,float size,int color) {
    pl.xvisuals.rendering.shaders.SdfRenderer.icon(g,x,y,size,ICONS.getOrDefault(name,ICONS.get("spark")),color);
  }
  private StudioIcons() {}
}
