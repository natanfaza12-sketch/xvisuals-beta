package pl.xvisuals.gui.components;

import pl.xvisuals.util.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.*;
import net.minecraft.util.Identifier;

/** Shared material and vector drawing. Coordinates are logical GUI pixels. */
public final class Glass {
  private static final Style FONT =
      Style.EMPTY.withFont(new StyleSpriteSource.Font(Identifier.of("xvisuals", "ui")));

  private static final pl.xvisuals.util.BoundedCache<String, OrderedText> TEXT =
      new pl.xvisuals.util.BoundedCache<>(512);

  public static OrderedText ordered(String s) {
    // Do not retain unusually long imported text in the shared cache.
    String font=pl.xvisuals.gui.FontSelection.selected();
    return s.length() > 256 ? label(s).asOrderedText()
        : TEXT.computeIfAbsent(font+"\u0000"+s, key -> label(s).asOrderedText());
  }

  public static Text label(String s) {
    // Include the actual face in the text identity used by Minecraft's GUI caches.
    // Merely rerouting getGlyphs leaves previously cached labels on the old face.
    return Text.literal(s).setStyle(FONT.withFont(pl.xvisuals.gui.FontSelection.replace(FONT.getFont())));
  }

  public static int textWidth(String s) {
    return MinecraftClient.getInstance().textRenderer.getWidth(ordered(s));
  }

  public static void text(DrawContext g, String s, float x, float y, int color) {
    g.drawText(
        MinecraftClient.getInstance().textRenderer,
        ordered(s),
        Math.round(x),
        Math.round(y),
        color,
        true);
  }

  public static void center(DrawContext g, String s, float x, float y, int color) {
    text(g, s, x - textWidth(s) / 2f, y, color);
  }

  public static void scaled(DrawContext g, String s, float x, float y, float scale, int color) {
    g.getMatrices().pushMatrix();
    g.getMatrices().translate(x, y);
    g.getMatrices().scale(scale, scale);
    text(g, s, 0, 0, color);
    g.getMatrices().popMatrix();
  }

  public static void rounded(
      DrawContext g, float x, float y, float w, float h, float r, int color) {
    pl.xvisuals.rendering.shaders.SdfRenderer.rect(g, x, y, w, h, r, color, 0);
  }

  public static void panel(DrawContext g, float x, float y, float w, float h, double opacity) {
    rounded(g, x - 3, y + 5, w + 6, h + 3, 13, 0x20000000);
    gradient(g, x, y, w, h, 10,
        Colors.alpha(pl.xvisuals.gui.themes.Theme.surface(), Math.max(.96, opacity)),
        Colors.alpha(pl.xvisuals.gui.themes.Theme.surfaceEnd(), Math.max(.96, opacity)), "Vertical");
  }

  public static void gradient(DrawContext g, float x, float y, float w, float h,
      float radius, int start, int end, String direction) {
    int mid = Colors.alpha(Colors.mix(start, end, .5), ((start >>> 24) + (end >>> 24)) / 510.0);
    boolean vertical = "Vertical".equals(direction), diagonal = "Diagonal".equals(direction);
    pl.xvisuals.rendering.shaders.SdfRenderer.gradient(g, x, y, w, h, radius,
        start, vertical ? start : diagonal ? mid : end,
        vertical ? end : diagonal ? mid : start, end, 1);
  }

  public static void line(
      DrawContext g, double x1, double y1, double x2, double y2, double width, int color) {
    double dx = x2 - x1, dy = y2 - y1, len = Math.sqrt(dx * dx + dy * dy);
    if (len < .1 || len > 16000) return;
    g.getMatrices().pushMatrix();
    g.getMatrices().translate((float) x1, (float) y1);
    g.getMatrices().rotate((float) Math.atan2(dy, dx));
    g.fill(
        0,
        (int) -Math.max(.5, width / 2),
        (int) Math.ceil(len),
        (int) Math.max(1, width / 2),
        color);
    g.getMatrices().popMatrix();
  }

  public static void glowLine(
      DrawContext g,
      double x1,
      double y1,
      double x2,
      double y2,
      double width,
      int color,
      double glow) {
    if (glow > 0) {
      line(g, x1, y1, x2, y2, width + 5, Colors.alpha(color, glow * .07));
      line(g, x1, y1, x2, y2, width + 2, Colors.alpha(color, glow * .15));
    }
    line(g, x1, y1, x2, y2, width, color);
  }

  public static void dot(DrawContext g, double x, double y, double size, int color, double glow) {
    if (glow > 0) {
      rounded(
          g,
          (float) (x - size * 2.5),
          (float) (y - size * 2.5),
          (float) (size * 5),
          (float) (size * 5),
          (float) (size * 2.5),
          Colors.alpha(color, glow * .045));
      rounded(
          g,
          (float) (x - size * 1.6),
          (float) (y - size * 1.6),
          (float) (size * 3.2),
          (float) (size * 3.2),
          (float) (size * 1.6),
          Colors.alpha(color, glow * .13));
    }
    rounded(
        g,
        (float) (x - size * .5),
        (float) (y - size * .5),
        (float) size,
        (float) size,
        (float) (size * .5),
        color);
  }

  public static void logo(DrawContext g, float cx, float cy, float s, int color) {
    float sc = s * 1.7f / 9f;
    float x = cx - 3f * sc, y = cy - 4.5f * sc;
    StudioChrome.scaled(g, "X", x - .6f, y, sc, color);
    StudioChrome.scaled(g, "X", x + .6f, y, sc, color);
    StudioChrome.scaled(g, "X", x, y, sc, color);
  }

  public static boolean contains(double mx, double my, double x, double y, double w, double h) {
    return mx >= x && my >= y && mx < x + w && my < y + h;
  }

  private Glass() {}
}
