package pl.xvisuals.gui.components;

/** One window size for every tab, chosen in physical pixels rather than Minecraft GUI coordinates. */
public record StudioLayout(int width,int height,int columns,int catalogWidth,float scale) {
  public static StudioLayout forWindow(int pixelWidth,int pixelHeight,int guiWidth,int guiHeight,double zoom) {
    boolean wide=pixelWidth>=1100 && pixelHeight>=650;
    int w=wide?1100:720, h=wide?640:480;
    double preferred=Math.clamp(pixelWidth/1100d,1.1,1.6)*Math.clamp(zoom,.65,1.5);
    double physicalScale=Math.min(preferred,Math.min(Math.max(1,pixelWidth-40d)/w,Math.max(1,pixelHeight-40d)/h));
    double pixelRatio=Math.max((double)pixelWidth/Math.max(1,guiWidth),(double)pixelHeight/Math.max(1,guiHeight));
    return new StudioLayout(w,h,wide?2:1,wide?580:300,(float)(physicalScale/pixelRatio));
  }
  public int inspectorX(){return catalogWidth+10;}
  public int inspectorWidth(){return width-inspectorX()-18;}
  public int cardWidth(){return columns==2?266:catalogWidth-38;}
  public int searchX(){return columns==2?305:19;}
  public int searchY(){return columns==2?110:142;}
  public int searchWidth(){return columns==2?257:catalogWidth-38;}
  public int listTop(){return columns==2?145:178;}
  public int pageSize(){return Math.max(1,(height-60-listTop())/40)*columns;}
}
