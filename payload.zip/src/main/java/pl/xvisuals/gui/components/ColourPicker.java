package pl.xvisuals.gui.components;

import java.awt.Color;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import pl.xvisuals.gui.themes.Theme;

/** Shared hue/saturation wheel with a separate brightness control. No text entry required. */
public final class ColourPicker {
  private static final Identifier WHEEL = Identifier.of("xvisuals", "dynamic/colour_wheel");
  private static boolean registered;
  private float hue, saturation, brightness;
  private final int original;
  private int dragging;
  public ColourPicker(String hex) {
    original = 0xff000000 | Integer.parseInt(hex.substring(1), 16);
    float[] hsv = Color.RGBtoHSB((original >> 16)&255, (original >> 8)&255, original&255, null);
    hue=hsv[0]; saturation=hsv[1]; brightness=hsv[2];
  }
  public String hex() { return String.format("#%06X", Color.HSBtoRGB(hue,saturation,brightness)&0xffffff); }
  public void press(double x, double y) {
    if (Math.hypot(x-231,y-212)<=80) dragging=1;
    else if (x>=341 && x<=471 && y>=235 && y<=260) dragging=2;
    drag(x,y);
  }
  public void drag(double x, double y) {
    if (dragging==1) {
      hue=(float)((Math.atan2(y-212,x-231)/(2*Math.PI)+1)%1);
      saturation=(float)Math.clamp(Math.hypot(x-231,y-212)/80,0,1);
    } else if (dragging==2) brightness=(float)Math.clamp((x-341)/130,0,1);
  }
  public void release() { dragging=0; }
  public void draw(DrawContext g,String title) {
    if (!registered) {
      var pixels=new NativeImage(192,192,false);
      for(int y=0;y<192;y++) for(int x=0;x<192;x++) {
        double dx=x+.5-96,dy=y+.5-96,r=Math.hypot(dx,dy);
        int alpha=(int)(255*Math.clamp(96-r,0,1));
        int rgb=Color.HSBtoRGB((float)((Math.atan2(dy,dx)/(2*Math.PI)+1)%1),(float)Math.min(1,r/95),1);
        pixels.setColorArgb(x,y,(alpha<<24)|(rgb&0xffffff));
      }
      MinecraftClient.getInstance().getTextureManager().registerTexture(WHEEL,new NativeImageBackedTexture(()->"Colour wheel",pixels));
      registered=true;
    }
    g.fill(0,0,620,410,0xA0060A10);
    Glass.rounded(g,118,83,384,267,12,0xff171b24);
    Glass.text(g,title,138,101,Theme.text());
    g.drawTexture(RenderPipelines.GUI_TEXTURED,WHEEL,151,132,0,0,160,160,160,160);
    float sx=231+(float)Math.cos(hue*Math.PI*2)*saturation*80;
    float sy=212+(float)Math.sin(hue*Math.PI*2)*saturation*80;
    Glass.rounded(g,sx-5,sy-5,10,10,5,0xff101319);
    Glass.rounded(g,sx-3,sy-3,6,6,3,0xffffffff);
    Glass.scaled(g,"Original",341,140,.8f,Theme.quiet());
    Glass.scaled(g,"New",416,140,.8f,Theme.quiet());
    Glass.rounded(g,341,157,56,45,6,original);
    Glass.rounded(g,415,157,56,45,6,Color.HSBtoRGB(hue,saturation,brightness));
    Glass.scaled(g,"Brightness",341,220,.85f,Theme.muted());
    Glass.gradient(g,341,242,130,9,4,0xff000000,Color.HSBtoRGB(hue,saturation,1),"Horizontal");
    Glass.rounded(g,338+brightness*130,239,6,15,3,0xffffffff);
    Glass.scaled(g,"Drag to choose a colour",145,310,.7f,Theme.quiet());
    Glass.rounded(g,245,307,110,26,5,0xff252b36);
    Glass.center(g,"Cancel",300,316,Theme.muted());
    Glass.rounded(g,365,307,110,26,5,0xff364158);
    Glass.center(g,"Apply",420,316,Theme.text());
  }
}
