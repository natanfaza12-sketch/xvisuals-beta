package pl.xvisuals.gui;
import java.util.*;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.util.Identifier;
import pl.xvisuals.XVisuals;
/** Central font routing keeps measurement and rendering on the same face. */
public final class FontSelection {
 public static final List<String> NAMES=List.of("Classic","Rajdhani","Chakra Petch","Audiowide","Russo One","Quantico","Play","Electrolize","Share Tech Mono","Black Ops One","Titan One");
 private static final Map<String,StyleSpriteSource.Font> FONTS=new HashMap<>();
 static {for(String name:NAMES)if(!name.equals("Classic"))FONTS.put(name,new StyleSpriteSource.Font(Identifier.of("xvisuals","choices/"+name.toLowerCase(Locale.ROOT).replace(" ",""))));}
 public static StyleSpriteSource.Font preview(String name){
  return FONTS.getOrDefault(name,new StyleSpriteSource.Font(Identifier.of("xvisuals","classic_preview")));
 }
 public static String selected(){
  if(!XVisuals.ready())return "Classic";
  var m=XVisuals.config().module("fontchanger");
  return m!=null&&m.enabled&&NAMES.contains(m.text("font"))?m.text("font"):"Classic";
 }
 public static StyleSpriteSource replace(StyleSpriteSource original){return replace(original,selected());}
 public static StyleSpriteSource replace(StyleSpriteSource original,String name){
  if(!(original instanceof StyleSpriteSource.Font font))return original;
  // Resource-pack symbol fonts, player heads and large title fonts retain their own metrics.
  if(!font.id().equals(Identifier.ofVanilla("default"))&&!font.id().equals(Identifier.of("xvisuals","ui")))return original;
  return FONTS.getOrDefault(name,font);
 }
 private FontSelection(){}
}
