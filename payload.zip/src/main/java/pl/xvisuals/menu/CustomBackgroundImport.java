package pl.xvisuals.menu;

import java.io.IOException;
import java.nio.file.*;
import javax.imageio.ImageIO;

/** Copies a validated still image into client-owned storage. Never depends on the original afterwards. */
public final class CustomBackgroundImport {
  public static Path importImage(Path source, Path directory) throws IOException {
    return importImage(source,directory,16_777_216L,32L*1024*1024);
  }
  public static Path importImage(Path source,Path directory,long maxPixels,long maxBytes) throws IOException {
    if (!Files.isRegularFile(source) || Files.size(source) > maxBytes)
      throw new IOException("Choose an image smaller than "+(maxBytes/1024/1024)+" MB");
    try (var input = ImageIO.createImageInputStream(source.toFile())) {
      if (input == null) throw new IOException("Could not open image");
      var readers = ImageIO.getImageReaders(input);
      if (!readers.hasNext()) throw new IOException("Choose a PNG or JPEG image");
      var reader = readers.next();
      try {
        String format = reader.getFormatName();
        if (!format.equalsIgnoreCase("png") && !format.equalsIgnoreCase("jpeg"))
          throw new IOException("Choose a PNG or JPEG image");
        reader.setInput(input, true, true);
        int w=reader.getWidth(0), h=reader.getHeight(0);
        if(w<1 || h<1 || w>8192 || h>8192 || (long)w*h>maxPixels)
          throw new IOException("Image must be at most 8192 pixels per side and "+(maxPixels/1_048_576)+" megapixels");
        var image=reader.read(0);
        Files.createDirectories(directory);
        Path target=Files.createTempFile(directory, "background-", ".png");
        try {
          if(!ImageIO.write(image,"png",target.toFile())) throw new IOException("Could not save image");
          if(Files.size(target)>maxBytes) throw new IOException("Converted image exceeds "+(maxBytes/1024/1024)+" MB");
          return target.toAbsolutePath();
        } catch(IOException e) { Files.deleteIfExists(target); throw e; }
        finally { image.flush(); }
      } finally { reader.dispose(); }
    }
  }
  private CustomBackgroundImport() {}
}
