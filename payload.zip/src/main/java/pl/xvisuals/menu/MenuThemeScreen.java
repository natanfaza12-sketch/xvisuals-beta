package pl.xvisuals.menu;

import pl.xvisuals.XVisuals;
import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.gui.components.StudioChrome;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class MenuThemeScreen extends Screen {
  private static final String[] NAMES=MenuThemes.names();
  private final Screen parent;
  private int preview;
  private final AtmosphereMotion motion;
  private long lastFrame=System.nanoTime(),opened=lastFrame;
  private boolean importing,dragPending,dragging;
  private double dragStartX,dragOrigin;
  private String importStatus="PNG / JPEG  ·  Drag an image here to import";
  public MenuThemeScreen(Screen parent){super(Text.literal("Choose your atmosphere"));this.parent=parent;preview=selected();motion=new AtmosphereMotion(preview);if(!MenuThemes.customPath().isBlank())importStatus="Custom image active · Choose an atmosphere to replace it";}
  public static int selected(){return MenuThemes.selected();}
  public static void drawTheme(DrawContext g,int theme,int x,int y,int w,int h){
    drawTheme(g,theme,x,y,w,h,1);
  }
  private static void drawTheme(DrawContext g,int theme,int x,int y,int w,int h,double alpha){
    var entry=MenuThemes.get(theme);
    Identifier id=entry.texture();
    float cover=Math.max((float)w/entry.width(),(float)h/entry.height());int dw=Math.round(entry.width()*cover),dh=Math.round(entry.height()*cover);
    g.enableScissor(x,y,x+w,y+h);
    g.drawTexture(RenderPipelines.GUI_TEXTURED,id,x+(w-dw)/2,y+(h-dh)/2,0,0,dw,dh,dw,dh,((int)(255*alpha)<<24)|0xFFFFFF);
    g.disableScissor();
  }
  private void step(int direction){if(NAMES.length<2)return;dragPending=dragging=false;motion.step(direction);preview=Math.floorMod(motion.target(),NAMES.length);}
  @Override public void renderBackground(DrawContext g,int mx,int my,float dt){}
  private int cardWidth(){return Math.max(42,(int)Math.min(width*.34,height*.65));}
  private double spacing(){return cardWidth()*1.16;}
  private int cardY(){return (int)(height*.44);}
  @Override protected void init(){
    dragPending=dragging=false;
    for(int i=0;i<NAMES.length;i++)addDrawableChild(new Card(i));
    int button=Math.max(42,Math.min(94,width/5)),bh=Math.max(16,Math.min(24,height/12)),bottom=(int)(height*.84);
    if(NAMES.length>1){
      addDrawableChild(new ArrowButton((int)(width/2.0-cardWidth()*.64)-14,cardY()-16,-1));
      addDrawableChild(new ArrowButton((int)(width/2.0+cardWidth()*.64)-14,cardY()-16,1));
    }
    addDrawableChild(new ActionButton(width/2-button*3/2-8,bottom,button,bh,"Back",false,this::close));
    addDrawableChild(new ActionButton(width/2-button/2,bottom,button,bh,"Apply",true,()->{
      XVisuals.config().module("menu").values.put("homeTheme",NAMES[preview]);
      XVisuals.config().module("menu").values.put("background", "");
      if(XVisuals.STORE.save())close();else importStatus="Applied for this session · Settings could not be saved";
    }));
    addDrawableChild(new ActionButton(width/2+button/2+8,bottom,button,bh,"Import image",false,this::chooseImage));
  }
  @Override public void render(DrawContext g,int mx,int my,float dt){
    long now=System.nanoTime();double elapsed=Math.clamp((now-lastFrame)/1e9,0,.1);lastFrame=now;if(!dragPending)motion.update(elapsed);
    // Blend only the two neighbours of the carousel, with no pointer pan or accumulating fades.
    double position=motion.position();int base=(int)Math.floor(position);double blend=position-base;
    drawTheme(g,Math.floorMod(base,NAMES.length),0,0,width,height);
    if(blend>.001)drawTheme(g,Math.floorMod(base+1,NAMES.length),0,0,width,height,blend);
    g.fill(0,0,width,height,0x8810151C);
    g.fillGradient(0,0,width,height/2,0xA0070A11,0x00070A11);g.fillGradient(0,height/2,width,height,0x00070A11,0xED070A11);
    float entrance=(float)(1-Math.exp(-(now-opened)/1e9*6));
    centerSmall(g,"YOUR SPACE, YOUR ATMOSPHERE",width/2f,height*.105f+(1-entrance)*5,.48f,0xFFABB5C5);
    centerSmall(g,"Find your atmosphere",width/2f,height*.16f+(1-entrance)*5,.95f,0xFFF5F7FB);
    centerSmall(g,"Drag to explore  /  Arrows or scroll",width/2f,height*.225f,.52f,0xFFB3BDCC);
    // Cards are positioned before rendering so pointer hitboxes always follow the actual artwork.
    for(var child:children())if(child instanceof Card card)card.place();
    super.render(g,mx,my,dt);
    float labelY=height*.69f;
    centerSmall(g,NAMES[preview],width/2f,labelY,.8f,0xFFF5F7FB);
    String detail=String.format(java.util.Locale.ROOT,"%02d / %02d",preview+1,NAMES.length);
    if(MenuThemes.customPath().isBlank()&&preview==selected())detail+="   ·   CURRENT";
    centerSmall(g,detail,width/2f,labelY+15,.48f,0xFFAEB9CA);
    float dotSpacing=Math.min(7,(width-32f)/NAMES.length),start=width/2f-(NAMES.length-1)*dotSpacing/2;
    for(int i=0;i<NAMES.length;i++)Glass.rounded(g,start+i*dotSpacing-(i==preview?3:1),height*.79f,i==preview?6:2,2,1,i==preview?0xFFE9EFF9:0x507F8DA4);
    centerSmall(g,importStatus,width/2f,height*.95f,Math.min(.43f,(width-24f)/Math.max(1,Glass.textWidth(importStatus))),0xFF8E9CAE);
  }
  private void chooseImage() {
    if(importing) return;
    try(var stack=org.lwjgl.system.MemoryStack.stackPush()) {
      var filters=stack.mallocPointer(3);
      filters.put(stack.UTF8("*.png")).put(stack.UTF8("*.jpg")).put(stack.UTF8("*.jpeg")).flip();
      String file=org.lwjgl.util.tinyfd.TinyFileDialogs.tinyfd_openFileDialog("Choose menu and loading image",null,filters,"PNG / JPEG images",false);
      if(file!=null) importImage(java.nio.file.Path.of(file));
    } catch(Exception e) { importStatus="Could not open picker. Drag an image here instead."; }
  }
  @Override public void onFilesDropped(java.util.List<java.nio.file.Path> files) {
    if(files.size()==1) importImage(files.getFirst());
    else importStatus="Please choose one image at a time";
  }
  private void importImage(java.nio.file.Path file) {
    if(importing) return;
    importing=true; importStatus="Importing image...";
    var game=client;
    java.util.concurrent.CompletableFuture.runAsync(()->{
      try {
        var directory=net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("xvisuals/backgrounds");
        var imported=CustomBackgroundImport.importImage(file,directory);
        game.execute(()->{
          if(game.currentScreen!=this) { importing=false; return; }
          XVisuals.config().module("menu").values.put("background",imported.toString());
          boolean saved=XVisuals.STORE.save();
          importing=false;
          importStatus=saved?"Custom image applied to menus and loading screens":"Applied for this session; settings could not be saved";
          if(saved && game.currentScreen==this) close();
        });
      } catch(Exception e) {
        game.execute(()->{importing=false;importStatus="Image not imported: "+e.getMessage();});
      }
    });
  }
  @Override public boolean mouseClicked(Click click,boolean doubled){
    // Navigation stays above the artwork for both drawing and hit testing.
    for(var child:children())if(child instanceof ArrowButton arrow&&arrow.isMouseOver(click.x(),click.y()))return arrow.mouseClicked(click,doubled);
    if(click.button()==0&&click.y()>cardY()-cardWidth()*9/32.0-6&&click.y()<cardY()+cardWidth()*9/32.0+14){dragPending=true;dragging=false;dragStartX=click.x();dragOrigin=motion.position();return true;}
    return super.mouseClicked(click,doubled);
  }
  @Override public boolean mouseDragged(Click click,double dx,double dy){
    if(dragPending&&click.button()==0){
      if(Math.abs(click.x()-dragStartX)>3)dragging=true;
      if(dragging){motion.dragTo(dragOrigin-(click.x()-dragStartX)/spacing());preview=Math.floorMod(motion.target(),NAMES.length);}return true;
    }
    return super.mouseDragged(click,dx,dy);
  }
  @Override public boolean mouseReleased(Click click){
    if(dragPending&&click.button()==0){
      if(dragging)motion.dragTo(dragOrigin-(click.x()-dragStartX)/spacing());
      else {int chosen=(int)Math.round(motion.position()+(click.x()-width/2.0)/spacing());motion.step(chosen-motion.target());}
      dragPending=dragging=false;preview=Math.floorMod(motion.target(),NAMES.length);return true;
    }
    return super.mouseReleased(click);
  }
  @Override public boolean mouseScrolled(double x,double y,double hx,double dy){if(dragPending)return true;double scroll=dy!=0?dy:hx;if(scroll!=0)step(scroll>0?-1:1);return true;}
  @Override public boolean keyPressed(KeyInput key){if(key.key()==263){step(-1);return true;}if(key.key()==262){step(1);return true;}return super.keyPressed(key);}
  @Override public void close(){client.setScreen(parent);}
  private static void centerSmall(DrawContext g,String text,float x,float y,float scale,int color){
    MenuText.center(g,text,x,y,scale,color);
  }
  static final class GlassButton extends ClickableWidget {
    private final Runnable action;
    private double hover;
    private long last=System.nanoTime();
    GlassButton(int x,int y,int w,int h,String label,Runnable action){super(x,y,w,h,Text.literal(label));this.action=action;}
    @Override protected void renderWidget(DrawContext g,int mx,int my,float dt){
      long now=System.nanoTime();double elapsed=Math.min(.1,(now-last)/1e9);last=now;
      hover+=((isHovered()||isFocused()?1:0)-hover)*(1-Math.exp(-elapsed*7));
      float x=getX(),y=getY();
      LiquidGlass.pill(g,x,y,width,height,hover);
      if(getMessage().getString().equals("Button settings"))
        pl.xvisuals.gui.components.StudioIcons.draw(g,"settings",x+4,y+4,13,0xFFF0F3F8);
      else MenuText.button(g,getMessage().getString(),x,y,width,height);
    }
    @Override public void onClick(Click click,boolean doubled){action.run();}
    @Override public boolean keyPressed(KeyInput key){if(key.key()==257||key.key()==32){action.run();return true;}return super.keyPressed(key);}
    @Override protected void appendClickableNarrations(NarrationMessageBuilder b){appendDefaultNarrations(b);}
  }
  private static final class ActionButton extends ClickableWidget {
    private final Runnable action;private final boolean primary;private double hover;private long last=System.nanoTime();
    ActionButton(int x,int y,int w,int h,String label,boolean primary,Runnable action){super(x,y,w,h,Text.literal(label));this.primary=primary;this.action=action;}
    @Override protected void renderWidget(DrawContext g,int mx,int my,float dt){
      long now=System.nanoTime();double elapsed=Math.min(.1,(now-last)/1e9);last=now;hover+=((isHovered()||isFocused()?1:0)-hover)*(1-Math.exp(-elapsed*12));
      float x=getX(),y=getY()-(float)hover;
      if(primary){Glass.rounded(g,x,y+2,width,height,6,0x38000000);Glass.rounded(g,x,y,width,height,6,hover>.5?0xFFF8FAFD:0xFFE0E6EF);}
      else if(hover>.01)Glass.rounded(g,x,y,width,height,6,((int)(hover*38)<<24)|0xDAE3F1);
      int color=primary?0xFF172130:0xFFE0E6F0;
      float scale=Math.min(.62f,(width-25f)/Math.max(1,Glass.textWidth(getMessage().getString())));
      centerSmall(g,getMessage().getString(),x+width/2f+4,y+(height-6)/2f,scale,color);
      float cx=x+11,cy=y+height/2f;
      if(primary){Glass.line(g,cx-3,cy,cx-1,cy+2,1.1,color);Glass.line(g,cx-1,cy+2,cx+3,cy-3,1.1,color);}
      else if(getMessage().getString().equals("Back")){Glass.line(g,cx+2,cy-3,cx-1,cy,1,color);Glass.line(g,cx-1,cy,cx+2,cy+3,1,color);}
      else {Glass.line(g,cx-3,cy,cx+3,cy,1,color);Glass.line(g,cx,cy-3,cx,cy+3,1,color);}
    }
    @Override public void onClick(Click click,boolean doubled){action.run();}
    @Override public boolean keyPressed(KeyInput key){if(key.key()==257||key.key()==32){action.run();return true;}return super.keyPressed(key);}
    @Override protected void appendClickableNarrations(NarrationMessageBuilder b){appendDefaultNarrations(b);}
  }
  private final class ArrowButton extends ClickableWidget {
    private final int direction;private double hover;private long last=System.nanoTime(),pressed;
    ArrowButton(int x,int y,int direction){super(x,y,28,32,Text.literal(direction<0?"Previous atmosphere":"Next atmosphere"));this.direction=direction;}
    @Override protected void renderWidget(DrawContext g,int mx,int my,float dt){
      long now=System.nanoTime();double elapsed=Math.min(.1,(now-last)/1e9);last=now;hover+=((isHovered()||isFocused()?1:0)-hover)*(1-Math.exp(-elapsed*14));
      float pulse=(float)Math.max(0,1-(now-pressed)/180_000_000.0),inset=pulse*1.5f;
      Glass.rounded(g,getX()+4+inset,getY()+2+inset,20-inset*2,28-inset*2,7,((int)(155+hover*65)<<24)|0x0D1522);
      float cx=getX()+14+(float)hover*direction,cy=getY()+16;
      g.getMatrices().pushMatrix();g.getMatrices().translate(cx,cy);
      Glass.line(g,-2*direction,-4,2*direction,0,1.1f,0xFFF2F6FC);Glass.line(g,2*direction,0,-2*direction,4,1.1f,0xFFF2F6FC);
      g.getMatrices().popMatrix();
    }
    private void activate(){pressed=System.nanoTime();step(direction);}
    @Override public void onClick(Click click,boolean doubled){activate();}
    @Override public boolean keyPressed(KeyInput key){if(key.key()==257||key.key()==32){activate();return true;}return super.keyPressed(key);}
    @Override protected void appendClickableNarrations(NarrationMessageBuilder b){appendDefaultNarrations(b);}
  }
  private final class Card extends ClickableWidget {
    private final int theme;
    private double offset,focus,drawX,drawY;
    Card(int theme){super(0,0,1,1,Text.literal(NAMES[theme]));this.theme=theme;}
    private void place(){
      offset=theme-motion.position();offset-=Math.floor((offset+NAMES.length/2.0)/NAMES.length)*NAMES.length;
      visible=Math.abs(offset)<2.15;active=visible;
      focus=Math.max(0,1-Math.abs(offset));double scale=.78+.22*focus;
      width=(int)(cardWidth()*scale);height=(int)(width*9/16.0);
      drawX=MenuThemeScreen.this.width/2.0+offset*spacing()-width/2.0;setX((int)Math.floor(drawX));
      drawY=cardY()-height/2.0+(1-focus)*7;setY((int)Math.floor(drawY));
    }
    @Override protected void renderWidget(DrawContext g,int mx,int my,float dt){
      int x=getX(),y=getY();
      g.getMatrices().pushMatrix();g.getMatrices().translate((float)(drawX-x),(float)(drawY-y));
      Glass.rounded(g,x-3,y+4,width+6,height+6,4,0x65000000);
      drawTheme(g,theme,x,y,width,height);
      int shade=(int)(105*(1-focus));if(shade>0)g.fill(x,y,x+width,y+height,(shade<<24)|0x080C14);
      g.fillGradient(x,y+height*2/3,x+width,y+height,0,0x55070A11);
      if(isHovered()||isFocused())g.fill(x,y,x+width,y+1,0xB0E5ECFA);
      if(focus>.7)g.fill(x+width/3,y+height+5,x+width*2/3,y+height+6,((int)(200*focus)<<24)|0xCCD8EA);
      g.getMatrices().popMatrix();
    }
    private void choose(){int delta=(int)Math.round(offset);if(delta!=0)step(delta);}
    @Override public void onClick(Click click,boolean doubled){choose();}
    @Override public boolean keyPressed(KeyInput key){if(key.key()==257||key.key()==32){choose();return true;}return super.keyPressed(key);}
    @Override protected void appendClickableNarrations(NarrationMessageBuilder b){appendDefaultNarrations(b);}
  }
}
