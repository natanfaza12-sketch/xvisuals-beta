package pl.xvisuals.menu;

import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.gui.components.Spring;
import pl.xvisuals.util.Colors;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.input.KeyInput;

/** Text navigation with full-sized hit targets and visible keyboard focus. */
public final class MenuAction extends ClickableWidget {
  private final Runnable action;
  private final Spring hover = new Spring(0);
  private final boolean primary;

  public MenuAction(int x, int y, int width, int height, String label, boolean primary, Runnable action) {
    super(x, y, width, height, Glass.label(label));
    this.primary = primary;
    this.action = action;
  }

  @Override protected void renderWidget(DrawContext g, int mx, int my, float dt) {
    float amount = hover.to(active && (isHovered() || isFocused()) ? 1 : 0);
    float scale = 1f;
    float x = getX() + (primary ? amount * 4 : 0);
    int color = Colors.alpha(Colors.mix(primary ? 0xFFCAD2D8 : 0xFF9EAAB4, 0xFFFFFFFF, amount), alpha * (active ? 1 : .4));
    pl.xvisuals.gui.components.StudioChrome.text(g, getMessage().getString(), Math.round(x), Math.round(getY() + (height - 9) / 2f), color);
    if (amount > .01) {
      if (primary) Glass.text(g, ">", getX() + width - 12, getY() + (height - 9) / 2f,
          Colors.alpha(0xE5EEF4, alpha * amount));
      else Glass.rounded(g, getX(), getY() + height - 2,
          Math.min(width, Glass.textWidth(getMessage().getString()) * scale), 1, 0,
          Colors.alpha(0xE5EEF4, alpha * amount * .8));
    }
  }

  @Override public void onClick(Click click, boolean doubled) { action.run(); }
  @Override public boolean keyPressed(KeyInput input) {
    if (active && isFocused() && (input.key() == 257 || input.key() == 335 || input.key() == 32)) {
      playDownSound(net.minecraft.client.MinecraftClient.getInstance().getSoundManager());
      action.run();
      return true;
    }
    return super.keyPressed(input);
  }
  @Override protected void appendClickableNarrations(NarrationMessageBuilder builder) { appendDefaultNarrations(builder); }
}
