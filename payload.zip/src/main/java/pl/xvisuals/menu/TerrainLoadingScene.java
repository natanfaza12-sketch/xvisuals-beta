package pl.xvisuals.menu;
import net.minecraft.client.gui.DrawContext;
/** Alpine artwork shared by launch, world entry and saving. */
public final class TerrainLoadingScene {
  private final pl.xvisuals.rendering.AmbientClock clock=new pl.xvisuals.rendering.AmbientClock();
  public void render(DrawContext g,int width,int height,boolean known,float progress){renderAt(g,width,height,known,progress,clock.advance(System.nanoTime(),false));}
  public void renderAt(DrawContext g,int width,int height,boolean known,float progress,double time){LaunchArtwork.world(g,progress,time,known,false);}
  public void renderSaving(DrawContext g,int width,int height){LaunchArtwork.world(g,0,clock.advance(System.nanoTime(),false),false,true);}
}
