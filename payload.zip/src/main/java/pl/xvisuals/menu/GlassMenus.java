package pl.xvisuals.menu;

import pl.xvisuals.XVisuals;
import pl.xvisuals.gui.components.Glass;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.util.Identifier;

/** Borderless menu treatments. Minecraft still owns input, narration and layout. */
public final class GlassMenus {
  private static final java.util.regex.Pattern SURFACE_SPRITES = java.util.regex.Pattern.compile(
      "widget/(button|text_field|slider|slider_handle|tab|scroller|scroller_background)(_(highlighted|disabled|selected|selected_highlighted))?");

  public static boolean enabled() {
    return XVisuals.ready() && XVisuals.config().on("menu")
        && XVisuals.config().module("menu").flag("glassPages");
  }

  public static boolean themed(Screen screen) {
    // Restore the whole vanilla container treatment together: background, tabs,
    // slots, highlights, labels and tooltips, without changing other menu screens.
    if (screen instanceof net.minecraft.client.gui.screen.ingame.HandledScreen<?>
        && (!XVisuals.ready() || !XVisuals.config().module("menu").flag("inventoryTextures"))) return false;
    return enabled() && screen != null && (screen instanceof CelestialServerScreen || screen.getClass().getName().startsWith("net.minecraft."));
  }

  public static boolean active() {
    return themed(MinecraftClient.getInstance().currentScreen);
  }

  /** Quiet interaction feedback, with no perimeter, bevel, shadow or animated shine. */
  public static void surface(DrawContext g, float x, float y, float w, float h, boolean lit, float alpha) {
    if (lit) Glass.rounded(g, x, y, w, h, 2, color(0xD8E2E8, .10f * alpha));
  }

  public static void scene(DrawContext g, int width, int height) {
    MenuBackdrop.draw(g, width, height);
    g.fillGradient(0, 0, width, height, 0x20080C10, 0x88080C10);
  }

  public static void background(DrawContext g, Screen screen) {
    var client = MinecraftClient.getInstance();
    if (client.world == null) scene(g, screen.width, screen.height);
    if (XVisuals.config().blur && client.options.getMenuBackgroundBlurrinessValue() > 0)
      g.applyBlur();
    // A full-bleed scrim supplies contrast without a floating window or nested cards.
    g.fillGradient(0, 0, screen.width, screen.height, 0x77090D11, 0xB3090D11);
  }

  public static boolean sprite(DrawContext g, Identifier id, int x, int y, int w, int h, int tint) {
    if (!active() || !id.getNamespace().equals("minecraft")) return false;
    String path = id.getPath();
    if (path.startsWith("container/") && (path.endsWith("/scroller") || path.endsWith("/scroller_disabled"))) {
      Glass.rounded(g, x + w / 2f - 1.5f, y + 1, 3, h - 2, 1.5f,
          path.endsWith("disabled") ? 0x405D516E : 0xAA9681B5);
      return true;
    }
    if (path.equals("container/slot") || path.startsWith("container/creative_inventory/tab_")
        || path.startsWith("container/inventory/effect_background")) {
      Glass.rounded(g, x, y, w, h, 3, path.contains("unselected") ? 0xAA10121D : 0xBF242033);
      return true;
    }
    if (path.equals("container/slot_highlight_front")) return true;
    if (path.equals("container/slot_highlight_back")) {
      Glass.rounded(g, x + 1, y + 1, w - 2, h - 2, 2, 0x267F68B4);
      return true;
    }
    boolean selected = path.contains("highlighted") || path.contains("selected") || path.endsWith("selection");
    float alpha = (tint >>> 24) / 255f;
    if (path.equals("tooltip/frame")) return true;
    if (path.equals("tooltip/background")) {
      Glass.rounded(g, x, y, w, h, 2, color(0x080D12, .92f * alpha));
      return true;
    }
    if (path.contains("disabled")) alpha *= .35f;
    if (SURFACE_SPRITES.matcher(path).matches()
        || path.equals("gamemode_switcher/slot") || path.equals("gamemode_switcher/selection")) {
      if (path.contains("text_field")) {
        // The baseline indicates editability without boxing the text in.
        Glass.rounded(g, x, y, w, h, 0, color(0x04080C, .20f * alpha));
        Glass.rounded(g, x, y + h - 1, w, 1, 0, color(0xDBE5ED, (selected ? .85f : .28f) * alpha));
      } else if (path.contains("slider_handle")) {
        Glass.rounded(g, x + w / 2f - 2, y + h - 5, 4, 4, 2, color(0xEDF2F4, alpha));
      } else if (path.startsWith("widget/slider")) {
        Glass.rounded(g, x + 4, y + h - 3, w - 8, 1, 0, color(0xCFDCE5, .28f * alpha));
      } else if (path.contains("scroller_background")) {
        // The scrollbar thumb alone communicates the scroll position.
      } else if (path.contains("scroller")) {
        Glass.rounded(g, x + w / 2f - 1, y, 2, h, 1, color(0xCDD8E1, .5f * alpha));
      } else {
        surface(g, x, y, w, h, selected, alpha);
        if (selected && (path.contains("tab") || path.startsWith("gamemode_switcher/")))
          Glass.rounded(g, x + w * .35f, y + h - 1, w * .3f, 1, 0, color(0xE4EDF2, alpha));
      }
      return true;
    }
    if (path.startsWith("widget/checkbox")) {
      Glass.rounded(g, x + 2, y + 2, w - 4, h - 4, 2, color(0xD0DFE9, (selected ? .18f : .07f) * alpha));
      if (path.contains("selected")) {
        Glass.line(g, x + w * .25, y + h * .5, x + w * .44, y + h * .7, 1.5, color(0xE7EEF3, alpha));
        Glass.line(g, x + w * .44, y + h * .7, x + w * .77, y + h * .3, 1.5, color(0xE7EEF3, alpha));
      }
      return true;
    }
    return false;
  }

  public static void progress(DrawContext g, int x, int y, int w, float progress) {
    Glass.rounded(g, x, y, w, 1, 0, 0x30D0DEE6);
    Glass.rounded(g, x, y, Math.max(0, Math.min(1, progress)) * w, 1, 0, 0xFFE1EAF0);
  }

  private static int color(int rgb, float alpha) {
    return (Math.round(Math.max(0, Math.min(1, alpha)) * 255) << 24) | rgb;
  }

  private GlassMenus() {}
}
