package pl.xvisuals.menu;

import pl.xvisuals.XVisuals;
import net.minecraft.util.Identifier;

/** One catalogue for menu previews, pages and bootstrap loading artwork. */
public final class MenuThemes {
  public record Theme(String name, String asset, int width, int height) {
    public Identifier texture() { return Identifier.of("xvisuals", "textures/menu/" + asset + ".png"); }
  }
  private static final Theme[] THEMES = {
      new Theme("Alpine", "alpine", 1672, 941),
      new Theme("Cyber Goth", "cyber_goth", 1672, 941),
      new Theme("Moonlit Ronin", "moonlit_ronin", 1672, 941),
      new Theme("Banana Cat", "banana_cat", 1672, 941),
      new Theme("Blue Meadow", "blue_meadow", 1672, 941),
      new Theme("Troll Temple", "troll_temple", 1672, 941),
      new Theme("Space Cat", "space_cat", 1672, 941),
      new Theme("Moonlit Catgirl", "moonlit_catgirl", 1672, 941),
      new Theme("Golden Bananas", "golden_bananas", 1672, 941),
      new Theme("Emerald Valley", "emerald_valley", 1672, 941),
      new Theme("Turquoise Sunset", "turquoise_sunset", 1672, 941),
      new Theme("Mountain Dawn", "mountain_dawn", 1672, 941),
      new Theme("Astronaut", "astronaut", 1672, 941),
      new Theme("Coastal Retreat", "coastal_retreat", 1672, 941),
      new Theme("Celestial Angel", "celestial_angel", 1672, 941),
      new Theme("Voxel Sunset", "voxel_sunset", 1672, 941),
      new Theme("Synthwave", "synthwave", 1672, 941),
      new Theme("Violet Moon", "violet_moon", 1672, 941),
      new Theme("Solar Wanderer", "solar_wanderer", 1672, 941),
      new Theme("Cherry Blossom", "cherry_blossom", 1672, 941),
      new Theme("Lavender Dreams", "lavender_dreams", 1672, 941),
      new Theme("Rainy Solitude", "rainy_solitude", 2560, 1440),
      new Theme("Moonlit Samurai", "moonlit_samurai", 1672, 941),
      new Theme("Moonlit Citadel", "moonlit_citadel", 1672, 941),
      new Theme("Broken Moon", "broken_moon", 1672, 941)
  };
  public static String[] names() { return java.util.Arrays.stream(THEMES).map(Theme::name).toArray(String[]::new); }
  public static Theme get(int index) { return THEMES[Math.floorMod(index, THEMES.length)]; }
  public static int index(String name) {
    for (int i=0;i<THEMES.length;i++) if(THEMES[i].name().equals(name)) return i;
    return 0;
  }
  public static int selected() {
    return index(XVisuals.ready()
        ? XVisuals.config().module("menu").text("homeTheme") : Bootstrap.NAME);
  }
  public static String customPath() {
    return XVisuals.ready() ? XVisuals.config().module("menu").text("background") : Bootstrap.BACKGROUND;
  }
  private static final class Bootstrap {
    static final String NAME = read("homeTheme", "Alpine");
    static final String BACKGROUND = read("background", "");
    private static String read(String key, String fallback) {
      var path = net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("xvisuals/config.json");
      try {
        if(java.nio.file.Files.size(path)>1_048_576) return fallback;
        var json=com.google.gson.JsonParser.parseString(java.nio.file.Files.readString(path)).getAsJsonObject();
        return json.getAsJsonObject("modules").getAsJsonObject("menu").getAsJsonObject("values").get(key).getAsString();
      } catch(Exception ignored) { return fallback; }
    }
  }
  private MenuThemes() {}
}
