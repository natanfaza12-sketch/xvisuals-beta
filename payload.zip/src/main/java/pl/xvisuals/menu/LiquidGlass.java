package pl.xvisuals.menu;

import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.rendering.shaders.SdfRenderer;
import net.minecraft.client.gui.DrawContext;

/** Clear glass: a continuous translucent lens and a faint directional rim. */
final class LiquidGlass {
  private LiquidGlass() {}
  static int surface() {
    var s=pl.xvisuals.XVisuals.config().module("menubuttons");
    int rgb=switch(s.text("theme")) {
      case "Frosted"->0xE1EAF4;case "Midnight"->0x142238;
      case "Rose"->0xEFA4BC;case "Ocean"->0x63CDE4;
      case "Custom"->s.color("color")&0xFFFFFF;default->0xC6D7E8;
    };
    return ((int)(Math.clamp(s.number("opacity"),0,1)*255)<<24)|rgb;
  }
  static void pill(DrawContext g,float x,float y,float w,float h,double hover) {
    var s=pl.xvisuals.XVisuals.config().module("menubuttons");
    float radius=(float)(h*.5*s.number("roundness"));
    double opacity=s.number("opacity");
    int rgb=surface()&0xFFFFFF;
    if(s.flag("shadow"))Glass.rounded(g,x,y+1.5f,w,h,radius,0x18030910);
    int top=((int)(Math.min(1,opacity+hover*.06)*255)<<24)|rgb;
    int bottom=((int)(opacity*255)<<24)|rgb;
    SdfRenderer.gradient(g,x,y,w,h,radius,top,top,bottom,bottom,0);
    if(s.flag("rim"))SdfRenderer.gradient(g,x,y,w,h,radius,0x48FFFFFF,0x1CFFFFFF,0x08D4E9FF,0x22E1F0FF,22);
  }
}
