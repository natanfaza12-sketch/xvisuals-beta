package pl.xvisuals.menu;
import java.util.List;

/** Resolve visible rows back to saved-list indices, including filtered views. */
public final class ServerReorder {
  public record Swap(int from,int to) {}
  public static <T> Swap resolve(List<T> saved,List<T> visible,T selected,int direction) {
    if(direction!=-1 && direction!=1)return null;
    int row=visible.indexOf(selected),neighbor=row+direction;
    if(row<0 || neighbor<0 || neighbor>=visible.size())return null;
    int from=saved.indexOf(selected),to=saved.indexOf(visible.get(neighbor));
    return from<0 || to<0 || from==to ? null : new Swap(from,to);
  }
  private ServerReorder() {}
}
