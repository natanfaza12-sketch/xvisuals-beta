package pl.xvisuals.menu;

import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.*;
import net.minecraft.text.Text;

/** Focused home-button settings with a live preview and no Studio navigation. */
public final class ButtonEditorScreen extends Screen {
  private final Screen parent;
  private int left,top;
  public ButtonEditorScreen(Screen parent){super(Text.literal("Button editor"));this.parent=parent;}
  private pl.xvisuals.config.VisualConfig.ModuleState settings(){return XVisuals.config().module("menubuttons");}
  @Override protected void init(){
    left=width/2-150;top=Math.max(4,(height-218)/2);
    var specs=Modules.get("menubuttons").settings();
    for(int i=0;i<specs.size();i++){
      var spec=specs.get(i);int x=left+(i%2)*156,y=top+32+(i/2)*25;
      switch(spec.kind()){
        case CHOICE -> addDrawableChild(ButtonWidget.builder(Text.literal(spec.label()+": "+settings().text(spec.key())),button->{
          var choices=spec.choices();int next=(choices.indexOf(settings().text(spec.key()))+1)%choices.size();
          settings().values.put(spec.key(),choices.get(next));button.setMessage(Text.literal(spec.label()+": "+choices.get(next)));
        }).dimensions(x,y,144,20).build());
        case BOOLEAN -> addDrawableChild(ButtonWidget.builder(Text.literal(spec.label()+": "+(settings().flag(spec.key())?"On":"Off")),button->{
          settings().values.put(spec.key(),!settings().flag(spec.key()));button.setMessage(Text.literal(spec.label()+": "+(settings().flag(spec.key())?"On":"Off")));
        }).dimensions(x,y,144,20).build());
        case NUMBER -> addDrawableChild(new SettingSlider(x,y,spec));
        case COLOR -> {
          var field=new TextFieldWidget(textRenderer,x+78,y,66,20,Text.literal(spec.label()));
          field.setMaxLength(7);field.setEditableColor(0xFFFFFFFF);field.setText(settings().text(spec.key()));
          field.setChangedListener(value->{boolean valid=value.matches("#[0-9a-fA-F]{6}");field.setEditableColor(valid?0xFFFFFFFF:0xFFFF8888);if(valid){settings().values.put(spec.key(),value);XVisuals.STORE.dirty();}});
          addDrawableChild(field);
        }
        default -> {}
      }
    }
    addDrawableChild(new MenuThemeScreen.GlassButton(width/2-60,top+167,120,22,"Singleplayer",()->{}));
    addDrawableChild(ButtonWidget.builder(Text.literal("Done"),button->close()).dimensions(width/2-40,top+197,80,20).build());
  }
  @Override public void renderBackground(DrawContext g,int mx,int my,float dt){if(!BackgroundTexture.draw(g,width,height))MenuThemeScreen.drawTheme(g,MenuThemeScreen.selected(),0,0,width,height);g.fill(0,0,width,height,0xB509101A);}
  @Override public void render(DrawContext g,int mx,int my,float dt){
    g.drawCenteredTextWithShadow(textRenderer,title,width/2,top,0xFFFFFFFF);
    g.drawCenteredTextWithShadow(textRenderer,"Changes preview below",width/2,top+15,0xFFADB8C7);
    var specs=Modules.get("menubuttons").settings();
    for(int i=0;i<specs.size();i++)if(specs.get(i).kind()==Setting.Kind.COLOR)
      g.drawTextWithShadow(textRenderer,specs.get(i).key().equals("color")?"Fill colour":"Text colour",left+(i%2)*156,top+38+(i/2)*25,0xFFE0E7EF);
    super.render(g,mx,my,dt);
  }
  @Override public void close(){XVisuals.STORE.save();client.setScreen(parent);}

  // Named so the protection configuration can preserve Minecraft's override callbacks.
  private final class SettingSlider extends SliderWidget {
    private final Setting spec;
    SettingSlider(int x,int y,Setting spec) {
      super(x,y,144,20,Text.empty(),Math.clamp(
          (settings().number(spec.key())-spec.min())/(spec.max()-spec.min()),0,1));
      this.spec=spec;
      updateMessage();
    }
    @Override protected void updateMessage() {
      setMessage(Text.literal(spec.label()+": "+Math.round(settings().number(spec.key())*100)+"%"));
    }
    @Override protected void applyValue() {
      double n=spec.min()+value*(spec.max()-spec.min());
      double snapped=Math.clamp(spec.min()+Math.round((n-spec.min())/spec.step())*spec.step(),spec.min(),spec.max());
      settings().values.put(spec.key(),snapped);
      XVisuals.STORE.dirty();
      updateMessage();
    }
  }
}

