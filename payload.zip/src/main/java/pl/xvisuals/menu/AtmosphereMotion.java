package pl.xvisuals.menu;
/** Analytic critically damped motion: continuous velocity when navigation reverses. */
public final class AtmosphereMotion {
 private double position,velocity;private int target;
 public AtmosphereMotion(int initial){position=target=initial;}
 public void step(int delta){target=(int)Math.clamp((long)target+delta,(long)Math.floor(position)-4,(long)Math.ceil(position)+4);}
 public void update(double seconds){if(seconds<=0)return;double omega=18,x=position-target,c=velocity+omega*x,e=Math.exp(-omega*seconds);position=target+(x+c*seconds)*e;velocity=(velocity-omega*c*seconds)*e;}
 public void dragTo(double value){if(!Double.isFinite(value))return;position=value;velocity=0;target=(int)Math.round(value);}
 public double position(){return position;}
 public int target(){return target;}
}
