package pl.xvisuals.menu;
/** Legible vanilla tooltip colours on the dark Studio surface. */
public final class TooltipStyle {
 public static final float SCALE=.9f;
 public static int color(int rgb){return switch(rgb&0xFFFFFF){
  case 0xFFFFFF -> 0xF0F2F7;
  case 0xAAAAAA -> 0xADB5C4;
  case 0x555555 -> 0x8C96AA;
  case 0x0000AA,0x5555FF -> 0xB8ADEB;
  case 0xAA00AA,0xFF55FF -> 0xE1A8ED;
  case 0x00AAAA,0x55FFFF -> 0x8FD9DA;
  case 0x00AA00,0x55FF55 -> 0xA0D7A7;
  case 0xAA0000,0xFF5555 -> 0xF3A1A8;
  case 0xFFAA00,0xFFFF55 -> 0xEAC68F;
  default -> rgb&0xFFFFFF;
 };}
 private TooltipStyle(){}
}
