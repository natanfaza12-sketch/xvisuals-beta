package pl.xvisuals.menu;

import pl.xvisuals.rendering.DimensionSkyMath;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.nio.file.*;
import java.util.*;
import java.io.IOException;

/** Validates headers before decoding. Six faces use +X,-X,+Y,-Y,+Z,-Z order. */
public final class DimensionSkyImport {
 public static Path importImages(List<Path> files,Path directory)throws IOException{
  BufferedImage image;
  if(files.size()==1){image=read(files.getFirst(),8192,33_554_432);if(DimensionSkyMath.layout(image.getWidth(),image.getHeight())<0){image.flush();throw new IOException("Use a 2:1 panorama, 6:1 / 1:6 strip, 4:3 cross or 3:2 atlas.");}}
  else if(files.size()==6){
   var order=List.of("px","nx","py","ny","pz","nz");var byName=new HashMap<String,Path>();
   for(var file:files){String name=file.getFileName().toString().toLowerCase(Locale.ROOT).replaceFirst("\\.png$","");if(!order.contains(name)||byName.put(name,file)!=null)throw new IOException("Name the six PNG faces px, nx, py, ny, pz, nz.");}
   image=null;
   try{for(int i=0;i<6;i++){var face=read(byName.get(order.get(i)),2048,4_194_304);try{
    if(face.getWidth()!=face.getHeight()||image!=null&&face.getWidth()!=image.getWidth()/3)throw new IOException("Cubemap faces must be equally sized squares, up to 2048 px.");
    if(image==null)image=new BufferedImage(face.getWidth()*3,face.getHeight()*2,BufferedImage.TYPE_INT_ARGB);
    var g=image.createGraphics();try{g.drawImage(face,(i%3)*face.getWidth(),(i/3)*face.getHeight(),null);}finally{g.dispose();}
   }finally{face.flush();}}}catch(IOException|RuntimeException ex){if(image!=null)image.flush();throw ex;}
  }else throw new IOException("Choose one panorama/atlas or six named PNG faces.");
  Files.createDirectories(directory);Path output=Files.createTempFile(directory,"dimension-",".png");
  try{if(!ImageIO.write(image,"png",output.toFile()))throw new IOException("Could not encode PNG.");return output.toAbsolutePath();}
  catch(IOException ex){Files.deleteIfExists(output);throw ex;}finally{image.flush();}
 }
 private static BufferedImage read(Path file,int maxSide,long maxPixels)throws IOException{
  if(!Files.isRegularFile(file)||Files.size(file)>128L*1024*1024)throw new IOException("Choose PNG files under 128 MB.");
  try(var stream=ImageIO.createImageInputStream(file.toFile())){
   if(stream==null)throw new IOException("Cannot open image.");var readers=ImageIO.getImageReaders(stream);
   if(!readers.hasNext())throw new IOException("Not a PNG image.");var reader=readers.next();
   try{if(!reader.getFormatName().equalsIgnoreCase("png"))throw new IOException("Use PNG images.");reader.setInput(stream,true,true);
    int w=reader.getWidth(0),h=reader.getHeight(0);if(w<1||h<1||w>maxSide||h>maxSide||(long)w*h>maxPixels)throw new IOException("Image exceeds the supported dimensions.");return reader.read(0);
   }finally{reader.dispose();}
  }
 }
 private DimensionSkyImport(){}
}
