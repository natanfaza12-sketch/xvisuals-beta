package pl.xvisuals.menu;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import org.slf4j.LoggerFactory;

/** Optional integration; Screen.class is remapped by Loom in production. */
public final class ModMenuBridge {
  public static void open(Screen parent) {
    if (FabricLoader.getInstance().isModLoaded("modmenu")) {
      try {
        Class<?> type = Class.forName("com.terraformersmc.modmenu.gui.ModsScreen");
        Screen screen = (Screen) type.getConstructor(Screen.class).newInstance(parent);
        MinecraftClient.getInstance().setScreen(screen);
        return;
      } catch (ReflectiveOperationException | LinkageError e) {
        LoggerFactory.getLogger("xvisuals").error("Unable to open installed Mod Menu", e);
      }
    }
    MinecraftClient.getInstance().setScreen(new ModsScreen(parent));
  }

  private ModMenuBridge() {}
}
