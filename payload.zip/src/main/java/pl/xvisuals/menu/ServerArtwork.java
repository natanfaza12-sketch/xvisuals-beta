package pl.xvisuals.menu;
import pl.xvisuals.gui.components.Glass;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerServerListWidget;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.util.Identifier;
public final class ServerArtwork {
  private static final java.util.regex.Pattern FORMATTING = java.util.regex.Pattern.compile("§.");
  public static void draw(DrawContext g,MultiplayerServerListWidget.ServerEntry e,CelestialServerScreen page,
      ServerInfo info,Identifier icon,int mx,int my) {
    int x=e.getX(), y=e.getY(), w=e.getWidth(), h=e.getHeight()-3;
    boolean selected=page.selected(e), hover=e.isMouseOver(mx,my);
    var font=net.minecraft.client.MinecraftClient.getInstance().textRenderer;
    GlassMenus.surface(g,x,y,w,h,selected || hover,selected?1:.85f);
    if(selected) g.fill(x-4,y+5,x-2,y+h-5,0xFFDCE6ED);
    // Keep reorder controls in their own gutter, never over the server artwork.
    g.drawTexture(RenderPipelines.GUI_TEXTURED,icon,x+20,y+1,0,0,32,32,32,32);
    if(hover || selected) {
      boolean up=page.canMove(e,-1),down=page.canMove(e,1);
      boolean onUp=mx>=x && mx<x+18 && my>=y+1 && my<y+17;
      boolean onDown=mx>=x && mx<x+18 && my>=y+17 && my<y+33;
      int upColor=up?(onUp?0xFFFFFFFF:0xFFB9C7DA):0xFF515963;
      int downColor=down?(onDown?0xFFFFFFFF:0xFFB9C7DA):0xFF515963;
      if(onUp && up) g.fill(x+1,y+2,x+17,y+16,0x303E5068);
      if(onDown && down) g.fill(x+1,y+18,x+17,y+32,0x303E5068);
      // Seven-pixel outline chevrons with generous, separate click targets.
      for(int i=0;i<4;i++) {
        g.fill(x+8-i,y+7+i,x+9-i,y+8+i,upColor);
        g.fill(x+8+i,y+7+i,x+9+i,y+8+i,upColor);
        g.fill(x+5+i,y+23+i,x+6+i,y+24+i,downColor);
        g.fill(x+11-i,y+23+i,x+12-i,y+24+i,downColor);
      }
    }
    int textX=x+58, nameWidth=Math.max(24,w-148);
    g.drawTextWithShadow(font,font.trimToWidth(info.name,nameWidth),textX,y+2,0xFFFFFFFF);
    String motd=page.compact() && info.label!=null
        ? FORMATTING.matcher(info.label.getString()).replaceAll("").replace('\n',' ') : info.address;
    g.drawTextWithShadow(font,font.trimToWidth(motd,nameWidth),textX,y+15,0xFFAAAAAA);
    String status=info.getStatus().name();
    boolean online=status.equals("SUCCESSFUL");
    String badge=online ? info.ping+" ms" : status.equals("INCOMPATIBLE") ? "Version mismatch" : status.equals("UNREACHABLE") ? "Offline" : "Pinging";
    String count=online && info.playerCountLabel!=null ? info.playerCountLabel.getString() : "-";
    count=font.trimToWidth(count,86); badge=font.trimToWidth(badge,86);
    g.drawTextWithShadow(font,count,x+w-font.getWidth(count)-3,y+2,0xFFAAAAAA);
    g.drawTextWithShadow(font,badge,x+w-font.getWidth(badge)-3,y+15,online?0xFF9DCEB3:0xFFAAAAAA);
    if(e.isMouseOver(mx,my) && mx>x+w-80) page.tooltip(
        net.minecraft.text.Text.literal(online ? info.ping+" ms" : badge));
  }
  private static String fit(String text,float width,float scale) {
    if(Glass.textWidth(text)*scale<=width) return text;
    int low=0, high=text.codePointCount(0,text.length());
    while(low<high) {
      int mid=(low+high+1)/2;
      String candidate=text.substring(0,text.offsetByCodePoints(0,mid))+"…";
      if(Glass.textWidth(candidate)*scale<=width) low=mid; else high=mid-1;
    }
    return text.substring(0,text.offsetByCodePoints(0,low))+"…";
  }
  private ServerArtwork() {}
}
