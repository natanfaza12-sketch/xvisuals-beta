package pl.xvisuals.menu;

import pl.xvisuals.XVisuals;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

public final class MenuBackdrop {

  public static void draw(DrawContext g, int width, int height) {
    BackgroundTexture.load(MenuThemes.customPath());
    Identifier texture = BackgroundTexture.available ? BackgroundTexture.ID : MenuThemes.get(MenuThemes.selected()).texture();
    float aspect =
        BackgroundTexture.available
            ? (float) BackgroundTexture.width / BackgroundTexture.height
            : (float) MenuThemes.get(MenuThemes.selected()).width() / MenuThemes.get(MenuThemes.selected()).height();
    double time = System.nanoTime() / 1e9;
    int dw = (int) (width * 1.055), dh = (int) (dw / aspect);
    if (dh < height * 1.055) {
      dh = (int) (height * 1.055);
      dw = (int) (dh * aspect);
    }
    float x = (width - dw) / 2f + (float) (Math.sin(time * .026) * (dw - width) * .28),
        y = (height - dh) / 2f + (float) (Math.cos(time * .021) * (dh - height) * .2);
    g.getMatrices().pushMatrix();
    g.getMatrices().translate(x, y);
    g.drawTexture(RenderPipelines.GUI_TEXTURED, texture, 0, 0, 0, 0, dw, dh, dw, dh);
    g.getMatrices().popMatrix();
    darken(g, width, height);
  }

  public static void darken(DrawContext g, int width, int height) {
    g.fill(0, 0, width, height, 0x51070D16);
    g.fillGradient(0, 0, width, height / 2, 0x30050A12, 0x00050A12);
    g.fillGradient(0, height / 3, width, height, 0x00071019, 0x96070D17);
  }

  private MenuBackdrop() {}
}
