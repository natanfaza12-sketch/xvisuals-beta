package pl.xvisuals.menu;

import java.util.Map;
import net.minecraft.client.gui.DrawContext;

/**
 * Bootstrap-safe artwork: vanilla primitives only, no font, texture or custom shader dependencies.
 */
public final class LoadingFallback {
  private static final Map<Character, String> GLYPHS =
      Map.ofEntries(
          Map.entry('A', "01110100011000111111100011000110001"),
          Map.entry('B', "11110100011000111110100011000111110"),
          Map.entry('C', "01111100001000010000100001000001111"),
          Map.entry('D', "11110100011000110001100011000111110"),
          Map.entry('E', "11111100001000011110100001000011111"),
          Map.entry('G', "01111100001000010111100011000101111"),
          Map.entry('I', "11111001000010000100001000010011111"),
          Map.entry('L', "10000100001000010000100001000011111"),
          Map.entry('N', "10001110011010110011100011000110001"),
          Map.entry('O', "01110100011000110001100011000101110"),
          Map.entry('R', "11110100011000111110101001001010001"),
          Map.entry('S', "01111100001000001110000010000111110"),
          Map.entry('T', "11111001000010000100001000010000100"),
          Map.entry('U', "10001100011000110001100011000101110"),
          Map.entry('V', "10001100011000110001100010101000100"),
          Map.entry('Y', "10001100010101000100001000010000100"),
          Map.entry('0', "01110100011001110101110011000101110"),
          Map.entry('1', "00100011000010000100001000010001110"),
          Map.entry('2', "01110100010000100010001000100011111"),
          Map.entry('3', "11110000010000101110000010000111110"),
          Map.entry('4', "00010001100101010010111110001000010"),
          Map.entry('5', "11111100001000011110000010000111110"),
          Map.entry('6', "01110100001000011110100011000101110"),
          Map.entry('7', "11111000010001000100010000100001000"),
          Map.entry('8', "01110100011000101110100011000101110"),
          Map.entry('9', "01110100011000101111000010000101110"),
          Map.entry('%', "11001110100001000100010000101110011"));

  public static void draw(DrawContext g, float progress, float alpha, double seconds) {
    int w = g.getScaledWindowWidth(), h = g.getScaledWindowHeight(), cx = w / 2, cy = h / 2;
    g.createNewRootLayer();
    g.fillGradient(0, 0, w, h, color(0x151C22, alpha), color(0x080C10, alpha));

    float unit = Math.max(.65f, Math.min(1.25f, w / 640f));
    g.getMatrices().pushMatrix();
    g.getMatrices().translate(cx, cy - 20 * unit);
    g.getMatrices().scale(unit, unit);

    int barWidth = 180;
    g.fill(-barWidth / 2, 98, barWidth / 2, 100, color(0x26323B, alpha));
    g.fill(
        -barWidth / 2,
        98,
        -barWidth / 2 + Math.round(barWidth * progress),
        100,
        color(0xD5E0E8, alpha));
    word(g, progress >= .999f ? "READY" : "LOADING RESOURCES", 0, 117, 1, color(0x9C9BAF, alpha));
    word(g, Math.round(progress * 100) + "%", 0, 133, 1, color(0x777C95, alpha));
    g.getMatrices().popMatrix();
  }

  private static int color(int rgb, float alpha) {
    return Math.max(0, Math.min(255, Math.round(alpha * 255))) << 24 | rgb;
  }

  private static void line(
      DrawContext g, double x, double y, double ex, double ey, float thickness, int color) {
    g.getMatrices().pushMatrix();
    g.getMatrices().translate((float) x, (float) y);
    g.getMatrices().rotate((float) Math.atan2(ey - y, ex - x));
    g.fill(0, 0, (int) Math.ceil(Math.hypot(ex - x, ey - y)), Math.max(1, (int) thickness), color);
    g.getMatrices().popMatrix();
  }

  private static void word(DrawContext g, String text, int cx, int y, int scale, int color) {
    int x = cx - (text.length() * 6 - 1) * scale / 2;
    for (char c : text.toCharArray()) {
      String bits = GLYPHS.get(c);
      if (bits != null)
        for (int row = 0; row < 7; row++)
          for (int col = 0; col < 5; col++) {
            if (bits.charAt(row * 5 + col) == '1')
              g.fill(
                  x + col * scale,
                  y + row * scale,
                  x + (col + 1) * scale,
                  y + (row + 1) * scale,
                  color);
          }
      x += 6 * scale;
    }
  }

  private LoadingFallback() {}
}


