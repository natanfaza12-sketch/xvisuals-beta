package pl.xvisuals.audio;

import pl.xvisuals.XVisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/** Local key-press feedback, never key logging or gameplay input modification. */
public final class CreamyKeys {
  private static final java.util.ArrayDeque<PositionedSoundInstance> VOICES=new java.util.ArrayDeque<>();
  private static final java.util.Random RANDOM=new java.util.Random();
  public static void key(long window,int action,net.minecraft.client.input.KeyInput input) {
    int key=input.key();
    var c=MinecraftClient.getInstance();
    if(!XVisuals.ready() || window!=c.getWindow().getHandle() || !c.isWindowFocused()
        || action!=GLFW.GLFW_PRESS || key==GLFW.GLFW_KEY_UNKNOWN) return;
    var s=XVisuals.config().module("creamykeys");
    if(!s.enabled || s.number("volume")<=0 || (c.currentScreen!=null && !s.flag("menus"))
        || (c.world==null && !s.flag("menus")))return;
    if(s.flag("movementOnly") && !(c.options.forwardKey.matchesKey(input)
        || c.options.backKey.matchesKey(input)
        || c.options.leftKey.matchesKey(input)
        || c.options.rightKey.matchesKey(input)
        || c.options.jumpKey.matchesKey(input)
        || c.options.sneakKey.matchesKey(input)))return;
    play();
  }
  public static void mouse(long window,int action) {
    var c=MinecraftClient.getInstance();
    if(!XVisuals.ready() || window!=c.getWindow().getHandle() || !c.isWindowFocused()
        || action!=GLFW.GLFW_PRESS)return;
    var s=XVisuals.config().module("creamykeys");
    if(!s.enabled || !s.flag("mouseClicks") || s.number("volume")<=0
        || ((c.currentScreen!=null || c.world==null) && !s.flag("menus")))return;
    play();
  }
  private static void play() {
    var c=MinecraftClient.getInstance();
    var s=XVisuals.config().module("creamykeys");
    String selection=s.text("sample");
    int sample=selection.equals("Mixed")?RANDOM.nextInt(9)+1:selection.charAt(selection.length()-1)-'0';
    var id=Identifier.of("xvisuals","creamykeys."+Math.clamp(sample,1,9));
    var manager=c.getSoundManager();
    if(manager.get(id)==null)return;
    VOICES.removeIf(sound->!manager.isPlaying(sound));
    while(VOICES.size()>=8)manager.stop(VOICES.removeFirst());
    double softness=s.number("softness");
    float pitch=(float)(1-.08*softness);
    float gain=(float)(s.number("volume")/(1+.08*softness*Math.min(4,VOICES.size())));
    var sound=PositionedSoundInstance.ui(SoundEvent.of(id),pitch,gain);
    manager.play(sound);VOICES.addLast(sound);
  }
  private CreamyKeys() {}
}
