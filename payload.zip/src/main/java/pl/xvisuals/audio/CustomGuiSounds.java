package pl.xvisuals.audio;

import pl.xvisuals.XVisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import java.util.*;

/** User-supplied GUI feedback, kept separate from keyboard and world audio. */
public final class CustomGuiSounds {
  private record Voice(PositionedSoundInstance sound,long started) {}
  private static final ArrayDeque<Voice> voices=new ArrayDeque<>();
  private static final Map<String,Long> last=new HashMap<>();
  public static void play(String event){
    if(!XVisuals.ready()||!Set.of("open","close","page","hover","enable","disable").contains(event))return;
    var s=XVisuals.config().module("sounds");
    if(!s.enabled||s.number("volume")<=0)return;
    String variant=s.text(event);if(variant.equals("Off")||variant.isEmpty())return;
    long now=net.minecraft.util.Util.getMeasuringTimeMs();
    if(now-last.getOrDefault(event,-1000L)<(event.equals("hover")?110:45))return;
    String number=variant.substring(variant.length()-1);
    var id=Identifier.of("xvisuals","custom."+event+number);
    var manager=MinecraftClient.getInstance().getSoundManager();if(manager.get(id)==null)return;
    tick();while(voices.size()>=6)manager.stop(voices.removeFirst().sound());
    var sound=PositionedSoundInstance.ui(SoundEvent.of(id),1,(float)Math.clamp(s.number("volume"),0,1));
    manager.play(sound);voices.add(new Voice(sound,now));last.put(event,now);
  }
  public static void tick(){
    if(!XVisuals.ready())return;
    var manager=MinecraftClient.getInstance().getSoundManager();
    var s=XVisuals.config().module("sounds");long now=net.minecraft.util.Util.getMeasuringTimeMs();
    voices.removeIf(v->{if(!s.enabled||s.number("volume")<=0||now-v.started()>10000){manager.stop(v.sound());return true;}
      return now-v.started()>500&&!manager.isPlaying(v.sound());});
  }
  private CustomGuiSounds(){}
}
