package pl.xvisuals.hud;

/**
 * Reconciles timestamped Windows snapshots with one monotonic playback clock. No game dependencies.
 */
public final class PlaybackClock {
  public record Anchor(double position, long atNanos, long duration, boolean playing, double rate, double correction) {
    public Anchor(double position,long atNanos,long duration,boolean playing,double rate){this(position,atNanos,duration,playing,rate,0);}
    private double remaining(long nowNanos){return correction*Math.exp(-Math.max(0,nowNanos-atNanos)/400_000_000.0);}
    private double precisePositionAt(long nowNanos) {
      return position+(playing?Math.max(0,nowNanos-atNanos)/1_000_000.0*rate+correction-remaining(nowNanos):0);
    }
    public long positionAt(long nowNanos) {
      double value=precisePositionAt(nowNanos);
      return Math.round(Math.max(0, duration > 0 ? Math.min(duration, value) : value));
    }
  }

  private String key;
  private Anchor anchor;
  private long lastRaw, lastUpdated, resumeAt;

  public Anchor update(
      String nextKey,
      long raw,
      long duration,
      boolean playing,
      double rate,
      long updatedUtc,
      long sampledUtc,
      long receivedUtc,
      long nowNanos) {
    rate = Double.isFinite(rate) && rate >= 0 && rate <= 4 ? rate : 1;
    raw = Math.max(0, raw);
    // Account for IPC transit, but not a clock adjustment or a suspended helper's old backlog.
    long transit = Math.max(0, Math.min(2000, receivedUtc - sampledUtc));
    long age =
        updatedUtc > 0 && updatedUtc <= sampledUtc
            ? Math.min(sampledUtc - updatedUtc, duration > 0 ? duration : 60_000)
            : 0;
    boolean same = nextKey.equals(key) && anchor != null;
    boolean changedPosition = !same || raw != lastRaw;
    boolean changedStamp = !same || updatedUtc != lastUpdated;
    double position,correction=0;
    if (!same) {
      resumeAt = 0;
      position = raw + (playing ? (age + transit) * rate : 0);
    } else if (!anchor.playing && playing) {
      // A paused timestamp is not the start of playback. Never add the time spent paused.
      resumeAt = sampledUtc;
      position = changedPosition ? raw : anchor.positionAt(nowNanos);
      position += transit * rate;
    } else if (anchor.playing && !playing) {
      position = changedPosition ? raw : anchor.positionAt(nowNanos);
    } else if (changedPosition) {
      // Fresh seek/position updates take effect immediately, with no smoothing lag.
      // Some providers advance Position without updating LastUpdatedTime: don't add its age twice.
      long validAge = changedStamp && updatedUtc >= resumeAt ? age : 0;
      position = raw + (playing ? (validAge + transit) * rate : 0);
      // Coarse provider timestamps can wobble around the true timeline. Keep the
      // monotonic estimate for tiny corrections; real seeks still snap immediately.
      double predicted=anchor.precisePositionAt(nowNanos);
      if(playing && rate>0 && Math.abs(position-predicted)<=120) {
        // Converge without replaying words. Previously these offsets were discarded forever.
        correction=Math.clamp(position-predicted,-120*rate,120*rate);position=predicted;
      }

    } else {
      // Repeated/stale snapshots (including timestamp-only heartbeats) must not rewind playback.
      position=anchor.precisePositionAt(nowNanos);
      if(playing)correction=anchor.remaining(nowNanos);
    }
    if(!playing||rate==0)correction=0;
    key = nextKey;
    lastRaw = raw;
    lastUpdated = updatedUtc;
    anchor =
        new Anchor(
            Math.max(0, duration > 0 ? Math.min(duration, position) : position),
            nowNanos,
            duration,
            playing,
            rate,correction);
    return anchor;
  }

  public void reset() {
    key = null;
    anchor = null;
    resumeAt = 0;
  }
}
