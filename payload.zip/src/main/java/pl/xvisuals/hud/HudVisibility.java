package pl.xvisuals.hud;

import pl.xvisuals.config.VisualConfig;

/** Shared rendering and picking policy; music has its own module switch. */
public final class HudVisibility {
  public static boolean visible(VisualConfig config, String name, boolean hasTrack, boolean editor) {
    var widget = config.widgets.get(name);
    if (widget == null) return false;
    if (name.equals("Now Playing")) return MusicVisibility.visible(config.on("music"), widget.hidden,
        hasTrack, config.module("music").flag("idle"), editor);
    return (editor || config.on("hud")) && !widget.hidden && widget.enabled;
  }
  private HudVisibility() {}
}
