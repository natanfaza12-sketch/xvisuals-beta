package pl.xvisuals.hud;

/** The module switch is authoritative even when a saved widget or media session remains enabled. */
public final class MusicVisibility {
 public static boolean visible(boolean enabled,boolean hidden,boolean hasTrack,boolean idle,boolean editor) {
  return enabled && !hidden && (hasTrack || idle || editor);
 }
 private MusicVisibility(){}
}
