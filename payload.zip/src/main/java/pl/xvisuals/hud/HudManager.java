package pl.xvisuals.hud;

import pl.xvisuals.XVisuals;
import pl.xvisuals.config.VisualConfig;
import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.gui.themes.Theme;
import pl.xvisuals.util.Colors;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;

public final class HudManager {
  public static final Map<String, String> VALUES = new LinkedHashMap<>();
  public static final List<MusicProvider> MUSIC = new CopyOnWriteArrayList<>();
  private static final long START = System.currentTimeMillis();
  private static final long[] CLICKS = new long[128];
  private static int clickIndex;
  private static MusicProvider.Track track;
  private static long trackSampleNanos;
  private static final Map<String, Integer> WIDTHS = new HashMap<>();
  private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm:ss");
  private static final DateTimeFormatter SOFT_CLOCK = DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH);
  private static String softClock = "";
  private static boolean softPanels() { return !XVisuals.config().module("hud").text("style").equals("Glass"); }
  private static String displayValue(String name) {
    String value=VALUES.getOrDefault(name,name);
    if(!softPanels()) return value;
    return switch(name) {
      case "FPS" -> "FPS: " + value.replace(" FPS", "");
      case "CPS" -> "CPS: " + value.replace(" CPS", "");
      case "Ping" -> value.endsWith(" ms") ? value.replace(" ms", " Ping") : value;
      case "Clock" -> softClock;
      case "Coordinates" -> value.startsWith("XYZ  ") ? value.substring(5).replace("  ", ", ") : value;
      case "Server" -> value.equals("Singleplayer") ? "world" : value;
      default -> value;
    };
  }

  public static void click(int button) {
    var c = MinecraftClient.getInstance();
    if (button == 0 && c.currentScreen == null && c.world != null)
      CLICKS[clickIndex++ % CLICKS.length] = System.currentTimeMillis();
  }

  public static void tick(MinecraftClient c) {
    WIDTHS.clear();
    long now = System.currentTimeMillis();
    int cps = 0;
    for (long t : CLICKS) if (now - t < 1000) cps++;
    VALUES.put("FPS", c.getCurrentFps() + " FPS");
    VALUES.put("Brand", "X Visuals");
    VALUES.put("Username", pl.xvisuals.modules.cosmetics.LocalAppearance.displayName(c.getSession().getUsername()));
    VALUES.put("CPS", cps + " CPS");
    var clock = LocalTime.now();
    VALUES.put("Clock", clock.format(CLOCK));
    softClock = clock.format(SOFT_CLOCK);
    VALUES.put("Session", time((now - START) / 1000) + " session");
    long used = (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1048576;
    VALUES.put("Memory", used + " MB");
    if (c.player != null && c.world != null) {
      var p = c.player;
      VALUES.put(
          "Coordinates",
          "XYZ  " + p.getBlockX() + "  " + p.getBlockY() + "  " + p.getBlockZ());
      VALUES.put(
          "Speed", String.format(Locale.ROOT, "%.1f m/s", p.getVelocity().horizontalLength() * 20));
      VALUES.put("Direction", p.getHorizontalFacing().asString().toUpperCase(Locale.ROOT));
      VALUES.put(
          "Server",
          c.getCurrentServerEntry() == null ? "Singleplayer" : c.getCurrentServerEntry().name);
      VALUES.put(
          "Biome",
          c.world
              .getBiome(p.getBlockPos())
              .getKey()
              .map(k -> k.getValue().getPath().replace('_', ' '))
              .orElse("Unknown biome"));
      var entry =
          c.getNetworkHandler() == null
              ? null
              : c.getNetworkHandler().getPlayerListEntry(p.getUuid());
      VALUES.put("Ping", entry == null ? "— ms" : entry.getLatency() + " ms");
      VALUES.put(
          "Effects",
          p.getStatusEffects().isEmpty()
              ? "No status effects"
              : p.getStatusEffects().stream()
                  .limit(4)
                  .map(
                      e ->
                          e.getEffectType().value().getName().getString()
                              + " "
                              + (e.isInfinite() ? "∞" : time(e.getDuration() / 20)))
                  .reduce((a, b) -> a + " · " + b)
                  .orElse(""));
    } else {
      // The title-screen editor uses these too: long status messages distort widget sizes.
      VALUES.put("Coordinates", "XYZ  —  —  —");
      VALUES.put("Speed", "— BPS");
      VALUES.put("Direction", "—");
      VALUES.put("Server", "Offline");
      VALUES.put("Biome", "Biome: —");
      VALUES.put("Ping", "— ms");
      VALUES.put("Effects", "No status effects");
    }
    track = null;
    for (MusicProvider provider : MUSIC) {
      try {
        var value = provider.currentTrack();
        if (value.isPresent() && !value.get().title().isBlank()) {
          track = value.get();
          trackSampleNanos = System.nanoTime();
          break;
        }
      } catch (RuntimeException ignored) {
      }
    }
  }

  public static MusicProvider.Track currentTrack() { return track; }
  public static long currentTrackPosition() {
    if (track == null) return 0;
    double elapsed=track.elapsedMillis()+(track.playing()
        ? Math.min(250,Math.max(0,(System.nanoTime()-trackSampleNanos)/1e6))*track.playbackRate():0);
    return Math.round(track.durationSeconds()>0?Math.min(elapsed,track.durationSeconds()*1000.):elapsed);
  }

  public static void render(DrawContext g, boolean editor) {
    var c = MinecraftClient.getInstance();
    var cfg = XVisuals.config();
    if (!editor && (c.options.hudHidden || c.world == null)) return;
    layout(g.getScaledWindowWidth(), g.getScaledWindowHeight());
    for (var e : cfg.widgets.entrySet()) {
      String name = e.getKey();
      var h = e.getValue();
      if (!visible(name, editor)) continue;
      draw(g, name, h, editor);
    }
  }

  public static boolean visible(String name, boolean editor) {
    return HudVisibility.visible(XVisuals.config(), name, track != null, editor);
  }

  public static int widgetWidth(String name) {
    if (SoupHud.owns(name)) return SoupHud.width(name);
    var state = XVisuals.config().widgets.get(name);
    return WIDTHS.computeIfAbsent(name + softPanels() + (state != null && state.icons), k -> measureWidth(name));
  }

  private static int measureWidth(String name) {
    if (SoupHud.owns(name)) return SoupHud.width(name);
    if (name.equals("Logo")) return softPanels()?30:20;
    if (name.equals("Keystrokes")) return 82;
    if (name.equals("Armor")) return 88;
    if (name.equals("Now Playing")) return 240;
    var state = XVisuals.config().widgets.get(name);
    if(softPanels()) {
      String reserve=switch(name) {
        case "FPS" -> "FPS: 9999"; case "CPS" -> "CPS: 99"; case "Ping" -> "9999 Ping";
        case "Clock" -> "12:59 PM"; default -> "";
      };
      return Math.max(64,(int)Math.ceil(Math.max(Glass.textWidth(reserve),Glass.textWidth(displayValue(name))))+24);
    }
    // Reserve space for changing digits so counters do not constantly resize their panels.
    String reserve = switch(name) {
      case "FPS" -> "9999 FPS"; case "Ping" -> "9999 ms"; case "CPS" -> "99 CPS";
      case "Clock" -> "00:00:00"; case "Memory" -> "99999 MB"; case "Speed" -> "999.9 m/s";
      default -> "";
    };
    double textWidth = Math.max(Glass.textWidth(reserve), Glass.textWidth(VALUES.getOrDefault(name, name)));
    return Math.max(36, (int) Math.ceil(textWidth * .9) + 14
        + (state != null && state.icons && !name.equals("Brand") ? 12 : 0));
  }

  public static void layout(int width, int height) {
    HudDefaultLayout.layout(XVisuals.config().widgets, width, height,
        HudManager::widgetWidth, HudManager::widgetHeight);
  }

  public static int widgetHeight(String name) {
    if (SoupHud.owns(name)) return SoupHud.height(name);
    return name.equals("Keystrokes")
        ? (softPanels()?70:84)+(XVisuals.config().widgets.get(name).mouseButtons?24:0)
        : name.equals("Now Playing") ? (XVisuals.config().module("music").text("lyrics").equals("In player")?106:62) : name.equals("Armor") ? 38 : softPanels()?24:20;
  }

  /** Shared bounds for painting and picking, including widgets from older layouts. */
  public static void clamp(String name, int width, int height) {
    var h = XVisuals.config().widgets.get(name);
    double fit = Math.min((double) width / widgetWidth(name), (double) height / widgetHeight(name));
    h.scale = Math.min(fit, Math.max(.25, Math.min(2.5, h.scale)));
    h.x = Math.max(0, Math.min(Math.max(0, 1 - widgetWidth(name) * h.scale / width), h.x));
    h.y = Math.max(0, Math.min(Math.max(0, 1 - widgetHeight(name) * h.scale / height), h.y));
  }

  public static HudBounds bounds(String name, int width, int height) {
    var h = XVisuals.config().widgets.get(name);
    return HudBounds.fit(h.x,h.y,h.scale,widgetWidth(name),widgetHeight(name),width,height);
  }

  public static void draw(DrawContext g, String name, VisualConfig.HudState h, boolean editor) {
    var c = MinecraftClient.getInstance();
    var bounds = bounds(name, g.getScaledWindowWidth(), g.getScaledWindowHeight());
    int w = widgetWidth(name), height = widgetHeight(name);
    float x = (float) bounds.x(), y = (float) bounds.y(), scale = (float) bounds.scale();
    g.getMatrices().pushMatrix();
    g.getMatrices().translate(x, y);
    g.getMatrices().scale(scale, scale);
    if(!SoupHud.owns(name) && (!softPanels() || !name.equals("Keystrokes"))) background(g, w, height, h.opacity, h.glass, h.accent);
    switch (name) {
      case "Logo" -> {
        Glass.logo(g, w / 2f, height / 2f, 11, hudColor("text"));
      }
      case "Keystrokes" -> {
        key(g, "W", 29, 5, c.options.forwardKey.isPressed());
        key(g, "A", 5, 29, c.options.leftKey.isPressed());
        key(g, "S", 29, 29, c.options.backKey.isPressed());
        key(g, "D", 53, 29, c.options.rightKey.isPressed());
        int spaceY=56;
        if(h.mouseButtons) {
          long window=c.getWindow().getHandle();
          for(int button=0;button<2;button++) {
            boolean down=c.isWindowFocused() && org.lwjgl.glfw.GLFW.glfwGetMouseButton(window,button)==org.lwjgl.glfw.GLFW.GLFW_PRESS;
            int bx=5+button*36;
            Glass.rounded(g,bx,55,34,21,3,softPanels()?softKeyColor(down):Colors.alpha(hudColor("highlight"),down?.4:.10));
            Glass.scaled(g,button==0?"LMB":"RMB",bx+17-Glass.textWidth(button==0?"LMB":"RMB")*.375f,62,.75f,hudColor("text"));
          }
          spaceY+=24;
        }
        Glass.rounded(
            g,
            5,
            spaceY,
            70,
            softPanels()?12:20,
            3,
            softPanels()?softKeyColor(c.options.jumpKey.isPressed()):c.options.jumpKey.isPressed() ? Colors.alpha(hudColor("highlight"), .4) : Colors.alpha(hudColor("highlight"), .10));
        Glass.scaled(g,"SPACE",40-Glass.textWidth("SPACE")*.325f,spaceY+(softPanels()?3:6),.65f,hudColor("text"));
      }
      case "Armor" -> {
        if (c.player != null) {
          int ix = 10;
          for (EquipmentSlot slot :
              new EquipmentSlot[] {
                EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
              }) {
            var stack = c.player.getEquippedStack(slot);
            g.drawItem(stack, ix, 13);
            if (!stack.isEmpty() && stack.isDamageable() && stack.getMaxDamage() > 0) {
              double remaining = Math.clamp(
                  (stack.getMaxDamage() - (double) stack.getDamage()) / stack.getMaxDamage(), 0, 1);
              int color = remaining > .5 ? 0xFF54DA83 : remaining > .2 ? 0xFFFFAA40 : 0xFFFF5058;
              g.fill(ix + 1, 31, ix + 15, 34, 0xC0181D25);
              int filled = remaining > 0 ? Math.max(1, (int) Math.round(14 * remaining)) : 0;
              if (filled > 0) g.fill(ix + 1, 31, ix + 1 + filled, 33, color);
              if (remaining <= .1) {
                double pulse = .5 + .5 * Math.sin(net.minecraft.util.Util.getMeasuringTimeMs() / 1000d * Math.PI * 3);
                int alpha = (int) (160 + 95 * pulse);
                Glass.center(g, "!", ix + 8, 3, (alpha << 24) | 0xFF5058);
              }
            }
            ix += 18;
          }
        } else Glass.text(g, "Armor", 11, 10, hudColor("text"));
      }
      case "Now Playing" -> music(g);
      case "Target HUD", "Potions", "Cooldowns", "Notifications", "Modules List", "HotKeys" -> SoupHud.draw(g, name, editor);
      default -> metric(g, name, h);
    }
    g.getMatrices().popMatrix();
  }

  private static void metric(DrawContext g, String name, VisualConfig.HudState h) {
    if(softPanels()) {
      String value=displayValue(name);
      centeredLabel(g,value,widgetWidth(name)/2f,8);
      return;
    }
    String text = VALUES.getOrDefault(name, name);
    float textX = h.icons && !name.equals("Brand") ? 20 : 7;
    if (h.icons && !name.equals("Brand")) icon(g, name, 10, 10, hudColor("highlight"));
    int split = switch (name) {
      case "FPS", "CPS", "Ping", "Speed", "Memory", "Session" -> text.lastIndexOf(' ');
      default -> -1;
    };
    int muted = h.accent && XVisuals.config().module("hud").flag("accent")
        ? hudColor("highlight") : hudColor("muted");
    if (split > 0) {
      String value = text.substring(0, split), unit = text.substring(split);
      Glass.scaled(g, value, textX, 6, .9f, hudColor("text"));
      Glass.scaled(g, unit, textX + Glass.textWidth(value) * .9f, 6, .9f, muted);
    } else {
      Glass.scaled(g, text, textX, 6, .9f, hudColor("text"));
    }
  }

  private static void icon(DrawContext g, String name, float x, float y, int color) {
    if (name.equals("Username")) {
      ringIcon(g, x, y - 2, 2, color);
      Glass.line(g, x - 3, y + 4, x - 3, y + 2, 1, color);
      Glass.line(g, x - 3, y + 2, x + 3, y + 2, 1, color);
      Glass.line(g, x + 3, y + 2, x + 3, y + 4, 1, color);
    } else if (name.equals("Ping") || name.equals("FPS")) {
      for (int i = 0; i < 3; i++) g.fill((int)x - 3 + i * 3, (int)y + 2 - i * 2,
          (int)x - 2 + i * 3, (int)y + 4, color);
    } else {
      ringIcon(g, x, y, 4, color);
      if (name.equals("Clock")) {
        Glass.line(g,x,y,x,y-2,1,color); Glass.line(g,x,y,x+2,y,1,color);
      } else if (name.equals("Speed")) {
        Glass.line(g,x-2,y+2,x+2,y-2,1,color);
      } else Glass.dot(g,x,y,2,color,0);
    }
  }

  private static void ringIcon(DrawContext g, float x, float y, float r, int color) {
    for (int i=0;i<12;i++) {
      double a=i*Math.PI/6,b=(i+1)*Math.PI/6;
      Glass.line(g,x+Math.cos(a)*r,y+Math.sin(a)*r,x+Math.cos(b)*r,y+Math.sin(b)*r,1,color);
    }
  }

  private static void key(DrawContext g, String label, int x, int y, boolean down) {
    Glass.rounded(g, x, y, 22, 22, 4, softPanels()?softKeyColor(down):down ? Colors.alpha(hudColor("highlight"), .4) : Colors.alpha(hudColor("highlight"), .10));
    centeredLabel(g, label, x + 11, y + 7);
  }
  private static void centeredLabel(DrawContext g,String label,float x,float y) {
    if(softPanels())g.drawText(MinecraftClient.getInstance().textRenderer,Glass.label(label),
        Math.round(x-Glass.textWidth(label)/2f),Math.round(y),hudColor("text"),false);
    else Glass.center(g,label,x,y,hudColor("text"));
  }
  private static int softKeyColor(boolean down) { return Colors.alpha(down?0xFF555966:hudColor("start"),down?.92:.82); }

  private static void music(DrawContext g) {
    int ink=hudColor("text"), muted=hudColor("muted");
    Glass.rounded(g,8,9,42,42,5,0x80282B34);
    if(track!=null && track.albumArt()!=null)
      g.drawTexture(RenderPipelines.GUI_TEXTURED,track.albumArt(),9,10,0,0,40,40,40,40);
    else {
      // Music note, not a duplicate client logo.
      Glass.line(g,29,20,29,37,1.5,muted);
      Glass.line(g,29,20,37,18,1.5,muted);
      Glass.dot(g,25,37,6,muted,0);
    }
    if(track==null) {
      mediaText(g,"Now playing",60,17,.95f,ink);
      mediaText(g,fitMediaText(WindowsMediaProvider.status(),186),60,33,.9f,muted);
      return;
    }
    mediaText(g,fitMediaText(track.title(),167),60,12,.95f,ink);
    mediaText(g,fitMediaText(track.artist().isBlank()?track.album():track.artist(),186),60,26,.9f,muted);
    double elapsed=currentTrackPosition();
    double progress=track.durationSeconds()>0?Math.clamp(elapsed/(track.durationSeconds()*1000.),0,1):0;
    Glass.rounded(g,60,42,168,2,1,0x604D5364);
    if(progress>0)Glass.rounded(g,60,42,(float)(168*progress),2,1,ink);
    mediaText(g,time((long)(elapsed/1000)),60,49,.8f,muted);
    String end=track.durationSeconds()>0?time(track.durationSeconds()):"LIVE";
    mediaText(g,end,228-Glass.textWidth(end)*.8f,49,.8f,muted);
    mediaControl(g,110,49,1,muted);
    mediaControl(g,137,49,track.playing()?0:3,ink);
    mediaControl(g,164,49,2,muted);
    if(XVisuals.config().module("music").text("lyrics").equals("In player"))pl.xvisuals.hud.lyrics.Lyrics.renderCard(g);
  }
  private static void mediaText(DrawContext g,String text,float x,float y,float scale,int color) {
    g.getMatrices().pushMatrix();
    g.getMatrices().translate(x,y);
    g.getMatrices().scale(scale,scale);
    g.drawText(MinecraftClient.getInstance().textRenderer,Glass.ordered(text),0,0,color,false);
    g.getMatrices().popMatrix();
  }
  /** Solid icons remain legible independently of the selected text font. */
  private static void mediaControl(DrawContext g,int x,int y,int action,int color) {
    if(action==0) { g.fill(x-3,y,x-1,y+8,color);g.fill(x+1,y,x+3,y+8,color);return; }
    boolean previous=action==1;
    for(int i=0;i<5;i++) {
      int px=previous?x+2-i:x-2+i;
      g.fill(px,y+i/2,px+1,y+8-i/2,color);
    }
    if(action!=3)g.fill(previous?x-4:x+4,y,previous?x-2:x+6,y+8,color);
  }
  public static boolean musicClick(double x,double y) {
    var c=MinecraftClient.getInstance();
    if(c.options.hudHidden||track==null||!visible("Now Playing",false))return false;
    var b=bounds("Now Playing",c.getWindow().getScaledWidth(),c.getWindow().getScaledHeight());
    double lx=(x-b.x())/b.scale(),ly=(y-b.y())/b.scale();
    if(ly<46||ly>61)return false;
    int action=lx>=98&&lx<124?1:lx>=124&&lx<151?0:lx>=151&&lx<179?2:-1;
    if(action<0)return false;
    WindowsMediaProvider.control(action);return true;
  }
  private static String fitMediaText(String value, int width) {
    if (Glass.textWidth(value) <= width) return value;
    return MinecraftClient.getInstance().textRenderer
        .trimToWidth(Glass.label(value), width - Glass.textWidth("…")).getString() + "…";
  }
  private static String time(long seconds) {
    seconds = Math.max(0, seconds);
    return String.format(Locale.ROOT, "%d:%02d", seconds / 60, seconds % 60);
  }

  private static HudPalette palette() {
    var m = XVisuals.config().module("hud");
    boolean custom = m.text("palette").equals("Custom");
    if(softPanels() && !custom) return HudPalette.resolve(0xFF14161C,0xFF14161C,0xFFF4F4F6,0xFFF4F4F6,false);
    return HudPalette.resolve(custom ? m.color("start") : Theme.surface(),
        custom ? m.color("end") : Theme.surfaceEnd(),
        custom ? m.color("text") : Theme.text(),
        custom ? m.color("highlight") : Theme.accent(), m.flag("readable"));
  }

  private static int hudColor(String key) {
    var p = palette();
    return switch (key) {
      case "start" -> p.start();
      case "end" -> p.end();
      case "text" -> p.text();
      case "muted" -> p.muted();
      default -> p.highlight();
    };
  }

  private static void background(DrawContext g, float w, float height,
      double widgetOpacity, boolean glass, boolean accent) {
    var style = XVisuals.config().module("hud");
    if(softPanels()) {
      if(glass) Glass.rounded(g,0,0,w,height,(float)style.number("radius"),
          Colors.alpha(hudColor("start"),Math.clamp(widgetOpacity*style.number("opacity")/.40,.05,.94)));
      return;
    }
    float radius = (float) style.number("radius");
    int start = hudColor("start"), end = hudColor("end");
    String direction = style.text("gradient");
    if (direction.equals("Solid")) end = start;
    double alpha = Math.min(.95, widgetOpacity * style.number("opacity") / .68);
    if (style.flag("readable")) alpha = HudPalette.MIN_OPACITY + .08 * alpha;
    if (glass) {
      if (style.flag("border")) Glass.gradient(g, 0, 0, w, height, radius,
          Colors.alpha(hudColor("highlight"), alpha * .22),
          Colors.alpha(style.text("palette").equals("Custom") ? end : Theme.secondary(), alpha * .15), direction);
      float inset = style.flag("border") ? .65f : 0;
      Glass.gradient(g, inset, inset, w - inset * 2, height - inset * 2,
          Math.max(0, radius - inset), Colors.alpha(start, alpha), Colors.alpha(end, alpha), direction);
    }
    if (accent && style.flag("accent")) Glass.gradient(g, 5, height - 1.5f,
        Math.max(1, w - 10), 1, .5f, hudColor("highlight"),
        style.text("palette").equals("Custom") ? style.color("end") : Theme.secondary(), "Horizontal");
  }

  public static void preview(DrawContext g, float x, float y) {
    if(softPanels()) {
      g.getMatrices().pushMatrix();g.getMatrices().translate(x,y);
      background(g,88,30,.62,true,false);
      centeredLabel(g,"FPS: 218",44,11);
      g.getMatrices().translate(96,0);background(g,78,30,.62,true,false);
      centeredLabel(g,"0 Ping",39,11);
      g.getMatrices().translate(86,0);background(g,88,30,.62,true,false);
      centeredLabel(g,"5:12 PM",44,11);
      g.getMatrices().popMatrix();return;
    }
    g.getMatrices().pushMatrix();
    g.getMatrices().translate(x, y);
    background(g, 245, 28, .62, true, true);
    g.getMatrices().popMatrix();
    Glass.logo(g, x + 14, y + 14, 6, hudColor("highlight"));
    Glass.text(g, "144 FPS    24 ms    XYZ  128 64 32", x + 28, y + 10, hudColor("text"));
    Glass.scaled(g, "LIVE PREVIEW", x + 257, y + 11, .65f, Theme.muted());
  }

  private HudManager() {}
}
