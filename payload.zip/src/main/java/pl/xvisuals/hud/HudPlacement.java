package pl.xvisuals.hud;

/** Pixel positioning shared by editor controls. No collision avoidance: overlap is intentional. */
public final class HudPlacement {
  private HudPlacement() {}
  public static double scale(double requested,double x,double y,double w,double h,double viewportW,double viewportH) {
    double fit=Math.min(Math.max(0,viewportW-x)/w,Math.max(0,viewportH-y)/h);
    return Math.min(fit,Math.clamp(Double.isFinite(requested)?requested:1,.25,2.5));
  }
  public static double position(double value, double extent, double viewport, boolean snap, double grid) {
    double max = Math.max(0, viewport - extent);
    if (!Double.isFinite(value)) return 0;
    if (snap) {
      double step = Double.isFinite(grid) ? Math.max(1, grid) : 8;
      value = Math.round(value / step) * step;
      double middle = max / 2;
      if (Math.abs(value - middle) <= 3) value = middle;
    }
    return Math.clamp(value, 0, max);
  }
}
