package pl.xvisuals.hud;

import pl.xvisuals.config.VisualConfig.HudState;
import java.util.Map;
import java.util.function.ToIntFunction;

/** Initial placement only; detached widgets keep the user's saved position. */
public final class HudDefaultLayout {
  public static final int OPTIONAL = 2;
  public static final String[] OPTIONAL_WIDGETS = {
      "Direction", "Server", "Biome", "Armor", "Effects", "Keystrokes", "CPS", "Memory", "Session"
  };
  private HudDefaultLayout() {}

  public static void layout(Map<String, HudState> widgets, int width, int height,
                            ToIntFunction<String> widgetWidth, ToIntFunction<String> widgetHeight) {
    String[][] rows = {{"Logo", "Brand", "Username", "FPS", "Ping", "Clock"}, {"Coordinates", "Speed"}};
    double y = 8;
    for (int row = 0; row < rows.length; row++) {
      double x = 8, tallest = 0;
      for (String name : rows[row]) {
        var h = widgets.get(name);
        if (h == null) continue;
        double w = widgetWidth.applyAsInt(name) * h.scale, hh = widgetHeight.applyAsInt(name) * h.scale;
        if (x + w > width - 8 && x > 8) { x = 8; y += tallest + 3; tallest = 0; }
        // Reserve each default slot even while disabled. Already detached
        // widgets keep their saved positions when another default is placed.
        if (h.row == row) {
          h.x = x / width; h.y = y / height; h.row = -1;
        }
        x += w + 3; tallest = Math.max(tallest, hh);
      }
      y += Math.max(15, tallest) + 4;
    }
    boolean pending = false;
    for (String name : OPTIONAL_WIDGETS) {
      var h = widgets.get(name);
      if (h != null && h.row == OPTIONAL) pending = true;
    }
    if (!pending) return;

    // Reserve disabled defaults too. Enabling one later must not restart the
    // column over widgets whose initial placement has already been detached.
    double top = y + 4, x = 8, columnWidth = 0;
    y = top;
    for (String name : OPTIONAL_WIDGETS) {
      var h = widgets.get(name);
      if (h == null) continue;
      double w = widgetWidth.applyAsInt(name) * h.scale;
      double hh = widgetHeight.applyAsInt(name) * h.scale;
      if (y + hh > height - 8 && y > top) {
        x += columnWidth + 4; y = top; columnWidth = 0;
      }
      if (h.row == OPTIONAL) {
        h.x = x / width; h.y = y / height; h.row = -1;
      }
      y += hh + 4;
      columnWidth = Math.max(columnWidth, w);
    }
  }
}
