package pl.xvisuals.hud;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Pointer;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

/** Spotify SMTC connection; create, poll and close on the same worker thread. */
public final class NativeWindowsMediaBridge implements AutoCloseable {
  private static final class Api {
    private final com.sun.jna.NativeLibrary library;
    Api(String path){library=com.sun.jna.NativeLibrary.getInstance(path);}
    Pointer media_open(){return library.getFunction("media_open").invokePointer(new Object[]{});}
    Pointer media_poll(Pointer context){return library.getFunction("media_poll").invokePointer(new Object[]{context});}
    void media_close(Pointer context){library.getFunction("media_close").invokeVoid(new Object[]{context});}
  }

  private static Api api;
  private final Pointer context;

  private static synchronized Api load() throws IOException {
    if (api != null) return api;
    String arch = System.getProperty("os.arch", "");
    if (!arch.equals("amd64") && !arch.equals("x86_64"))
      throw new IOException("Windows media requires an x64 Java runtime");
    try (var source = NativeWindowsMediaBridge.class.getResourceAsStream(
        "/assets/xvisuals/media/windows-x64/visuals-media.dll")) {
      if (source == null) throw new IOException("Bundled Windows media library is missing");
      var library = Files.createTempFile("visuals-media-", ".dll");
      library.toFile().deleteOnExit();
      Files.copy(source, library, StandardCopyOption.REPLACE_EXISTING);
      try { api = new Api(library.toAbsolutePath().toString()); }
      catch (LinkageError error) { throw new IOException("Cannot load Windows media library", error); }
    }
    return api;
  }

  public NativeWindowsMediaBridge() throws IOException {
    context = load().media_open();
    if (context == null) throw new IOException("Cannot initialize Windows media connection");
  }

  public String poll() throws IOException {
    if (closed) throw new IOException("Windows media connection is closed");
    Pointer result = api.media_poll(context);
    if (result == null) throw new IOException("Windows media returned an empty response");
    return result.getString(0, "UTF-8");
  }

  public boolean command(int action) { return !closed && api.library.getFunction("media_command").invokeInt(new Object[]{context,action})==1; }

  private boolean closed;
  @Override public void close() {
    if (!closed) { closed = true; api.media_close(context); }
  }
}
