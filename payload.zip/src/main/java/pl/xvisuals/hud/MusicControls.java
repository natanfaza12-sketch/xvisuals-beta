package pl.xvisuals.hud;
import pl.xvisuals.config.VisualConfig;
/** All entry points operate the same music switch and clear stale widget hiding. */
public final class MusicControls {
 public static void setEnabled(VisualConfig config,boolean enabled){
  config.module("music").enabled=enabled;
  var widget=config.widgets.get("Now Playing");
  if(widget!=null){widget.enabled=enabled;widget.hidden=!enabled;}
 }
 private MusicControls(){}
}
