package pl.xvisuals.hud;

import java.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import pl.xvisuals.XVisuals;
import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.gui.themes.Theme;
import pl.xvisuals.modules.entity.TargetHud;

/** Widgety HUD wzorowane na Soup Visuals (SOUP-1.0, Copyright 2025-2026 Padej_), przepisane pod 1.21.11. */
public final class SoupHud {
  public static final List<String> NAMES =
      List.of("Target HUD", "Potions", "Cooldowns", "Notifications", "Modules List", "HotKeys");
  private static final Map<String, Boolean> PREV = new HashMap<>();
  private static final List<Object[]> NOTES = new ArrayList<>();

  public static boolean owns(String name) { return NAMES.contains(name); }

  /** Co klatke: wykrywa wlaczenie/wylaczenie modulow dla powiadomien. */
  public static void poll() {
    if (!XVisuals.ready()) return;
    boolean first = PREV.isEmpty();
    for (var m : pl.xvisuals.modules.Modules.ALL) {
      boolean now = XVisuals.config().on(m.id());
      Boolean old = PREV.put(m.id(), now);
      if (!first && old != null && old != now && !m.id().equals("hud"))
        NOTES.add(new Object[] {m.name() + (now ? " enabled" : " disabled"), System.currentTimeMillis(), now});
    }
    long t = System.currentTimeMillis();
    NOTES.removeIf(n -> t - (long) n[1] > 3500);
    while (NOTES.size() > 5) NOTES.remove(0);
  }

  private static List<String> modules() {
    List<String> out = new ArrayList<>();
    for (var m : pl.xvisuals.modules.Modules.ALL)
      if (XVisuals.config().on(m.id()) && !m.id().equals("hud") && !m.id().equals("targethud")) out.add(m.name());
    out.sort((a, b) -> Glass.textWidth(b) - Glass.textWidth(a));
    return out.size() > 14 ? out.subList(0, 14) : out;
  }

  private static List<String[]> hotkeys() {
    List<String[]> out = new ArrayList<>();
    for (var m : pl.xvisuals.modules.Modules.ALL) {
      var st = XVisuals.config().module(m.id());
      if (st == null || !st.enabled) continue;
      String k = st.text("key");
      if (k.isBlank() || k.equals("key.keyboard.unknown")) continue;
      try { out.add(new String[] {m.name(), InputUtil.fromTranslationKey(k).getLocalizedText().getString().toUpperCase(Locale.ROOT)}); }
      catch (RuntimeException ignored) {}
    }
    return out;
  }

  private static List<String[]> potions(boolean editor) {
    List<String[]> out = new ArrayList<>();
    var p = MinecraftClient.getInstance().player;
    if (p != null)
      for (var e : p.getStatusEffects()) {
        long s = e.isInfinite() ? -1 : e.getDuration() / 20;
        out.add(new String[] {e.getEffectType().value().getName().getString() + " " + (e.getAmplifier() + 1),
            s < 0 ? "inf" : String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60)});
      }
    if (out.isEmpty() && editor) { out.add(new String[] {"Speed 2", "1:30"}); out.add(new String[] {"Strength 1", "0:45"}); }
    return out;
  }

  private static List<Object[]> cooldowns(boolean editor) {
    List<Object[]> out = new ArrayList<>();
    var p = MinecraftClient.getInstance().player;
    if (p != null) {
      var inv = p.getInventory();
      Set<String> seen = new HashSet<>();
      for (int i = 0; i < 9; i++) cool(out, inv.getStack(i), seen);
      cool(out, p.getOffHandStack(), seen);
    }
    if (out.isEmpty() && editor) out.add(new Object[] {ItemStack.EMPTY, .6f});
    return out;
  }

  private static void cool(List<Object[]> out, ItemStack s, Set<String> seen) {
    var p = MinecraftClient.getInstance().player;
    if (s.isEmpty() || !seen.add(s.getItem().toString())) return;
    float pr = p.getItemCooldownManager().getCooldownProgress(s, 0f);
    if (pr > 0f) out.add(new Object[] {s, pr});
  }

  public static int width(String n) {
    switch (n) {
      case "Target HUD": return TargetHud.width();
      case "Potions": { int w = 90; for (var e : potions(true)) w = Math.max(w, Glass.textWidth(e[0] + e[1]) + 24); return w; }
      case "Cooldowns": return 84;
      case "Notifications": return 130;
      case "Modules List": { int w = 70; for (var s : modules()) w = Math.max(w, Glass.textWidth(s) + 12); return w; }
      default: { int w = 90; for (var e : hotkeys()) w = Math.max(w, Glass.textWidth(e[0] + e[1]) + 22); return w; }
    }
  }

  public static int height(String n) {
    switch (n) {
      case "Target HUD": return TargetHud.height();
      case "Potions": return 14 + 12 * Math.max(1, potions(true).size());
      case "Cooldowns": return 8 + 20 * Math.max(1, cooldowns(true).size());
      case "Notifications": return 26;
      case "Modules List": return 6 + 11 * Math.max(1, modules().size());
      default: return 14 + 11 * Math.max(1, hotkeys().size());
    }
  }

  private static void panel(DrawContext g, int w, int h) {
    Glass.rounded(g, 0, 0, w, h, 6, 0xC00A0D14);
    Glass.rounded(g, 0, 0, w, 1.5f, 1f, 0xFF000000 | (Theme.accent() & 0xFFFFFF));
  }

  public static void draw(DrawContext g, String n, boolean editor) {
    int w = width(n), h = height(n);
    int acc = 0xFF000000 | (Theme.accent() & 0xFFFFFF);
    switch (n) {
      case "Target HUD" -> TargetHud.draw(g, editor);
      case "Potions" -> {
        var l = potions(editor);
        if (l.isEmpty()) return;
        panel(g, w, h);
        Glass.text(g, "Potions", 6, 4, acc);
        int y = 15;
        for (var e : l) { Glass.text(g, e[0], 6, y, 0xFFFFFFFF); Glass.text(g, e[1], w - 6 - Glass.textWidth(e[1]), y, 0xFFB0B5C4); y += 12; }
      }
      case "Cooldowns" -> {
        var l = cooldowns(editor);
        if (l.isEmpty()) return;
        panel(g, w, h);
        int y = 5;
        for (var e : l) {
          g.drawItem((ItemStack) e[0], 4, y);
          float pr = (float) e[1];
          Glass.rounded(g, 24, y + 6, 54, 4, 2, 0x60000000);
          Glass.rounded(g, 24, y + 6, Math.max(3f, 54 * (1f - pr)), 4, 2, acc);
          y += 20;
        }
      }
      case "Notifications" -> {
        long t = System.currentTimeMillis();
        List<Object[]> l = new ArrayList<>(NOTES);
        if (l.isEmpty() && editor) l.add(new Object[] {"Module enabled", t, true});
        int y = 0;
        for (var e : l) {
          float age = (t - (long) e[1]) / 1000f;
          float in = Math.min(1f, age * 5f), out = age > 3f ? Math.max(0f, 1f - (age - 3f) * 2f) : 1f;
          float a = Math.min(in, out);
          if (a <= .02f) continue;
          int al = Math.round(255 * a);
          int shift = Math.round((1f - in) * 30);
          Glass.rounded(g, shift, y, w, 20, 6, (Math.round(al * .78f) << 24) | 0x0A0D14);
          Glass.rounded(g, shift, y + 3, 2, 14, 1, ((boolean) e[2] ? (al << 24) | 0x54DA83 : (al << 24) | 0xFF5058));
          Glass.text(g, (String) e[0], shift + 8, y + 6, (al << 24) | 0xFFFFFF);
          y += 23;
        }
      }
      case "Modules List" -> {
        var l = modules();
        if (l.isEmpty()) { if (!editor) return; l = List.of("Example Module"); }
        int y = 3;
        for (var s : l) {
          Glass.rounded(g, 0, y - 1, w, 11, 3, 0x900A0D14);
          Glass.text(g, s, w - 6 - Glass.textWidth(s), y, acc);
          y += 11;
        }
      }
      default -> {
        var l = hotkeys();
        if (l.isEmpty() && !editor) return;
        if (l.isEmpty()) { l = new ArrayList<>(); l.add(new String[] {"Example", "G"}); }
        panel(g, w, h);
        Glass.text(g, "HotKeys", 6, 4, acc);
        int y = 15;
        for (var e : l) { Glass.text(g, e[0], 6, y, 0xFFFFFFFF); Glass.text(g, "[" + e[1] + "]", w - 6 - Glass.textWidth("[" + e[1] + "]"), y, 0xFFB0B5C4); y += 11; }
      }
    }
  }

  private SoupHud() {}
}
