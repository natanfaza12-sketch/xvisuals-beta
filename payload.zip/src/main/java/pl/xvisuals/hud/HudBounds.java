package pl.xvisuals.hud;

/** Viewport fitting never rewrites the user's saved layout. */
public record HudBounds(double x, double y, double width, double height, double scale) {
  public static HudBounds fit(double x, double y, double scale, int widgetWidth, int widgetHeight, int width, int height) {
    double fitted = Math.min(Math.clamp(scale,.25,2.5), Math.min((double)Math.max(1,width)/widgetWidth,(double)Math.max(1,height)/widgetHeight));
    double w=widgetWidth*fitted,h=widgetHeight*fitted;
    return new HudBounds(Math.clamp(x*width,0,Math.max(0,width-w)),Math.clamp(y*height,0,Math.max(0,height-h)),w,h,fitted);
  }
}
