package pl.xvisuals.hud;

import java.util.Optional;
import net.minecraft.util.Identifier;

/** Integrations publish actual playback state; there is deliberately no demo track. */
public interface MusicProvider {
  Optional<Track> currentTrack();

  record Track(
      String title,
      String artist,
      long elapsedSeconds,
      long durationSeconds,
      Identifier albumArt,
      boolean playing,
      long elapsedMillis,
      String album,
      double playbackRate) {
    public Track(
        String title,
        String artist,
        long elapsedSeconds,
        long durationSeconds,
        Identifier albumArt,
        boolean playing,
        long elapsedMillis) {
      this(title, artist, elapsedSeconds, durationSeconds, albumArt, playing, elapsedMillis, "", 1);
    }

    public Track(
        String title,
        String artist,
        long elapsedSeconds,
        long durationSeconds,
        Identifier albumArt,
        boolean playing) {
      this(
          title, artist, elapsedSeconds, durationSeconds, albumArt, playing, elapsedSeconds * 1000);
    }
  }
}
