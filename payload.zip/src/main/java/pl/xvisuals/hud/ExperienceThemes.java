package pl.xvisuals.hud;

import java.util.List;

public final class ExperienceThemes {
  public static final List<String> NAMES = List.of("Void Stream", "Solar Edge", "Frostline", "Sakura Silk", "Chrono Grid", "Prism Wave");
  private static final int[][] COLORS = {{0xFF853FFF,0xFFE4BFFF},{0xFFFF6826,0xFFFFE58A},
      {0xFF43CFFF,0xFFE6FFFF},{0xFFFF78B7,0xFFFFD8EB},{0xFF20DBC9,0xFFB6FAFF},{0xFF8B79FF,0xFFFF9BDD}};
  public static String migrate(String name) {
    return switch(name) {
      case "Aurora", "Dusk" -> "Void Stream";
      case "Ember" -> "Solar Edge";
      case "Tidal", "Mist" -> "Frostline";
      case "Sage" -> "Sakura Silk";
      case "Reactor", "Circuit", "Graphite" -> "Chrono Grid";
      case "Prism" -> "Prism Wave";
      default -> name;
    };
  }
  public static int index(String name) { return Math.max(0,NAMES.indexOf(name)); }
  public static int color(int theme, int endpoint) { return COLORS[Math.clamp(theme,0,COLORS.length-1)][Math.clamp(endpoint,0,1)]; }
  /** Material at native bar coordinates. Time changes geometry and illumination, not just hue. */
  public static int pixel(int theme,double x,double y,double seconds,int a,int b) {
    double t=Double.isFinite(seconds)?seconds:0;
    double v=y/5.,u=x/182.,light=.25,mix=u;
    switch(theme) {
      case 0 -> {
        double ridge=.5+.24*Math.sin(x*.07-t*2)+.1*Math.sin(x*.21+t);
        light=.2+.9*Math.exp(-Math.pow((v-ridge)*7,2));
        light+=.3*Math.exp(-Math.pow((wrap(x-t*28,55)-27)/3,2));
        mix=.5+.5*Math.sin(x*.04-t+v*3);
      }
      case 1 -> {
        double crack=Math.abs(Math.sin(x*.17+v*5+Math.sin(x*.4-t*2)));
        light=.3+.6*Math.pow(1-crack,4)+.4*Math.exp(-Math.pow((v-.8)*9,2));
        light*=.8+.2*Math.sin(x*.13+t*3);mix=Math.clamp(light,0,1);
      }
      case 2 -> {
        double facet=wrap(x*.1+v*2-t*.4,2);
        light=facet<1?.75:.32;
        light+=.6*Math.exp(-Math.pow((facet-1)*12,2));
        mix=.5+.5*Math.sin(x*.08+v*3+t);
      }
      case 3 -> {
        double ribbon=.5+.22*Math.sin(x*.06-t*1.4);
        double petal=wrap(x-t*16,23)-11.5;
        light=.3+.55*Math.exp(-Math.pow((v-ribbon)*6,2));
        light+=.4*Math.exp(-petal*petal/5-Math.pow((v-.5-.2*Math.sin(t+x*.1))*6,2));
        mix=.5+.5*Math.sin(x*.035-t*.6);
      }
      case 4 -> {
        double cell=Math.floor(x/10),local=wrap(x,10);
        double scan=Math.exp(-Math.pow((wrap(x-t*35,182)-91)/13,2));
        light=local<1?.08:.3+.45*(.5+.5*Math.sin(cell*.6-t*3))+scan*.4;
        if(v<.18||v>.82)light*=.55;mix=scan;
      }
      default -> {
        double wave=.5+.28*Math.sin(x*.07-t*2);
        light=.3+.65*Math.exp(-Math.pow((v-wave)*6,2));
        light+=.2*Math.sin(x*.22+v*5+t*2);mix=.5+.5*Math.sin(x*.055+v*2-t);
      }
    }
    int tint=pl.xvisuals.util.Colors.mix(a,b,mix);
    int r=(int)Math.clamp(((tint>>16)&255)*light,0,255);
    int g=(int)Math.clamp(((tint>>8)&255)*light,0,255);
    int blue=(int)Math.clamp((tint&255)*light,0,255);
    return 0xFF000000|r<<16|g<<8|blue;
  }
  private static double wrap(double x,double period){return x-Math.floor(x/period)*period;}
  public static int pixels(double progress) {
    return Double.isFinite(progress) ? (int)Math.floor(Math.clamp(progress,0,1)*182) : 0;
  }
  private ExperienceThemes() {}
}
