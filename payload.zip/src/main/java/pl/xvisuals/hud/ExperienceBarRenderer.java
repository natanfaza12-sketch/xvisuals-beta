package pl.xvisuals.hud;

import pl.xvisuals.XVisuals;
import pl.xvisuals.gui.components.Glass;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Replaces only vanilla's XP bar; vanilla still owns its placement, visibility and level label. */
public final class ExperienceBarRenderer {
  private static final Material[] MATERIALS=new Material[40];
  private static final class Material {
    final Identifier id;final NativeImageBackedTexture texture;
    long frame=Long.MIN_VALUE;int a,b;
    Material(int slot){
      id=Identifier.of("xvisuals","dynamic/xp_"+slot);
      texture=new NativeImageBackedTexture(()->"Animated XP material",new NativeImage(364,10,false));
      MinecraftClient.getInstance().getTextureManager().registerTexture(id,texture);
    }
    void update(int theme,double time,int primary,int secondary){
      long next=(long)Math.floor((Double.isFinite(time)?time:0)*30);
      if(frame==next&&a==primary&&b==secondary)return;
      frame=next;a=primary;b=secondary;
      for(int py=0;py<10;py++)for(int px=0;px<364;px++)
        texture.getImage().setColorArgb(px,py,ExperienceThemes.pixel(theme,(px+.5)/2.,(py+.5)/2.,next/30.,a,b));
      texture.upload();
    }
  }
  public static boolean render(DrawContext g, float delta) {
    var c=MinecraftClient.getInstance();
    if(!XVisuals.ready() || !XVisuals.config().on("xp") || c.player==null) return false;
    if(c.player.getNextLevelExperience()<=0) return true;
    var m=XVisuals.config().module("xp");
    double time=(c.player.age+delta)/20.0*m.number("speed");
    if(!m.flag("animated") || XVisuals.config().module("performance").text("animation").equals("Off")) time=0;
    int width=Math.min(m.integer("width"),Math.max(1,g.getScaledWindowWidth()-4)),height=m.integer("height");
    int x=Math.clamp((g.getScaledWindowWidth()-width)/2+m.integer("offsetX"),1,Math.max(1,g.getScaledWindowWidth()-width-1));
    int y=Math.clamp(g.getScaledWindowHeight()-29+m.integer("offsetY"),1,Math.max(1,g.getScaledWindowHeight()-height-1));
    draw(g,x,y,width,height,
        c.player.experienceProgress,m.text("theme"),time,m.flag("custom"),m.color("color"),m.color("secondary"));
    return true;
  }

  public static void draw(DrawContext g,int x,int y,double progress,String name,double time,
      boolean custom,int primary,int secondary) {
    draw(g,x,y,182,5,progress,name,time,custom,primary,secondary);
  }
  public static void draw(DrawContext g,int x,int y,int width,int height,double progress,String name,double time,
      boolean custom,int primary,int secondary) {
    int theme=ExperienceThemes.index(name), fill=Double.isFinite(progress)?(int)Math.floor(Math.clamp(progress,0,1)*width):0;
    int a=custom?primary:ExperienceThemes.color(theme,0), b=custom?secondary:ExperienceThemes.color(theme,1);
    // Native dimensions and a strict earned-XP clip keep every theme accurate.
    Glass.rounded(g,x-1,y-1,width+2,height+2,2,0xA610141B);
    Glass.rounded(g,x,y,width,height,1,0xE52B303A);
    if(fill==0) return;
    int slot=theme+(custom?10:0)+(time==0?20:0);
    if(MATERIALS[slot]==null)MATERIALS[slot]=new Material(slot);
    Material material=MATERIALS[slot];material.update(theme,time,a,b);
    g.enableScissor(x,y,x+fill,y+height);
    try {
      // One textured draw, rather than hundreds of small GUI shapes each frame.
      g.drawTexture(RenderPipelines.GUI_TEXTURED,material.id,x,y,0,0,width,height,364,10,364,10);
    } finally {
      g.disableScissor();
    }
  }
  private ExperienceBarRenderer() {}
}
