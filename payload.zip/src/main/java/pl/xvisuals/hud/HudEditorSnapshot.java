package pl.xvisuals.hud;

import pl.xvisuals.config.ConfigStore;
import pl.xvisuals.config.VisualConfig;

/** The editor owns widget layout and the switches that determine widget visibility. */
public final class HudEditorSnapshot {
  public static String capture(VisualConfig config) { return ConfigStore.JSON.toJson(config); }

  public static void restore(VisualConfig config, String snapshot) {
    var saved = ConfigStore.parse(snapshot);
    config.widgets = saved.widgets;
    config.module("hud").enabled = saved.on("hud");
    config.module("music").enabled = saved.on("music");
  }

  private HudEditorSnapshot() {}
}
