package pl.xvisuals.hud;

import pl.xvisuals.util.Colors;

/** Contrast protection includes a white scene behind translucent HUD glass. */
public record HudPalette(int start, int end, int text, int highlight, int muted) {
  public static final double MIN_OPACITY = .90;
  private static int lastStart, lastEnd, lastText, lastHighlight;
  private static boolean lastProtect;
  private static HudPalette cached;

  public static HudPalette resolve(int start, int end, int text, int highlight, boolean protect) {
    if (cached != null && start == lastStart && end == lastEnd && text == lastText
        && highlight == lastHighlight && protect == lastProtect) return cached;
    lastStart = start; lastEnd = end; lastText = text; lastHighlight = highlight; lastProtect = protect;
    if (protect) {
      start = surface(start); end = surface(end);
      int a = Colors.mix(0xFFFFFFFF, start, MIN_OPACITY);
      int b = Colors.mix(0xFFFFFFFF, end, MIN_OPACITY);
      text = readable(text, a, b);
      highlight = readable(highlight, a, b);
      return cached = new HudPalette(start, end, text, highlight,
          readable(Colors.mix(text, start, .22), a, b));
    }
    return cached = new HudPalette(start, end, text, highlight, Colors.mix(text, start, .22));
  }

  private static int surface(int color) {
    // Preserve dark custom colors; compress only overly bright backgrounds.
    double luminance = luminance(color);
    if (luminance <= .055) return color;
    double lo = 0, hi = 1;
    for (int i = 0; i < 10; i++) {
      double t = (lo + hi) * .5;
      if (luminance(Colors.mix(color, 0xFF10131B, t)) > .055) lo = t; else hi = t;
    }
    return Colors.mix(color, 0xFF10131B, hi);
  }

  private static int readable(int color, int a, int b) {
    double target = 4.5 * (Math.max(luminance(a), luminance(b)) + .05) - .05;
    if (luminance(color) >= target) return color;
    double lo = 0, hi = 1;
    for (int i = 0; i < 10; i++) {
      double t = (lo + hi) * .5;
      if (luminance(Colors.mix(color, 0xFFFFFFFF, t)) < target) lo = t; else hi = t;
    }
    return Colors.mix(color, 0xFFFFFFFF, hi);
  }

  public static double luminance(int color) {
    return .2126 * linear((color >> 16) & 255) + .7152 * linear((color >> 8) & 255)
        + .0722 * linear(color & 255);
  }
  private static double linear(int channel) {
    double s = channel / 255.0;
    return s <= .04045 ? s / 12.92 : Math.pow((s + .055) / 1.055, 2.4);
  }
}
