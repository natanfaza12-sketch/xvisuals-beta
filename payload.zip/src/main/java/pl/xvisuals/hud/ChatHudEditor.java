package pl.xvisuals.hud;

import pl.xvisuals.XVisuals;
import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.gui.themes.Theme;
import java.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Mouse editing only consumes gestures that begin on a visible HUD widget. */
public final class ChatHudEditor {
  private String active;
  private boolean resizing;
  private double offsetX, offsetY;

  private int width() {
    return MinecraftClient.getInstance().getWindow().getScaledWidth();
  }

  private int height() {
    return MinecraftClient.getInstance().getWindow().getScaledHeight();
  }

  private String at(double x, double y) {
    if (MinecraftClient.getInstance().options.hudHidden) return null;
    var names = new ArrayList<>(XVisuals.config().widgets.keySet());
    Collections.reverse(names);
    for (String name : names) {
      var h = XVisuals.config().widgets.get(name);
      if (!HudManager.visible(name, false) || h.locked) continue;
      var b = HudManager.bounds(name, width(), height());
      if (Glass.contains(
          x,
          y,
          b.x(), b.y(), b.width(), b.height())) return name;
    }
    return null;
  }

  public void render(DrawContext g, int mx, int my) {
    if (MinecraftClient.getInstance().options.hudHidden)
      return;
    String name = active == null ? at(mx, my) : active;
    if (name != null) {
      var b = HudManager.bounds(name, width(), height());
      float x = (float)b.x(), y = (float)b.y(), w = (float)b.width(), hh = (float)b.height();
      float handle = Math.min(6, Math.min(w, hh) * .35f);
      Glass.rounded(g, x + w - handle, y + hh - handle, handle, handle, 1, Theme.accent());
      // The resize handle is enough feedback here; names and scale belong in HUD studio.
    }
  }

  public boolean click(double x, double y, int button) {
    if (button != 0) return false;
    if(HudManager.musicClick(x,y))return true;
    active = at(x, y);
    if (active == null) return false;
    var h = XVisuals.config().widgets.get(active);
    var b = HudManager.bounds(active, width(), height());
    h.x=b.x()/width(); h.y=b.y()/height(); h.scale=b.scale();
    h.row = -1;
    offsetX = x - h.x * width();
    offsetY = y - h.y * height();
    double handle = Math.min(8, Math.min(HudManager.widgetWidth(active),
        HudManager.widgetHeight(active)) * h.scale * .35);
    resizing = offsetX > HudManager.widgetWidth(active) * h.scale - handle
        && offsetY > HudManager.widgetHeight(active) * h.scale - handle;
    return true;
  }

  public boolean drag(double x, double y) {
    if (active == null) return false;
    var h = XVisuals.config().widgets.get(active);
    if (resizing)
      h.scale =
          Math.max(
              .25,
              Math.min(
                  2.5,
                  Math.max(
                      (x - h.x * width()) / HudManager.widgetWidth(active),
                      (y - h.y * height()) / HudManager.widgetHeight(active))));
    else {
      double px = x - offsetX, py = y - offsetY;
      var options = XVisuals.config().module("hud");
      long window = MinecraftClient.getInstance().getWindow().getHandle();
      if (org.lwjgl.glfw.GLFW.glfwGetKey(window,org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT_SHIFT)==1
          || org.lwjgl.glfw.GLFW.glfwGetKey(window,org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_SHIFT)==1) {
        double grid = Math.max(1, options.number("grid"));
        px = Math.round(px / grid) * grid;
        py = Math.round(py / grid) * grid;
      }
      h.x = px / width();
      h.y = py / height();
    }
    if(resizing) h.scale=HudPlacement.scale(h.scale,h.x*width(),h.y*height(),
        HudManager.widgetWidth(active),HudManager.widgetHeight(active),width(),height());
    clamp(active);
    XVisuals.STORE.dirty();
    return true;
  }

  public boolean release() {
    boolean consumed = active != null;
    active = null;
    if (consumed) XVisuals.STORE.save();
    return consumed;
  }

  public boolean scroll(double x, double y, double amount) {
    String name = at(x, y);
    if (name == null) return false;
    var h = XVisuals.config().widgets.get(name);
    var b = HudManager.bounds(name, width(), height());
    h.row=-1; h.x=b.x()/width(); h.y=b.y()/height(); h.scale=b.scale();
    h.scale = Math.max(.25, Math.min(2.5, h.scale + amount * .05));
    clamp(name);
    XVisuals.STORE.dirty();
    return true;
  }

  private void clamp(String name) {
    HudManager.clamp(name, width(), height());
  }
}

