package pl.xvisuals.hud.lyrics;

/** Line-timed lyrics have no exact word timestamps: distribute time by word length. */
public final class LyricStyle {
  /** Entrance animation is decorative, never a guess at when each word is sung. */
  public static double entrance(long elapsedMillis) {
    return Math.clamp(elapsedMillis / 180.0, 0, 1);
  }

  public static double wordProgress(double progress, int before, int length, int total) {
    return Math.clamp((progress * Math.max(1, total) - before) / Math.max(1, length), 0, 1);
  }

  public static String prefix(String text, double progress) {
    int count = (int) Math.ceil(Math.clamp(progress, 0, 1) * text.codePointCount(0, text.length()));
    return text.substring(0, text.offsetByCodePoints(0, count));
  }

  public static double decay(double age, double duration) {
    double t = Math.clamp(age / Math.max(.1, duration), 0, 1);
    return 1 - t * t * (3 - 2 * t);
  }

  private LyricStyle() {}
}
