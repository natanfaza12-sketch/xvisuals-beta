package pl.xvisuals.hud.lyrics;

/** Shared card state: seeking and silent gaps must never retain another phrase. */
public record LyricCard(String current,String next,double progress) {
  public static LyricCard at(LyricTimeline timeline,long time,long duration,boolean showNext) {
    int index=timeline.indexAt(time);
    if(index<0)return new LyricCard("","",0);
    var line=timeline.lines().get(index);
    if(line.text().isBlank())return new LyricCard("","",0);
    long end=timeline.endAt(index,duration);
    if(time>=end)return new LyricCard("","",0);
    double progress=Math.clamp((double)(time-line.millis())/Math.max(1,end-line.millis()),0,1);
    String next=showNext&&index+1<timeline.lines().size()?timeline.lines().get(index+1).text():"";
    return new LyricCard(line.text(),next,progress);
  }
}
