package pl.xvisuals.hud.lyrics;

import java.net.http.HttpClient;
import java.security.KeyStore;
import java.time.Duration;
import java.util.Locale;
import javax.net.ssl.*;

/** Scoped Windows trust fallback; hostname and certificate verification remain enabled. */
public final class LyricsHttp {
  private static HttpClient windows;
  public static boolean certificateFailure(Throwable error) {
    for (Throwable cause = error; cause != null; cause = cause.getCause())
      if (cause instanceof SSLHandshakeException) return true;
    return false;
  }
  public static synchronized HttpClient windowsClient() throws Exception {
    if (!System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("windows")) return null;
    if (windows == null) {
      KeyStore roots = KeyStore.getInstance("Windows-ROOT");
      roots.load(null, null);
      TrustManagerFactory trust = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
      trust.init(roots);
      SSLContext tls = SSLContext.getInstance("TLS");
      tls.init(null, trust.getTrustManagers(), null);
      windows = HttpClient.newBuilder().sslContext(tls).connectTimeout(Duration.ofSeconds(5)).build();
    }
    return windows;
  }
  private LyricsHttp() {}
}
