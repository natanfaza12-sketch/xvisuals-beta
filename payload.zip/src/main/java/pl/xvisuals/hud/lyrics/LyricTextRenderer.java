package pl.xvisuals.hud.lyrics;

import pl.xvisuals.XVisuals;
import pl.xvisuals.gui.FontSelection;
import pl.xvisuals.util.BoundedCache;
import pl.xvisuals.util.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.*;
import net.minecraft.util.Identifier;

/** Shared word renderer for the Spotify card, HUD, and world anchors. No frame-rate-dependent timers. */
final class LyricTextRenderer {
  private record LayoutKey(LyricTimeline timeline,int index,long duration,String font,int width,int rows) {
    @Override public int hashCode(){return java.util.Objects.hash(System.identityHashCode(timeline),index,duration,font,width,rows);}
    @Override public boolean equals(Object other){return other instanceof LayoutKey key&&timeline==key.timeline&&index==key.index&&duration==key.duration&&font.equals(key.font)&&width==key.width&&rows==key.rows;}
  }
  private record TextKey(String font,String text) {}
  private static final BoundedCache<LayoutKey,LyricLayout> LAYOUTS=new BoundedCache<>(16);
  private static final BoundedCache<TextKey,Text> TEXT=new BoundedCache<>(512);
  static String font(){return XVisuals.config().module("music").text("lyricFont");}
  private static Text text(String value) {
    String font=font();return TEXT.computeIfAbsent(new TextKey(font,value),key->Text.literal(value).setStyle(Style.EMPTY.withFont(
        font.equals("Inter")?new StyleSpriteSource.Font(Identifier.of("xvisuals","lyrics")):FontSelection.preview(font))));
  }
  static LyricLayout layout(LyricTimeline timeline,int index,long duration,int width,int rows) {
    return LAYOUTS.computeIfAbsent(new LayoutKey(timeline,index,duration,font(),width,rows),key->
        new LyricLayout(timeline.wordsAt(index,duration),value->MinecraftClient.getInstance().textRenderer.getWidth(text(value)),width,rows));
  }
  static void draw(DrawContext g,LyricLayout.Page page,long time,float cx,float y,float scale,double opacity,boolean preview,double retirement) {
    if(page.words().isEmpty()||opacity<.015)return;
    var settings=XVisuals.config().module("music");
    boolean motion=!preview&&!XVisuals.config().module("performance").text("animation").equals("Off")&&!settings.text("lyricAnimation").equals("Still");
    String style=settings.text("lyricStyle"),animation=settings.text("lyricAnimation");
    double amount=motion?settings.number("lyricMotion"):0;
    boolean retired=retirement>=0;
    g.getMatrices().pushMatrix();g.getMatrices().translate(cx-page.width()*scale/2,y);g.getMatrices().scale(scale,scale);
    int index=0;
    for(var placed:page.words()) {
      var word=placed.word();double progress=retired?1:word.progress(time);
      double enter=retired?1:Math.clamp((time-word.start())/160.,0,1);
      double pulse=retired?0:Math.sin(Math.PI*Math.clamp((time-word.start())/360.,0,1));
      boolean started=retired||time>=word.start(),singing=started&&!retired&&time<word.end();
      double alpha=opacity;
      if(!preview&&!retired) {
        if(style.equals("Word reveal")||style.equals("Typewriter"))alpha*=started?.22+.78*(1-Math.pow(1-enter,3)):0;
        else if(style.equals("Spotlight"))alpha*=singing?1:started?.45:.13;
        else alpha*=started?1:.35;
      }
      if(alpha<.015){index++;continue;}
      float x=placed.x(),dy=placed.y(),zoom=1;
      if(!preview&&started) {
        float arrival=(float)Math.pow(1-enter,3);
        if(animation.equals("Float")||animation.equals("Lift"))dy+=amount*(3*arrival-1.1*pulse);
        if(animation.equals("Pop")||animation.equals("Bounce"))zoom+=(float)(.12*pulse*amount);
        if(animation.equals("Slide"))x+=amount*5*arrival;
        if(animation.equals("Soft zoom"))zoom-=(float)(.08*arrival*amount);
      }
      if(retired&&amount>0) {
        double phase=((index*37)%17)/16.;String exit=settings.text("lyricExit");
        if(exit.equals("Disintegrate")||exit.equals("Ash")) {
          alpha*=Math.clamp(1-retirement*(.35+phase*.5),0,1);
          x+=(phase-.5)*retirement*12*amount;dy+=retirement*retirement*(exit.equals("Ash")?12:-12)*amount;
        }else if(exit.equals("Drift"))dy-=retirement*9*amount;
        else if(exit.equals("Glitch"))x+=Math.sin(retirement*18+index)*retirement*3*amount;
      }
      g.getMatrices().pushMatrix();g.getMatrices().translate(x+placed.width()/2f,dy+5);g.getMatrices().scale(zoom,zoom);g.getMatrices().translate(-placed.width()/2f,-5);
      var label=text(word.text());var renderer=MinecraftClient.getInstance().textRenderer;
      if(preview)g.drawText(renderer,label,0,0,Colors.alpha(0xC2C9D9,alpha),true);
      else {
        if(style.equals("Typewriter")&&!retired)g.enableScissor(0,-2,Math.max(1,(int)Math.ceil(placed.width()*progress)),13);
        g.drawText(renderer,label,0,0,Colors.alpha(0xE0E5EF,alpha),true);
        double fill=style.equals("Word reveal")||style.equals("Spotlight")?started?1:0:progress;
        int sweep=(int)Math.ceil(placed.width()*fill);
        if(sweep>0) {
          int from=settings.color("lyricColor"),to=settings.flag("lyricGradient")?settings.color("lyricColorEnd"):from;
          if(settings.flag("lyricGlow")&&singing)g.drawText(renderer,label,0,-1,Colors.alpha(Colors.mix(from,to,.5),alpha*.14),false);
          int bands=settings.flag("lyricGradient")?4:1;
          for(int band=0;band<bands;band++) {
            int left=placed.width()*band/bands,right=Math.min(sweep,placed.width()*(band+1)/bands);
            if(right<=left)continue;
            g.enableScissor(left,-2,right,13);
            double blend=(placed.x()+(left+right)*.5)/Math.max(1,page.width());
            g.drawText(renderer,label,0,0,Colors.alpha(Colors.mix(from,to,blend),alpha),true);g.disableScissor();
          }
        }
        if(style.equals("Typewriter")&&!retired)g.disableScissor();
      }
      if(retired&&amount>0&&settings.number("lyricEffects")>0&&!settings.text("lyricExit").equals("Fade")&&index%2==0) {
        int count=(int)Math.ceil(settings.number("lyricEffects")*3);
        for(int k=0;k<count;k++) {
          float dx=placed.width()*.5f+(float)(Math.sin(index*12.3+k*4)*retirement*22*amount);
          float fragmentY=(float)(retirement*retirement*(settings.text("lyricExit").equals("Ash")?22:-20)*amount)-k*3;
          int color=Colors.alpha(settings.color("lyricColor"),alpha*(1-retirement)*.55);
          g.fill((int)dx,(int)fragmentY,(int)dx+1,(int)fragmentY+1,color);
        }
      }
      g.getMatrices().popMatrix();index++;
    }
    g.getMatrices().popMatrix();
  }
  private LyricTextRenderer(){}
}
