package pl.xvisuals.hud.lyrics;

import java.util.*;
import java.util.function.ToIntFunction;

/** Small, pre-measured phrase windows preserve every word instead of shrinking/truncating long lines. */
public final class LyricLayout {
  public record Placed(LyricTimeline.Word word,int x,int y,int width) {}
  public record Page(List<Placed> words,int width,int height,long start) {
    public Page {words=List.copyOf(words);}
  }
  private final List<Page> pages;
  public LyricLayout(List<LyricTimeline.Word> words,ToIntFunction<String> measure,int limit,int rows) {
    var result=new ArrayList<Page>();var placed=new ArrayList<Placed>();
    int x=0,y=0,w=0,space=measure.applyAsInt(" ");
    for(var word:words) {
      int width=measure.applyAsInt(word.text());
      boolean wrap=x>0&&x+width>limit;
      if(!placed.isEmpty()&&((wrap&&y+15>=rows*15)||placed.size()>=16)) {
        result.add(center(placed,w,y+12));placed=new ArrayList<>();x=0;y=0;w=0;wrap=false;
      }
      if(wrap){x=0;y+=15;}
      placed.add(new Placed(word,x,y,width));w=Math.max(w,x+width);x+=width+space;
    }
    if(!placed.isEmpty())result.add(center(placed,w,y+12));
    pages=List.copyOf(result);
  }
  private static Page center(List<Placed> words,int width,int height) {
    Map<Integer,Integer> widths=new HashMap<>();for(var p:words)widths.merge(p.y,p.x+p.width,Math::max);
    return new Page(words.stream().map(p->new Placed(p.word,p.x+(width-widths.get(p.y))/2,p.y,p.width)).toList(),width,height,words.getFirst().word.start());
  }
  public List<Page> pages(){return pages;}
  public int indexAt(long time){int result=0;for(int i=1;i<pages.size()&&pages.get(i).start<=time;i++)result=i;return result;}
  public Page at(long time){return pages.isEmpty()?new Page(List.of(),0,0,0):pages.get(indexAt(time));}
  public int maxWidth(){return pages.stream().mapToInt(Page::width).max().orElse(1);}
}
