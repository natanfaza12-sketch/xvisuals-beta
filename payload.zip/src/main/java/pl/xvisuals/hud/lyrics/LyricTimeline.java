package pl.xvisuals.hud.lyrics;

import java.text.BreakIterator;
import java.util.*;
import java.util.regex.Pattern;

/** Immutable LRC data. Embedded word times are retained; inferred times are explicitly marked. */
public record LyricTimeline(List<Line> lines) {
  private static final Pattern TIME=Pattern.compile("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?\\]");
  private static final Pattern WORD_TIME=Pattern.compile("<(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?>");
  private static final Pattern OFFSET=Pattern.compile("\\[offset:([+-]?\\d+)\\]",Pattern.CASE_INSENSITIVE);
  public record Word(long start,long end,String text,boolean exact) {
    public double progress(long time){return Math.clamp((double)(time-start)/Math.max(1,end-start),0,1);}
  }
  public record Line(long millis,String text,List<Word> words,long explicitEnd) {
    public Line(long millis,String text){this(millis,text,List.of(),-1);}
    public Line {words=List.copyOf(words);}
  }
  public LyricTimeline {lines=List.copyOf(lines);}
  private static long stamp(String minutes,String seconds,String fraction) {
    if(Integer.parseInt(seconds)>=60)return -1;
    return Long.parseLong(minutes)*60000+Long.parseLong(seconds)*1000+
        (fraction==null?0:Integer.parseInt((fraction+"000").substring(0,3)));
  }
  private static String clean(String text){return text.replaceAll("<[^>]*>","").replaceAll("[\\p{Cntrl}§]","").strip();}
  public static LyricTimeline parse(String lrc) {
    if(lrc==null||lrc.length()>500_000)return new LyricTimeline(List.of());
    long offset=0;var metadata=OFFSET.matcher(lrc);
    if(metadata.find())try{offset=Math.clamp(Long.parseLong(metadata.group(1)),-60000,60000);}catch(NumberFormatException ignored){}
    TreeMap<Long,Line> sorted=new TreeMap<>();
    for(String row:lrc.split("\\R")) {
      var matcher=TIME.matcher(row);List<Long> times=new ArrayList<>();int end=0;
      while(matcher.find()) {
        long time=stamp(matcher.group(1),matcher.group(2),matcher.group(3));
        if(time>=0){times.add(time);end=matcher.end();}
      }
      if(times.isEmpty())continue;
      String raw=row.substring(end),text=clean(raw);
      if(text.length()>500)text=text.substring(0,text.offsetByCodePoints(0,Math.min(500,text.codePointCount(0,text.length()))));
      for(long base:times) {
        long at=Math.max(0,base+offset),shift=offset+base-times.getFirst();
        List<Word> words=new ArrayList<>();long explicitEnd=-1,last=-1;int previousEnd=0;boolean valid=true;
        var wordMatcher=WORD_TIME.matcher(raw);
        while(wordMatcher.find()) {
          long time=stamp(wordMatcher.group(1),wordMatcher.group(2),wordMatcher.group(3));
          time=time<0?-1:Math.max(0,time+shift);
          String part=clean(raw.substring(previousEnd,wordMatcher.start()));
          if(time<at||time<last||(!part.isBlank()&&time<=Math.max(at,last))){valid=false;break;}
          if(!part.isBlank())words.add(new Word(last<0?at:last,time,part,last>=0));
          last=time;previousEnd=wordMatcher.end();
        }
        if(valid&&last>=0) {
          String tail=clean(raw.substring(previousEnd));
          if(!tail.isBlank())words.add(new Word(last,-1,tail,true));else explicitEnd=last;
          // Do not let an oversized, truncated source retain hidden words.
          if(!clean(raw).equals(text)) {words.clear();explicitEnd=-1;}
        } else {words.clear();explicitEnd=-1;}
        sorted.put(at,new Line(at,text,words,explicitEnd));
      }
      if(sorted.size()>5000)break;
    }
    return new LyricTimeline(new ArrayList<>(sorted.values()));
  }
  public int indexAt(long millis) {
    int low=0,high=lines.size()-1,result=-1;
    while(low<=high){int mid=(low+high)>>>1;if(lines.get(mid).millis<=millis){result=mid;low=mid+1;}else high=mid-1;}return result;
  }
  public long endAt(int index,long duration) {
    var line=lines.get(index);
    long end=index+1<lines.size()?lines.get(index+1).millis:duration>line.millis?duration:line.millis+4000;
    if(duration>0)end=Math.min(end,duration);
    if(line.explicitEnd>=line.millis)end=Math.min(end,line.explicitEnd);
    // Without a closing cue, don't stretch a handful of words across a long instrumental outro.
    if(line.words.isEmpty()&&end-line.millis>12000)end=line.millis+Math.min(12000,Math.max(2500,tokens(line.text).size()*650L));
    else if(!line.words.isEmpty()&&line.explicitEnd<0) {
      var last=line.words.getLast();
      if(last.end<0&&end-last.start>12000)end=last.start+Math.min(12000,Math.max(2500,tokens(last.text).size()*650L));
    }
    return Math.max(line.millis,end);
  }
  public List<Word> wordsAt(int index,long duration) {
    if(index<0||index>=lines.size())return List.of();
    var line=lines.get(index);long end=endAt(index,duration);
    if(line.text.isBlank()||end<=line.millis)return List.of();
    List<Word> result=new ArrayList<>();
    if(line.words.isEmpty())distribute(result,line.text,line.millis,end,false);
    else for(var word:line.words) {
      long stop=Math.min(end,word.end<0?end:word.end);
      if(word.start<stop)distribute(result,word.text,word.start,stop,word.exact&&word.end>=0);
    }
    return List.copyOf(result);
  }
  static List<String> tokens(String text) {
    if(text.isBlank())return List.of();
    if(!text.matches(".*\\s.*")&&text.codePoints().anyMatch(c->Character.UnicodeScript.of(c)==Character.UnicodeScript.HAN
        ||Character.UnicodeScript.of(c)==Character.UnicodeScript.HIRAGANA||Character.UnicodeScript.of(c)==Character.UnicodeScript.KATAKANA)) {
      var iterator=BreakIterator.getCharacterInstance(Locale.ROOT);iterator.setText(text);List<String> result=new ArrayList<>();
      int start=iterator.first();for(int next=iterator.next();next!=BreakIterator.DONE;start=next,next=iterator.next())result.add(text.substring(start,next));
      return result;
    }
    return List.of(text.strip().split("\\s+"));
  }
  private static double weight(String text) {
    int letters=(int)text.codePoints().filter(Character::isLetterOrDigit).count();
    return Math.max(1,Math.sqrt(letters))+(text.matches(".*[,.!?;:]$")?.35:0);
  }
  private static void distribute(List<Word> output,String text,long start,long end,boolean exact) {
    var tokens=tokens(text);double total=tokens.stream().mapToDouble(LyricTimeline::weight).sum(),used=0;
    for(int i=0;i<tokens.size();i++) {
      String token=tokens.get(i);long from=start+Math.round((end-start)*used/total);used+=weight(token);
      long to=i+1==tokens.size()?end:start+Math.round((end-start)*used/total);
      output.add(new Word(from,Math.max(from+1,to),token,exact&&tokens.size()==1));
    }
  }
}
