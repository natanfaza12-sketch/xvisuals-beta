package pl.xvisuals.hud.lyrics;

import pl.xvisuals.XVisuals;
import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.rendering.Projection;
import pl.xvisuals.util.Colors;
import java.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.joml.Vector3f;

/** One placement per phrase. Off-screen phrases never trigger relocation or raycasts. */
final class WorldLyrics {
  private static final class Phrase {
    final LyricLayout layout;
    final long start,end;
    final int width;
    Vec3d anchor;
    boolean visible;
    double retired=-1;
    Phrase(LyricTimeline timeline,int index,long duration) {
      start=timeline.lines().get(index).millis();end=timeline.endAt(index,duration);
      layout=LyricTextRenderer.layout(timeline,index,duration,170,2);width=layout.maxWidth();
    }
  }
  private static String lastFont="";

  private static final ArrayDeque<Phrase> HISTORY = new ArrayDeque<>();
  private static Phrase current;
  private static int active = -2, ticks;
  private static long lastTime = -1;
  private static final Projection PROJECTION = new Projection();
  private static final Projection.Point POINT = new Projection.Point();
  private static long placements, rays;

  private static double seconds() {
    return System.nanoTime() / 1e9;
  }

  private static pl.xvisuals.config.VisualConfig.ModuleState settings() {
    return XVisuals.config().module("music");
  }

  static void reset() {
    current = null;
    HISTORY.clear();
    active = -2;
    lastTime = -1;
  }

  static void tick(MinecraftClient c, LyricTimeline timeline, int index, long time, long duration) {
    double now = seconds();
    if(!lastFont.equals(LyricTextRenderer.font())){reset();lastFont=LyricTextRenderer.font();}
    if (lastTime >= 0 && (time < lastTime - 350 || time > lastTime + 1500)) reset();
    lastTime = time;
    var s = settings();
    HISTORY.removeIf(p -> now - p.retired >= s.number("lyricDecay"));
    if (index != active) {
      if (current != null && current.anchor != null) {
        current.retired = now;
        HISTORY.addLast(current);
      }
      current = null;
      active = index;
      if (index >= 0 && time < timeline.endAt(index,duration) && !timeline.lines().get(index).text().isBlank()) {
        var line = timeline.lines().get(index);
        current = new Phrase(timeline,index,duration);
        current.anchor = place(c, current, index);
      }
    }
    if (current != null && time >= current.end) {
      if (current.anchor != null) {
        current.retired = now;
        HISTORY.addLast(current);
      }
      current = null;
    }
    while (HISTORY.size() > s.integer("lyricHistory")) HISTORY.removeFirst();
    // At most four phrases, three terrain rays each, five times per second.
    if (++ticks % 4 == 0) {
      if(current!=null&&current.anchor==null&&time<current.end)current.anchor=place(c,current,index);
      PROJECTION.begin(c, 1);
      if (current != null) visibility(c, current);
      for (Phrase p : HISTORY) visibility(c, p);
    }
  }

  private static Vec3d place(MinecraftClient c, Phrase p, int index) {
    placements++;
    var s = settings();
    double distance = s.number("lyricDistance");
    double side =
        s.text("lyricSideMode").equals("Left")
            ? -1
            : s.text("lyricSideMode").equals("Right") ? 1 : index % 2 == 0 ? 1 : -1;
    // Keep placed phrases fixed, but fit new phrases into nearby clear space indoors.
    for (double range : new double[] {distance, Math.max(3,distance*.5), 3})
    for (double sign : new double[] {side, -side}) {
      if (sign != side && !s.text("lyricSideMode").equals("Alternate")) break;
      Vector3f offset =
          new Vector3f(
                  (float) (sign * range * s.number("lyricSide")),
                  (float) (range * (range<=6?.02:(.10 + (index % 3) * .055))),
                  (float) -range)
              .rotate(c.gameRenderer.getCamera().getRotation());
      Vec3d candidate = c.gameRenderer.getCamera().getCameraPos().add(offset.x, offset.y, offset.z);
      if (clear(c, p, candidate)) {
        p.visible = true;
        return candidate;
      }
    }
    return null;
  }

  private static void visibility(MinecraftClient c, Phrase p) {
    p.visible =
        p.anchor != null
            && p.anchor.squaredDistanceTo(PROJECTION.camera) < 96 * 96
            && PROJECTION.project(p.anchor, POINT)
            && POINT.visible
            && clear(c, p, p.anchor);
  }

  private static boolean clear(MinecraftClient c, Phrase p, Vec3d anchor) {
    Vec3d camera = c.gameRenderer.getCamera().getCameraPos();
    Vector3f right = new Vector3f(1, 0, 0).rotate(c.gameRenderer.getCamera().getRotation());
    double fov=((pl.xvisuals.mixins.GameRendererAccessor)c.gameRenderer).visuals$getFov(c.gameRenderer.getCamera(),1,true);
    double aspect=(double)c.getWindow().getScaledWidth()/Math.max(1,c.getWindow().getScaledHeight());
    double extent = Math.min(p.width * .5 * .05 * settings().number("lyricScale"),camera.distanceTo(anchor)*Math.tan(Math.toRadians(fov)/2)*aspect*.32);
    for (int i = -1; i <= 1; i++) {
      Vec3d edge = anchor.add(right.x * extent * i, right.y * extent * i, right.z * extent * i);
      rays++;
      if (c.world
              .raycast(
                  new RaycastContext(
                      camera,
                      edge,
                      RaycastContext.ShapeType.COLLIDER,
                      RaycastContext.FluidHandling.NONE,
                      c.player))
              .getType()
          != HitResult.Type.MISS) return false;
    }
    return true;
  }

  static void render(DrawContext g, float tick, long time) {
    var c = MinecraftClient.getInstance();
    PROJECTION.begin(c, tick);
    for (Phrase p : HISTORY) draw(g, c, p, time);
    if (current != null) draw(g, c, current, time);
  }

  private static void draw(DrawContext g, MinecraftClient c, Phrase p, long time) {
    if (p.anchor == null
        || !p.visible
        || !PROJECTION.project(p.anchor, POINT)
        || !POINT.visible
        || POINT.depth < 2) return;
    var s = settings();
    double deadAge = p.retired < 0 ? 0 : seconds() - p.retired;
    double death = p.retired < 0 ? 0 : Math.clamp(deadAge / s.number("lyricDecay"), 0, 1);
    double opacity =
        p.retired < 0
            ? .8 + .2 * LyricStyle.entrance(time - p.start)
            : LyricStyle.decay(deadAge, s.number("lyricDecay"));
    if (opacity < .015) return;
    float fov =
        ((pl.xvisuals.mixins.GameRendererAccessor) c.gameRenderer)
            .visuals$getFov(c.gameRenderer.getCamera(), PROJECTION.tick, true);
    float scale =
        (float)
            (.05
                * s.number("lyricScale")
                * PROJECTION.height
                / (2 * POINT.depth * Math.tan(Math.toRadians(fov) / 2)));
    scale = Math.min(scale, PROJECTION.width * .32f / Math.max(1, p.width));
    if (scale < .12) return;
    // Retired phrases finish their last word window, while active windows follow the same clock as the HUD.
    var page=p.layout.at(p.retired<0?time:p.end-1);
    LyricTextRenderer.draw(g,page,time,(float)POINT.x,(float)POINT.y,scale,opacity,false,p.retired<0?-1:death);
  }

  static Vec3d developmentAnchor() {
    return current == null ? null : current.anchor;
  }

  static long developmentPlacements() {
    return placements;
  }

  static long developmentRays() {
    return rays;
  }

  static int developmentHistory() {
    return HISTORY.size();
  }

  private WorldLyrics() {}
}
