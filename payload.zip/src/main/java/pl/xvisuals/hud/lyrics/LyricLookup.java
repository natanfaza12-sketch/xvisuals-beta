package pl.xvisuals.hud.lyrics;

import com.google.gson.*;
import java.net.*;
import java.net.http.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;

/** Public LRCLIB search; requires an exact title/artist and matching duration. */
public final class LyricLookup {
  public record Result(LyricTimeline timeline, String status) {}

  private static final HttpClient HTTP =
      HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();

  public Result fetch(String title, String artist, long duration) throws Exception {
    return fetch(title, artist, duration, "");
  }

  public Result fetch(String title, String artist, long duration, String album) throws Exception {
    if (duration <= 0) return empty("Waiting for song duration");
    String query = "track_name=" + encode(title) + "&artist_name=" + encode(artist);
    if (!album.isBlank()) query += "&album_name=" + encode(album);
    Exception failure = null;
    Result missing = empty("No timed lyrics for this song");
    // The exact endpoint and search have independent failure modes. Keep both bounded,
    // and retain strict recording matching rather than substituting unrelated lyrics.
    for (String endpoint : new String[]{"get?" + query + "&duration=" + duration, "search?" + query}) {
      var request = HttpRequest.newBuilder(URI.create("https://lrclib.net/api/" + endpoint))
          .timeout(Duration.ofSeconds(8)).header("User-Agent", "XVisuals (Minecraft lyrics)").GET().build();
      try {
        HttpResponse<byte[]> response;
        try { response = request(HTTP, request); }
        catch (Exception error) {
          if (!LyricsHttp.certificateFailure(error)) throw error;
          HttpClient windows = LyricsHttp.windowsClient();
          if (windows == null) throw error;
          response = request(windows, request);
        }
        if (response.statusCode() == 404) continue;
        if (response.statusCode() != 200) throw new java.io.IOException("Lyrics service unavailable (HTTP " + response.statusCode() + ")");
        var json = JsonParser.parseString(new String(response.body(), StandardCharsets.UTF_8));
        JsonArray rows;
        if (json.isJsonArray()) rows = json.getAsJsonArray();
        else { rows = new JsonArray(); rows.add(json); }
        Result selected = select(rows, title, artist, duration, album);
        if (!selected.timeline().lines().isEmpty()) return selected;
        missing = selected;
      } catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); throw interrupted; }
      catch (Exception error) { failure = error; }
    }
    // An unavailable endpoint must remain retryable, rather than becoming a cached miss.
    if (failure != null) throw failure;
    return missing;
  }

  private static HttpResponse<byte[]> request(HttpClient client, HttpRequest request) throws Exception {
    var future = client.sendAsync(request, info -> new BoundedBody());
    try {
      return future.get(15, TimeUnit.SECONDS);
    } finally {
      if (!future.isDone()) future.cancel(true);
    }
  }

  private static final class BoundedBody implements HttpResponse.BodySubscriber<byte[]> {
    private final HttpResponse.BodySubscriber<byte[]> delegate =
        HttpResponse.BodySubscribers.ofByteArray();
    private Flow.Subscription subscription;
    private int size;
    private boolean done;

    public CompletionStage<byte[]> getBody() {
      return delegate.getBody();
    }

    public void onSubscribe(Flow.Subscription s) {
      subscription = s;
      delegate.onSubscribe(s);
    }

    public void onNext(List<ByteBuffer> buffers) {
      if (done) return;
      for (ByteBuffer buffer : buffers) {
        if (buffer.remaining() > 2_000_000 - size) {
          done = true;
          subscription.cancel();
          delegate.onError(new java.io.IOException("Oversized lyrics response"));
          return;
        }
        size += buffer.remaining();
      }
      delegate.onNext(buffers);
    }

    public void onError(Throwable error) {
      if (!done) {
        done = true;
        delegate.onError(error);
      }
    }

    public void onComplete() {
      if (!done) {
        done = true;
        delegate.onComplete();
      }
    }
  }

  public static Result select(JsonArray records, String title, String artist, long duration) {
    return select(records, title, artist, duration, "");
  }

  public static Result select(
      JsonArray records, String title, String artist, long duration, String album) {
    Result fallback = empty("No timed lyrics for this song");
    double best = Double.MAX_VALUE;
    Result result = null;
    for (var entry : records) {
      try {
        var row = entry.getAsJsonObject();
        if (!album.isBlank()
            && (!row.has("albumName")
                || row.get("albumName").isJsonNull()
                || !normalize(album).equals(normalize(row.get("albumName").getAsString()))))
          continue;
        if (!normalize(title).equals(normalize(row.get("trackName").getAsString()))
            || !normalize(artist).equals(normalize(row.get("artistName").getAsString()))) continue;
        double difference = Math.abs(row.get("duration").getAsDouble() - duration);
        if (duration <= 0 || difference > 2) continue;
        if (row.has("instrumental") && row.get("instrumental").getAsBoolean())
          fallback = empty("Instrumental — no lyrics");
        if (!row.has("syncedLyrics") || row.get("syncedLyrics").isJsonNull()) continue;
        var timeline = LyricTimeline.parse(row.get("syncedLyrics").getAsString());
        if (!timeline.lines().isEmpty() && difference < best) {
          best = difference;
          result = new Result(timeline, "Lyrics · LRCLIB");
        }
      } catch (RuntimeException ignored) {
      }
    }
    return result == null ? fallback : result;
  }

  public static Result empty(String status) {
    return new Result(new LyricTimeline(List.of()), status);
  }

  private static String normalize(String value) {
    return value.strip().replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
  }

  private static String encode(String value) {
    return URLEncoder.encode(value, StandardCharsets.UTF_8);
  }
}
