package pl.xvisuals.hud.lyrics;

import pl.xvisuals.XVisuals;
import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.hud.HudManager;
import pl.xvisuals.util.Colors;
import java.util.*;
import java.util.concurrent.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Tick-owned playback and world anchors; lyric fetching never blocks the game thread. */
public final class Lyrics {
  private record Key(String title, String artist, long duration, String album) {}

  private record Cached(LyricLookup.Result result, long expires) {}

  private static final ExecutorService WORKER =
      Executors.newSingleThreadExecutor(
          r -> {
            Thread t = new Thread(r, "X Visuals lyrics");
            t.setDaemon(true);
            return t;
          });
  private static final Map<Key, Cached> CACHE = new LinkedHashMap<>(32, .75f, true);
  private static Future<LyricLookup.Result> pending;
  private static Key key;
  private static LyricLookup.Result result = LyricLookup.empty("");
  private static Object world;
  private static long retryAt;
  private static String lastMode = "Off";

  static void seedDevelopmentTrack(String title, String artist, long duration, String lrc) {
    if (!net.fabricmc.loader.api.FabricLoader.getInstance().isDevelopmentEnvironment()
        || !Boolean.getBoolean("visuals.lyrics")) return;
    CACHE.put(
        new Key(title, artist, duration, ""),
        new Cached(
            new LyricLookup.Result(LyricTimeline.parse(lrc), "Development fixture"),
            Long.MAX_VALUE));
  }

  public static void tick(MinecraftClient c) {
    var settings = XVisuals.config().module("music");
    String mode = settings.text("lyrics");
    var track = HudManager.currentTrack();
    if (!settings.enabled || mode.equals("Off") || track == null || track.title().isBlank()) {
      reset();
      return;
    }
    if (!mode.equals(lastMode) || world != c.world) {
      WorldLyrics.reset();
    }
    lastMode = mode;
    world = c.world;
    Key next = new Key(track.title(), track.artist(), track.durationSeconds(), track.album());
    if (!next.equals(key)) {
      reset();
      key = next;
      result = LyricLookup.empty("Finding timed lyrics…");
      retryAt = 0;
    }
    long now = System.currentTimeMillis();
    if (pending != null && pending.isDone()) {
      try {
        result = pending.get();
        CACHE.put(key, new Cached(result, now + (result.timeline().lines().isEmpty()?60_000:30 * 60_000)));
        while (CACHE.size() > 32) CACHE.remove(CACHE.keySet().iterator().next());
        retryAt = now + (result.timeline().lines().isEmpty()?60_000:30 * 60_000);
      } catch (ExecutionException | CancellationException e) {
        result = LyricLookup.empty("Lyrics service unavailable — retrying shortly");
        retryAt = now + 15_000;
      }
      catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); return; }
      pending = null;
    }
    if (pending == null && now >= retryAt) {
      Cached cached = CACHE.get(key);
      if (cached != null && cached.expires > now) {
        result = cached.result;
        retryAt = cached.expires;
      } else {
        Key requested = key;
        pending = WORKER.submit(() -> new LyricLookup().fetch(
            requested.title, requested.artist, requested.duration, requested.album));
        retryAt = Long.MAX_VALUE;
      }
    }
    int index = result.timeline().indexAt(position());
    if ((mode.equals("In world") || mode.equals("Both")) && c.world != null && c.player != null) {
      WorldLyrics.tick(
          c, result.timeline(), index, position(), key == null ? 0 : key.duration * 1000);
    } else WorldLyrics.reset();
  }

  private static void reset() {
    if (pending != null) pending.cancel(true);
    pending = null;
    key = null;
    result = LyricLookup.empty("");
    WorldLyrics.reset();
  }

  /** Guard rendering too: a media session can disappear between lyric ticks. */
  static boolean hasActiveTrack() {
    var track = HudManager.currentTrack();
    return XVisuals.config().on("music") && track != null && !track.title().isBlank() && key != null
        && key.title.equals(track.title()) && key.artist.equals(track.artist())
        && key.album.equals(track.album()) && key.duration == track.durationSeconds();
  }

  private static long position() {
    long extrapolated = HudManager.currentTrackPosition();
    return extrapolated
        + Math.round(XVisuals.config().module("music").number("lyricOffset") * 1000);
  }

  private static LyricLayout.Page upcoming(LyricTimeline timeline,int index,LyricLayout layout,long time,int width,int rows) {
    int page=layout.indexAt(time);
    if(page+1<layout.pages().size())return layout.pages().get(page+1);
    if(index+1<timeline.lines().size())return LyricTextRenderer.layout(timeline,index+1,key.duration*1000,width,rows).at(0);
    return null;
  }

  public static void renderCard(DrawContext g) {
    if(!hasActiveTrack())return;
    var timeline=result.timeline();long time=position();int index=timeline.indexAt(time);
    if(index<0){
      if(timeline.lines().isEmpty())Glass.scaled(g,result.status(),9,76,Math.min(.7f,220f/Math.max(1,Glass.textWidth(result.status()))),0xFF9CA7B8);
      return;
    }
    if(time>=timeline.endAt(index,key.duration*1000))return;
    var layout=LyricTextRenderer.layout(timeline,index,key.duration*1000,235,1);
    var page=layout.at(time);if(page.words().isEmpty())return;
    float scale=Math.min(.92f,216f/Math.max(1,page.width()));
    LyricTextRenderer.draw(g,page,time,119,73,scale,1,false,-1);
    if(XVisuals.config().module("music").flag("lyricNext")) {
      var next=upcoming(timeline,index,layout,time,235,1);
      if(next!=null)LyricTextRenderer.draw(g,next,time,119,91,Math.min(.65f,216f/Math.max(1,next.width())),.55,true,-1);
    }
  }

  public static void render(DrawContext g,float tick) {
    var c=MinecraftClient.getInstance();var settings=XVisuals.config().module("music");String mode=settings.text("lyrics");
    if(mode.equals("Off")||!hasActiveTrack()||c.world==null||c.player==null||c.options.hudHidden||c.currentScreen!=null)return;
    var timeline=result.timeline();long time=position();int index=timeline.indexAt(time);
    if(index<0){
      if(timeline.lines().isEmpty()&&!mode.equals("In player")&&!result.status().isBlank()) {
        String status=result.status();float scale=Math.min(.65f,g.getScaledWindowWidth()*.75f/Math.max(1,Glass.textWidth(status)));
        Glass.scaled(g,status,(g.getScaledWindowWidth()-Glass.textWidth(status)*scale)/2,g.getScaledWindowHeight()-35,scale,0xCCB8BEC9);
      }
      return;
    }
    if((mode.equals("Sing-along HUD")||mode.equals("Both"))&&time<timeline.endAt(index,key.duration*1000)) {
      var layout=LyricTextRenderer.layout(timeline,index,key.duration*1000,250,2);var page=layout.at(time);
      if(!page.words().isEmpty()) {
        int w=g.getScaledWindowWidth(),h=g.getScaledWindowHeight();
        float scale=(float)Math.min(settings.number("lyricScale"),w*.65/Math.max(1,page.width()));
        var next=settings.flag("lyricNext")?upcoming(timeline,index,layout,time,250,1):null;
        float blockHeight=(page.height()+(next==null||next.words().isEmpty()?0:23))*scale;
        float hudY=(float)Math.clamp(h*settings.number("lyricY"),12,Math.max(12,h-blockHeight-16));
        var media=XVisuals.config().widgets.get("Now Playing");
        if(media!=null&&HudManager.visible("Now Playing",false)) {
          var bounds=HudManager.bounds("Now Playing",w,h);
          double mediaTop=bounds.y(),mediaLeft=bounds.x();
          double mediaRight=mediaLeft+bounds.width();
          double mediaBottom=mediaTop+bounds.height();
          if(mediaRight>w*.2&&mediaLeft<w*.8&&hudY+blockHeight>mediaTop-10&&hudY<mediaBottom+10) {
            if(mediaTop-blockHeight-12>=12)hudY=(float)(mediaTop-blockHeight-12);
            else if(mediaBottom+blockHeight+24<h)hudY=(float)(mediaBottom+12);
          }
        }
        long end=timeline.endAt(index,key.duration*1000);
        double fade=Math.clamp((end-time)/160.,0,1);
        Glass.rounded(g,w*.5f-page.width()*scale/2-8,hudY-4,page.width()*scale+16,page.height()*scale+8,7,Colors.alpha(0x080B14,fade*.28));
        LyricTextRenderer.draw(g,page,time,w*.5f,hudY,scale,fade,false,-1);
        if(next!=null)LyricTextRenderer.draw(g,next,time,w*.5f,hudY+(page.height()+8)*scale,
            Math.min(scale*.65f,w*.6f/Math.max(1,next.width())),fade*.48,true,-1);
      }
    }
    if(mode.equals("In world")||mode.equals("Both"))WorldLyrics.render(g,tick,time);
  }

  public static void close() {
    reset();
    WORKER.shutdownNow();
    CACHE.clear();
  }

  private Lyrics() {}
}
