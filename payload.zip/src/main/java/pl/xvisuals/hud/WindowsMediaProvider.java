package pl.xvisuals.hud;

import com.google.gson.*;
import pl.xvisuals.XVisuals;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.*;
import javax.imageio.ImageIO;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.*;
import net.minecraft.util.Identifier;

/** Spotify-only Windows SMTC bridge, with native polling and image decoding off-thread. */
public final class WindowsMediaProvider implements MusicProvider, AutoCloseable {
  private static final Identifier ART = Identifier.of("xvisuals", "media_art");
  private static volatile String connectionStatus="Connecting to Windows media…";
  public static String status() { return connectionStatus; }

  private record State(
      String title,
      String artist,
      String album,
      String key,
      PlaybackClock.Anchor clock,
      long received,
      byte[] art) {}

  private static final java.util.concurrent.atomic.AtomicInteger COMMAND = new java.util.concurrent.atomic.AtomicInteger(-1);
  public static void control(int action) { if(action>=0&&action<=2) COMMAND.compareAndSet(-1,action); }
  private volatile State latest;
  private volatile boolean running;
  private Thread worker;
  private volatile long retryAt;
  private static final org.slf4j.Logger LOG = org.slf4j.LoggerFactory.getLogger("xvisuals.media");
  private String artKey = "";
  private Identifier texture;
  private byte[] uploadedArt;
  private final boolean supported =
      System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("windows");

  public void tick() {
    var cfg = XVisuals.config();
    boolean enabled = cfg.on("music");
    if (!enabled) {
      if (running) close();
      return;
    }
    if (!supported) connectionStatus="Windows media is only available on Windows";
    if (supported
        && !running
        && (worker == null || !worker.isAlive())
        && System.currentTimeMillis() > retryAt) {
      running = true;
      connectionStatus="Connecting to Windows media…";
      retryAt = System.currentTimeMillis() + 5000;
      worker = new Thread(this::read, "X Visuals Windows media");
      worker.setDaemon(true);
      worker.start();
    }
    State state = latest;
    if (state == null) {
      clearArt();
      return;
    }
    if (!state.key.equals(artKey) || state.art != uploadedArt) {
      clearArt();
      artKey = state.key;
      uploadedArt = state.art;
      if (state.art != null)
        try {
          NativeImage image = NativeImage.read(new ByteArrayInputStream(state.art));
          MinecraftClient.getInstance()
              .getTextureManager()
              .registerTexture(
                  ART, new NativeImageBackedTexture(() -> "Now playing artwork", image));
          texture = ART;
        } catch (IOException ignored) {
        }
    }
  }

  private void clearArt() {
    if (texture != null) MinecraftClient.getInstance().getTextureManager().destroyTexture(ART);
    texture = null;
    artKey = "";
    uploadedArt = null;
  }

  private void read() {
    PlaybackClock clock = new PlaybackClock();
    try (var bridge = new NativeWindowsMediaBridge()) {
        int failedPolls=0;
        while (running) {
          Thread.sleep(100);
          if (!running) break;
          String line = bridge.poll();
          int action=COMMAND.getAndSet(-1);
          if(action>=0 && latest!=null) bridge.command(action);
          try {
            JsonObject o = JsonParser.parseString(line).getAsJsonObject();
            long receivedNanos = System.nanoTime(), receivedUtc = System.currentTimeMillis();
            if(o.has("ready")) { latest=null;clock.reset();connectionStatus="Open Spotify and play a song"; continue; }
            if(o.has("error")) {
              connectionStatus="Reconnecting to Windows media…";
              if(failedPolls==0) LOG.warn("Windows media read failed: {}", text(o,"error"));
              if(++failedPolls>=10) throw new IOException("Windows media session stopped responding");
              continue;
            }
            failedPolls=0;
            if(o.has("loading")) { latest=null;clock.reset();connectionStatus="Reading track information…"; continue; }
            if (o.has("artOnly")) {
              State before = latest;
              if (before != null && before.key.equals(text(o, "key"))) {
                byte[] art = decodeArt(text(o, "art"));
                latest =
                    new State(
                        before.title,
                        before.artist,
                        before.album,
                        before.key,
                        before.clock,
                        before.received,
                        art);
              }
              continue;
            }
            if (o.has("idle") || !o.has("title") || o.get("title").getAsString().isBlank()) {
              latest = null;
              connectionStatus="Open Spotify and play a song";
              clock.reset();
              continue;
            }
            State before = latest;
            String key = text(o, "key");
            byte[] art = before != null && before.key.equals(key) ? before.art : null;
            PlaybackClock.Anchor anchor =
                clock.update(
                    key,
                    o.get("positionMs").getAsLong(),
                    o.get("durationMs").getAsLong(),
                    o.get("playing").getAsBoolean(),
                    o.get("rate").getAsDouble(),
                    o.get("updatedUtc").getAsLong(),
                    o.get("sampledUtc").getAsLong(),
                    receivedUtc,
                    receivedNanos);
            latest =
                new State(
                    text(o, "title"),
                    text(o, "artist"),
                    text(o, "album"),
                    key,
                    anchor,
                    receivedNanos,
                    art);
            connectionStatus="Connected";
          } catch (RuntimeException error) {
            throw new IOException("Invalid Windows media response", error);
          }
        }
    } catch (InterruptedException ignored) {
      Thread.currentThread().interrupt();
    } catch (IOException | LinkageError error) {
      connectionStatus="Windows media unavailable — retrying";
      if (running) LOG.warn("Windows media could not connect: {}", error.toString());
    } finally {
      latest = null;
      running = false;
      retryAt = System.currentTimeMillis() + 3000;
    }
  }

  private static String text(JsonObject o, String key) {
    return o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : "";
  }

  private static byte[] decodeArt(String base64) {
    if (base64.isEmpty() || base64.length() > 2_800_000) return null;
    try (var input =
        ImageIO.createImageInputStream(
            new ByteArrayInputStream(Base64.getDecoder().decode(base64)))) {
      var readers = ImageIO.getImageReaders(input);
      if (!readers.hasNext()) return null;
      var reader = readers.next();
      try {
        reader.setInput(input);
        if (reader.getWidth(0) > 2048 || reader.getHeight(0) > 2048) return null;
        BufferedImage source = reader.read(0),
            small = new BufferedImage(192, 192, BufferedImage.TYPE_INT_ARGB);
        var g = small.createGraphics();
        g.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION,java.awt.RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g.drawImage(source, 0, 0, 192, 192, null);
        g.dispose();
        var out = new ByteArrayOutputStream();
        ImageIO.write(small, "png", out);
        return out.toByteArray();
      } finally {
        reader.dispose();
      }
    } catch (Exception ignored) {
      return null;
    }
  }

  @Override
  public Optional<Track> currentTrack() {
    State s = latest;
    if (s == null || System.nanoTime() - s.received > 8_000_000_000L) return Optional.empty();
    long elapsed = s.clock.positionAt(System.nanoTime());
    return Optional.of(
        new Track(
            s.title,
            s.artist,
            elapsed / 1000,
            Math.round(s.clock.duration() / 1000.0),
            texture,
            s.clock.playing(),
            elapsed,
            s.album,
            s.clock.rate()));
  }

  @Override
  public void close() {
    running = false;
    COMMAND.set(-1);
    Thread w = worker;
    if (w != null) w.interrupt();
    latest = null;
    clearArt();
  }
}
