package pl.xvisuals.util;

public final class Colors {
  public static int alpha(int color, double a) {
    return ((int) (Math.max(0, Math.min(1, a)) * 255) << 24) | (color & 0xFFFFFF);
  }

  public static int mix(int a, int b, double t) {
    t = Math.max(0, Math.min(1, t));
    return 0xFF000000
        | ((int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t) << 16)
        | ((int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t) << 8)
        | (int) ((a & 255) * (1 - t) + (b & 255) * t);
  }

  public static int parse(String hex) {
    try {
      return 0xFF000000 | Integer.parseInt(hex.replace("#", ""), 16);
    } catch (Exception e) {
      return 0xFFB88CFF;
    }
  }

  public static int rainbow(double t) {
    return java.awt.Color.HSBtoRGB((float) (t - Math.floor(t)), .5f, 1f) | 0xFF000000;
  }

  private Colors() {}
}
