package pl.xvisuals.util;

import java.util.LinkedHashMap;
import java.util.Map;

/** Access-ordered cache for render-thread-owned data. Never retains more than capacity entries. */
public final class BoundedCache<K,V> extends LinkedHashMap<K,V> {
  private final int capacity;
  public BoundedCache(int capacity) {
    super(Math.max(1, capacity), .75f, true);
    if (capacity < 1) throw new IllegalArgumentException("capacity must be positive");
    this.capacity = capacity;
  }
  @Override protected boolean removeEldestEntry(Map.Entry<K,V> eldest) {
    return size() > capacity;
  }
}
