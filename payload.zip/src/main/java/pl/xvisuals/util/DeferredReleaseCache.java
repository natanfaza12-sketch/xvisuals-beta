package pl.xvisuals.util;

import java.util.*;
import java.util.function.Consumer;

/** Render-thread LRU: evicted resources remain alive until the next frame. */
public final class DeferredReleaseCache<K, V> {
  private final int capacity;
  private final Map<K, V> entries = new LinkedHashMap<>(16, .75f, true);
  private final List<V> retired = new ArrayList<>();

  public DeferredReleaseCache(int capacity) {
    if (capacity < 1) throw new IllegalArgumentException("capacity must be positive");
    this.capacity = capacity;
  }

  public V get(K key) { return entries.get(key); }

  public void put(K key, V value) {
    V previous = entries.put(key, value);
    if (previous != null && previous != value) retired.add(previous);
    if (entries.size() > capacity) {
      var iterator = entries.values().iterator();
      retired.add(iterator.next());
      iterator.remove();
    }
  }

  public void beginFrame(Consumer<V> release) {
    retired.forEach(release);
    retired.clear();
  }
}
