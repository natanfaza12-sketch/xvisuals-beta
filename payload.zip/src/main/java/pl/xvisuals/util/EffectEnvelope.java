package pl.xvisuals.util;
/** A bounded envelope with zero velocity at appearance and disappearance. */
public final class EffectEnvelope {
 public static double smooth(double value){double t=Double.isFinite(value)?Math.clamp(value,0,1):0;return t*t*(3-2*t);}
 public static double fade(double progress,double attack,double release){
  if(!Double.isFinite(progress)||progress<=0||progress>=1)return 0;
  attack=Math.clamp(attack,.001,.49);release=Math.clamp(release,attack,.99);
  return smooth(progress/attack)*(1-smooth((progress-release)/(1-release)));
 }
 private EffectEnvelope(){}
}
