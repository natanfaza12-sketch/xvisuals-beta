package pl.xvisuals.util;

/** Animation time that freezes during pause, including the first resumed frame. */
public final class EffectClock {
  private long previous=Long.MIN_VALUE;
  private boolean wasPaused;
  private double seconds;
  public double sample(long nanos, boolean paused) {
    if (previous!=Long.MIN_VALUE && !paused && !wasPaused)
      seconds+=Math.max(0,nanos-previous)/1e9;
    previous=nanos;
    wasPaused=paused;
    return seconds;
  }
}
