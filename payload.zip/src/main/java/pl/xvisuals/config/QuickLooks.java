package pl.xvisuals.config;

import pl.xvisuals.modules.*;
import java.util.*;

/** Shared preset and bulk-edit rules, independent of rendering and input. */
public final class QuickLooks {
  public static final List<String> PRESETS = List.of("Max Visuals", "PvP Clean", "PvP Plus", "Cinematic", "High FPS", "Default");
  public static final List<String> SCOPES = List.of("All visuals", "Enabled only", "Combat", "Player effects", "World effects");
  public record Palette(String name, String primary, String secondary) {}
  public static final List<Palette> PALETTES = List.of(
      new Palette("Monochrome", "#FFFFFF", "#000000"),
      new Palette("Amethyst", "#BB85FF", "#73D9FF"),
      new Palette("Neon Mint", "#9EFF54", "#50EBCB"),
      new Palette("Sunset", "#FF8066", "#FFD166"),
      new Palette("Frost", "#75CFFF", "#E1F5FF"),
      new Palette("Rose", "#FF74BD", "#B794FF"),
      new Palette("Crimson", "#FF4569", "#FFAA7A"));
  private static final Set<String> COMBAT = Set.of("crystals", "anchorshader", "nametags", "hitfx",
      "damagefeedback", "afterimage", "swing", "totemparticles", "totemtexture", "totemsize", "totemghost", "deathghost", "explosionfx");
  private static final Set<String> ACCENTS = Set.of("secondary", "end", "outlineColor", "background", "highlight", "tailColor", "criticalColor", "absorptionColor", "lyricColor");
  private static final Set<String> STRENGTH = Set.of("opacity", "glow", "bloom", "density", "count", "amount", "fragments", "intensity");

  // Automatic themes opt in only generic accent effects. New modules retain their
  // authored palettes until explicitly reviewed; bulk colour editing is separate.
  private static final Set<String> THEME_EFFECTS = Set.of(
      "hitfx", "swing", "jumpcircles", "afterimage", "playerafterimage", "enemyanimations");

  public static boolean followsTheme(ModuleSpec spec) { return THEME_EFFECTS.contains(spec.id()); }

  public static void themeColors(VisualConfig c, String primary, String secondary) {
    if (!validColor(primary) || !validColor(secondary)) throw new IllegalArgumentException("Use #RRGGBB colours");
    for (var spec : Modules.ALL) {
      if (!followsTheme(spec)) continue;
      var state = c.module(spec.id());
      for (var setting : spec.settings()) {
        // Keep critical/status colours and all design/mode choices independent.
        if (setting.kind() == Setting.Kind.COLOR && Set.of("color", "start").contains(setting.key()))
          state.values.put(setting.key(), primary);
        if (setting.kind() == Setting.Kind.COLOR && Set.of("secondary", "end").contains(setting.key()))
          state.values.put(setting.key(), secondary);
        if (setting.kind() == Setting.Kind.BOOLEAN && setting.key().equals("gradient"))
          state.values.put(setting.key(), true);
      }
    }
  }

  public static void normalize(VisualConfig c) {
    if (!validColor(c.lookPrimary)) c.lookPrimary = "#FFFFFF";
    if (!validColor(c.lookSecondary)) c.lookSecondary = "#000000";
    if (c.lookScope == null || !SCOPES.contains(c.lookScope)) c.lookScope = "All visuals";
    if (c.lookMode == null || !List.of("Solid", "Gradient").contains(c.lookMode)) c.lookMode = "Gradient";
    if (c.lookPalette < 0 || c.lookPalette >= PALETTES.size()) c.lookPalette = 0;
  }

  public static boolean validColor(String value) { return value != null && value.matches("#[0-9a-fA-F]{6}"); }

  public static boolean includes(ModuleSpec spec, VisualConfig c, String scope) {
    if (spec.category().equals("Settings") || spec.id().equals("crosshair")) return false;
    return switch (scope) {
      case "Enabled only" -> c.on(spec.id());
      case "Combat" -> COMBAT.contains(spec.id());
      case "Player effects" -> spec.category().equals("Player");
      case "World effects" -> Set.of("World", "Environment", "Particles").contains(spec.category());
      default -> true;
    };
  }

  public static int colors(VisualConfig c, String primary, String secondary, boolean gradient, String scope) {
    if (!validColor(primary) || !validColor(secondary)) throw new IllegalArgumentException("Use #RRGGBB colours");
    if (!SCOPES.contains(scope)) throw new IllegalArgumentException("Choose an effect group");
    int changed = 0;
    for (var spec : Modules.ALL) {
      if (!includes(spec, c, scope)) continue;
      var m = c.module(spec.id());
      if (protectsHud(spec)) {
        boolean changedColor = false;
        for (var setting : spec.settings()) if (setting.kind() == Setting.Kind.COLOR) {
          m.values.put(setting.key(), gradient && ACCENTS.contains(setting.key()) ? secondary : primary);
          changedColor = true;
        }
        if (changedColor) changed++;
        continue;
      }
      boolean colored = false;
      for (var setting : spec.settings()) {
        if (setting.kind() == Setting.Kind.BOOLEAN && Set.of("custom", "customTint", "customColors").contains(setting.key()))
          m.values.put(setting.key(), true);
        if (Set.of("preset", "theme").contains(setting.key()) && setting.kind() == Setting.Kind.CHOICE && setting.choices().contains("Custom"))
          m.values.put(setting.key(), "Custom");
        if (setting.kind() != Setting.Kind.COLOR) continue;
        String color = gradient && ACCENTS.contains(setting.key()) ? secondary : primary;
        // Preserve shading on sculpted feathers while using the selected hue.
        if (setting.key().equals("shadow")) color = darken(primary);
        m.values.put(setting.key(), color);
        colored = true;
      }
      if (!colored) continue;
      changed++;
      if (spec.id().equals("particles")) put(c, "particles", "preset", "Cosmic");
      for (var setting : spec.settings()) {
        if (setting.kind() == Setting.Kind.BOOLEAN && Set.of("rainbow", "chromatic").contains(setting.key()))
          m.values.put(setting.key(), false);
        if (setting.key().equals("gradient") && setting.kind() == Setting.Kind.BOOLEAN)
          m.values.put(setting.key(), gradient);
        if (setting.kind() == Setting.Kind.CHOICE && Set.of("mode", "colorMode", "palette").contains(setting.key())) {
          if (gradient && setting.choices().contains("Gradient")) m.values.put(setting.key(), "Gradient");
          else if (setting.choices().contains("Custom")) m.values.put(setting.key(), "Custom");
          else if (setting.choices().contains("Static")) m.values.put(setting.key(), "Static");
          else if (setting.choices().contains("Solid")) m.values.put(setting.key(), "Solid");
        }
      }
      if (spec.category().equals("Entities") && m.values.containsKey("style"))
        put(c, spec.id(), "style", gradient ? "Gradient" : "Glow Outline");
    }
    if (scope.equals("All visuals") || scope.equals("Enabled only")) {
      c.accent = primary; c.secondary = gradient ? secondary : primary; c.theme = "Custom";
    }
    return changed;
  }

  private static String darken(String color) {
    int rgb = Integer.parseInt(color.substring(1), 16);
    return String.format(Locale.ROOT, "#%02X%02X%02X", (int)((rgb >> 16 & 255) * .42),
        (int)((rgb >> 8 & 255) * .42), (int)((rgb & 255) * .42));
  }

  /** Absolute levels based on defaults: repeated clicks cannot inflate particle counts. */
  public static int intensity(VisualConfig c, String level, String scope) {
    double factor = switch (level) { case "Subtle" -> .6; case "Balanced" -> 1; case "Vivid" -> 1.35; default -> throw new IllegalArgumentException("Unknown intensity"); };
    int changed = 0;
    for (var spec : Modules.ALL) {
      if (!includes(spec, c, scope)) continue;
      if (protectsHud(spec)) continue;
      boolean touched = false;
      for (var s : spec.settings()) {
        if (s.kind() != Setting.Kind.NUMBER || !STRENGTH.contains(s.key())) continue;
        double value = ((Number)s.initial()).doubleValue() * factor;
        value = Math.max(s.min(), Math.min(s.max(), Math.round(value / s.step()) * s.step()));
        c.module(spec.id()).values.put(s.key(), value); touched = true;
      }
      if (touched) changed++;
    }
    return changed;
  }

  public static boolean protectsHud(ModuleSpec spec) {
    return spec.category().equals("HUD") || spec.id().equals("crosshair");
  }

  /** Only explicit colour values may be replaced; future HUD fields stay protected too. */
  public static void preserveHud(VisualConfig previous, VisualConfig next) {
    var saved = ConfigStore.JSON.fromJson(ConfigStore.JSON.toJson(previous), VisualConfig.class);
    next.widgets = saved.widgets;
    for (var spec : Modules.ALL) if (protectsHud(spec)) {
      var state = saved.module(spec.id());
      var incoming = next.module(spec.id());
      for (var setting : spec.settings()) if (!spec.id().equals("crosshair") && setting.kind() == Setting.Kind.COLOR)
        state.values.put(setting.key(), incoming.values.get(setting.key()));
      next.modules.put(spec.id(), state);
    }
  }

  public static String caption(String name) {
    return switch (name) {
      case "Max Visuals" -> "Aurora, water, wings and layered violet effects";
      case "PvP Clean" -> "Small frost hits and totem rings; clear sightlines";
      case "PvP Plus" -> "Rose criticals, short trails and controlled shockwaves";
      case "Cinematic" -> "Chrome sky, silver water and restrained motion";
      case "High FPS" -> "Minimal hit feedback; no extra sky or world passes";
      default -> "Balanced everyday effects in violet and blue";
    };
  }

  public static void configurePreset(VisualConfig c, String name) {
    name = switch(name) { case "PvP" -> "PvP Clean"; case "Performance" -> "High FPS"; default -> name; };
    if (!PRESETS.contains(name)) return;
    var previous = ConfigStore.JSON.fromJson(ConfigStore.JSON.toJson(c), VisualConfig.class);
    // Start from current schema defaults so new settings never inherit stale recipes.
    for (var spec : Modules.ALL) c.modules.put(spec.id(), new VisualConfig.ModuleState(spec));
    c.modules.values().forEach(m -> m.enabled = false);
    boolean max = name.equals("Max Visuals"), clean = name.equals("PvP Clean"),
        plus = name.equals("PvP Plus"), cinema = name.equals("Cinematic"), fast = name.equals("High FPS");
    enable(c, "menu", "performance", "hitfx", "totemparticles");
    if (!fast) enable(c, "swing", "jumpcircles");
    String primary = max ? "#BB85FF" : clean ? "#98DCFF" : plus ? "#FF82BE" : cinema ? "#DCE4ED" : fast ? "#D5EBF5" : "#B5A0FF";
    String secondary = max ? "#73D9FF" : clean ? "#EAF8FF" : plus ? "#A69BFF" : cinema ? "#76899D" : fast ? "#8DBDCE" : "#80D5EC";
    colors(c, primary, secondary, true, "All visuals");
    put(c, "hud", "start", darken(primary)); put(c, "hud", "end", darken(secondary));
    put(c, "hud", "text", "#F3F5FF");
    put(c, "performance", "quality", fast ? "LOW" : clean ? "MEDIUM" : "HIGH");
    put(c, "performance", "adaptive", true);
    put(c, "performance", "targetFps", fast ? 240d : clean || plus ? 144d : 90d);
    put(c, "performance", "entityCap", fast ? 32d : max ? 128d : 64d);
    put(c, "performance", "performanceMode", fast);
    put(c, "performance", "reducedBloom", !max);
    c.blur = max || cinema;
    put(c, "hitfx", "style", clean || fast ? "Sparks" : plus ? "Stars" : "Shards");
    put(c, "hitfx", "count", fast ? 2d : clean ? 4d : max ? 8d : 6d);
    put(c, "hitfx", "glow", fast ? 0d : clean ? .1 : .25);
    put(c, "hitfx", "duration", clean || fast ? .45 : .7);
    put(c, "hitfx", "damageNumbers", !cinema);
    put(c, "totemparticles", "amount", fast ? 16d : clean ? 28d : max ? 72d : 48d);
    put(c, "totemparticles", "pattern", max ? "Helix" : plus ? "Bloom" : "Halo");
    put(c, "totemparticles", "style", "Sparks");
    put(c, "totemparticles", "opacity", clean ? .65 : .8);
    put(c, "jumpcircles", "style", max ? "Supernova" : plus ? "Arcane Bloom" : "Reactor");
    put(c, "jumpcircles", "glow", clean ? .1 : .3);
    if (fast) for (String id : List.of("hostile", "items", "projectiles")) {
      put(c,id,"style","Minimal"); put(c,id,"distance",64d);
    }
    if (clean || plus) {
      enable(c, "crystals", "nametags", "damagefeedback", "totemsize");

      put(c,"nametags","depth",true); put(c,"nametags","armor",true); put(c,"nametags","held",true);
      put(c,"totemsize","hand",.75); put(c,"totemsize","pop",.65);
    }
    if (max || plus || cinema) {
      enable(c,"afterimage","totemghost","deathghost","explosionfx");
      put(c,"afterimage","count",max ? 6d : 3d); put(c,"afterimage","opacity",max ? .3 : .2);
      put(c,"totemghost","duration",1.0); put(c,"deathghost","duration",1.4); put(c,"deathghost","limit",3d);
      put(c,"explosionfx","preset",plus ? "Clean" : "Cinematic");
      put(c,"explosionfx","quality",max ? "High" : "Medium");
      put(c,"explosionfx","debrisAmount",max ? 28d : 12d);
      put(c,"explosionfx","sparkAmount",max ? 40d : 20d);
      put(c,"explosionfx","budget",max ? 448d : 256d);
      put(c,"explosionfx","majorBudget",max ? 8d : 4d);
      put(c,"explosionfx","shake",false); put(c,"explosionfx","roll",false); put(c,"explosionfx","fov",false);
      put(c,"explosionfx","heat",max);
    }
    if (max || cinema) {
      enable(c,"cinematicsky","shootingstars","capes");
      put(c,"cinematicsky","preset",cinema ? "Silver Storm" : "Aurora Veil");
      put(c,"cinematicsky","quality","Balanced"); put(c,"cinematicsky","adaptive",true);
      put(c,"cinematicsky","speed",cinema ? .45 : .6);
      put(c,"cinematicsky","brightness",cinema ? 1.15 : 1.3);
    }
    if (max) {
      enable(c,"fireflies","angelwings","playerafterimage","damagefeedback");
      put(c,"fireflies","count",48d); put(c,"fireflies","radius",10d);
      put(c,"playerafterimage","opacity",.2);
    }
    if (plus) enable(c,"playerafterimage");
    ConfigStore.normalize(c);
    preserveHud(previous, c);
  }

  private static void enable(VisualConfig c, String... ids) { for (String id : ids) if (c.module(id) != null) c.module(id).enabled = true; }
  private static void put(VisualConfig c, String id, String key, Object value) {
    if (c.module(id) == null) return;
    var spec = Modules.get(id);
    if (spec == null || c.module(id) == null) return;
    for (var s : spec.settings()) if (s.key().equals(key)) {
      if (s.kind() != Setting.Kind.CHOICE || s.choices().contains(value)) c.module(id).values.put(key, value);
      return;
    }
  }
  private QuickLooks() {}
}

