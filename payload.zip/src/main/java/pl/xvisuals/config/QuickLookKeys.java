package pl.xvisuals.config;

import pl.xvisuals.XVisuals;
import pl.xvisuals.gui.world.WorldStudio;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Native bindings persist in Minecraft options independently of profiles. */
public final class QuickLookKeys {
  public enum Action {
    NEXT("Next colour palette", "next_palette", GLFW.GLFW_KEY_F6),
    CUSTOM("Apply my custom colours", "custom_colors", GLFW.GLFW_KEY_F7),
    CLEAN("Load PvP Clean", "pvp_clean", GLFW.GLFW_KEY_F8),
    PLUS("Load PvP Plus", "pvp_plus", GLFW.GLFW_KEY_UNKNOWN),
    MAX("Load Max Visuals", "max_visuals", GLFW.GLFW_KEY_F9),
    UNDO("Undo preset / bulk edit", "undo_look", GLFW.GLFW_KEY_UNKNOWN);
    public final String label;
    private final String key;
    private final int defaultKey;
    public KeyBinding binding;
    Action(String label, String key, int defaultKey) { this.label = label; this.key = key; this.defaultKey = defaultKey; }
  }
  public static void init(KeyBinding.Category category) {
    for (var a : Action.values()) a.binding = KeyBindingHelper.registerKeyBinding(
        new KeyBinding("key.xvisuals." + a.key, InputUtil.Type.KEYSYM, a.defaultKey, category));
  }
  public static void tick(MinecraftClient c) {
    for (var a : Action.values()) while (a.binding != null && a.binding.wasPressed()) {
      if (c.player == null || c.currentScreen != null || WorldStudio.active()) continue;
      try {
        var store = XVisuals.STORE;
        switch (a) {
          case NEXT -> store.cycleQuickPalette();
          case CUSTOM -> store.applyQuickColors(store.current.lookPrimary, store.current.lookSecondary);
          case CLEAN -> store.loadQuickPreset("PvP Clean");
          case PLUS -> store.loadQuickPreset("PvP Plus");
          case MAX -> store.loadQuickPreset("Max Visuals");
          case UNDO -> store.undoQuick();
        }
        c.player.sendMessage(Text.literal(store.message), true);
      } catch (Exception e) { c.player.sendMessage(Text.literal("Could not apply look: " + e.getMessage()), true); }
    }
  }
  private QuickLookKeys() {}
}
