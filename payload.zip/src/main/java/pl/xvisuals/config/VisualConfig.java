package pl.xvisuals.config;

import pl.xvisuals.modules.*;
import java.util.*;
import com.google.gson.annotations.SerializedName;

public final class VisualConfig {
  @SerializedName("schema")
  public int schema = 1;
  @SerializedName("skyRendererRevision")
  public int skyRendererRevision = 1;
  @SerializedName("autumnRendererRevision")
  public int autumnRendererRevision = 1;
  @SerializedName("accent")
  public String accent = "#FFFFFF";
  @SerializedName("secondary")
  public String secondary = "#000000";
  @SerializedName("theme")
  public String theme = "Monochrome";
  @SerializedName("themeEffects")
  public boolean themeEffects = true;
  @SerializedName("lookPrimary")
  public String lookPrimary = "#FFFFFF";
  @SerializedName("lookSecondary")
  public String lookSecondary = "#000000";
  @SerializedName("lookMode")
  public String lookMode = "Gradient";
  @SerializedName("lookScope")
  public String lookScope = "All visuals";
  @SerializedName("lookPalette")
  public int lookPalette;
  @SerializedName("guiAppearance")
  public String guiAppearance = "Classic";
  @SerializedName("glassOpacity")
  public double glassOpacity = .68;
  @SerializedName("guiScale")
  public double guiScale = 1;
  @SerializedName("studioX")
  public double studioX = .5;
  @SerializedName("studioY")
  public double studioY = .5;
  @SerializedName("popupX")
  public double popupX = .5;
  @SerializedName("popupY")
  public double popupY = .5;
  @SerializedName("blur")
  public boolean blur = true;
  @SerializedName("worldGui")
  public boolean worldGui = false;
  @SerializedName("modules")
  public Map<String, ModuleState> modules = new LinkedHashMap<>();
  @SerializedName("widgets")
  public Map<String, HudState> widgets = new LinkedHashMap<>();

  public VisualConfig() {
    for (ModuleSpec spec : Modules.ALL) modules.put(spec.id(), new ModuleState(spec));
    QuickLooks.themeColors(this, accent, secondary);
    theme = "Monochrome";
    String[] names = {
      "Logo",
      "Brand",
      "Username",
      "FPS",
      "Ping",
      "Coordinates",
      "Speed",
      "Direction",
      "Server",
      "Biome",
      "Clock",
      "Armor",
      "Effects",
      "Keystrokes",
      "CPS",
      "Memory",
      "Session",
      "Now Playing",
      "Target HUD",
      "Potions",
      "Cooldowns",
      "Notifications",
      "Modules List",
      "HotKeys"
    };
    for (int i = 0; i < names.length; i++) {
      HudState h = new HudState();
      h.x = .018;
      h.y = .03 + i * .044;
      h.enabled = i < 3;
      widgets.put(names[i], h);
    }
    widgets.get("Now Playing").enabled = true;
    double[][] soup = {{.62, .55}, {.85, .30}, {.85, .55}, {.78, .85}, {.86, .03}, {.02, .45}};
    for (int i = 0; i < 6; i++) {
      var w = widgets.get(pl.xvisuals.hud.SoupHud.NAMES.get(i));
      w.x = soup[i][0]; w.y = soup[i][1]; w.enabled = i == 0;
    }
    widgets.get("Now Playing").x = .4;
    widgets.get("Now Playing").y = .78;
    widgets.get("Ping").x = .12;
    widgets.get("Ping").y = .03;
    widgets.get("Coordinates").y = .91;
    applyHudLayout();
  }

  /** Reference layout; widgets detach from a row when dragged. */
  public void applyHudLayout() {
    widgets.values().forEach(h -> { h.enabled = false; h.hidden = false; h.locked = false; h.row = -1; });
    String[][] rows = {{"Logo", "Brand", "Username", "FPS", "Ping", "Clock"}, {"Coordinates", "Speed"}};
    for (int row = 0; row < rows.length; row++) for (String name : rows[row]) {
      HudState h = widgets.get(name);
      h.enabled = true; h.row = row; h.scale = .75; h.icons = true;
      h.glass = true; h.opacity = .62; h.x = .018; h.y = .03 + row * .05;
    }
    for (String name : pl.xvisuals.hud.SoupHud.NAMES) { var w = widgets.get(name); if (w != null) { w.scale = 1; w.glass = false; w.enabled = name.equals("Target HUD"); } }
    for (String name : pl.xvisuals.hud.HudDefaultLayout.OPTIONAL_WIDGETS)
      widgets.get(name).row = pl.xvisuals.hud.HudDefaultLayout.OPTIONAL;
  }

  public ModuleState module(String id) {
    return modules.get(id);
  }

  public boolean on(String id) {
    if (id.equals("nametags")) return false;
    ModuleState m = modules.get(id);
    return m != null && m.enabled;
  }

  public static final class ModuleState {
    @SerializedName("enabled")
    public boolean enabled;
    @SerializedName("favorite")
    public boolean favorite;
    @SerializedName("values")
    public Map<String, Object> values = new LinkedHashMap<>();
    private final transient Map<String, CachedColor> colorCache = new HashMap<>();
    private record CachedColor(String source, int color) {}

    public ModuleState() {}

    public ModuleState(ModuleSpec spec) {
      enabled = spec.enabled();
      for (Setting s : spec.settings()) values.put(s.key(), s.initial());
    }

    public double number(String key) {
      Object v = values.get(key);
      return v instanceof Number n ? n.doubleValue() : 0;
    }

    public int integer(String key) {
      return (int) number(key);
    }

    public boolean flag(String key) {
      return Boolean.TRUE.equals(values.get(key));
    }

    public String text(String key) {
      return String.valueOf(values.getOrDefault(key, ""));
    }

    public int color(String key) {
      String source = text(key);
      CachedColor cached = colorCache.get(key);
      if (cached != null && cached.source.equals(source)) return cached.color;
      int result;
      try {
        result = 0xFF000000 | Integer.parseInt(source.replace("#", ""), 16);
      } catch (Exception e) {
        result = 0xFFB88CFF;
      }
      colorCache.put(key, new CachedColor(source, result));
      return result;
    }
  }

  public static final class HudState {
    @SerializedName("mouseButtons")
    public boolean mouseButtons = false;
    @SerializedName("locked")
    public boolean locked = false;
    @SerializedName("hidden")
    public boolean hidden = false;
    @SerializedName("enabled")
    public boolean enabled = false;
    @SerializedName("glass")
    public boolean glass = true;
    @SerializedName("accent")
    public boolean accent = true;
    @SerializedName("blur")
    public boolean blur = false;
    @SerializedName("icons")
    public boolean icons = true;
    @SerializedName("row")
    public int row = -1;
    @SerializedName("x")
    public double x = .02;
    @SerializedName("y")
    public double y = .04;
    @SerializedName("scale")
    public double scale = .85;
    @SerializedName("opacity")
    public double opacity = .46;
  }
}

