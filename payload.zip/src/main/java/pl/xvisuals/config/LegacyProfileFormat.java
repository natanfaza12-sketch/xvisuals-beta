package pl.xvisuals.config;
import com.google.gson.JsonObject;
/** Migration for config field names in the October 10 public build. */
final class LegacyProfileFormat {
 static JsonObject migrate(JsonObject root) {
  if(root.has("modules") || !root.has("A") || !root.has("F") || !root.get("A").isJsonObject()) return root;
  JsonObject result=rename(root, new String[]{"m", "accent", "o", "autumnRendererRevision", "T", "blur", "n", "glassOpacity", "h", "guiScale", "b", "lookMode", "Y", "lookPalette", "k", "lookPrimary", "H", "lookScope", "O", "lookSecondary", "A", "modules", "d", "popupX", "q", "popupY", "F", "schema", "w", "secondary", "z", "skyRendererRevision", "S", "studioX", "I", "studioY", "x", "theme", "Q", "themeEffects", "C", "widgets", "G", "worldGui"});
  for(String group:new String[]{"modules","widgets"}) {
   if(!result.has(group)||!result.get(group).isJsonObject())continue;
   JsonObject entries=result.getAsJsonObject(group);
   for(String key:java.util.List.copyOf(entries.keySet())) {
    if(entries.get(key).isJsonObject()) entries.add(key,rename(entries.getAsJsonObject(key),
      group.equals("modules")?new String[]{"J", "enabled", "x", "favorite", "Y", "values"}:new String[]{"e", "accent", "x", "blur", "X", "enabled", "R", "glass", "w", "hidden", "I", "icons", "q", "locked", "h", "mouseButtons", "c", "opacity", "g", "row", "K", "scale", "A", "x", "F", "y"}));
   }
  }
  return result;
 }
 private static JsonObject rename(JsonObject source,String[] names) {
  JsonObject result=new JsonObject();
  for(int i=0;i<names.length;i+=2)if(source.has(names[i]))result.add(names[i+1],source.get(names[i]));
  return result;
 }
 private LegacyProfileFormat(){}
}
