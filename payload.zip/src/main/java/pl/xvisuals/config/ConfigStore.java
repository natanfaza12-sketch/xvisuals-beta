package pl.xvisuals.config;

import com.google.gson.*;
import pl.xvisuals.modules.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.FileTime;
import java.util.*;

/** Atomic saves, bounded imports and schema normalization. No imported path is trusted. */
public final class ConfigStore {
  public static final Gson JSON = new GsonBuilder().setPrettyPrinting().create();
  private final Path root;
  public VisualConfig current = new VisualConfig();
  public String activeProfile = "Default", message = "";
  private long dirtyAt;
  private boolean incompatibleActive;
  private String undoQuickJson, undoQuickProfile;
  private boolean undoQuickPreserveHud = true;
  private static final int MAX_CONFIG_BYTES = 1_048_576;
  private static final String LOCAL_FORMAT = "visual-client-local";
  private record LocalConfig(VisualConfig settings, String moduleId, boolean privateSnapshot) {}
  private record LocalScope(long size, FileTime modified, String moduleId) {}
  private final Map<Path, LocalScope> localScopes = new LinkedHashMap<>();

  public ConfigStore(Path root) {
    this.root = root;
  }

  public void load() {
    incompatibleActive = false;
    try {
      Files.createDirectories(root.resolve("profiles"));
      if (Files.exists(root.resolve("config.json")))
        current = readStoredProfile(root.resolve("config.json"));
    } catch (Exception e) {
      incompatibleActive = e instanceof UnsupportedConfigException;
      message = "Config recovered: " + e.getMessage();
      try {
        if (Files.exists(root.resolve("config.json")))
          Files.copy(
              root.resolve("config.json"),
              root.resolve("config.invalid-" + System.currentTimeMillis() + ".json"));
      } catch (IOException ignored) {
      }
      current = new VisualConfig();
    }
    // Metadata and preset IO must never discard a successfully loaded configuration.
    activeProfile = "Default";
    try {
      Path active = root.resolve("active.txt");
      if (Files.exists(active)) activeProfile = safeName(Files.readString(active).trim());
    } catch (Exception e) {
      message = "Profile selection recovered; settings preserved";
    }
    try {
      for (String name : List.of("Default", "PvP", "Cinematic", "Performance", "High FPS", "Max Visuals", "PvP Clean", "PvP Plus"))
        if (!Files.exists(profilePath(name))) write(profilePath(name), JSON.toJson(preset(name)));
    } catch (IOException e) {
      message = "Could not initialize presets: " + e.getMessage();
    }
  }

  public static VisualConfig parse(String text) {
    if (text == null || text.isBlank()) throw new IllegalArgumentException("Clipboard is empty. Copy the full config text first.");
    if (text.length() > 1_048_576) throw new IllegalArgumentException("Profile exceeds 1 MB");
    text = text.strip();
    if (text.startsWith("\uFEFF")) text = text.substring(1).strip();
    if (text.startsWith("```") && text.endsWith("```") && text.contains("\n"))
      text = text.substring(text.indexOf('\n') + 1, text.length() - 3).strip();
    JsonElement tree = JsonParser.parseString(text);
    if (tree.isJsonObject() && tree.getAsJsonObject().has("format")) {
      JsonObject envelope = tree.getAsJsonObject();
      if (!"visual-client-config".equals(envelope.get("format").getAsString()) || !(supportedVersion(envelope.get("version")) || moduleEnvelope(envelope)))
        throw new UnsupportedConfigException();
      if (supportedVersion(envelope.get("version")) && envelope.has("moduleId")) throw new UnsupportedConfigException();
      tree = envelope.get("settings");
      if (tree == null || !tree.isJsonObject()) throw new IllegalArgumentException("Missing config settings");
    }
    if (tree.isJsonObject()) tree = LegacyProfileFormat.migrate(tree.getAsJsonObject());
    if (!tree.isJsonObject() || !tree.getAsJsonObject().has("modules"))
      throw new IllegalArgumentException("Copy the full Visuals config text, not a file path or link.");
    if (tree.getAsJsonObject().has("schema") && !supportedVersion(tree.getAsJsonObject().get("schema")))
      throw new UnsupportedConfigException();
    VisualConfig c = JSON.fromJson(tree, VisualConfig.class);
    if (c.schema != 1) throw new UnsupportedConfigException();
    // Older releases silently defaulted every window to supersampled 4K.
    // Migrate that costly default once; explicit Ultra choices in this release persist.
    if (!tree.getAsJsonObject().has("skyRendererRevision") && c.modules != null) {
      var sky = c.modules.get("cinematicsky");
      if (sky != null && sky.values != null && "4K Ultra".equals(sky.values.get("quality")))
        sky.values.put("quality", "Balanced");
    }
    if(!tree.getAsJsonObject().has("autumnRendererRevision") && c.modules!=null) {
      var leaves=c.modules.get("autumnleaves");
      if(leaves!=null && leaves.values!=null && leaves.values.get("count") instanceof Number n && n.intValue()==20)
        leaves.values.put("count",80.0);
    }
    c.autumnRendererRevision=1;
    c.skyRendererRevision = 1;
    var savedModules=tree.getAsJsonObject().get("modules") instanceof JsonObject object?object:null;
    if(c.modules!=null && savedModules!=null && !savedModules.has("swingspeed")) {
      var old=c.modules.get("swing");
      if(old!=null && old.values!=null && old.values.get("speed") instanceof Number speed) {
        var separate=new VisualConfig().module("swingspeed");
        separate.enabled=old.enabled;
        separate.values.put("speed",speed.doubleValue());
        c.modules.put("swingspeed",separate);
      }
    }
    normalize(c);
    return c;
  }

  private static boolean supportedVersion(JsonElement value) {
    if (value == null || !value.isJsonPrimitive() || !value.getAsJsonPrimitive().isNumber()) return false;
    try { return value.getAsBigDecimal().compareTo(java.math.BigDecimal.ONE) == 0; }
    catch (NumberFormatException e) { return false; }
  }

  public static void normalize(VisualConfig c) {
    VisualConfig defaults = new VisualConfig();
    c.guiScale = clamp(c.guiScale, .65, 1.5, 1);
    c.studioX = clamp(c.studioX, 0, 1, .5);
    c.studioY = clamp(c.studioY, 0, 1, .5);
    c.popupX = clamp(c.popupX, 0, 1, .5);
    c.popupY = clamp(c.popupY, 0, 1, .5);
    if (c.modules == null) c.modules = new LinkedHashMap<>();
    // Merge legacy cosmetics before discarding removed module IDs. Prefer the cape
    // design when both were enabled; otherwise retain the active elytra design.
    var legacyWings = c.modules.remove("elytraskins");
    if (legacyWings != null) {
      var cape = c.modules.get("capes");
      if (cape == null || (!cape.enabled && legacyWings.enabled)) {
        legacyWings.favorite |= cape != null && cape.favorite;
        c.modules.put("capes", legacyWings);
      } else {
        cape.enabled |= legacyWings.enabled;
        cape.favorite |= legacyWings.favorite;
      }
    }
    c.modules.keySet().retainAll(defaults.modules.keySet());
    for (ModuleSpec spec : Modules.ALL) {
      var m = c.modules.computeIfAbsent(spec.id(), k -> new VisualConfig.ModuleState(spec));
      if (m.values == null) m.values = new LinkedHashMap<>();
      if(spec.id().equals("hitfx") && !pl.xvisuals.modules.combat.ImpactStyles.HITS.contains(m.text("style"))
          && Math.abs(m.number("duration")-.85)<.001)m.values.put("duration",.55);
      if (spec.id().equals("playerafterimage") && !m.values.containsKey("emission")) {
        if (Math.abs(m.number("opacity")-.18)<.001) m.values.put("opacity",.45);
        if (Math.abs(m.number("duration")-.3)<.001) m.values.put("duration",.65);
        if (m.integer("count")==2) m.values.put("count",4);
        if (m.integer("spacing")==160) m.values.put("spacing",100);
      }
      if (spec.id().equals("xp")) m.values.put("theme",pl.xvisuals.hud.ExperienceThemes.migrate(m.text("theme")));
      if (spec.id().equals("jumpcircles")) {
        String replacement = switch (m.text("style")) {
          case "Ring", "Clean", "Echo", "Prism", "Lotus", "Astral", "Runic Gate" -> "Reactor";
          case "Pulse", "Ripple", "Double Ring" -> "Reactor";
          case "Shockwave" -> "Supernova";
          case "Halo" -> "Reactor";
          case "Runic" -> "Reactor";
          default -> m.text("style");
        };
        m.values.put("style", pl.xvisuals.modules.motion.LandingDesigns.migrate(replacement));
      }
      if (m.text("style").equals("Glass Outline")) m.values.put("style", "Soft Outline");
      if (spec.id().equals("cinematicsky"))
        m.values.put("preset", pl.xvisuals.modules.SkyScenes.migrate(m.text("preset")));
      if (spec.id().equals("nametags") && !m.values.containsKey("showDistance")
          && m.values.get("distance") instanceof Boolean oldDistance) {
        m.values.put("showDistance", oldDistance);
        m.values.remove("distance");
      }
      if (spec.id().equals("totemtexture")) {
        String renamed = switch (m.text("style")) {
          case "Crystal" -> "Void Monarch";
          case "Seraph" -> "Solar Seraph";
          case "Heart" -> "Pixel Heart";
          case "Eclipse" -> "Tiny UFO";
          case "Phoenix" -> "Inferno Blade";
          case "Dragon" -> "Cyber Samurai";
          case "Reaper" -> "Void Monarch";
          case "Crown" -> "Frog King";
          case "Lotus" -> "Solar Seraph";
          case "Hourglass" -> "Classic Gold";
          case "Moth" -> "Smug Cat";
          case "Kraken" -> "Sus";
          case "Astral" -> "Lucky Star";
          case "Sword" -> "Inferno Blade";
          case "Runestone" -> "Classic Gold";
          default -> m.text("style");
        };
        m.values.put("style", renamed);
      }
      Set<String> keys = new HashSet<>();
      for (Setting s : spec.settings()) {
        keys.add(s.key());
        Object v = m.values.get(s.key());
        if (spec.id().equals("capes") && s.key().equals("style") && v instanceof String name)
          v = name.replace("Premium \u00c2\u00b7 ", "Premium - ").replace("Premium \u00b7 ", "Premium - ");
        boolean valid = v != null;
        switch (s.kind()) {
          case BOOLEAN -> valid = v instanceof Boolean;
          case NUMBER -> {
            valid = v instanceof Number && Double.isFinite(((Number) v).doubleValue());
            if (valid) v = Math.max(s.min(), Math.min(s.max(), ((Number) v).doubleValue()));
          }
          case CHOICE -> valid = v instanceof String && s.choices().contains(v);
          case COLOR -> valid = v instanceof String && ((String) v).matches("#[0-9a-fA-F]{6}");
          case KEY ->
              valid =
                  v instanceof String
                      && (((String) v).startsWith("key.keyboard.") || ((String) v).startsWith("key.mouse."))
                      && ((String) v).length() < 80;
          case TEXT -> valid = v instanceof String && ((String) v).length() <= 2048;
        }
        m.values.put(s.key(), valid ? v : s.initial());
      }
      m.values.keySet().retainAll(keys);
      if (spec.id().equals("crosshair")) m.values.put("pixels",
          pl.xvisuals.modules.crosshair.CrosshairDesign.normalize(m.text("pixels")));
    }
    if (c.widgets == null) c.widgets = new LinkedHashMap<>();
    c.widgets.keySet().retainAll(defaults.widgets.keySet());
    boolean existingHud = !c.widgets.isEmpty();
    defaults.widgets.forEach(
        (key, value) -> {
          if (c.widgets.get(key) == null) {
            if (existingHud && Set.of("Logo", "Brand", "Username").contains(key)) value.enabled = false;
            c.widgets.put(key, value);
          }
        });
    for (var h : c.widgets.values()) {
      if (h.row < -1 || h.row > pl.xvisuals.hud.HudDefaultLayout.OPTIONAL) h.row = -1;
      h.x = clamp(h.x, 0, 1, .02);
      h.y = clamp(h.y, 0, 1, .04);
      h.scale = clamp(h.scale, .25, 2.5, 1);
      h.opacity = clamp(h.opacity, .05, 1, .68);
    }
    if (c.accent == null || !c.accent.matches("#[0-9a-fA-F]{6}")) c.accent = defaults.accent;
    if (c.secondary == null || !c.secondary.matches("#[0-9a-fA-F]{6}"))
      c.secondary = defaults.secondary;
    if (c.theme == null || c.theme.length() > 64) c.theme = "Custom";
    if (!"Glass".equals(c.guiAppearance) && !"Weathered Glass".equals(c.guiAppearance)) c.guiAppearance = "Classic";
    c.glassOpacity = clamp(c.glassOpacity, .2, 1, .87);
    QuickLooks.normalize(c);
  }

  private static double clamp(double n, double lo, double hi, double fallback) {
    return Double.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : fallback;
  }

  public void dirty() {
    dirtyAt = System.currentTimeMillis();
  }

  public void tick() {
    if (dirtyAt != 0 && System.currentTimeMillis() - dirtyAt > 650) save();
  }

  public boolean save() {
    if (incompatibleActive) { message = "A newer client saved your settings. Update the client; original files are protected."; return false; }
    try {
      normalize(current);
      persist(current, activeProfile);
      dirtyAt = 0;
      return true;
    } catch (Exception e) {
      message = "Could not save: " + e.getMessage();
      // Retry in about five seconds, without writing on every client tick.
      dirtyAt = System.currentTimeMillis() + 4350;
      return false;
    }
  }

  private void requireSave() throws IOException {
    if (!save()) throw new IOException(message);
  }

  /** Stage every destination before changing any live file; rollback a failed commit. */
  private void persist(VisualConfig config, String profile) throws IOException {
    if (incompatibleActive) throw new IOException("A newer client saved your settings. Update the client; original files are protected.");
    String json = JSON.toJson(config);
    Map<Path, String> writes = new LinkedHashMap<>();
    writes.put(profilePath(profile), json);
    writes.put(root.resolve("active.txt"), profile);
    writes.put(root.resolve("config.json"), json);
    Map<Path, byte[]> originals = new LinkedHashMap<>();
    List<Path> staged = new ArrayList<>(), committed = new ArrayList<>();
    try {
      for (Path path : writes.keySet())
        originals.put(path, Files.exists(path) ? Files.readAllBytes(path) : null);
      for (var entry : writes.entrySet()) {
        Path path = entry.getKey(), temp = path.resolveSibling(path.getFileName() + ".tmp");
        Files.createDirectories(path.getParent());
        Files.writeString(temp, entry.getValue(), StandardCharsets.UTF_8);
        staged.add(temp);
      }
      for (Path path : writes.keySet()) {
        moveReplacement(path.resolveSibling(path.getFileName() + ".tmp"), path);
        committed.add(path);
      }
    } catch (IOException failure) {
      Collections.reverse(committed);
      for (Path path : committed) {
        try {
          byte[] original = originals.get(path);
          if (original == null) Files.deleteIfExists(path);
          else write(path, new String(original, StandardCharsets.UTF_8));
        } catch (IOException rollback) { failure.addSuppressed(rollback); }
      }
      if (failure.getSuppressed().length > 0)
        throw new IOException("Saving failed and some files could not be restored; check your configuration folder before retrying.", failure);
      throw failure;
    } finally {
      for (Path temp : staged) try { Files.deleteIfExists(temp); } catch (IOException ignored) {}
    }
  }

  /** Keep the original before an update adds defaults or migrates old fields. */
  private VisualConfig readStoredProfile(Path path) throws IOException {
    String original = readConfigText(path);
    VisualConfig next = parse(original);
    if (!JsonParser.parseString(original).equals(JSON.toJsonTree(next))) {
      String fingerprint = UUID.nameUUIDFromBytes(original.getBytes(StandardCharsets.UTF_8)).toString();
      Path backup = root.resolve("backups").resolve(path.getFileName() + "." + fingerprint + ".bak");
      Files.createDirectories(backup.getParent());
      if (!Files.exists(backup)) Files.writeString(backup, original, StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW);
    }
    return next;
  }

  private static void write(Path path, String content) throws IOException {
    Files.createDirectories(path.getParent());
    Path temp = path.resolveSibling(path.getFileName() + ".tmp");
    Files.writeString(temp, content, StandardCharsets.UTF_8);
    moveReplacement(temp, path);
  }

  private static void moveReplacement(Path temp, Path path) throws IOException {
    try {
      Files.move(temp, path, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
    } catch (AtomicMoveNotSupportedException e) {
      Files.move(temp, path, StandardCopyOption.REPLACE_EXISTING);
    }
  }

  public List<String> profiles() {
    try (var files = Files.list(root.resolve("profiles"))) {
      return files
          .filter(p -> p.getFileName().toString().endsWith(".json"))
          .map(p -> p.getFileName().toString().replaceFirst("\\.json$", ""))
          .sorted()
          .toList();
    } catch (IOException e) {
      return List.of("Default");
    }
  }

  public void select(String name) throws IOException {
    name = safeName(name);
    if (name.equals(activeProfile)
        || (Files.exists(profilePath(name)) && Files.exists(profilePath(activeProfile))
            && Files.isSameFile(profilePath(name), profilePath(activeProfile)))) {
      requireSave();
      message = "Loaded " + activeProfile;
      return;
    }
    VisualConfig next = readStoredProfile(profilePath(name));
    if (QuickLooks.PRESETS.contains(name) || name.equals("PvP") || name.equals("Performance"))
      QuickLooks.preserveHud(current, next);
    requireSave();
    current = next;
    activeProfile = safeName(name);
    requireSave();
    message = "Loaded " + name;
  }

  public void duplicate(String name) throws IOException {
    name = safeName(name);
    if (Files.exists(profilePath(name))) throw new IOException("Profile already exists");
    requireSave();
    write(profilePath(name), JSON.toJson(current));
    activeProfile = name;
    requireSave();
    message = "Created " + name;
  }

  public void rename(String name) throws IOException {
    name = safeName(name);
    if (Files.exists(profilePath(name))) throw new IOException("Profile already exists");
    requireSave();
    Files.move(profilePath(activeProfile), profilePath(name));
    activeProfile = name;
    requireSave();
  }

  public void delete() throws IOException {
    String old = activeProfile;
    if (old.equals("Default") || (Files.exists(profilePath(old))
        && Files.isSameFile(profilePath(old), profilePath("Default"))))
      throw new IOException("Default cannot be deleted");
    select("Default");
    Files.deleteIfExists(profilePath(old));
    message = "Deleted " + old;
  }

  /** Copy only portable settings. Free text and integration choices stay on this machine. */
  public static VisualConfig shareable(VisualConfig source) {
    VisualConfig copy = parse(JSON.toJson(source));
    copy.theme = "Custom";
    for (ModuleSpec spec : Modules.ALL) {
      var module = copy.module(spec.id());
      for (Setting setting : spec.settings()) {
        if (localSetting(spec.id(), setting))
          module.values.put(setting.key(), setting.initial());
      }
    }
    return copy;
  }

  private static boolean localSetting(String module, Setting setting) {
    return setting.kind() == Setting.Kind.KEY
        || setting.kind() == Setting.Kind.TEXT
            && !(module.equals("crosshair") && setting.key().equals("pixels"));
  }

  private VisualConfig sharedImport(String text) {
    VisualConfig next = shareable(parse(text));
    String moduleId = moduleId(text);
    VisualConfig local = parse(JSON.toJson(current));
    for (ModuleSpec spec : Modules.ALL)
      for (Setting setting : spec.settings())
        if (localSetting(spec.id(), setting))
          next.module(spec.id()).values.put(setting.key(), local.module(spec.id()).values.get(setting.key()));
    if (!moduleId.isEmpty()) {
      var replacement = next.module(moduleId);
      replacement.favorite = local.module(moduleId).favorite;
      local.modules.put(moduleId, replacement);
      return local;
    }
    return next;
  }

  public String exportText() {
    if (!save()) throw new IllegalStateException(message);
    return envelope(current);
  }

  public void importText(String text) throws IOException {
    VisualConfig next = sharedImport(text);
    String name = "Imported";
    for (int index = 2; Files.exists(profilePath(name)); index++)
      name = "Imported " + index;
    requireSave();
    persist(next, name);
    current = next;
    activeProfile = name;
    message = "Imported profile";
  }

  public void resetModule(String id) {
    current.modules.put(id, new VisualConfig.ModuleState(Modules.get(id)));
    dirty();
  }

  public boolean canUndoQuick() { return undoQuickJson != null; }

  private void rememberQuick() {
    undoQuickPreserveHud = true;
    undoQuickJson = JSON.toJson(current);
    undoQuickProfile = activeProfile;
  }

  public void loadQuickPreset(String name) throws IOException {
    if (!QuickLooks.PRESETS.contains(name)) throw new IllegalArgumentException("Unknown preset");
    VisualConfig next = preset(name);
    requireSave();
    rememberQuick();
    // Keep the editor and custom colour shortcut stable while changing visual presets.
    next.guiScale = current.guiScale; next.studioX = current.studioX; next.studioY = current.studioY;
    next.popupX = current.popupX; next.popupY = current.popupY; next.worldGui = current.worldGui;
    next.lookPrimary = current.lookPrimary; next.lookSecondary = current.lookSecondary;
    next.lookMode = current.lookMode; next.lookScope = current.lookScope; next.lookPalette = current.lookPalette;
    // Rich Presence and its privacy choice are independent of visual presets.
    QuickLooks.preserveHud(current, next);
    current = next; requireSave(); message = "Applied " + name;
  }

  public void applyQuickColors(String primary, String secondary) {
    if (!QuickLooks.validColor(primary) || !QuickLooks.validColor(secondary)) throw new IllegalArgumentException("Use #RRGGBB colours");
    rememberQuick();
    int count = QuickLooks.colors(current, primary, secondary, current.lookMode.equals("Gradient"), current.lookScope);
    dirty(); message = "Recoloured " + count + " modules / " + current.lookScope;
  }

  public void cycleQuickPalette() {
    int next = (current.lookPalette + 1) % QuickLooks.PALETTES.size();
    var palette = QuickLooks.PALETTES.get(next);
    applyQuickColors(palette.primary(), palette.secondary());
    current.lookPalette = next;
    message = palette.name() + " / " + current.lookMode + " / " + current.lookScope;
  }

  public void quickIntensity(String level) {
    rememberQuick();
    int count = QuickLooks.intensity(current, level, current.lookScope);
    dirty(); message = level + " intensity / " + count + " modules";
  }

  public void quickGroup(String label, String[] ids) {
    rememberQuick();
    boolean enable = Arrays.stream(ids).anyMatch(id -> !current.on(id));
    for (String id : ids) if (current.module(id) != null) current.module(id).enabled = enable;
    dirty(); message = label + (enable ? " enabled" : " disabled");
  }

  public void undoQuick() {
    if (undoQuickJson == null) { message = "Nothing to undo"; return; }
    VisualConfig previous = parse(undoQuickJson);
    if (undoQuickPreserveHud) QuickLooks.preserveHud(current, previous);
    if (!save()) return;
    try { persist(previous, undoQuickProfile); }
    catch (IOException e) { message = "Could not undo: " + e.getMessage(); return; }
    current = previous; activeProfile = undoQuickProfile;
    undoQuickJson = null; undoQuickProfile = null;
    message = "Undid last preset or bulk edit";
  }

  public void resetAll() {
    current = new VisualConfig();
    dirty();
  }

  public Path root() {
    return root;
  }

  public static final int MAX_LOCAL_CONFIGS = 25;

  public List<String> localConfigs() throws IOException {
    Path directory = root.resolve("configs");
    Files.createDirectories(directory);
    try (var files = Files.list(directory)) {
      return files.filter(Files::isRegularFile)
          .map(p -> p.getFileName().toString()).filter(n -> n.endsWith(".json"))
          .map(n -> n.substring(0, n.length() - 5)).sorted(String.CASE_INSENSITIVE_ORDER).toList();
    }
  }

  private Path localPath(String name) { return root.resolve("configs").resolve(safeName(name) + ".json"); }

  public void saveLocal(String name, boolean overwrite) throws IOException { saveLocal(name, overwrite, ""); }

  public void saveLocal(String name, boolean overwrite, String moduleId) throws IOException {
    Path target = localPath(name);
    boolean exists = Files.exists(target);
    if (overwrite && !exists) throw new IOException("Config no longer exists");
    if (!overwrite && exists) throw new IOException("A config with that name already exists");
    if (!exists && localConfigs().size() >= MAX_LOCAL_CONFIGS) throw new IOException("All 25 slots are full. Overwrite or delete a config first.");
    String scope = exists ? localModule(name) : moduleId;
    String snapshot = privateEnvelope(current, scope);
    if (exists) backupLocal(target);
    write(target, snapshot);
    localScopes.remove(target);
    message = "Saved " + name;
  }

  public void loadLocal(String name) throws IOException {
    Path saved = localPath(name);
    String text = readConfigText(saved);
    LocalConfig snapshot = readLocal(text);
    VisualConfig next = snapshot.privateSnapshot() ? snapshot.settings() : sharedImport(text);
    if (snapshot.privateSnapshot() && !snapshot.moduleId().isEmpty()) {
      VisualConfig local = parse(JSON.toJson(current));
      var replacement = next.module(snapshot.moduleId());
      replacement.favorite = local.module(snapshot.moduleId()).favorite;
      local.modules.put(snapshot.moduleId(), replacement);
      next = local;
    }
    // Retain the original before any legacy defaults/migrations are applied.
    if (!snapshot.privateSnapshot()) backupLocal(saved);
    applySaved(next);
    message = "Loaded " + name + " — changes do not overwrite this saved config";
  }

  public void renameLocal(String oldName, String newName) throws IOException {
    Path source = localPath(oldName), target = localPath(newName);
    if (oldName.equals(newName)) return;
    if (Files.exists(target)) throw new IOException("A config with that name already exists");
    Files.move(source, target);
    localScopes.remove(source); localScopes.remove(target);
    message = "Renamed to " + newName;
  }

  public void deleteLocal(String name) throws IOException {
    backupLocal(localPath(name));
    Files.delete(localPath(name));
    localScopes.remove(localPath(name));
    message = "Deleted " + name;
  }

  public static final class UnsupportedConfigException extends IllegalArgumentException {
    public UnsupportedConfigException() { super("This config needs a newer client. Update before importing it."); }
  }

  public static String envelope(VisualConfig config) {
    JsonObject root = new JsonObject();
    root.addProperty("format", "visual-client-config");
    root.addProperty("version", 1);
    root.addProperty("clientVersion", "1.18.9");
    root.add("settings", JSON.toJsonTree(shareable(config)));
    return JSON.toJson(root);
  }

  private static boolean moduleEnvelope(JsonObject envelope) {
    if (!envelope.has("version") || !envelope.get("version").isJsonPrimitive()
        || !envelope.get("version").getAsJsonPrimitive().isNumber()
        || !envelope.get("version").getAsString().equals("2")) return false;
    if (!envelope.has("moduleId") || !envelope.get("moduleId").isJsonPrimitive()) return false;
    String id = envelope.get("moduleId").getAsString();
    if (id.equals("discord") || Modules.ALL.stream().noneMatch(m -> m.id().equals(id))) return false;
    var settings = envelope.get("settings");
    if (settings == null || !settings.isJsonObject()) return false;
    var modules = settings.getAsJsonObject().get("modules");
    return modules != null && modules.isJsonObject() && modules.getAsJsonObject().size() == 1
        && modules.getAsJsonObject().has(id) && modules.getAsJsonObject().get(id).isJsonObject();
  }

  public static String moduleId(String text) {
    // parse first validates version, module identity, and the entire payload.
    parse(text);
    String clean = text.strip();
    if (clean.startsWith("\uFEFF")) clean = clean.substring(1).strip();
    if (clean.startsWith("```") && clean.endsWith("```") && clean.contains("\n"))
      clean = clean.substring(clean.indexOf('\n') + 1, clean.length() - 3).strip();
    JsonObject object = JsonParser.parseString(clean).getAsJsonObject();
    return moduleEnvelope(object) ? object.get("moduleId").getAsString() : "";
  }

  public String localModule(String name) throws IOException {
    Path path = localPath(name);
    var attributes = Files.readAttributes(path, java.nio.file.attribute.BasicFileAttributes.class);
    if (!attributes.isRegularFile() || attributes.size() > MAX_CONFIG_BYTES)
      throw new IOException("Choose a config JSON file smaller than 1 MB");
    LocalScope cached = localScopes.get(path);
    if (cached != null && cached.size() == attributes.size() && cached.modified().equals(attributes.lastModifiedTime()))
      return cached.moduleId();
    String scope = readLocal(readConfigText(path)).moduleId();
    if (localScopes.size() >= MAX_LOCAL_CONFIGS) localScopes.clear();
    localScopes.put(path, new LocalScope(attributes.size(), attributes.lastModifiedTime(), scope));
    return scope;
  }

  /** This format is accepted only by the local disk loader, never by import APIs. */
  private static String privateEnvelope(VisualConfig config, String moduleId) {
    VisualConfig snapshot = parse(JSON.toJson(config));
    JsonObject envelope = new JsonObject();
    envelope.addProperty("format", LOCAL_FORMAT);
    envelope.addProperty("version", 1);
    envelope.addProperty("clientVersion", "1.18.9");
    JsonObject settings = JSON.toJsonTree(snapshot).getAsJsonObject();
    if (moduleId != null && !moduleId.isEmpty()) {
      if (Modules.ALL.stream().noneMatch(m -> m.id().equals(moduleId)))
        throw new IllegalArgumentException("Choose a module");
      envelope.addProperty("moduleId", moduleId);
      settings = new JsonObject(); settings.addProperty("schema", 1);
      settings.addProperty("skyRendererRevision", snapshot.skyRendererRevision);
      settings.addProperty("autumnRendererRevision", snapshot.autumnRendererRevision);
      JsonObject modules = new JsonObject();
      modules.add(moduleId, JSON.toJsonTree(snapshot.module(moduleId)));
      settings.add("modules", modules);
    }
    envelope.add("settings", settings);
    return JSON.toJson(envelope);
  }

  private static LocalConfig readLocal(String text) {
    JsonElement tree = JsonParser.parseString(text);
    if (tree.isJsonObject() && tree.getAsJsonObject().has("format")
        && LOCAL_FORMAT.equals(tree.getAsJsonObject().get("format").getAsString())) {
      JsonObject envelope = tree.getAsJsonObject();
      if (!supportedVersion(envelope.get("version"))) throw new UnsupportedConfigException();
      JsonElement settings = envelope.get("settings");
      if (settings == null || !settings.isJsonObject()) throw new IllegalArgumentException("Missing config settings");
      String scope = "";
      if (envelope.has("moduleId")) {
        JsonElement id = envelope.get("moduleId");
        if (!id.isJsonPrimitive() || !id.getAsJsonPrimitive().isString()) throw new UnsupportedConfigException();
        scope = id.getAsString();
        String module = scope;
        JsonElement modules = settings.getAsJsonObject().get("modules");
        if (Modules.ALL.stream().noneMatch(m -> m.id().equals(module)) || modules == null || !modules.isJsonObject()
            || modules.getAsJsonObject().size() != 1 || !modules.getAsJsonObject().has(scope)
            || !modules.getAsJsonObject().get(scope).isJsonObject()) throw new UnsupportedConfigException();
      }
      return new LocalConfig(parse(settings.toString()), scope, true);
    }
    return new LocalConfig(parse(text), moduleId(text), false);
  }

  private static String readConfigText(Path path) throws IOException {
    if (!Files.isRegularFile(path) || Files.size(path) > MAX_CONFIG_BYTES)
      throw new IOException("Choose a config JSON file smaller than 1 MB");
    try (InputStream input = Files.newInputStream(path)) {
      byte[] bytes = input.readNBytes(MAX_CONFIG_BYTES + 1);
      if (bytes.length > MAX_CONFIG_BYTES) throw new IOException("Config exceeds 1 MB");
      return new String(bytes, StandardCharsets.UTF_8);
    }
  }

  public static String envelope(VisualConfig config, String moduleId) {
    if (moduleId == null || moduleId.isEmpty()) return envelope(config);
    if (moduleId.equals("discord") || Modules.ALL.stream().noneMatch(m -> m.id().equals(moduleId)))
      throw new IllegalArgumentException("Choose a shareable module");
    JsonObject root = new JsonObject(), settings = new JsonObject(), modules = new JsonObject();
    root.addProperty("format", "visual-client-config");root.addProperty("version", 2);
    root.addProperty("clientVersion", "1.18.9");root.addProperty("moduleId", moduleId);
    settings.addProperty("schema", 1);
    settings.addProperty("skyRendererRevision", 1);
    settings.addProperty("autumnRendererRevision", 1);
    modules.add(moduleId, JSON.toJsonTree(shareable(config).module(moduleId)));
    settings.add("modules", modules);root.add("settings", settings);
    return JSON.toJson(root);
  }

  private void backupLocal(Path path) throws IOException {
    if (!Files.exists(path)) return;
    String original = readConfigText(path);
    String fingerprint = UUID.nameUUIDFromBytes(original.getBytes(StandardCharsets.UTF_8)).toString();
    Path backup = root.resolve("backups").resolve(path.getFileName() + "." + fingerprint + ".bak");
    Files.createDirectories(backup.getParent());
    if (!Files.exists(backup)) Files.writeString(backup, original, StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW);
  }

  public void importLocal(String name, String text) throws IOException {
    VisualConfig parsed = parse(text);
    Path target = localPath(name);
    if (Files.exists(target)) throw new IOException("A config with that name already exists");
    if (localConfigs().size() >= MAX_LOCAL_CONFIGS) throw new IOException("All 25 slots are full. Delete a config first.");
    write(target, envelope(parsed, moduleId(text)));
    localScopes.remove(target);
    message = "Imported " + name;
  }

  public String exportLocal(String name) throws IOException {
    LocalConfig snapshot = readLocal(readConfigText(localPath(name)));
    return envelope(snapshot.settings(), snapshot.moduleId());
  }

  public Path exportLocalFile(String name) throws IOException {
    Path file = root.resolve("exports").resolve(safeName(name) + ".visual.json");
    write(file, exportLocal(name)); return file;
  }

  public void importLocalFile(String name, Path file) throws IOException {
    importLocal(name, readConfigText(file));
  }

  public void useShared(String text) throws IOException {
    VisualConfig next = sharedImport(text);
    applySaved(next);
    message = "Config applied. Save locally to keep a separate copy.";
  }

  private void applySaved(VisualConfig next) throws IOException {
    requireSave(); backupLocal(root.resolve("config.json"));
    // Do not publish the candidate in memory (or replace undo) until it is durable.
    persist(next, activeProfile);
    rememberQuick(); undoQuickPreserveHud = false;
    current = next;
  }

  public Path profilePath(String name) {
    return root.resolve("profiles").resolve(safeName(name) + ".json");
  }

  public static String safeName(String name) {
    if (name == null || !name.matches("[\\p{L}\\p{N} _-]{1,48}") || name.isBlank()
        || !name.equals(name.strip()) || name.matches("(?i)(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])"))
      throw new IllegalArgumentException("Use 1-48 letters, numbers, spaces, - or _; no surrounding spaces or reserved Windows names");
    return name;
  }

  public static VisualConfig preset(String name) {
    VisualConfig c = new VisualConfig();
    QuickLooks.configurePreset(c, name);
    return c;
  }
}
