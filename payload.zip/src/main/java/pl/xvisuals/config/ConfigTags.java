package pl.xvisuals.config;
import java.util.*;
/** Shared publication/filter vocabulary matching the server's supported categories. */
public final class ConfigTags {
 public static final List<String> ALL=List.of("pvp","clean","cinematic","performance","colourful","minimal","dark","bright","hud","sky","effects","other");
 public static List<String> parse(String text){
  var result=Arrays.stream(text.split(",")).map(String::strip).map(t->t.toLowerCase(Locale.ROOT)).filter(t->!t.isEmpty()).distinct().toList();
  if(result.size()>5)throw new IllegalArgumentException("Choose up to 5 tags.");
  for(String tag:result)if(!ALL.contains(tag))throw new IllegalArgumentException("Unsupported tag: "+tag+". Choose from the listed tags.");
  return result.isEmpty()?List.of("other"):result;
 }
 private ConfigTags(){}
}
