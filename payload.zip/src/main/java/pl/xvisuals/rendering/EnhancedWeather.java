package pl.xvisuals.rendering;

import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import pl.xvisuals.mixins.RenderLayerAccessor;
import java.util.*;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.*;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;

/** Local, bounded precipitation and depth-tested frost. Never writes world blocks. */
public final class EnhancedWeather {
  private static final Random RANDOM = new Random();
  private static final List<Drop> DROPS = new ArrayList<>();
  private static final Map<Long, Surface> SURFACES = new HashMap<>();
  private static final BufferAllocator ALLOCATOR = new BufferAllocator(524288);
  private static final VertexConsumerProvider.Immediate BUFFERS = VertexConsumerProvider.immediate(ALLOCATOR);
  private static final RenderLayer RAIN = layer("rain"), SNOW = layer("snow"), FROST = layer("frost");
  private static World world;
  private static int scan, ticks;
  private static double strength, whiteout;
  private static String previousMode = "";
  private static boolean stormProfile;

  private static RenderLayer layer(String name) {
    return RenderLayerAccessor.visuals$of("xvisuals_weather_" + name,
        RenderSetup.builder(RenderPipeline.builder()
            .withLocation(Identifier.of("xvisuals", "pipeline/weather_" + name))
            .withVertexShader(Identifier.of("xvisuals", "core/weather"))
            .withFragmentShader(Identifier.of("xvisuals", "core/weather_" + name))
            .withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
            .withUniform("Projection", UniformType.UNIFORM_BUFFER).withSampler("Sampler0")
            .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, VertexFormat.DrawMode.QUADS)
            .withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
            .withDepthWrite(false).withCull(false).build())
            .texture("Sampler0",Identifier.of("xvisuals","textures/crafted/"+name+".png")).translucent().expectedBufferSize(524288).build());
  }

  public static void init() {
    Lightning.init();
    WorldRenderEvents.END_MAIN.register(c -> render(c.matrices()));
    net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING.register(c -> ALLOCATOR.close());
  }

  public static boolean replaces(World w) {
    return w != null && w.getRegistryKey().equals(World.OVERWORLD) && XVisuals.ready()
        && (RealisticRain.active() || Storm.running(w) || XVisuals.config().on("weatherfx")
        && XVisuals.config().module("weatherfx").flag("enhanced"));
  }

  private static pl.xvisuals.config.VisualConfig.ModuleState settings() {
    return RealisticRain.precipitation(Storm.running() ? Storm.precipitation() : XVisuals.config().module("weatherfx"));
  }

  public static void tick(MinecraftClient c) {
    Lightning.tick(c);
    Storm.tick(c);
    if (world != c.world || !replaces(c.world)) {
      DROPS.clear(); SURFACES.clear(); strength = whiteout = 0; scan = 0; ticks = 0; world = c.world;
    }
    if (!replaces(c.world) || c.player == null || c.isPaused()) return;
    boolean storm = Storm.running(c.world);
    if (stormProfile != storm) {
      DROPS.clear(); SURFACES.clear(); strength = whiteout = 0; stormProfile = storm;
    }
    ticks++;
    var s = settings();
    String mode = s.text("weather");
    if (!mode.equals(previousMode)) { previousMode=mode; }
    double target = storm ? Storm.rain() : c.world.getRainGradient(1) * s.number("intensity");
    strength += MathHelper.clamp(target - strength, -.025, .025);
    Vec3d camera = c.gameRenderer.getCamera().getCameraPos();
    BlockPos eye = BlockPos.ofFloored(camera);
    boolean localBlizzard = mode.equals("Blizzard") || mode.equals("Server") && s.flag("snowBlizzard") && snowAt(c.world, eye, mode);
    double hazeTarget = localBlizzard && s.flag("mist") && c.world.isSkyVisible(eye) ? strength * s.number("haze") * .4 : 0;
    whiteout += MathHelper.clamp(hazeTarget - whiteout, -.02, .02);
    if (ticks % 4 == 0 && strength > .01 && !snowAt(c.world, eye, mode)
        && (!mode.equals("Server") || c.world.getBiome(eye).value().getPrecipitation(eye, c.world.getSeaLevel()) == Biome.Precipitation.RAIN)) {
      int roof = c.world.getTopY(Heightmap.Type.MOTION_BLOCKING, eye.getX(), eye.getZ());
      if (roof < camera.y + 6) c.world.playSoundClient(camera.x, Math.max(camera.y, roof), camera.z,
          roof > camera.y ? net.minecraft.sound.SoundEvents.WEATHER_RAIN_ABOVE : net.minecraft.sound.SoundEvents.WEATHER_RAIN,
          net.minecraft.sound.SoundCategory.WEATHER, (float)(strength * .12), 1, false);
    }
    int radius = s.integer("radius");
    double wind = s.number("wind") * (1 + .35 * Math.sin(ticks * .027));
    List<Drop> splashes = new ArrayList<>();
    for (Iterator<Drop> it = DROPS.iterator(); it.hasNext();) {
      Drop d = it.next(); if(!d.snow&&RealisticRain.active()){it.remove();continue;} d.previous = d.position; d.age++;
      if (d.splash) {
        if (d.age > 8) it.remove();
        continue;
      }
      double gust = d.snow ? wind * (d.blizzard ? .12 : .045) : wind * .06;
      d.velocity = new Vec3d(gust + (d.snow ? Math.sin(ticks * .055 + d.phase) * .012 : 0),
          d.snow ? (d.blizzard ? -.11 : -.055) : -.95, gust * .38);
      if(WindFX.enabled()){var shared=AtmosphericWind.sample(ticks*.05);d.velocity=new Vec3d(shared.x()*.06,d.velocity.y,shared.z()*.06);}
      if(!d.snow&&RealisticRain.active()){var directed=RealisticRain.wind(Math.max(.012,gust));d.velocity=new Vec3d(directed.x,d.velocity.y,directed.z);}
      d.position = d.position.add(d.velocity);
      BlockPos pos = BlockPos.ofFloored(d.position);
      if (d.age > 240 || d.position.squaredDistanceTo(camera) > (radius + 10) * (radius + 10)
          || !c.world.isChunkLoaded(pos.getX() >> 4, pos.getZ() >> 4)) { it.remove(); continue; }
      int floor = c.world.getTopY(Heightmap.Type.MOTION_BLOCKING, pos.getX(), pos.getZ());
      if (d.position.y <= floor) {
        // A side-entered roof must not produce a splash above the falling drop.
        if (!d.snow && s.flag("splashes") && d.previous.y >= floor && splashes.size() < 12)
          splashes.add(new Drop(new Vec3d(d.position.x, floor + .025, d.position.z), false, false, true));
        it.remove();
      }
    }
    DROPS.addAll(splashes);
    int cap = (int)(1000 * s.number("density") * Math.min(1, Quality.factor()));
    int spawn = (int)(strength * (mode.equals("Blizzard") ? 32 : snowAt(c.world,eye,mode) ? 14 : 42) * s.number("density") * Math.min(1, Quality.factor()));
    for (int i = 0; i < spawn && DROPS.size() < cap; i++) {
      double x = camera.x + (RANDOM.nextDouble() * 2 - 1) * radius;
      double z = camera.z + (RANDOM.nextDouble() * 2 - 1) * radius;
      double y = camera.y - 3 + RANDOM.nextDouble() * 15;
      BlockPos pos = BlockPos.ofFloored(x, y, z);
      if (!c.world.isChunkLoaded(pos.getX() >> 4, pos.getZ() >> 4)
          || y <= c.world.getTopY(Heightmap.Type.MOTION_BLOCKING, pos.getX(), pos.getZ())) continue;
      boolean snow = snowAt(c.world, pos, mode);
      if(!snow&&RealisticRain.active())continue;
      if (mode.equals("Server") && c.world.getBiome(pos).value().getPrecipitation(pos, c.world.getSeaLevel()) == Biome.Precipitation.NONE) continue;
      DROPS.add(new Drop(new Vec3d(x, y, z), snow,
          snow && (mode.equals("Blizzard") || mode.equals("Server") && s.flag("snowBlizzard")), false));
    }
    // Incremental loaded-column scan; no chunk loads or per-frame terrain queries.
    int diameter = radius * 2 + 1;
    for (int i = 0; i < (s.flag("freeze") ? 32 : 0); i++) {
      int index = Math.floorMod(scan++, diameter * diameter);
      int x = MathHelper.floor(camera.x) + index % diameter - radius;
      int z = MathHelper.floor(camera.z) + index / diameter - radius;
      long key = BlockPos.asLong(x, 0, z);
      if (!c.world.isChunkLoaded(x >> 4, z >> 4)) { SURFACES.remove(key); continue; }
      int y = c.world.getTopY(Heightmap.Type.MOTION_BLOCKING, x, z) - 1;
      BlockPos p = new BlockPos(x, y, z);
      var block = c.world.getBlockState(p);
      boolean water = block.getFluidState().isIn(FluidTags.WATER);
      // Full top faces only: frost cannot bridge stairs, fences, plants or empty space.
      if (Math.abs(y - camera.y) > 18 || (!water && !block.isSideSolidFullSquare(c.world, p, Direction.UP))) {
        SURFACES.remove(key); continue;
      }
      boolean blizzard = mode.equals("Blizzard") || mode.equals("Server") && s.flag("snowBlizzard") && snowAt(c.world, p.up(), mode);
      Surface old = SURFACES.get(key);
      double height = y + (water ? block.getFluidState().getHeight(c.world, p) : 1) + .012;
      if (old == null || Math.abs(old.y - height) > .02) {
        old = new Surface(x, height, z); SURFACES.put(key, old);
      }
      old.blizzard = blizzard;
    }
    for (Iterator<Surface> it = SURFACES.values().iterator(); it.hasNext();) {
      Surface f = it.next();
      if (Math.abs(f.x - camera.x) > radius + 1 || Math.abs(f.z - camera.z) > radius + 1) { it.remove(); continue; }
      boolean freeze = s.flag("freeze") && !mode.equals("Clear") &&
          (mode.equals("Blizzard") || mode.equals("Server") && s.flag("snowBlizzard") && f.blizzard) && strength > .01;
      f.cover = WeatherMath.cover(f.cover, freeze ? strength : 0, .05, s.number("freezeTime"), s.number("thawTime"));
    }
  }

  private static boolean snowAt(World w, BlockPos p, String mode) {
    return mode.equals("Snow") || mode.equals("Blizzard") || mode.equals("Server")
        && w.getBiome(p).value().getPrecipitation(p, w.getSeaLevel()) == Biome.Precipitation.SNOW;
  }

  private static void render(MatrixStack matrices) {
    var c = MinecraftClient.getInstance();
    if (!replaces(c.world) || world != c.world) return;
    if (!CameraEnvironment.surface()) return;
    var settings = settings();
    double radius = settings.number("radius");
    Vec3d camera = c.gameRenderer.getCamera().getCameraPos();
    float delta = c.getRenderTickCounter().getTickProgress(false);
    var rotation = c.gameRenderer.getCamera().getRotation();
    var r = new org.joml.Vector3f(1, 0, 0).rotate(rotation);
    var u = new org.joml.Vector3f(0, 1, 0).rotate(rotation);
    Vec3d right = new Vec3d(r.x, r.y, r.z), up = new Vec3d(u.x, u.y, u.z);
    matrices.push(); matrices.translate(-camera.x, -camera.y, -camera.z);
    var matrix = matrices.peek().getPositionMatrix();
    var frost = BUFFERS.getBuffer(FROST);
    if (settings.flag("freeze")) for (Surface f : SURFACES.values()) {
      if (f.cover < .005) continue;
      double distance=Math.hypot(f.x+.5-camera.x,f.z+.5-camera.z);
      double edge=MathHelper.clamp((radius-distance)/6,0,1);
      int color=((int)(f.cover * edge * settings.number("frostOpacity") * 255)<<24)|0xcbd7df;
      vertex(frost,matrix,new Vec3d(f.x,f.y,f.z),f.x,f.z,color);
      vertex(frost,matrix,new Vec3d(f.x+1,f.y,f.z),f.x+1,f.z,color);
      vertex(frost,matrix,new Vec3d(f.x+1,f.y,f.z+1),f.x+1,f.z+1,color);
      vertex(frost,matrix,new Vec3d(f.x,f.y,f.z+1),f.x,f.z+1,color);
    }
    BUFFERS.draw();
    // Back-to-front within each material, with normal terrain depth testing.
    for (Drop d : DROPS) d.sortDistance = d.position.squaredDistanceTo(camera);
    DROPS.sort(DRAW_ORDER);
    for (int material = 0; material < 2; material++) {
      boolean snow = material == 1;
      var out = BUFFERS.getBuffer(snow ? SNOW : RAIN);
      for (Drop d : DROPS) {
        if (d.snow != snow || !snow&&RealisticRain.active()) continue;
        double px = MathHelper.lerp(delta, d.previous.x, d.position.x);
        double py = MathHelper.lerp(delta, d.previous.y, d.position.y);
        double pz = MathHelper.lerp(delta, d.previous.z, d.position.z);
        double dx = px-camera.x, dy = py-camera.y, dz = pz-camera.z;
        double distance = Math.sqrt(dx*dx+dy*dy+dz*dz);
        double fade = MathHelper.clamp((distance - .6) / 2.5, 0, 1) * MathHelper.clamp((radius + 4 - distance) / 5, 0, 1);
        int alpha = (int)(fade * Math.min(1, (d.age + delta) / 8) * Math.min(1,strength*3) * (snow ? .55 : .34 * RealisticRain.opacity()) * 255);
        if (alpha <= 0) continue;
        if (d.splash) {
          double t = (d.age + delta) / 9;
          double size = .04 + t * .22;
          // Four short outward spray streaks.
          for (int j = 0; j < 4; j++) {
            double angle = j * Math.PI / 2 + d.phase;
            double cs = Math.cos(angle), sn = Math.sin(angle);
            billboard(out, matrix, px+cs*size, py+Math.sin(t*Math.PI)*.12, pz+sn*size,
                right.x*.012, right.y*.012, right.z*.012, cs*.05, .065*(1-t), sn*.05,
                false, ((int)(alpha*(1-t))<<24)|0xb5d7f4);
          }
        } else {
          double size = snow ? .022 + d.phase * .006 : .009;
          double hx = snow ? up.x*size : d.velocity.x*-.38;
          double hy = snow ? up.y*size : d.velocity.y*-.38;
          double hz = snow ? up.z*size : d.velocity.z*-.38;
          billboard(out, matrix, px, py, pz, right.x*size, right.y*size, right.z*size,
              hx, hy, hz, true, (alpha<<24)|(snow?0xe8f3ff:0xa9c9e8));
        }
      }
      BUFFERS.draw();
    }
    matrices.pop();
  }

  private static final Comparator<Drop> DRAW_ORDER = Comparator.comparingDouble(d -> -d.sortDistance);
  private static void billboard(VertexConsumer out, org.joml.Matrix4f m,
      double x, double y, double z, double wx, double wy, double wz,
      double hx, double hy, double hz, boolean centered, int color) {
    double bottom = centered ? 1 : 0;
    out.vertex(m,(float)(x-wx-hx*bottom),(float)(y-wy-hy*bottom),(float)(z-wz-hz*bottom)).texture(0,0).color(color);
    out.vertex(m,(float)(x+wx-hx*bottom),(float)(y+wy-hy*bottom),(float)(z+wz-hz*bottom)).texture(1,0).color(color);
    out.vertex(m,(float)(x+wx+hx),(float)(y+wy+hy),(float)(z+wz+hz)).texture(1,1).color(color);
    out.vertex(m,(float)(x-wx+hx),(float)(y-wy+hy),(float)(z-wz+hz)).texture(0,1).color(color);
  }

  private static void quad(VertexConsumer out, org.joml.Matrix4f m, Vec3d a, Vec3d b, Vec3d c, Vec3d d, int color) {
    vertex(out, m, a, 0, 0, color); vertex(out, m, b, 1, 0, color);
    vertex(out, m, c, 1, 1, color); vertex(out, m, d, 0, 1, color);
  }
  private static void vertex(VertexConsumer out, org.joml.Matrix4f m, Vec3d p, float u, float v, int color) {
    out.vertex(m, (float)p.x, (float)p.y, (float)p.z).texture(u, v).color(color);
  }
  public static int count() { return DROPS.size(); }
  public static double whiteout() {
    return CameraEnvironment.surface() && replaces(MinecraftClient.getInstance().world) ? whiteout : 0;
  }
  public static int frozenCount() { return (int)SURFACES.values().stream().filter(f -> f.cover > .05).count(); }
  private static final class Drop {
    Vec3d position, previous, velocity = Vec3d.ZERO;
    final boolean snow, blizzard, splash;
    final double phase = RANDOM.nextDouble() * Math.PI * 2;
    int age;
    double sortDistance;
    Drop(Vec3d p, boolean snow, boolean blizzard, boolean splash) {
      position = previous = p; this.snow = snow; this.blizzard = blizzard; this.splash = splash;
    }
  }
  private static final class Surface {
    final int x, z; final double y; double cover; boolean blizzard;
    Surface(int x, double y, int z) { this.x = x; this.y = y; this.z = z; }
  }
  private EnhancedWeather() {}
}
