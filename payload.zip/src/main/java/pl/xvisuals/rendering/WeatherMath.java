package pl.xvisuals.rendering;

public final class WeatherMath {
  /** Seconds-based accumulation, bounded and reversible when precipitation ends. */
  public static double cover(double current, double target, double dt, double freeze, double thaw) {
    double step = dt / Math.max(.1, target > current ? freeze : thaw);
    return Math.max(0, Math.min(1, current + Math.max(-step, Math.min(step, target - current))));
  }
  private WeatherMath() {}
}
