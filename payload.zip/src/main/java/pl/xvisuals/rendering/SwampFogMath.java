package pl.xvisuals.rendering;
public final class SwampFogMath {
 public static boolean supported(String biome){return biome.equals("minecraft:swamp")||biome.equals("minecraft:mangrove_swamp");}
 public static int cap(String quality){return JungleMistMath.cap(quality);}
 public static double approach(double current,boolean active){return JungleMistMath.approach(current,active);}
 public static double fade(double distance,double limit){return JungleMistMath.fade(distance,limit);}
 private SwampFogMath(){}
}
