package pl.xvisuals.rendering;
public final class LavafallMistMath {
 public static boolean aboveLava(double relativeY,double fluidHeight){return relativeY>=fluidHeight+.01;}
 public static int cap(String quality){return quality.equals("Low")?64:quality.equals("High")?192:128;}
 public static double strength(boolean impact,int fallHeight,int neighbours){return Math.min(3,.35+Math.clamp(neighbours,0,4)*.13+(impact?.65+Math.log1p(Math.max(0,fallHeight))*.4:0));}
 public static double fade(double age,double life){return Math.clamp(age/10,0,1)*Math.clamp((life-age)/Math.max(10,life*.3),0,1);}
 public static int ember(double age){double t=Math.clamp(age,0,1);return (255<<16)|((int)(190*(1-t)+35*t)<<8)|(int)(65*(1-t));}
 /** 0 no effect, 1 explicit Heat Distortion, 2 restrained lava-only fallback. */
 public static int haze(boolean heat,boolean mist){return heat?1:mist?2:0;}
 private LavafallMistMath(){}
}
