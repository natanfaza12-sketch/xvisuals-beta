package pl.xvisuals.rendering;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.*;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import java.nio.*;
import java.util.OptionalInt;

/** Sky-only geometry, submitted before world terrain. Never changes weather, fog or world state. */
public final class DimensionSkies {
 private static final RenderPipeline PIPELINE=RenderPipeline.builder()
  .withLocation(Identifier.of("xvisuals","pipeline/dimension_sky"))
  .withVertexShader(Identifier.of("xvisuals","core/dimension_sky"))
  .withFragmentShader(Identifier.of("xvisuals","core/dimension_sky"))
  .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER)
  .withUniform("Fog",UniformType.UNIFORM_BUFFER).withSampler("Panorama")
  .withVertexFormat(VertexFormats.POSITION,VertexFormat.DrawMode.TRIANGLES).withBlend(BlendFunction.TRANSLUCENT)
  .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).build();
 private static final Identifier FALLBACK=Identifier.ofVanilla("textures/environment/end_sky.png");
 private static GpuBuffer cube;
 private static Object world;
 private static int ticks,preset,oldPreset;
 private static double time,opacity,previousOpacity,transition=1,previousTransition;
 private static boolean shaders;
 private static String image="";
 private static final Matrix4f EXTRA=new Matrix4f();
 private static final Vector4f PARAMS=new Vector4f();
 private static final Vector3f OPTIONS=new Vector3f();
 public static void init(){ClientTickEvents.END_CLIENT_TICK.register(DimensionSkies::tick);ClientLifecycleEvents.CLIENT_STOPPING.register(c->close());}
 private static boolean targetDimension(MinecraftClient c){return c.world!=null&&(c.world.getRegistryKey().equals(World.NETHER)||c.world.getRegistryKey().equals(World.END));}
 public static boolean nether(){var c=MinecraftClient.getInstance();return c.world!=null&&c.world.getRegistryKey().equals(World.NETHER);}
 public static boolean active(){
  var c=MinecraftClient.getInstance();if(!XVisuals.ready()||!targetDimension(c)||world!=c.world||ShaderPackSupport.active()||Math.max(opacity,previousOpacity)<.002||!CameraEnvironment.surface())return false;
  var focused=c.gameRenderer.getCamera().getFocusedEntity();return !(focused instanceof LivingEntity living&&(living.hasStatusEffect(StatusEffects.BLINDNESS)||living.hasStatusEffect(StatusEffects.DARKNESS)));
 }
 public static String status(){return shaders?"Shader pack active: using its sky renderer.":DimensionSkyTexture.status();}
 private static void tick(MinecraftClient c){
  if(world!=c.world){close();world=c.world;ticks=0;shaders=FabricLoader.getInstance().isModLoaded("iris");}
  if(!XVisuals.ready()||!targetDimension(c)){if(cube!=null)close();return;}
  if(ticks++%20==0){shaders=false;if(FabricLoader.getInstance().isModLoaded("iris"))try{
   var api=Class.forName("net.irisshaders.iris.api.v0.IrisApi");shaders=(boolean)api.getMethod("isShaderPackInUse").invoke(api.getMethod("getInstance").invoke(null));
  }catch(ReflectiveOperationException|LinkageError ex){shaders=true;}}
  if(c.isPaused())return;
  var s=XVisuals.visualModule("dimensionskies");boolean selected=DimensionSkyMath.selected(s.text("dimension"),c.world.getRegistryKey().getValue().toString());
  int next=DimensionSkyMath.preset(s.text(nether()?"netherPreset":"endPreset"),nether());
  boolean changedImage=!s.text("image").equals(image);
  boolean usingImage=DimensionSkyMath.needsImage(preset,oldPreset,transition);
  // Keep the old texture alive while it fades; swapping two preset-8 images needs its own transition.
  if(changedImage&&(!s.flag("smooth")||!usingImage||opacity<.01)){
   image=s.text("image");DimensionSkyTexture.close();changedImage=false;
  }
  boolean wanted=s.enabled&&selected&&next>=0&&!shaders&&!changedImage;
  previousOpacity=opacity;opacity=s.flag("smooth")?DimensionSkyMath.approach(opacity,wanted?1:0,.05):wanted?1:0;
  previousTransition=transition;
  if(next>=0&&next!=preset){oldPreset=preset;preset=next;transition=previousTransition=opacity<.02?1:0;}
  transition=s.flag("smooth")?Math.min(1,transition+.05/1.2):1;
  if(opacity<.002&&!wanted){release();return;}
  time+=.05*s.number("speed");
  if(wanted&&s.flag("particles")&&ticks%6==0&&c.player!=null&&active()){
   var random=c.world.random;var camera=c.gameRenderer.getCamera().getCameraPos();double x=camera.x+(random.nextDouble()*2-1)*9,y=camera.y+random.nextDouble()*7-2,z=camera.z+(random.nextDouble()*2-1)*9;
   var pos=BlockPos.ofFloored(x,y,z);
   if(c.world.isChunkLoaded(pos.getX()>>4,pos.getZ()>>4)&&c.world.getBlockState(pos).isAir()){
    var particle=nether()?(preset==2?ParticleTypes.WHITE_ASH:ParticleTypes.ASH):ParticleTypes.END_ROD;
    if(nether()&&preset==0)particle=ParticleTypes.SMALL_FLAME;
    c.world.addParticleClient(particle,x,y,z,.008,nether()&&preset==0?.012:-.008,.004);
   }
  }
 }
 public static void render(Framebuffer target){
  if(!active())return;var client=MinecraftClient.getInstance();var s=XVisuals.visualModule("dimensionskies");
  if(cube==null){
   float[][] corners={{-1,-1,-1},{1,-1,-1},{1,1,-1},{-1,1,-1},{-1,-1,1},{1,-1,1},{1,1,1},{-1,1,1}};
   int[] indices={0,1,2,0,2,3,5,4,7,5,7,6,4,0,3,4,3,7,1,5,6,1,6,2,3,2,6,3,6,7,4,5,1,4,1,0};
   var data=ByteBuffer.allocateDirect(432).order(ByteOrder.nativeOrder());for(int i:indices)for(float value:corners[i])data.putFloat(value*512);data.flip();
   cube=RenderSystem.getDevice().createBuffer(()->"Dimension sky cube",GpuBuffer.USAGE_VERTEX,data);
  }
  float delta=client.getRenderTickCounter().getTickProgress(false);
  double alpha=previousOpacity+(opacity-previousOpacity)*delta,blend=previousTransition+(transition-previousTransition)*delta;
  int current=preset,previous=oldPreset;boolean needsImage=DimensionSkyMath.needsImage(current,previous,blend);
  if(!needsImage)DimensionSkyTexture.close();
  var custom=needsImage?DimensionSkyTexture.get(image):null;
  if(custom==null){if(current==8)current=nether()?0:4;if(previous==8)previous=nether()?0:4;}
  var texture=custom!=null?custom:client.getTextureManager().getTexture(FALLBACK);
  int color=s.color("color");float clock=(float)(time+(client.isPaused()?0:delta*.05*s.number("speed")));
  PARAMS.set(clock,current,(float)s.number("brightness"),(float)alpha);
  OPTIONS.set((float)Math.toRadians(s.number("rotation")),s.flag("stars")?1:0,s.flag("nebula")?1:0);
  EXTRA.identity().m00(((color>>16)&255)/255f).m01(((color>>8)&255)/255f).m02((color&255)/255f)
   .m10(previous).m11((float)blend).m12(custom!=null?DimensionSkyTexture.layout():0).m13(nether()?1:0);
  var transform=RenderSystem.getDynamicUniforms().write(RenderSystem.getModelViewMatrix(),PARAMS,OPTIONS,EXTRA);
  try(var pass=RenderSystem.getDevice().createCommandEncoder().createRenderPass(()->"Dimension sky",target.getColorAttachmentView(),OptionalInt.empty())){
   pass.setPipeline(PIPELINE);RenderSystem.bindDefaultUniforms(pass);pass.setUniform("DynamicTransforms",transform);
   pass.bindTexture("Panorama",texture.getGlTextureView(),RenderSystem.getSamplerCache().get(com.mojang.blaze3d.textures.FilterMode.LINEAR));
   pass.setVertexBuffer(0,cube);pass.draw(0,36);
  }
 }
 private static void release(){if(cube!=null){cube.close();cube=null;}DimensionSkyTexture.close();}
 public static void close(){release();world=null;opacity=previousOpacity=time=0;transition=previousTransition=1;preset=oldPreset=0;}
 private DimensionSkies(){}
}
