package pl.xvisuals.rendering;
import pl.xvisuals.XVisuals;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.*;
import net.minecraft.client.MinecraftClient;
import com.mojang.blaze3d.systems.*;
/** Shared local weather flow. Terrain vertices only move on the GPU. */
public final class WindFX {
 private static double x,z,previousX,previousZ,time,previousTime,sway,previousSway;
 private static Object world;private static int ticks;
 
 public static boolean nativeTerrain(){return pl.xvisuals.bootstrap.WindTerrainSupport.nativeTerrain();}
 public static boolean enabled(){return XVisuals.ready()&&XVisuals.visualModule("windfx").enabled;}
 public static boolean leaves(){return enabled()&&XVisuals.visualModule("windfx").flag("leaves");}
 public static void init(){WindStreaks.init();AtmosphericWind.setSource(seconds->enabled()?new AtmosphericWind.Flow(x,z):AtmosphericWind.fallback(seconds));ClientTickEvents.END_CLIENT_TICK.register(WindFX::tick);ClientLifecycleEvents.CLIENT_STOPPING.register(c->{pl.xvisuals.bootstrap.WindTerrainSupport.close();});}
 private static void tick(MinecraftClient c){
  if(world!=c.world){world=c.world;x=z=previousX=previousZ=time=previousTime=sway=previousSway=0;}
  if(c.world==null||c.player==null){WindStreaks.clear();return;}if(c.isPaused())return;
  previousX=x;previousZ=z;previousTime=time;previousSway=sway;ticks++;
  var s=XVisuals.visualModule("windfx");boolean on=enabled();
  time+=.05*(on?s.number("speed"):1);
  double rain=s.flag("weather")?Math.max(c.world.getRainGradient(1),Storm.running()?Storm.rain():0):0;
  boolean thunder=s.flag("weather")&&(Storm.running()||c.world.isThundering());
  double force=on?WindMath.strength(s.number("strength"),rain,thunder)*.45:0;
  if(on&&s.flag("gusts"))force*=WindMath.gust(time,s.number("frequency"));
  force=Math.min(3,force);double angle=Math.toRadians(s.number("direction"));
  x+=(Math.cos(angle)*force-x)*.08;z+=(Math.sin(angle)*force-z)*.08;
  sway+=((on&&s.flag("sway")?1:0)-sway)*.12;
  WindStreaks.tick(c,on&&s.flag("airborne"),x,z,s.number("speed"));
 }
 public static void beginFrame(){
  if(!nativeTerrain())return;
  var c=MinecraftClient.getInstance();float a=c.getRenderTickCounter().getTickProgress(false);
  double amount=c.world==null?0:previousSway+(sway-previousSway)*a;
  pl.xvisuals.bootstrap.WindTerrainSupport.update((float)((previousX+(x-previousX)*a)*amount),(float)((previousZ+(z-previousZ)*a)*amount),(float)(previousTime+(time-previousTime)*a));
 }
 public static void bind(RenderPass pass){pl.xvisuals.bootstrap.WindTerrainSupport.bind(pass);}
 private WindFX(){}
}
