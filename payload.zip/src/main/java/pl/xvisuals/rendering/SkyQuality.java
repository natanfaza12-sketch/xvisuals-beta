package pl.xvisuals.rendering;

/** Explicit pixel budgets: window resolution must not silently select supersampling. */
public final class SkyQuality {
  public record Target(int width, int height, int detail) {}

  public static Target target(String mode, int width, int height, double scale, double detail) {
    return target(mode, width, height, scale, detail, 1);
  }

  public static boolean adaptive(String mode) {
    return mode.equals("Balanced") || mode.equals("Performance") || mode.equals("Cinematic");
  }

  public static Target target(String mode, int width, int height, double scale, double detail, double adaptive) {
    width = Math.max(16, width); height = Math.max(16, height);
    double factor; int samples;
    switch (mode) {
      case "4K Ultra" -> { factor = Math.max(1, 2160.0 / height); samples = 3; }
      case "Native Ultra" -> { factor = 1; samples = 3; }
      case "Custom" -> { factor = Math.clamp(scale, .35, 1); samples = (int)Math.clamp(detail, 1, 3); }
      case "Performance" -> { factor = budget(width, height, .55, 600, 640_000); samples = 1; }
      case "Cinematic" -> { factor = budget(width, height, 1, 1080, 2_073_600); samples = 3; }
      default -> { factor = budget(width, height, .9, 1080, 2_073_600); samples = 2; }
    }
    if (adaptive(mode)) factor *= Math.clamp(adaptive, .5, 1);
    factor = Math.min(factor, 8192.0 / Math.max(width, height));
    return new Target(Math.max(16, (int)Math.round(width * factor)),
        Math.max(16, (int)Math.round(height * factor)), samples);
  }

  private static double budget(int width, int height, double scale, int maxHeight, int pixels) {
    return Math.min(scale, Math.min((double)maxHeight / height, Math.sqrt((double)pixels / ((double)width * height))));
  }

  private SkyQuality() {}
}
