package pl.xvisuals.rendering;
import pl.xvisuals.XVisuals;
import pl.xvisuals.util.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
/** Layered artwork in the world pass; foreground terrain naturally occludes it. */
public final class CelestialRenderer {
 public static void renderWorld(MatrixStack matrices){
  var c=MinecraftClient.getInstance();var s=XVisuals.config().module("celestial");
  if(c.world==null||!s.enabled||CinematicSky.active())return;
  double t=(c.world.getTime()+c.getRenderTickCounter().getTickProgress(false))/20.*s.number("speed"),alpha=s.number("intensity");
  var eye=c.gameRenderer.getCamera().getCameraPos();
  if(s.flag("stars")){CraftedSprites.begin();for(int i=0;i<(int)(90*Math.min(1,Quality.factor()));i++){
    double a=i*2.39996,e=.3+(i*.618%1)*1.1;
    CraftedSprites.add(eye.add(Math.cos(a)*Math.cos(e)*180,Math.sin(e)*180,Math.sin(a)*Math.cos(e)*180),.7,.7,0,5,(int)(t*4+i),Colors.alpha(s.color("secondary"),alpha));
   }CraftedSprites.draw(matrices);}
  for(String name:new String[]{"nebula","aurora"})if(s.flag(name)){
   CraftedSprites.begin();for(int i=0;i<10;i++){double a=i*Math.PI/5+t*.005;
    CraftedSprites.plane(eye.add(Math.cos(a)*170,95,Math.sin(a)*170),new Vec3d(-Math.sin(a)*125,0,Math.cos(a)*125),new Vec3d(0,65,0),Colors.alpha(i%2==0?s.color("color"):s.color("secondary"),alpha));
   }CraftedSprites.draw(matrices,Identifier.of("xvisuals","textures/crafted/"+name+".png"),false);
  }
 }
 private CelestialRenderer(){}
}
