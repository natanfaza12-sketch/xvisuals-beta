package pl.xvisuals.rendering;

import net.minecraft.block.enums.CameraSubmersionType;
import net.minecraft.client.MinecraftClient;

/** Surface-only effects follow the camera, including third-person and spectator views. */
public final class CameraEnvironment {
  public static boolean surface() {
    var c=MinecraftClient.getInstance();
    return c.world!=null && surface(c.gameRenderer.getCamera().getSubmersionType());
  }
  public static boolean surface(CameraSubmersionType type) {
    return type==CameraSubmersionType.NONE;
  }
  private CameraEnvironment() {}
}
