package pl.xvisuals.rendering;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.mixins.RenderLayerAccessor;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.util.Identifier;
import java.util.Map;
/** Skin-preserving silky trails with soft luminous silhouette edges. */
public final class SwingTrailMaterial {
 private static final RenderPipeline PIPE=RenderPipeline.builder().withLocation(Identifier.of("xvisuals","pipeline/swing_silk"))
 .withVertexShader(Identifier.of("xvisuals","core/spirit")).withFragmentShader(Identifier.of("xvisuals","core/swing_silk"))
 .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER).withSampler("Sampler0")
 .withVertexFormat(VertexFormats.POSITION_COLOR_TEXTURE_OVERLAY_LIGHT_NORMAL,VertexFormat.DrawMode.QUADS)
 .withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withDepthWrite(false).withCull(false).build();
 private static final Map<Identifier,RenderLayer> LAYERS=new pl.xvisuals.util.BoundedCache<>(128);
 public static RenderLayer layer(Identifier texture){return LAYERS.computeIfAbsent(texture,t->RenderLayerAccessor.visuals$of("swing_silk",RenderSetup.builder(PIPE).texture("Sampler0",t).translucent().expectedBufferSize(131072).build()));}
 private SwingTrailMaterial(){}
}
