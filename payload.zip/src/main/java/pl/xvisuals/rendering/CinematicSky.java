package pl.xvisuals.rendering;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import java.nio.*;
import java.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

/** Authored panoramas on independently moving depth shells, drawn before terrain. */
public final class CinematicSky {
  public static final List<String> PRESETS =
      pl.xvisuals.modules.SkyScenes.ALL;
  private static final RenderPipeline IMAGE_PIPELINE = RenderPipeline.builder()
      .withLocation(Identifier.of("xvisuals","pipeline/custom_sky"))
      .withVertexShader(Identifier.of("xvisuals","core/cinematic_sky"))
      .withFragmentShader(Identifier.of("xvisuals","core/custom_sky"))
      .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER)
      .withUniform("Projection",UniformType.UNIFORM_BUFFER).withSampler("Panorama")
      .withVertexFormat(VertexFormats.POSITION,VertexFormat.DrawMode.TRIANGLES)
      .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).build();
  private static final RenderPipeline COMPOSITE =
      RenderPipeline.builder()
          .withLocation(Identifier.of("xvisuals", "pipeline/sky_composite"))
          .withVertexShader(Identifier.of("xvisuals", "core/sky_composite"))
          .withFragmentShader(Identifier.of("xvisuals", "core/sky_composite"))
          .withSampler("SkySampler")
          .withVertexFormat(VertexFormats.POSITION, VertexFormat.DrawMode.TRIANGLES)
          .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
          .withDepthWrite(false)
          .withCull(false)
          .build();
  private static final RenderPipeline LAYERED_PIPELINE=RenderPipeline.builder()
      .withLocation(Identifier.of("xvisuals","pipeline/layered_sky"))
      .withVertexShader(Identifier.of("xvisuals","core/cinematic_sky"))
      .withFragmentShader(Identifier.of("xvisuals","core/layered_sky"))
      .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER)
      .withUniform("Projection",UniformType.UNIFORM_BUFFER)
      .withSampler("Panorama").withSampler("Veil")
      .withVertexFormat(VertexFormats.POSITION,VertexFormat.DrawMode.TRIANGLES)
      .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).build();
  private static GpuBuffer cube, screen;
  private static net.minecraft.client.gl.SimpleFramebuffer target;
  private static final Matrix4f IDENTITY = new Matrix4f();
  private static final Matrix4f WEATHER = new Matrix4f();
  private static final Vector4f PARAMS = new Vector4f();
  private static final Vector3f OPTIONS = new Vector3f();
  private static final SkyBudget BUDGET = new SkyBudget();
  private static long lastTime;
  private static double animation;
  private static Object world;
  private static String lastQuality = "";
  private static double originX,originY,originZ;

  public static boolean active() {
    var c = MinecraftClient.getInstance();
    return XVisuals.ready()
        && XVisuals.config().on("cinematicsky")
        && CameraEnvironment.surface()
        && c.world != null
        && c.world.getRegistryKey() == World.OVERWORLD;
  }

  public static void render() {
    if (!active()) return;
    if (cube == null) {
      float[][] corners = {
        {-1, -1, -1},
        {1, -1, -1},
        {1, 1, -1},
        {-1, 1, -1},
        {-1, -1, 1},
        {1, -1, 1},
        {1, 1, 1},
        {-1, 1, 1}
      };
      int[] indices = {
        0, 1, 2, 0, 2, 3, 5, 4, 7, 5, 7, 6, 4, 0, 3, 4, 3, 7, 1, 5, 6, 1, 6, 2, 3, 2, 6, 3, 6, 7, 4,
        5, 1, 4, 1, 0
      };
      ByteBuffer data =
          ByteBuffer.allocateDirect(indices.length * 12).order(ByteOrder.nativeOrder());
      for (int i : indices) for (float coordinate : corners[i]) data.putFloat(coordinate * 512);
      data.flip();
      cube =
          RenderSystem.getDevice()
              .createBuffer(() -> "X Visuals sky cube", GpuBuffer.USAGE_VERTEX, data);
    }
    var s = XVisuals.config().module("cinematicsky");
    var client = MinecraftClient.getInstance();
    var cameraPos=client.gameRenderer.getCamera().getCameraPos();
    if(world!=client.world){originX=cameraPos.x;originY=cameraPos.y;originZ=cameraPos.z;}
    if (world != client.world || !lastQuality.equals(s.text("quality"))) {
      BUDGET.reset(); world = client.world; lastQuality = s.text("quality"); lastTime = 0;
    }
    long now = System.nanoTime();
    if (lastTime != 0 && !client.isPaused()) animation += Math.min(.1, (now - lastTime) / 1e9) * s.number("speed");
    lastTime = now;
    boolean adaptive = s.flag("adaptive") && SkyQuality.adaptive(s.text("quality"));
    if (adaptive && client.isWindowFocused() && !client.isPaused()) {
      int fpsTarget = Math.min(s.integer("targetFps"), client.options.getMaxFps().getValue());
      if (client.options.getEnableVsync().getValue()) fpsTarget = Math.min(fpsTarget, 60);
      BUDGET.update(now, client.getCurrentFps(), fpsTarget);
    }
    var main = client.getFramebuffer();
    var quality = SkyQuality.target(s.text("quality"), main.textureWidth, main.textureHeight,
        s.number("resolution"), s.number("detail"), adaptive ? BUDGET.scale() : 1);
    boolean imageSky=s.text("preset").equals("Custom Image");
    var panorama = imageSky ? CustomSkyImage.get(s.text("image")) : null;
    String scene = imageSky && panorama == null ? "Aurora Veil" : s.text("preset");
    boolean layered=pl.xvisuals.modules.SkyScenes.layered(scene);
    if (!imageSky && !layered) { scene="Aurora Veil"; layered=true; }
    int targetWidth = imageSky?main.textureWidth:quality.width();
    int targetHeight = imageSky?main.textureHeight:quality.height();
    if (target == null)
      target =
          new net.minecraft.client.gl.SimpleFramebuffer(
              "X Visuals sky", targetWidth, targetHeight, false);
    else if (target.textureWidth != targetWidth || target.textureHeight != targetHeight)
      target.resize(targetWidth, targetHeight);
    if (screen == null) {
      ByteBuffer vertices = ByteBuffer.allocateDirect(36).order(ByteOrder.nativeOrder());
      vertices
          .putFloat(-1)
          .putFloat(-1)
          .putFloat(0)
          .putFloat(3)
          .putFloat(-1)
          .putFloat(0)
          .putFloat(-1)
          .putFloat(3)
          .putFloat(0)
          .flip();
      screen =
          RenderSystem.getDevice()
              .createBuffer(() -> "Sky composite triangle", GpuBuffer.USAGE_VERTEX, vertices);
    }
    float time = (float)animation;
    PARAMS.set(
        time,
        pl.xvisuals.modules.SkyScenes.shaderId(scene),
        (float) s.number("brightness"),
        quality.detail());
    OPTIONS.set(
        (float) Math.toRadians(s.number("rotation")),
        s.flag("stars") ? 1 : 0,
        (float) s.number("haze"));
    // The sky shader draws its own clouds, independently of the vanilla cloud pass.
    WEATHER.identity().m30(Storm.running() ? Storm.darkness() : WeatherTransitions.cloud())
        .m31(Storm.flash()).m32(time).m33(Lightning.flashChannel(0))
        .m12(Lightning.flashChannel(16)).m13(Lightning.flashChannel(8));
    float depth=s.flag("depth3d")?(float)s.number("depth"):0;
    WEATHER.m00(SkyDepth.offset(cameraPos.x-originX,depth))
        .m01(SkyDepth.offset(cameraPos.y-originY,depth))
        .m02(SkyDepth.offset(cameraPos.z-originZ,depth)).m03(depth)
        .m10((float)s.number("veil")).m11(panorama!=null?1:0)
        .m20((float)s.number("starSize")).m21((float)s.number("starBrightness"))
        .m22((float)s.number("starDensity")).m23((float)s.number("starTwinkle"));
    var transform =
        RenderSystem.getDynamicUniforms()
            .write(RenderSystem.getModelViewMatrix(), PARAMS, OPTIONS, WEATHER);
    var framebuffer = MinecraftClient.getInstance().getFramebuffer();
    boolean useLayers=layered || panorama!=null&&s.flag("depth3d");
    // Texture uploads must finish before opening the GPU render pass.
    var art=layered?client.getTextureManager().getTexture(Identifier.of("xvisuals","textures/skies/layered/"
        +pl.xvisuals.modules.SkyScenes.artwork(scene)+".png")):null;
    var veil=useLayers?client.getTextureManager().getTexture(Identifier.of("xvisuals","textures/skies/layered/"+pl.xvisuals.modules.SkyScenes.veil(scene)+".png")):null;

    try (var pass =
        RenderSystem.getDevice()
            .createCommandEncoder()
            .createRenderPass(
                () -> "X Visuals cinematic sky",
                target.getColorAttachmentView(),
                OptionalInt.empty())) {
      pass.setPipeline(useLayers?LAYERED_PIPELINE:IMAGE_PIPELINE);
      if(layered){
        pass.bindTexture("Panorama",art.getGlTextureView(),RenderSystem.getSamplerCache().get(com.mojang.blaze3d.textures.FilterMode.LINEAR));
      }else if(panorama != null)pass.bindTexture("Panorama",panorama.getGlTextureView(),
          RenderSystem.getSamplerCache().get(com.mojang.blaze3d.textures.FilterMode.LINEAR));
      if(useLayers){
        pass.bindTexture("Veil",veil.getGlTextureView(),RenderSystem.getSamplerCache().get(com.mojang.blaze3d.textures.FilterMode.LINEAR));
      }
      RenderSystem.bindDefaultUniforms(pass);
      pass.setUniform("DynamicTransforms", transform);
      pass.setVertexBuffer(0, cube);
      pass.draw(0, 36);
    }
    try (var pass =
        RenderSystem.getDevice()
            .createCommandEncoder()
            .createRenderPass(
                () -> "X Visuals sky upscale",
                framebuffer.getColorAttachmentView(),
                OptionalInt.empty())) {
      pass.setPipeline(COMPOSITE);
      pass.bindTexture(
          "SkySampler",
          target.getColorAttachmentView(),
          RenderSystem.getSamplerCache().get(com.mojang.blaze3d.textures.FilterMode.LINEAR));
      pass.setVertexBuffer(0, screen);
      pass.draw(0, 3);
    }

  }

  public static void tick() {
    if (!active() && (world != null || target != null || cube != null)) close();
  }

  public static void close() {
    CustomSkyImage.close();
    world = null;
    lastQuality = "";
    lastTime = 0;
    BUDGET.reset();
    if (cube != null) {
      cube.close();
      cube = null;
    }
    if (screen != null) {
      screen.close();
      screen = null;
    }
    if (target != null) {
      target.delete();
      target = null;
    }
  }

  /** Save the actual sky render target, before display downsampling, in explicit dev runs. */
  public static void captureDevelopmentSky(String name) {
    if (target != null && Boolean.getBoolean("visuals.skies4k")
        && net.fabricmc.loader.api.FabricLoader.getInstance().isDevelopmentEnvironment()) {
      var client = MinecraftClient.getInstance();
      net.minecraft.client.util.ScreenshotRecorder.saveScreenshot(
          client.runDirectory, "4k-" + name, target, 1, message -> {});
    }
  }

  private CinematicSky() {}
}
