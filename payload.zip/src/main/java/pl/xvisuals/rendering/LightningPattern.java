package pl.xvisuals.rendering;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Pure, bounded bolt generation; geometry is generated once, not randomised every frame. */
public final class LightningPattern {
  public record Segment(double x0,double y0,double z0,double x1,double y1,double z1,boolean branch,double width0,double width1) {}
  private record Point(double x,double y,double z) {}
  public static List<Segment> create(long seed,double height) {
    height=bound(height,60,32,112);
    var random=new Random(seed);
    var segments=new ArrayList<Segment>(256);
    int shape=random.nextInt(3),depth=5+random.nextInt(2);
    double bearing=random.nextDouble()*Math.PI*2;
    double lean=height*(.1+random.nextDouble()*.25);
    double width=.12+random.nextDouble()*.12;
    var top=new Point(Math.cos(bearing)*lean,height,Math.sin(bearing)*lean);
    var ground=new Point(0,0,0);
    var trunk=channel(top,ground,depth,height*(shape==0?.12:.075),random);
    append(segments,trunk,false,width);
    int forks=shape==0?3+random.nextInt(3):5+random.nextInt(3);
    for(int fork=0;fork<forks;fork++){
      int index=2+random.nextInt(Math.max(1,(int)(trunk.size()*.72)-2));
      var start=trunk.get(index);
      double angle=bearing+(fork%2==0?1:-1)*(1+random.nextDouble()*1.4);
      double reach=height*(shape==2?.22:.12)*(1+random.nextDouble());
      double drop=Math.min(start.y-.5,height*(.13+random.nextDouble()*.3));
      var tip=new Point(start.x+Math.cos(angle)*reach,start.y-drop,start.z+Math.sin(angle)*reach);
      double branchWidth=width*(.35+random.nextDouble()*.3);
      var branch=channel(start,tip,4,reach*.17,random);
      append(segments,branch,true,branchWidth);
      if(random.nextDouble()<.7){
        int attach=4+random.nextInt(7);var twigStart=branch.get(attach);
        double side=angle+(random.nextBoolean()?1:-1)*(.6+random.nextDouble());
        var twigEnd=new Point(twigStart.x+Math.cos(side)*reach*.4,Math.max(.1,twigStart.y-drop*.4),twigStart.z+Math.sin(side)*reach*.4);
        append(segments,channel(twigStart,twigEnd,3,reach*.06,random),true,branchWidth*(1-attach/16d)*.5);
      }
    }
    return List.copyOf(segments);
  }
  private static List<Point> channel(Point from,Point to,int depth,double roughness,Random random){
    var points=new ArrayList<Point>();points.add(from);subdivide(points,from,to,depth,roughness,random);return points;
  }
  private static void subdivide(List<Point> out,Point from,Point to,int depth,double roughness,Random random){
    if(depth==0){out.add(to);return;}
    var mid=new Point((from.x+to.x)*.5+(random.nextDouble()*2-1)*roughness,(from.y+to.y)*.5,(from.z+to.z)*.5+(random.nextDouble()*2-1)*roughness);
    subdivide(out,from,mid,depth-1,roughness*.52,random);
    subdivide(out,mid,to,depth-1,roughness*.52,random);
  }
  private static void append(List<Segment> out,List<Point> points,boolean branch,double width){
    int count=points.size()-1;
    for(int i=0;i<count;i++){
      var a=points.get(i);var b=points.get(i+1);
      double start=width*(branch?1-.92*i/count:.86+.14*Math.sin(Math.PI*i/count));
      double end=width*(branch?1-.92*(i+1)/count:.86+.14*Math.sin(Math.PI*(i+1)/count));
      out.add(new Segment(a.x,a.y,a.z,b.x,b.y,b.z,branch,Math.max(.002,start),Math.max(.002,end)));
    }
  }
  public static double opacity(double seconds) {
    if(!Double.isFinite(seconds)||seconds<=0||seconds>=.9)return 0;
    double first=Math.exp(-Math.pow((seconds-.055)/.042,2));
    double second=.8*Math.exp(-Math.pow((seconds-.27)/.07,2));
    double tail=.22*Math.sin(Math.PI*seconds/.9);
    return Math.min(1,Math.max(first,second)+tail);
  }
  public static int intervalTicks(double frequency,double jitter) {
    return Math.max(20,(int)Math.round(1200/bound(frequency,12,1,60)
        *(.8+.4*bound(jitter,.5,0,1))));
  }
  public static double distance(double value) { return bound(value,48,16,96); }
  public static int thunderTicks(double distance) { return (int)Math.round(4+distance(distance)/90*20); }
  public static double unit(double value) { return bound(value,0,0,1); }
  private static double bound(double value,double fallback,double min,double max) {
    return Math.clamp(Double.isFinite(value)?value:fallback,min,max);
  }
  private LightningPattern() {}
}
