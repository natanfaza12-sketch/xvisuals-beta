package pl.xvisuals.rendering;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.*;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import java.nio.*;
import java.util.*;

/** Local depth-softened mountain cloud wisps and gusts; no world changes. */
public final class MountainWinds {
 private static final List<Puff> PARTICLES=new ArrayList<>();private static final Random RANDOM=new Random();
 private static final ByteBuffer VERTICES=ByteBuffer.allocateDirect(192*6*24).order(ByteOrder.nativeOrder());
 private static MappableRingBuffer vertices;private static Object world;private static int ticks;private static double blend,clock,ashCredit,smokeCredit;private static boolean failed;
 private static WindSound windSound;private static double soundTarget;private static int soundStarted;
 private static final class WindSound extends net.minecraft.client.sound.MovingSoundInstance {
  WindSound(){super(net.minecraft.sound.SoundEvents.ITEM_ELYTRA_FLYING,net.minecraft.sound.SoundCategory.AMBIENT,net.minecraft.util.math.random.Random.create());repeat=true;repeatDelay=0;relative=true;attenuationType=net.minecraft.client.sound.SoundInstance.AttenuationType.NONE;volume=.001f;pitch=.65f;}
  @Override public void tick(){volume+=(float)(soundTarget-volume)*.08f;if(!enabled()||MinecraftClient.getInstance().world!=world)setDone();}
 }
 private static final Matrix4f OPTIONS=new Matrix4f();private static final Vector4f WHITE=new Vector4f(1,1,1,1);private static final Vector3f ZERO=new Vector3f();
 private static final RenderPipeline PIPELINE=RenderPipeline.builder().withLocation(Identifier.of("xvisuals","pipeline/mountainwinds"))
  .withVertexShader(Identifier.of("xvisuals","core/lavafall_mist")).withFragmentShader(Identifier.of("xvisuals","core/lavafall_mist"))
  .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER).withUniform("Fog",UniformType.UNIFORM_BUFFER).withSampler("SceneDepth")
  .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.TRIANGLES).withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).build();
 private static class Puff {Vec3d pos,previous;double size,life,phase,ground=1;int age;boolean smoke;}
 public static void init(){ClientTickEvents.END_CLIENT_TICK.register(MountainWinds::tick);WorldRenderEvents.END_MAIN.register(c->render(c.matrices()));ClientLifecycleEvents.CLIENT_STOPPING.register(c->clear());}
 private static boolean enabled(){return XVisuals.ready()&&XVisuals.visualModule("mountainwinds").enabled;}
 private static void clear(){soundTarget=0;if(windSound!=null){MinecraftClient.getInstance().getSoundManager().stop(windSound);windSound=null;}PARTICLES.clear();blend=0;clock=0;ashCredit=smokeCredit=0;failed=false;if(vertices!=null){vertices.close();vertices=null;}}
 private static boolean peaks(MinecraftClient c,BlockPos p){return MountainWindsMath.supported(c.world.getBiome(p).getKey().map(k->k.getValue().toString()).orElse(""));}
 private static boolean shaderPack(){return ShaderPackSupport.active();}
 private static void tick(MinecraftClient c){
  if(world!=c.world||!enabled()){world=c.world;clear();}
  if(!enabled()||c.world==null||c.player==null||c.isPaused())return;
  if(shaderPack()){clear();return;}ticks++;clock+=.05;
  var camera=c.gameRenderer.getCamera().getCameraPos();boolean active=peaks(c,c.player.getBlockPos());blend=JungleMistMath.approach(blend,active);
  var s=XVisuals.visualModule("mountainwinds");double radius=s.number("distance");int cap=MountainWindsMath.cap(s.text("quality"));double gust=EmberstormMath.gust(clock,s.number("gust"));while(PARTICLES.size()>cap)PARTICLES.removeFirst();var wind=AtmosphericWind.sample(clock);double altitude=MountainWindsMath.altitude(camera.y,s.flag("altitude"));int ash=0,smoke=0;
  soundTarget=s.flag("sound")?Math.min(.16,s.number("wind")*altitude*(.025+gust*.055))*blend:0;
  if(windSound!=null&&ticks-soundStarted>20&&!c.getSoundManager().isPlaying(windSound))windSound=null;
  if(soundTarget>.001&&windSound==null){windSound=new WindSound();soundStarted=ticks;c.getSoundManager().play(windSound);}
  if(soundTarget<.001&&windSound!=null&&windSound.getVolume()<.003){c.getSoundManager().stop(windSound);windSound=null;}
  for(var it=PARTICLES.iterator();it.hasNext();){var p=it.next();p.previous=p.pos;p.age++;
   if(p.age>=p.life||p.pos.squaredDistanceTo(camera)>radius*radius||p.smoke&&!s.flag("clouds")||!p.smoke&&!s.flag("particles")){it.remove();continue;}
   if(p.smoke)smoke++;else ash++;
   double phase=p.phase+clock*.45,strength=s.number("wind")*altitude*(.45+gust*2),speed=p.smoke?.4:s.number("speed");
   double direction=Math.atan2(wind.z(),wind.x())+Math.sin(clock*.17)*.7+Math.sin(clock*.31)*gust;
   var next=p.pos.add((Math.cos(direction)*strength+Math.sin(phase)*.12)*.05*speed,Math.sin(phase*.83)*.006*speed,(Math.sin(direction)*strength+Math.cos(phase)*.12)*.05*speed);
   var block=BlockPos.ofFloored(next);if(!c.world.isChunkLoaded(block.getX()>>4,block.getZ()>>4)){it.remove();continue;}
   var hit=c.world.raycast(new RaycastContext(p.pos,next,RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.ANY,c.player));
   if(hit.getType()!=HitResult.Type.MISS){
    // Slide along the hit face while fading, instead of pushing wisps through terrain.
    var normal=hit.getSide();var movement=next.subtract(p.pos);var n=new Vec3d(normal.getOffsetX(),normal.getOffsetY(),normal.getOffsetZ());
    var slide=p.pos.add(movement.subtract(n.multiply(movement.dotProduct(n))));
    if(c.world.raycast(new RaycastContext(p.pos,slide,RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.ANY,c.player)).getType()==HitResult.Type.MISS)p.pos=slide;
    p.life=Math.min(p.life,p.age+20);
   }else p.pos=next;
   var floor=c.world.raycast(new RaycastContext(next,next.add(0,-1.2,0),RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.ANY,c.player));
   p.ground=floor.getType()==HitResult.Type.MISS?1:AshfallMath.groundFade(next.distanceTo(floor.getPos()));
  }
  if(!active){ashCredit=smokeCredit=0;return;}
  ashCredit=Math.min(4,ashCredit+(s.flag("particles")?18:0)*.05);smokeCredit=Math.min(2,smokeCredit+(s.flag("clouds")?s.number("cloudDensity")*.05:0));
  while(ashCredit>=1){ashCredit--;if(ash<cap-cap/3&&PARTICLES.size()<cap&&spawn(c,false,radius))ash++;}
  while(smokeCredit>=1){smokeCredit--;if(smoke<cap/3&&PARTICLES.size()<cap&&spawn(c,true,radius))smoke++;}
 }
 private static boolean spawn(MinecraftClient c,boolean smoke,double radius){
  var camera=c.gameRenderer.getCamera().getCameraPos();double angle=RANDOM.nextDouble()*Math.PI*2,dist=Math.sqrt(RANDOM.nextDouble())*(radius-3);
  var pos=camera.add(Math.cos(angle)*dist,smoke?RANDOM.nextDouble()*6-3:RANDOM.nextDouble()*10-2,Math.sin(angle)*dist);var at=BlockPos.ofFloored(pos);
  if(!c.world.isChunkLoaded(at.getX()>>4,at.getZ()>>4)||!peaks(c,at)||!c.world.isSkyVisible(at)||!c.world.getBlockState(at).getCollisionShape(c.world,at).isEmpty()||!c.world.getFluidState(at).isEmpty())return false;
  var p=new Puff();p.pos=p.previous=pos;p.smoke=smoke;p.phase=RANDOM.nextDouble()*6.283;p.size=smoke?1.4+RANDOM.nextDouble()*1.2:.7+RANDOM.nextDouble()*.6;p.life=smoke?150+RANDOM.nextInt(60):200+RANDOM.nextInt(100);PARTICLES.add(p);return true;
 }
 private static void vertex(Vec3d p,float u,float v,int rgb,double alpha){VERTICES.putFloat((float)p.x).putFloat((float)p.y).putFloat((float)p.z).putFloat(u).putFloat(v).put((byte)(rgb>>16)).put((byte)(rgb>>8)).put((byte)rgb).put((byte)(Math.clamp(alpha,0,1)*255));}
 private static void render(MatrixStack matrices){
  var c=MinecraftClient.getInstance();if(!enabled()||shaderPack()||world!=c.world||c.world==null||failed||PARTICLES.isEmpty()||!CameraEnvironment.surface()||c.getFramebuffer().getDepthAttachmentView()==null)return;
  var s=XVisuals.visualModule("mountainwinds");var camera=c.gameRenderer.getCamera().getCameraPos();float delta=c.getRenderTickCounter().getTickProgress(false);
  var q=c.gameRenderer.getCamera().getRotation();var rr=new Vector3f(1,0,0).rotate(q);var uu=new Vector3f(0,1,0).rotate(q);var right=new Vec3d(rr.x,rr.y,rr.z);var up=new Vec3d(uu.x,uu.y,uu.z);
  PARTICLES.sort(Comparator.comparingDouble((Puff p)->-p.pos.squaredDistanceTo(camera)));VERTICES.clear();int tint=0xCDD7E0;
  for(var p:PARTICLES){double age=p.age+delta,t=age/p.life,alpha=LavafallMistMath.fade(age,p.life)*JungleMistMath.fade(p.pos.distanceTo(camera),s.number("distance"))*blend*p.ground;if(alpha<.002)continue;
   var pos=p.previous.lerp(p.pos,delta).subtract(camera);double size=p.smoke?p.size*(1+t*.4):p.size*.018;int color=tint;alpha*=p.smoke?.07:.22;
   double angle=p.phase+Math.sin(p.phase+age*.03)*.5,cos=Math.cos(angle),sin=Math.sin(angle);var r=right.multiply(cos).add(up.multiply(sin)).multiply(size);var u=up.multiply(cos).subtract(right.multiply(sin)).multiply((p.smoke?size*.65:size));
   int seed=(int)(p.phase*8);float base=seed*8+(!p.smoke?4:0);
   var a=pos.subtract(r).subtract(u);var b=pos.add(r).subtract(u);var d=pos.subtract(r).add(u);var e=pos.add(r).add(u);
   vertex(a,base,1,color,alpha);vertex(b,base+1,1,color,alpha);vertex(e,base+1,0,color,alpha);vertex(a,base,1,color,alpha);vertex(e,base+1,0,color,alpha);vertex(d,base,0,color,alpha);
  }
  int count=VERTICES.position()/24;if(count==0)return;VERTICES.flip();
  try{
   if(vertices==null)vertices=new MappableRingBuffer(()->"MountainWinds mist",GpuBuffer.USAGE_VERTEX|GpuBuffer.USAGE_COPY_DST|GpuBuffer.USAGE_MAP_WRITE,VERTICES.capacity());
   var buffer=vertices.getBlocking();var encoder=RenderSystem.getDevice().createCommandEncoder();encoder.writeToBuffer(buffer.slice(0,VERTICES.remaining()),VERTICES);
   OPTIONS.identity().m00((float)(clock+delta*.05)).m01(0);var transform=RenderSystem.getDynamicUniforms().write(new Matrix4f(RenderSystem.getModelViewMatrix()).mul(matrices.peek().getPositionMatrix()),WHITE,ZERO,OPTIONS);
   try(var pass=encoder.createRenderPass(()->"MountainWinds cloud wisps and air particles",c.getFramebuffer().getColorAttachmentView(),OptionalInt.empty())){
    pass.setPipeline(PIPELINE);RenderSystem.bindDefaultUniforms(pass);pass.setUniform("DynamicTransforms",transform);pass.bindTexture("SceneDepth",c.getFramebuffer().getDepthAttachmentView(),RenderSystem.getSamplerCache().get(com.mojang.blaze3d.textures.FilterMode.NEAREST));pass.setVertexBuffer(0,buffer);pass.draw(0,count);
   }vertices.rotate();
  }catch(RuntimeException ex){failed=true;org.slf4j.LoggerFactory.getLogger("VisualClient").warn("MountainWinds rendering unavailable",ex);}
 }
 private MountainWinds(){}
}
