package pl.xvisuals.rendering.particles;
/** Custom sprite designs and shared animation paths used in the world and gallery. */
public final class PvpStyle {
 public static final String[] STYLES={"Phoenix Feathers","Frost Lotus","Lunar Moths","Sakura Waltz","Astral Shards","Solar Scarabs","Void Butterflies","Storm Koi","Emerald Leaves","Clockwork Sparks","Seraph Plumes","Crimson Roses","Celestial Sigils","Ocean Spirits","Prism Dragonflies"};
 private static final net.minecraft.util.Identifier[] TEXTURES=java.util.Arrays.stream(STYLES).map(s->net.minecraft.util.Identifier.of("xvisuals","textures/player_effects/"+s.toLowerCase(java.util.Locale.ROOT).replace(' ','_')+".png")).toArray(net.minecraft.util.Identifier[]::new);
 public static int index(String s){return Math.max(0,java.util.Arrays.asList(STYLES).indexOf(s));}
 public static String asset(String s){return STYLES[index(s)].toLowerCase(java.util.Locale.ROOT).replace(' ','_');}
 public static net.minecraft.util.Identifier texture(String s){return TEXTURES[index(s)];}
 public record Point(double x,double y,double z,int shape){}
 public static boolean compact(String s){return true;}
 public static boolean lines(String s){return false;}
 public static boolean connected(String s,int i){return false;}
 public static int material(String s){return 0;}
 public static int shape(String s){return 0;}
 public static int count(String s){return switch(index(s)){case 1,5,7,11,13->5;case 3,8,10->10;default->7;};}
 public static int frame(double time,int i){if(!Double.isFinite(time))return 0;return (int)Math.floor(((Math.max(0,time)%1.2)*20+i*3.1)%24);}
 public static double opacity(String s,double t,int i){double alpha=.68+.24*Math.sin(t*.8+i)*Math.sin(t*.8+i);int k=index(s);double speed=switch(k){case 0->.13;case 3->.12;case 8->.15;case 10->.1;default->0;};return speed==0?alpha:alpha*Math.pow(Math.sin(Math.PI*((t*speed+i/(double)count(s))%1)),2);}
 public static double size(String s,double t,int i){return (switch(index(s)){case 1,7,11,13->.65;case 3,8->.36;default->.5;})*(.93+.07*Math.sin(t*2+i));}
 public static double angle(String s,double t,int i){return switch(index(s)){case 2,5,6,7,13,14->.18*Math.sin(t*2+i);case 4,9,12->(t*.6+i)%(Math.PI*2);default->.55*Math.sin(t+i)+i*.7;};}
 public static Point point(String s,double t,int i){
  int k=index(s),n=count(s);double u=i/(double)n,a=u*Math.PI*2+t*(.22+k*.025),r=.62,y=.3+u*1.35;
  switch(k){
   case 0->{r=.5+.15*Math.sin(t*.7+i);y=.3+1.5*((t*.13+u)%1);}
   case 1->{r=.70;y=.12+.1*Math.sin(t+i);}
   case 2->{r=.63+.14*Math.sin(t+i);y=1.2+.5*Math.sin(t*.6+i);}
   case 3->{r=.65+.2*Math.sin(t*.4+i);y=1.85-1.6*((t*.12+u)%1);}
   case 4->{r=.7;y=.9+.55*Math.sin(a*2);}
   case 5->{a=-a;r=.68;y=.9+.35*Math.sin(a);}
   case 6->{r=.65+.18*Math.cos(t*.6+i);y=.8+.55*Math.sin(t*.8+i);}
   case 7->{r=.78;y=.75+.3*Math.sin(a*2);}
   case 8->{r=.7+.12*Math.cos(t+i);y=.25+1.5*((t*.15+u)%1);}
   case 9->{r=.68;y=.4+(i%3)*.45+.12*Math.sin(t*2+i);}
   case 10->{a=u*Math.PI*2+t*.18;r=.65;y=1.75-1.5*((t*.1+u)%1);}
   case 11->{r=.68;y=.35+.12*Math.sin(t*.8+i);}
   case 12->{r=.72;y=.6+(i%3)*.35;}
   case 13->{r=.72;y=.6+.65*Math.sin(t*.45+i);y=Math.max(.25,y);}
   case 14->{r=.78+.13*Math.sin(t+i);y=1.1+.5*Math.sin(t*1.1+i);}
  }
  return new Point(Math.cos(a)*r,Math.max(size(s,t,i)*.72+.08,y),Math.sin(a)*r,0);
 }
 private PvpStyle(){}
}
