package pl.xvisuals.rendering.particles;

/** Smooth, bounded flight and light envelopes, expressed in simulation ticks. */
public final class FireflyMotion {
  public static double smooth(double value) {
    double t = Math.max(0, Math.min(1, value));
    return t * t * (3 - 2 * t);
  }

  public static double pulse(double age, double phase) {
    double wave = .5 + .5 * Math.sin(age * .045 + phase);
    return .18 + .82 * wave * wave * wave;
  }

  public static double envelope(double age, double life) {
    return smooth(age / 30) * smooth((life - age) / 50);
  }

  public static double drift(double time, double phase) {
    return Math.sin(time * .023 + phase) * .75
        + Math.sin(time * .051 + phase * 1.7) * .25;
  }

  private FireflyMotion() {}
}
