package pl.xvisuals.rendering.particles;

import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.entity.EntityVisuals;
import pl.xvisuals.rendering.*;
import pl.xvisuals.util.Colors;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

/** A fixed-size pool; particles are recycled without allocation in tick or draw loops. */
public final class ParticleEngine {
  private static final int MAX = 512;
  private static final pl.xvisuals.rendering.shaders.SdfRenderer.Batch BATCH =
      new pl.xvisuals.rendering.shaders.SdfRenderer.Batch(MAX * 2);
  public static int rendered;
  private static final Particle[] POOL = new Particle[MAX];
  private static final Random RANDOM = new Random(0xA1A71C);
  private static final Projection.Point A = new Projection.Point(), B = new Projection.Point();
  private static int next, ticks, ambientSignature;
  private static Object world;
  private static boolean grounded = true;
  private static boolean compactSpawn;
  private static Vec3d previous = Vec3d.ZERO;
  private static Entity attacked;
  private static int attackedAt;

  private static final class Particle {
    double x, y, z, px, py, pz, vx, vy, vz, age, life, size, gravity, phase;
    int color, shape;
    boolean alive, visible, trail, ambient, compact;
    double bloom, opacity, sway, rise, speed;
  }

  static {
    for (int i = 0; i < MAX; i++) POOL[i] = new Particle();
  }

  public static void attacked(Entity e) {
    attacked = e;
    attackedAt = ticks;
  }

  public static void tick(MinecraftClient c) {
    if (c.world != world) {
      world = c.world;
      clear();
      if (c.player != null) {
        previous = c.player.getEntityPos();
        grounded = c.player.isOnGround();
      }
    }
    if (c.player == null || c.world == null) { clear(); return; }
    var ambient = XVisuals.visualModule("particles");
    var fx = XVisuals.visualModule("playerfx");
    if (!ambient.enabled && !fx.enabled) { clear(); previous=c.player.getEntityPos(); grounded=c.player.isOnGround(); return; }
    for (Particle p : POOL) if (p.alive && !(p.ambient ? ambient.enabled : fx.enabled)) p.alive=false;
    int signature = ambient.values.hashCode();
    if (signature != ambientSignature) {
      for (Particle p : POOL) if (p.ambient) p.alive = false;
      ambientSignature = signature;
    }
    if (c.isPaused()) return;
    ticks++;
    if (!fx.enabled || ticks-attackedAt>100) attacked=null;
    int visibilityIndex = 0;
    int ambientBudget = ambient.enabled ? AmbientStyle.budget(ambient.integer("count"), Quality.factor()) : 0;
    int ambientAlive = 0, fxAlive = 0;
    for (Particle p : POOL) {
      if (!p.alive) continue;
      if ((p.ambient ? ++ambientAlive > ambientBudget : ++fxAlive > (Quality.factor()<.75?24:48))) {
        p.alive = false;
        continue;
      }
      p.px = p.x;
      p.py = p.y;
      p.pz = p.z;
      if (p.ambient) {
        double t = p.age * .032 * p.speed;
        p.vx = Math.cos(t + p.phase) * p.sway * p.speed;
        p.vz = Math.sin(t * .73 + p.phase) * p.sway * p.speed;
        p.vy = (p.rise + Math.sin(t * .8 + p.phase) * p.sway * .3) * p.speed - p.gravity * .01;
      }
      p.x += p.vx;
      p.y += p.vy;
      p.z += p.vz;
      if (!p.ambient) {
        p.vy -= p.gravity * .01;
        double clearance=Math.clamp(p.size*3,.12,.42)*.72+.04;
        var block=net.minecraft.util.math.BlockPos.ofFloored(p.x,p.y-clearance,p.z);
        var shape=c.world.getBlockState(block).getCollisionShape(c.world,block);
        if(!shape.isEmpty()) {
          double floor=block.getY()+shape.getMax(net.minecraft.util.math.Direction.Axis.Y)+clearance;
          if(p.y<floor){p.y=floor;p.py=floor;p.vy=Math.max(0,p.vy);p.age=Math.max(p.age,p.life*.7);}
        }
      }
      p.age++;
      if (p.age >= p.life || c.player.getEntityPos().squaredDistanceTo(p.x, p.y, p.z) > 4096) {
        p.alive = false;
        continue;
      }
      if ((visibilityIndex++ & 7) == (ticks & 7))
        p.visible = !p.ambient || !ambient.flag("depth") || EntityVisuals.visible(c, new Vec3d(p.x, p.y, p.z));
    }
    if (ambient.enabled && ambientAlive < ambientBudget) {
      int count = Math.min(12, Math.max(1, (ambientBudget - ambientAlive + 5) / 6));
      count = Math.min(count, ambientBudget - ambientAlive);
      for (int i = 0; i < count; i++) {
        double angle = RANDOM.nextDouble() * Math.PI * 2,
            r = ambient.number("radius") * Math.sqrt(.08 + .92 * RANDOM.nextDouble());
        Vec3d pos = c.player.getEntityPos();
        Particle p =
            spawn(
                pos.x + Math.cos(angle) * r,
                pos.y + RANDOM.nextDouble() * ambient.number("spread"),
                pos.z + Math.sin(angle) * r,
                presetColor(
                    ambient.text("preset"), ambient.color("color"), ambient.color("secondary")),
                AmbientStyle.shape(ambient.text("shape"), ambient.text("preset")),
                ambient.number("size") * (.75 + RANDOM.nextDouble() * .5),
                ambient.number("lifetime") * (16 + RANDOM.nextDouble() * 8));
        double speed = ambient.number("speed");
        p.ambient = true;
        p.speed = speed;
        p.sway = AmbientStyle.sway(ambient.text("preset"));
        p.rise = AmbientStyle.rise(ambient.text("preset"));
        p.gravity = ambient.number("gravity");
        p.opacity = ambient.number("opacity");
        p.bloom = ambient.number("bloom") * .35;
        p.trail = ambient.flag("trails");
        p.visible = !ambient.flag("depth") || EntityVisuals.visible(c, new Vec3d(p.x, p.y, p.z));
      }
    }
    Vec3d pos = c.player.getEntityPos();
    double moved = pos.distanceTo(previous);
    boolean ground = c.player.isOnGround();
    if (fx.enabled) {
      boolean compact = PvpStyle.compact(fx.text("style"));
      compactSpawn = compact;
      int color = fx.color("color");
      int intensity = (int) (10 * fx.number("intensity") * Math.min(1, Quality.factor()));
      if (compact) intensity = Math.max(1, Math.min(5, intensity / 3));
      if (fx.flag("jump") && grounded && !ground && c.player.getVelocity().y > 0)
        burst(pos, color, intensity, 3);
      if (fx.flag("landing") && !grounded && ground) burst(pos, color, intensity * 2, 6);
      if (fx.flag("damage") && c.player.hurtTime == 9)
        burst(pos.add(0, 1, 0), color, intensity * 2, 2);
      if (fx.flag("kill")
          && attacked instanceof LivingEntity living
          && living.deathTime > 0
          && ticks - attackedAt < 100) {
        burst(living.getEntityPos().add(0, 1, 0), color, intensity * 3, 5);
        attacked = null;
      }
      if (ticks - attackedAt > 100) attacked = null;
      if (moved > .04 && moved < 4) {
        if (fx.flag("trail"))
          for (int i = 0; i < Math.max(1, intensity / 5); i++) {
            Particle p =
                spawn(
                    pos.x,
                    pos.y + .1 + RANDOM.nextDouble() * .5,
                    pos.z,
                    color,
                    PvpStyle.shape(fx.text("style")),
                    .10,
                    25);
            p.trail = true;
            p.bloom = .5;
          }
        if (fx.flag("footsteps") && ground && ticks % 5 == 0)
          spawn(pos.x, pos.y + .02, pos.z, color, 6, .35, 30);
        if (fx.flag("velocity") && moved > .2) {
          Particle p = spawn(pos.x, pos.y + 1, pos.z, color, 2, .16, 15);
          p.vx = (previous.x - pos.x) * .4;
          p.vy = (previous.y - pos.y) * .4;
          p.vz = (previous.z - pos.z) * .4;
          p.trail = true;
        }
      }
      if (fx.flag("aura") && ticks % 2 == 0) {
        double a = ticks * .3;
        Particle p =
            spawn(
                pos.x + Math.cos(a) * (compact ? .40 : .7),
                pos.y + .2,
                pos.z + Math.sin(a) * (compact ? .40 : .7),
                color,
                PvpStyle.shape(fx.text("style")),
                .10,
                35);
        p.vy = compact ? .012 : .035;
      }
    }
    compactSpawn = false;
    grounded = ground;
    previous = pos;
  }

  private static Particle spawn(
      double x, double y, double z, int color, int shape, double size, double life) {
    Particle p = POOL[next];
    next=(next+1)%MAX;
    p.x = p.px = x;
    p.y = p.py = y;
    p.z = p.pz = z;
    p.vx = p.vy = p.vz = p.gravity = p.age = 0;
    p.life = life;
    p.color = color;
    p.shape = compactSpawn ? PvpStyle.shape(XVisuals.visualModule("playerfx").text("style")) : shape;
    p.size = size;
    p.alive = p.visible = true;
    p.ambient = false;
    p.compact = compactSpawn;
    if (p.compact) { p.size *= .5; p.life = Math.min(p.life, 16); }
    p.trail = false;
    p.bloom = .5;
    p.opacity = .8;
    p.phase = RANDOM.nextDouble() * Math.PI * 2;
    return p;
  }

  private static void burst(Vec3d v, int color, int n, int shape) {
    for (int i = 0; i < n; i++) {
      Particle p =
          spawn(
              v.x,
              v.y + .1,
              v.z,
              color,
              shape,
              .08 + RANDOM.nextDouble() * .09,
              20 + RANDOM.nextInt(20));
      double a = RANDOM.nextDouble() * Math.PI * 2, s = .03 + RANDOM.nextDouble() * .12;
      p.vx = Math.cos(a) * s;
      p.vz = Math.sin(a) * s;
      p.vy = RANDOM.nextDouble() * .13;
      p.gravity = .16;
      if (p.compact) { p.vx *= .35; p.vy *= .35; p.vz *= .35; }
      p.trail = true;
    }
  }

  private static int presetColor(String name, int primary, int secondary) {
    double t = RANDOM.nextDouble();
    return switch (name) {
      case "Void" -> Colors.mix(0xFF7851BC, 0xFFD7A5FF, t);
      case "Neon" -> t < .72 ? 0xFF64F3F1 : 0xFFFF68BC;
      case "Purple Storm" -> t < .82 ? Colors.mix(0xFF9862F4, 0xFFC8A1FF, t) : 0xFFF1E9FF;
      case "Angel" -> Colors.mix(0xFFFFFFFF, 0xFFFFE5A4, t);
      case "Inferno" -> Colors.mix(0xFFFF4B32, 0xFFFFD27C, t);
      case "Ice" -> Colors.mix(0xFF91DAFF, 0xFFE7F9FF, t);
      case "Minimal" -> 0xFFDAD5EE;
      case "Chromatic" -> Colors.rainbow(t);
      default -> Colors.mix(primary, secondary, t);
    };
  }

  public static void render(DrawContext g,Projection projection) {} // World pass owns the effects, including F1.
  public static void renderAmbientWorld(net.minecraft.client.util.math.MatrixStack matrices){
    rendered=0;var c=MinecraftClient.getInstance();var settings=XVisuals.visualModule("particles");
    if(c.world==null||c.world!=world||!settings.enabled)return;
    CraftedSprites.begin();double tick=c.getRenderTickCounter().getTickProgress(false),time=(ticks+tick)/20.;
    int cap=AmbientStyle.budget(settings.integer("count"),Quality.factor());
    for(var p:POOL){if(rendered>=cap)break;if(!p.alive||!p.ambient)continue;
      double age=p.age+tick,fade=Math.min(1,age/10)*Math.min(1,(p.life-age)/15)*p.opacity;
      if(fade<=0)continue;
      CraftedSprites.add(new Vec3d(p.px+(p.x-p.px)*tick,p.py+(p.y-p.py)*tick,p.pz+(p.z-p.pz)*tick),p.size*3.6,p.size*3.6,p.phase+time*.15*p.speed,p.shape,(int)(time*8),Colors.alpha(p.color,fade));rendered++;
    }CraftedSprites.draw(matrices);
  }

  public static void renderPlayerWorld(net.minecraft.client.util.math.MatrixStack matrices){
    PlayerSpriteRenderer.begin();var c=MinecraftClient.getInstance();var fx=XVisuals.visualModule("playerfx");
    if(c.world==null||c.player==null||c.world!=world||!fx.enabled)return;
    double tick=c.isPaused()?0:c.getRenderTickCounter().getTickProgress(false),time=(ticks+tick)/20.;
    if(XVisuals.config().module("performance").text("animation").equals("Off"))time=2;
    String style=fx.text("style");int tint=fx.flag("customColors")?fx.color("color"):0xFFFFFFFF;
    for(Particle p:POOL){if(!p.alive||p.ambient)continue;
      double age=(p.age+tick)/p.life,alpha=Math.sin(Math.PI*Math.clamp(age,0,1))*.85;
      var pos=new Vec3d(p.px+(p.x-p.px)*tick,p.py+(p.y-p.py)*tick,p.pz+(p.z-p.pz)*tick);
      PlayerSpriteRenderer.add(pos,Math.clamp(p.size*3,.12,.42),PvpStyle.angle(style,time,(int)(p.phase*10)),PvpStyle.frame(time,(int)(p.phase*10)),Colors.alpha(tint,alpha));
    }
    if(fx.flag("orbit")&&!c.options.getPerspective().isFirstPerson()){
      var base=c.player.getLerpedPos((float)tick);
      for(int i=0;i<PvpStyle.count(style);i++){var p=PvpStyle.point(style,time,i);
        PlayerSpriteRenderer.add(base.add(p.x(),p.y(),p.z()),PvpStyle.size(style,time,i),PvpStyle.angle(style,time,i),PvpStyle.frame(time,i),Colors.alpha(tint,PvpStyle.opacity(style,time,i)));
      }
    }
    PlayerSpriteRenderer.draw(matrices,style);
  }

  public static int count() {
    int n = 0;
    for (Particle p : POOL) if (p.alive) n++;
    return n;
  }

  public static void clear() {
    for (Particle p : POOL) p.alive = false;
    attacked = null;
    rendered = 0;
  }

  private ParticleEngine() {}
}
