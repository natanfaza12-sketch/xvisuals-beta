package pl.xvisuals.rendering.particles;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.mixins.RenderLayerAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3f;
/** Real textured world billboards with depth testing, sorted transparency and bounded storage. */
public final class HitSpriteRenderer {
 private static final BufferAllocator ALLOCATOR=new BufferAllocator(262144);
 private static final VertexConsumerProvider.Immediate BUFFERS=VertexConsumerProvider.immediate(ALLOCATOR);
 private static final RenderPipeline PIPE=RenderPipeline.builder().withLocation(Identifier.of("xvisuals","pipeline/hit_sprite"))
  .withVertexShader(Identifier.of("xvisuals","core/player_sprite")).withFragmentShader(Identifier.of("xvisuals","core/player_sprite"))
  .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER).withSampler("Sampler0")
  .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS).withBlend(BlendFunction.TRANSLUCENT)
  .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withDepthWrite(false).withCull(false).build();
 private static final RenderPipeline GLOW=RenderPipeline.builder().withLocation(Identifier.of("xvisuals","pipeline/hit_sprite_glow"))
  .withVertexShader(Identifier.of("xvisuals","core/player_sprite")).withFragmentShader(Identifier.of("xvisuals","core/player_sprite"))
  .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER).withSampler("Sampler0")
  .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS).withBlend(new BlendFunction(com.mojang.blaze3d.platform.SourceFactor.SRC_ALPHA,com.mojang.blaze3d.platform.DestFactor.ONE))
  .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withDepthWrite(false).withCull(false).build();
 private static final java.util.Map<String,RenderLayer> LAYERS=new java.util.HashMap<>();
 private static final class Sprite {Vec3d p;double size,angle,distance;int frame,color,style;boolean glow;}
 private static final Sprite[] POOL=new Sprite[96];static{for(int i=0;i<POOL.length;i++)POOL[i]=new Sprite();}
 private static final java.util.Comparator<Sprite> FAR_FIRST=java.util.Comparator.comparingDouble((Sprite p)->p.distance).reversed();
 private static final Vector3f RIGHT=new Vector3f(),UP=new Vector3f(),FORWARD=new Vector3f();
 public static long lastDrawNanos;
 private static final java.util.List<Sprite> SPRITES=new java.util.ArrayList<>(64);
 public static int rendered;
 public static void init(){net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents.END_MAIN.register(c->pl.xvisuals.modules.combat.HitEffects.renderWorld(c.matrices()));net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING.register(c->ALLOCATOR.close());}
 public static void begin(){SPRITES.clear();rendered=0;}
 public static void add(Vec3d p,double size,double angle,int frame,int color,int style,boolean glow){if(SPRITES.size()<POOL.length){var s=POOL[SPRITES.size()];s.p=p;s.size=size;s.angle=angle;s.frame=frame;s.color=color;s.style=style;s.glow=glow;SPRITES.add(s);}}
 public static void draw(MatrixStack matrices){
  long started=System.nanoTime();if(SPRITES.isEmpty()){lastDrawNanos=0;return;}
  var c=MinecraftClient.getInstance();var camera=c.gameRenderer.getCamera();var eye=camera.getCameraPos();
  for(var s:SPRITES)s.distance=s.p.squaredDistanceTo(eye);SPRITES.sort(FAR_FIRST);
  RIGHT.set(1,0,0).rotate(camera.getRotation());UP.set(0,1,0).rotate(camera.getRotation());FORWARD.set(0,0,-1).rotate(camera.getRotation());
  var matrix=matrices.peek().getPositionMatrix();
  for(var sprite:SPRITES){
   double ox=sprite.p.x-eye.x,oy=sprite.p.y-eye.y,oz=sprite.p.z-eye.z;
   if(sprite.distance<.04||sprite.distance>2304||ox*FORWARD.x+oy*FORWARD.y+oz*FORWARD.z<.05)continue;
   float fade=(float)Math.clamp((Math.sqrt(sprite.distance)-.2)/.45,0,1);
   int color=(((int)((sprite.color>>>24)*fade))<<24)|(sprite.color&0xFFFFFF);
   String style=pl.xvisuals.modules.combat.ImpactStyles.HITS.get(sprite.style);
   var layer=LAYERS.computeIfAbsent(style+(sprite.glow?"_glow":""),s->RenderLayerAccessor.visuals$of("xvisuals_hit_sprite_"+s,RenderSetup.builder(sprite.glow?GLOW:PIPE).texture("Sampler0",pl.xvisuals.modules.combat.ImpactStyles.texture(style)).translucent().expectedBufferSize(262144).build()));
   var out=BUFFERS.getBuffer(layer);
   float u=(sprite.frame%6)/6f,v=(sprite.frame/6)/4f;
   double co=Math.cos(sprite.angle),si=Math.sin(sprite.angle);
   for(int k=0;k<4;k++){
    float xx=(k==0||k==3?-.5f:.5f),yy=k<2?-.5f:.5f;
    float rx=(float)((xx*co-yy*si)*sprite.size),ry=(float)((xx*si+yy*co)*sprite.size);
    out.vertex(matrix,(float)ox+RIGHT.x*rx+UP.x*ry,(float)oy+RIGHT.y*rx+UP.y*ry,(float)oz+RIGHT.z*rx+UP.z*ry)
      .texture(u+(.5f+(xx+.5f)*127)/768f,v+(.5f+(.5f-yy)*127)/512f).color(color);
   }rendered++;
  }
  BUFFERS.draw();SPRITES.clear();lastDrawNanos=System.nanoTime()-started;
 }
 private HitSpriteRenderer(){}
}
