package pl.xvisuals.rendering.particles;

/** Small, deliberate silhouettes and motion profiles; no random shape soup. */
public final class AmbientStyle {
  public static int shape(String shape, String preset) {
    if (shape.equals("Preset") || shape.equals("Mixed")) shape = switch (preset) {
      case "Void", "Chromatic" -> "Diamonds";
      case "Angel" -> "Feathers";
      case "Inferno" -> "Sparks";
      case "Ice" -> "Snowflakes";
      case "Minimal" -> "Dots";
      default -> "Stars";
    };
    return switch (shape) {
      case "Diamonds", "Cubes", "Geometric" -> 18;
      case "Hearts" -> 19;
      case "Snowflakes" -> 20;
      case "Feathers", "Wisps", "Crescents" -> 21;
      case "Dots", "Orbits" -> 15;
      case "Sparks" -> 16;
      default -> 17;
    };
  }

  public static double rise(String preset) {
    return switch (preset) {
      case "Ice", "Angel" -> -.012;
      case "Inferno" -> .035;
      case "Purple Storm" -> .015;
      case "Minimal" -> .002;
      default -> .006;
    };
  }

  public static double sway(String preset) {
    return switch (preset) {
      case "Minimal" -> .003;
      case "Inferno" -> .009;
      case "Angel", "Ice" -> .018;
      default -> .012;
    };
  }

  public static int budget(int count, double quality) {
    return Math.max(0, Math.min(240, (int)(count * Math.min(1, Math.max(0, quality)))));
  }

  /** No minimum pixel size: distant particles recede naturally instead of filling the screen. */
  public static double projectedSize(double size, double height, double depth) {
    return Math.max(0, Math.min(18, size * height / Math.max(1, depth) * 1.8));
  }

  private AmbientStyle() {}
}
