package pl.xvisuals.rendering.particles;

import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.entity.EntityVisuals;
import pl.xvisuals.rendering.Projection;
import pl.xvisuals.rendering.Quality;
import pl.xvisuals.rendering.ShootingStars;
import pl.xvisuals.rendering.shaders.SdfRenderer;
import pl.xvisuals.util.Colors;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** Independent bounded pool: world-anchored flight, interpolated motion and occlusion. */
public final class Fireflies {
  private static final int MAX = 240;
  private static final Fly[] FLIES = new Fly[MAX];
  private static final SdfRenderer.Batch BATCH = new SdfRenderer.Batch(MAX);
  private static final Projection.Point POINT = new Projection.Point();
  private static final Random RANDOM = new Random();
  private static Object world;
  private static int ticks;

  private static final class Fly {
    double ax, ay, az, x, y, z, px, py, pz, phase, motion, life, tint, scale;
    int age;
    boolean alive, visible;
  }

  static {
    for (int i = 0; i < MAX; i++) FLIES[i] = new Fly();
  }

  public static void tick(MinecraftClient client) {
    var settings = XVisuals.visualModule("fireflies");
    if (world != client.world || !settings.enabled || client.player == null) {
      for (Fly fly : FLIES) fly.alive = false;
      world = client.world;
    }
    if (!settings.enabled || client.world == null || client.player == null) return;
    if (client.isPaused()) return;
    ticks++;
    Vec3d player = client.player.getEntityPos();
    double radius = settings.number("radius");
    int cap = Math.min(MAX, (int) (settings.integer("count") * Math.min(1, Quality.factor())));
    double night = settings.flag("night") ? ShootingStars.nightVisibility(client.world.getTimeOfDay()) : 1;
    int spawned = 0;
    for (int i = 0; i < MAX; i++) {
      Fly fly = FLIES[i];
      if (i >= cap || night <= 0) {
        fly.alive = false;
        continue;
      }
      if (fly.alive && (++fly.age >= fly.life
          || player.squaredDistanceTo(fly.x, fly.y, fly.z) > (radius + 5) * (radius + 5)))
        fly.alive = false;
      if (!fly.alive) {
        if (spawned >= 3) continue;
        spawned++;
        double angle = RANDOM.nextDouble() * Math.PI * 2;
        double distance = Math.sqrt(.04 + RANDOM.nextDouble() * .96) * radius;
        double x = player.x + Math.cos(angle) * distance;
        double y = player.y + .4 + RANDOM.nextDouble() * settings.number("spread");
        double z = player.z + Math.sin(angle) * distance;
        BlockPos block = BlockPos.ofFloored(x, y, z);
        if (!client.world.isChunkLoaded(block.getX() >> 4, block.getZ() >> 4)
            || !client.world.getBlockState(block).isAir()) continue;
        fly.ax = fly.x = fly.px = x;
        fly.ay = fly.y = fly.py = y;
        fly.az = fly.z = fly.pz = z;
        fly.age = 0;
        fly.motion = 0;
        fly.life = 240 + RANDOM.nextInt(240);
        fly.phase = RANDOM.nextDouble() * Math.PI * 2;
        fly.tint = RANDOM.nextDouble();
        fly.scale = .75 + RANDOM.nextDouble() * .5;
        fly.alive = true;
        fly.visible = false;
      }
      fly.px = fly.x;
      fly.py = fly.y;
      fly.pz = fly.z;
      fly.motion += settings.number("speed");
      // Subtract the starting offset so a newly spawned light never jumps.
      fly.x = fly.ax + FireflyMotion.drift(fly.motion, fly.phase) - FireflyMotion.drift(0, fly.phase);
      fly.y = fly.ay + .35 * (FireflyMotion.drift(fly.motion * .7, fly.phase + 2)
          - FireflyMotion.drift(0, fly.phase + 2));
      fly.z = fly.az + FireflyMotion.drift(fly.motion, fly.phase + 4) - FireflyMotion.drift(0, fly.phase + 4);
      if (fly.age == 0 || ((ticks + i) & 3) == 0)
        fly.visible = client.world.getBlockState(BlockPos.ofFloored(fly.x, fly.y, fly.z)).isAir()
            && EntityVisuals.visible(client, new Vec3d(fly.x, fly.y, fly.z));
    }
  }

  public static void renderWorld(net.minecraft.client.util.math.MatrixStack matrices){
    var settings=XVisuals.visualModule("fireflies");var c=MinecraftClient.getInstance();
    if(!settings.enabled||c.world==null||c.world!=world)return;
    pl.xvisuals.rendering.CraftedSprites.begin();double t=c.getRenderTickCounter().getTickProgress(false);
    double night=settings.flag("night")?ShootingStars.nightVisibility(c.world.getTimeOfDay()):1;
    for(var fly:FLIES){if(!fly.alive)continue;double age=Math.max(0,fly.age-1+t);
      double alpha=FireflyMotion.envelope(age,fly.life)*FireflyMotion.pulse(age,fly.phase)*night*settings.number("opacity");
      if(alpha<.005)continue;double size=.14*settings.number("size")*fly.scale;
      int color=Colors.alpha(Colors.mix(settings.color("color"),settings.color("secondary"),fly.tint),alpha);
      pl.xvisuals.rendering.CraftedSprites.add(new Vec3d(fly.px+(fly.x-fly.px)*t,fly.py+(fly.y-fly.py)*t,fly.pz+(fly.z-fly.pz)*t),size,size,0,22,(int)(age*.8),color);
    }pl.xvisuals.rendering.CraftedSprites.draw(matrices);
  }

  private Fireflies() {}
}
