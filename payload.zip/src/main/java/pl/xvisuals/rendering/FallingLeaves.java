package pl.xvisuals.rendering;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import pl.xvisuals.mixins.RenderLayerAccessor;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.block.BlockState;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.RaycastContext;
import java.util.*;

/** Capped client-only tree particles; actual block-atlas textures, no block mutations. */
public final class FallingLeaves {
 private static final List<Leaf> LEAVES=new ArrayList<>();
 private static final List<BlockPos> SOURCES=new ArrayList<>();
 private static final Random RANDOM=new Random();
 private static Object world;private static int ticks;private static double emissions;
 private static final BufferAllocator ALLOCATOR=new BufferAllocator(262144);
 private static final VertexConsumerProvider.Immediate BUFFERS=VertexConsumerProvider.immediate(ALLOCATOR);
 private static final RenderLayer LAYER=RenderLayerAccessor.visuals$of("xvisuals_falling_leaves",RenderSetup.builder(RenderPipeline.builder()
  .withLocation(Identifier.of("xvisuals","pipeline/falling_leaves"))
  .withVertexShader(Identifier.of("xvisuals","core/player_sprite")).withFragmentShader(Identifier.of("xvisuals","core/player_sprite"))
  .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER).withSampler("Sampler0")
  .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS).withBlend(BlendFunction.TRANSLUCENT)
  .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withDepthWrite(false).withCull(false).build())
  .texture("Sampler0",SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE).translucent().expectedBufferSize(262144).build());
 private static class Leaf {
  Vec3d pos,previous;final BlockState state;final int color;final double phase,size,life,shape;int age,groundAge;double light=.7,settledRotation;boolean ground;
  Leaf(Vec3d p,BlockState state,int color,double size,double life){pos=previous=p;this.state=state;this.color=color;this.size=size;this.life=life;phase=RANDOM.nextDouble()*6.28;shape=.55+RANDOM.nextDouble()*.3;}
 }
 public static void init(){ClientTickEvents.END_CLIENT_TICK.register(FallingLeaves::tick);WorldRenderEvents.END_MAIN.register(c->render(c.matrices()));ClientLifecycleEvents.CLIENT_STOPPING.register(c->ALLOCATOR.close());}
 private static final pl.xvisuals.config.VisualConfig.ModuleState WIND_LEAVES=new pl.xvisuals.config.VisualConfig.ModuleState();
 private static pl.xvisuals.config.VisualConfig.ModuleState settings(){var own=XVisuals.visualModule("fallingleaves");if(own.enabled)return own;
  WIND_LEAVES.values.clear();WIND_LEAVES.values.putAll(own.values);WIND_LEAVES.values.put("density",8d);WIND_LEAVES.values.put("distance",16d);WIND_LEAVES.values.put("quality","Low");WIND_LEAVES.values.put("ground",false);WIND_LEAVES.values.put("colors",true);WIND_LEAVES.values.put("wind",1d);return WIND_LEAVES;}
 private static boolean enabled(){return XVisuals.ready()&&(XVisuals.visualModule("fallingleaves").enabled||WindFX.leaves());}
 private static void tick(MinecraftClient c){
  if(world!=c.world||!enabled()){world=c.world;LEAVES.clear();SOURCES.clear();emissions=0;}
  if(!enabled()||c.world==null||c.player==null||c.isPaused())return;
  ticks++;var s=settings();var center=c.player.getEntityPos();double distance=s.number("distance");
  int cap=LeafMath.cap(s.text("quality"));
  SOURCES.removeIf(p->p.getSquaredDistance(c.player.getBlockPos())>distance*distance||!c.world.isChunkLoaded(p.getX()>>4,p.getZ()>>4)||!c.world.getBlockState(p).isIn(BlockTags.LEAVES));
  // Bounded random discovery around the player; never force chunk loading.
  int scans=cap/2;
  for(int i=0;i<scans&&SOURCES.size()<256;i++){
   var p=BlockPos.ofFloored(center.x+(RANDOM.nextDouble()*2-1)*distance,center.y-4+RANDOM.nextDouble()*Math.min(24,distance),center.z+(RANDOM.nextDouble()*2-1)*distance);
   if(p.getSquaredDistance(c.player.getBlockPos())<=distance*distance&&c.world.isChunkLoaded(p.getX()>>4,p.getZ()>>4)&&c.world.getBlockState(p).isIn(BlockTags.LEAVES)&&!SOURCES.contains(p))SOURCES.add(p);
  }
  double rain=Storm.running()?Storm.rain():c.world.getRainGradient(1),weather=LeafMath.weather(rain,Storm.running());
  double time=ticks*.05;
  if(!XVisuals.visualModule("fallingleaves").enabled&&WindFX.enabled()&&!XVisuals.visualModule("windfx").flag("weather"))weather=1;
  int settled=0;
  for(var it=LEAVES.iterator();it.hasNext();){var leaf=it.next();leaf.previous=leaf.pos;leaf.age++;
   var at=BlockPos.ofFloored(leaf.pos);
   if(leaf.age*.05>=leaf.life||leaf.pos.squaredDistanceTo(center)>distance*distance||!c.world.isChunkLoaded(at.getX()>>4,at.getZ()>>4)){it.remove();continue;}
   leaf.light=.18+.82*Math.clamp(c.world.getBaseLightLevel(at,c.world.getAmbientDarkness())/15d,0,1);
   if(leaf.ground){leaf.groundAge++;settled++;
    if(!s.flag("ground")||leaf.groundAge>Math.min(120,leaf.life*10)||settled>cap/3){it.remove();continue;}
    var support=c.world.raycast(new RaycastContext(leaf.pos.add(0,.05,0),leaf.pos.add(0,-.12,0),RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,c.player));
    if(support.getType()==HitResult.Type.MISS){leaf.ground=false;leaf.groundAge=0;}continue;
   }
   double flutter=LeafMath.flutter(time,leaf.phase);var flow=AtmosphericWind.sample(time);
   var velocity=new Vec3d((flow.x()*s.number("wind")+flutter*.18)*.05,-s.number("fall")*(.35+.13*Math.sin(time*2+leaf.phase))*.05,(flow.z()*s.number("wind")+Math.cos(time*1.3+leaf.phase)*.13)*.05);
   var next=leaf.pos.add(velocity);var nextBlock=BlockPos.ofFloored(next);
   if(!c.world.isChunkLoaded(nextBlock.getX()>>4,nextBlock.getZ()>>4)){it.remove();continue;}
   var hit=c.world.raycast(new RaycastContext(leaf.pos,next,RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.ANY,c.player));
   if(hit.getType()!=HitResult.Type.MISS){
    if(s.flag("ground")&&hit.getSide()==Direction.UP&&c.world.getFluidState(hit.getBlockPos()).isEmpty()&&!c.world.getBlockState(hit.getBlockPos()).isIn(BlockTags.LEAVES)){
     leaf.pos=hit.getPos().add(0,.016,0);leaf.ground=true;leaf.groundAge=0;leaf.settledRotation=leaf.phase+leaf.age*.05*s.number("rotation")*(.5+leaf.shape);
    }else{it.remove();continue;}
   }else leaf.pos=next;
  }
  emissions=Math.min(4,emissions+s.number("density")*weather*.05*Math.min(1,Quality.factor()));
  while(emissions>=1){emissions--;if(LEAVES.size()>=cap||SOURCES.isEmpty())break;
   var p=SOURCES.get(RANDOM.nextInt(SOURCES.size()));var state=c.world.getBlockState(p);
   if(!state.isIn(BlockTags.LEAVES))continue;
   Vec3d pos=new Vec3d(p.getX()+.1+RANDOM.nextDouble()*.8,p.getY()-.035,p.getZ()+.1+RANDOM.nextDouble()*.8);
   var below=BlockPos.ofFloored(pos);if(!c.world.getBlockState(below).getCollisionShape(c.world,below).isEmpty()||!c.world.getFluidState(below).isEmpty())continue;
   int tint=s.flag("colors")?c.getBlockColors().getColor(state,c.world,p,0):0xBCC58C;if(tint==-1)tint=0xFFFFFF;
   LEAVES.add(new Leaf(pos,state,tint,s.number("size")*(.7+RANDOM.nextDouble()*.6),s.number("lifetime")*(.85+RANDOM.nextDouble()*.15)));
  }
  while(LEAVES.size()>cap)LEAVES.removeFirst();
 }
 private static void render(MatrixStack matrices){
  var c=MinecraftClient.getInstance();if(!enabled()||c.world==null||world!=c.world||LEAVES.isEmpty())return;
  var s=settings();var camera=c.gameRenderer.getCamera().getCameraPos();float delta=c.getRenderTickCounter().getTickProgress(false);
  LEAVES.sort(Comparator.comparingDouble((Leaf l)->-l.pos.squaredDistanceTo(camera)));
  matrices.push();matrices.translate(-camera.x,-camera.y,-camera.z);var m=matrices.peek().getPositionMatrix();var out=BUFFERS.getBuffer(LAYER);
  for(var l:LEAVES){double age=(l.age+delta)*.05,alpha=LeafMath.fade(age,l.life)*s.number("opacity")*Math.clamp((s.number("distance")-l.pos.distanceTo(camera))/4,0,1);
   if(l.ground)alpha*=Math.clamp((Math.min(120,l.life*10)-l.groundAge-delta)/25,0,1);if(alpha<.004)continue;
   var pos=l.previous.lerp(l.pos,delta);double rot=l.phase+age*s.number("rotation")*(.5+l.shape),tilt=LeafMath.flutter(age,l.phase)*.8;
   double settle=l.ground?Math.clamp((l.groundAge+delta)/5d,0,1):0;tilt*=1-settle;
   if(l.ground)rot=l.settledRotation;
   Vec3d right=new Vec3d(Math.cos(rot),0,Math.sin(rot)).multiply(l.size*l.shape),up=new Vec3d(-Math.sin(rot)*Math.cos(tilt),Math.sin(tilt),Math.cos(rot)*Math.cos(tilt)).multiply(l.size);
   var sprite=c.getBlockRenderManager().getModels().getModelParticleSprite(l.state);
   int rgb=0;for(int shift=0;shift<=16;shift+=8)rgb|=((int)(((l.color>>>shift)&255)*l.light))<<shift;
   int color=((int)(alpha*255)<<24)|rgb;
   // A pointed six-sided leaf silhouette, textured from the actual tree's atlas sprite.
   double[] xx={0,.7,1,0,-1,-.7},yy={-1,-.45,.25,1,.25,-.45};
   for(int j=1;j<5;j++)for(int k=0;k<4;k++){
    int index=k==0?0:k==1?j:j+1;double x=xx[index],y=yy[index];var v=pos.add(right.multiply(x)).add(up.multiply(y));
    float u=(float)(sprite.getMinU()+(sprite.getMaxU()-sprite.getMinU())*(x*.5+.5)),vv=(float)(sprite.getMinV()+(sprite.getMaxV()-sprite.getMinV())*(y*.5+.5));
    out.vertex(m,(float)v.x,(float)v.y,(float)v.z).texture(u,vv).color(color);
   }
  }
  BUFFERS.draw();matrices.pop();
 }
 private FallingLeaves(){}
}
