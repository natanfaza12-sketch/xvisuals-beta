package pl.xvisuals.rendering;
import net.fabricmc.loader.api.FabricLoader;
import java.lang.reflect.Method;
/** Reads live pack state at draw time as well as during ticks, including while paused. */
public final class ShaderPackSupport {
 private static final boolean IRIS_LOADED=FabricLoader.getInstance().isModLoaded("iris");
 private static Method instance,active;
 public static boolean active(){
  if(!IRIS_LOADED)return false;
  try{if(instance==null){var api=Class.forName("net.irisshaders.iris.api.v0.IrisApi");var getter=api.getMethod("getInstance");var query=api.getMethod("isShaderPackInUse");active=query;instance=getter;}return (boolean)active.invoke(instance.invoke(null));}
  catch(ReflectiveOperationException|LinkageError ex){return true;}
 }
 private ShaderPackSupport(){}
}
