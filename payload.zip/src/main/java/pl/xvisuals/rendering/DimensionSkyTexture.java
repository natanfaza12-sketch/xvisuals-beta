package pl.xvisuals.rendering;
import java.nio.file.*;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
public final class DimensionSkyTexture {
 private static NativeImageBackedTexture texture;
 private static String loaded="",status="Import a PNG panorama or cubemap.";
 private static int layout;
 public static Path directory(){return net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("xvisuals/dimension-skies").toAbsolutePath().normalize();}
 public static String status(){return status;}
 public static int layout(){return layout;}
 public static NativeImageBackedTexture get(String file){
  if(file.equals(loaded))return texture;close();loaded=file;
  if(file.isBlank())return null;
  try{
   Path path=Path.of(file).toRealPath();if(!path.startsWith(directory().toRealPath())||!Files.isRegularFile(path)||Files.size(path)>128L*1024*1024)throw new java.io.IOException();
   // Check the header before allocating native image memory, including files edited after import.
   try(var input=javax.imageio.ImageIO.createImageInputStream(path.toFile())){
    var readers=javax.imageio.ImageIO.getImageReaders(input);if(!readers.hasNext())throw new java.io.IOException();var reader=readers.next();
    try{reader.setInput(input,true,true);int w=reader.getWidth(0),h=reader.getHeight(0);layout=DimensionSkyMath.layout(w,h);if(layout<0||w>8192||h>8192||(long)w*h>33_554_432L)throw new java.io.IOException();}finally{reader.dispose();}
   }
   try(var in=Files.newInputStream(path)){var image=NativeImage.read(in);texture=new NativeImageBackedTexture(()->"Dimension sky",image);}
   status="Custom sky loaded: "+texture.getImage().getWidth()+" x "+texture.getImage().getHeight();
  }catch(Exception ex){status="Image unavailable. Import it again; using the dimension preset.";}
  return texture;
 }
 public static void close(){if(texture!=null)texture.close();texture=null;loaded="";}
 private DimensionSkyTexture(){}
}
