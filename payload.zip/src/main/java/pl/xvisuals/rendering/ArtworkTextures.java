package pl.xvisuals.rendering;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.util.Identifier;
/** Immutable CPU artwork snapshots: native image decoding occurs once per resource reload. */
public final class ArtworkTextures {
 public static final class Sampler {
  private final int width,height;private final int[] pixels;
  private Sampler(int width,int height,int[] pixels){this.width=width;this.height=height;this.pixels=pixels;}
  public int sample(double u,double v){return pixels[ArtworkSampling.index(u,v,width,height)];}
 }
 private static final Sampler MISSING=new Sampler(1,1,new int[]{0xffff00ff});
 private static final java.util.Map<String,Sampler> IMAGES=new java.util.concurrent.ConcurrentHashMap<>();
 static {net.fabricmc.fabric.api.resource.v1.ResourceLoader.get(net.minecraft.resource.ResourceType.CLIENT_RESOURCES)
  .registerReloader(Identifier.of("xvisuals","crafted_artwork"),(net.minecraft.resource.SynchronousResourceReloader)r->clear());
  net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING.register(c->clear());}
 public static int sample(String path,double u,double v){
  return sampler(path).sample(u,v);
 }
 /** Retain only for the current paint/update so resource reloads are picked up next time. */
 public static Sampler sampler(String path){
  Sampler image=IMAGES.get(path);return image==null?load(path):image;
 }
 private static synchronized Sampler load(String path){
  Sampler cached=IMAGES.get(path);if(cached!=null)return cached;
  Sampler result;
  try(var in=MinecraftClient.getInstance().getResourceManager().open(Identifier.of("xvisuals","textures/"+path+".png"));var image=NativeImage.read(in)){
   int width=image.getWidth(),height=image.getHeight();int[] pixels=new int[Math.multiplyExact(width,height)];
   for(int y=0;y<height;y++)for(int x=0;x<width;x++)pixels[y*width+x]=image.getColorArgb(x,y);
   result=new Sampler(width,height,pixels);
  }catch(java.io.IOException e){result=MISSING;}
  // Cache missing resources too: retry on reload, not on every sampled pixel.
  IMAGES.put(path,result);return result;
 }
 private static synchronized void clear(){IMAGES.clear();}
 private ArtworkTextures(){}
}
