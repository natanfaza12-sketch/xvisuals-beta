package pl.xvisuals.rendering;

import java.nio.file.*;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;

/** Owns only a validated local panorama, never a URL or a file from a shared profile. */
public final class CustomSkyImage {
  private static NativeImageBackedTexture texture;
  private static String loaded="", status="Import a PNG/JPEG; a 2:1 panorama works best.";
  public static Path directory() { return net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("xvisuals/skies").toAbsolutePath().normalize(); }
  public static String status() { return status; }
  public static NativeImageBackedTexture get(String file) {
    if(file.equals(loaded))return texture;
    close();loaded=file;
    if(file.isBlank()){status="No image imported. Showing Aurora Veil.";return null;}
    try {
      Path path=Path.of(file).toAbsolutePath().normalize();
      if(!path.startsWith(directory()) || !Files.isRegularFile(path) || Files.size(path)>128L*1024*1024)
        throw new java.io.IOException("Import the sky image on this computer first.");
      try(var in=Files.newInputStream(path)) {
        NativeImage image=NativeImage.read(in);
        if(image.getWidth()>8192 || image.getHeight()>8192 || (long)image.getWidth()*image.getHeight()>33_554_432L) {
          image.close();throw new java.io.IOException("Image is too large.");
        }
        texture=new NativeImageBackedTexture(()->"Imported sky panorama",image);
      }
      var image=texture.getImage();
      status="Sky: "+image.getWidth()+" x "+image.getHeight()+
          (Math.abs(image.getWidth()/(double)image.getHeight()-2)>.05?" — use a 2:1 panorama to avoid stretching.":image.getWidth()<4096?" — use a 4K/8K panorama for sharper detail.":" — full-resolution rendering.");
    } catch(Exception e){status="Image unavailable. Import it again; showing Aurora Veil.";}
    return texture;
  }
  public static void close(){if(texture!=null)texture.close();texture=null;loaded="";}
  private CustomSkyImage(){}
}
