package pl.xvisuals.rendering;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Predicate;

/** Keeps published terrain snapshots immutable, allocating only when a patch disappears. */
final class WaterSurfaceSnapshot {
    static <K, V> Map<K, V> retain(Map<K, V> snapshot, Predicate<K> valid) {
        Map<K, V> next = null;
        for (K key : snapshot.keySet()) {
            if (valid.test(key)) continue;
            if (next == null) next = new HashMap<>(snapshot);
            next.remove(key);
        }
        return next == null ? snapshot : Map.copyOf(next);
    }

    private WaterSurfaceSnapshot() {}
}
