package pl.xvisuals.rendering;

import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import pl.xvisuals.mixins.RenderLayerAccessor;
import pl.xvisuals.modules.world.MeteorField;
import pl.xvisuals.modules.world.MeteorArtwork;
import pl.xvisuals.util.Colors;
import java.util.Random;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.joml.Matrix4f;

/** Authored animated meteor sprites and textured wakes at sky depth, occluded by terrain and roofs. */
public final class ShootingStars {
  private static final MeteorField FIELD = new MeteorField();
  private static final BufferAllocator ALLOCATOR = new BufferAllocator(262144);
  private static final VertexConsumerProvider.Immediate BUFFERS =
      VertexConsumerProvider.immediate(ALLOCATOR);
  private static final Vec3d[] STARS = new Vec3d[192];
  private static final float[] SIZES = new float[192];
  private static Object world;
  private static long lastFrame;
  private static boolean wasEnabled;
  public static int renderedQuads;
  public static long lastDrawNanos;
  private static final RenderLayer[][] LAYERS=new RenderLayer[2][4];
  private static final int[] DRAW_ORDER={MeteorArtwork.WAKE,MeteorArtwork.FRAGMENT,MeteorArtwork.STAR,MeteorArtwork.FIREBALL};
  private static RenderPipeline pipeline(boolean glow){return RenderPipeline.builder()
      .withLocation(Identifier.of("xvisuals","pipeline/meteor_art"+(glow?"_glow":"")))
      .withVertexShader(Identifier.of("xvisuals","core/shooting_star"))
      .withFragmentShader(Identifier.of("xvisuals","core/shooting_star"))
      .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER)
      .withSampler("Sampler0").withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS)
      .withBlend(glow?new BlendFunction(com.mojang.blaze3d.platform.SourceFactor.SRC_ALPHA,com.mojang.blaze3d.platform.DestFactor.ONE):BlendFunction.TRANSLUCENT)
      .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withDepthWrite(false).withCull(false).build();}
  static {for(int pass=0;pass<2;pass++){var pipeline=pipeline(pass==1);for(int type=0;type<4;type++)
    LAYERS[pass][type]=RenderLayerAccessor.visuals$of("xvisuals_meteor_art_"+pass+"_"+type,
      RenderSetup.builder(pipeline).texture("Sampler0",MeteorArtwork.texture(type)).translucent().expectedBufferSize(262144).build());}}

  static {
    Random random = new Random(0xA1A71C);
    for (int i = 0; i < STARS.length; i++) {
      double azimuth = random.nextDouble() * Math.PI * 2;
      double y = .08 + random.nextDouble() * .92;
      double horizontal = Math.sqrt(1 - y * y);
      STARS[i] =
          new Vec3d(Math.cos(azimuth) * horizontal, y, Math.sin(azimuth) * horizontal)
              .multiply(128);
      SIZES[i] = .1f + random.nextFloat() * .18f;
    }
  }

  public static void init() {
    WorldRenderEvents.END_MAIN.register(c -> render(c.matrices()));
    net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING.register(c -> ALLOCATOR.close());
  }

  public static void tick(MinecraftClient client) {
    boolean enabled = XVisuals.visualModule("shootingstars").enabled&&!MeteorShower.enabled();
    if (world != client.world || wasEnabled != enabled) {
      FIELD.reset(System.nanoTime());
      lastFrame = 0;
      world = client.world;
      wasEnabled = enabled;
    }
  }

  public static double nightVisibility(long ticks) {
    double t = Math.floorMod(ticks, 24000L);
    return smooth((t - 12500) / 1800) * (1 - smooth((t - 22200) / 1300));
  }

  private static double smooth(double t) {
    t = Math.clamp(t, 0, 1);
    return t * t * (3 - 2 * t);
  }

  private static void render(MatrixStack matrices) {
    long started=System.nanoTime();renderedQuads=0;lastDrawNanos=0;
    MinecraftClient client = MinecraftClient.getInstance();
    if (client.world == null
        || client.world.getRegistryKey() != World.OVERWORLD
        || !XVisuals.visualModule("shootingstars").enabled || MeteorShower.enabled()) {
      lastFrame = 0;
      return;
    }
    long now = System.nanoTime();
    double dt = lastFrame == 0 || client.isPaused() ? 0 : Math.min(.1, (now - lastFrame) / 1e9);
    lastFrame = now;
    var s = XVisuals.visualModule("shootingstars");
    double visibility = s.flag("night") ? nightVisibility(client.world.getTimeOfDay()) : 1;
    if (s.flag("weather")) visibility *= 1 - client.world.getRainGradient(1) * .92;
    double quality = Math.min(1, Quality.factor());
    int cap = Math.max(2, (int) (s.number("limit") * quality));
    FIELD.update(dt, visibility > .02 ? s.number("frequency") : 0, cap, s.number("speed"));
    if (visibility < .005 || (client.player != null && client.player.isSubmergedInWater())) return;
    int headColor = s.color("color"), tailColor = s.color("tailColor");
    double opacity = s.number("opacity") * visibility;
    double size = s.number("size"), trail = s.number("trail");
    double glow = s.number("glow") * Quality.glow();
    int segments = quality < .4 ? 8 : 16;
    Matrix4f matrix = matrices.peek().getPositionMatrix();
    // Draw by atlas and blend pass: at most eight batches, independent of meteor count.
    for(int pass=0;pass<2;pass++){
      if(pass==1 && glow<=.01)continue;
      for(int type:DRAW_ORDER){
        if(pass==1 && type==MeteorArtwork.FRAGMENT)continue;
        VertexConsumer out=BUFFERS.getBuffer(LAYERS[pass][type]);
        if(type==MeteorArtwork.STAR && pass==0 && s.flag("twinkle")){
          int stars=Math.min(STARS.length,(int)(s.number("stars")*quality));
          for(int i=0;i<stars;i++){
            double a=(.48+.3*Math.sin(FIELD.time()*.7+i*2.399))*opacity;
            sprite(out,matrix,STARS[i],SIZES[i]*1.8,Colors.alpha(headColor,a),MeteorArtwork.frame(FIELD.time()*.3,i),i*.7);
          }
        }
        for(var meteor:FIELD.meteors()){
          double alpha=meteor.alpha()*opacity;if(alpha<.005)continue;
          boolean fireball=s.flag("fireballs")&&meteor.fireball();
          double variedSize=size*(.85+Math.floorMod(meteor.seed(),101)/250.0)*(fireball?1.8:1);
          double tailSeconds=Math.min(trail*(fireball?1.3:1),meteor.age());
          int frame=MeteorArtwork.frame(meteor.age(),meteor.seed());
          Vec3d head=point(meteor.direction());
          if(type==MeteorArtwork.WAKE){
            for(int i=0;i<segments;i++){
              double u=i/(double)segments,v=(i+1.)/segments;
              Vec3d a=point(meteor.direction(u*tailSeconds)),b=point(meteor.direction(v*tailSeconds));
              Vec3d side=a.crossProduct(b.subtract(a)).normalize();if(side.lengthSquared()<.01)continue;
              a=a.add(side.multiply(meteor.wakeOffset(u,s.number("turbulence"))));
              b=b.add(side.multiply(meteor.wakeOffset(v,s.number("turbulence"))));
              double width=variedSize*(pass==1?2.8:1.6);
              double strength=alpha*(pass==1?glow*.32:1);
              ribbon(out,matrix,a,b,side,width,width,u,v,
                Colors.alpha(Colors.mix(headColor,tailColor,u),strength),
                Colors.alpha(Colors.mix(headColor,tailColor,v),strength),frame);
            }
          }else if(type==MeteorArtwork.FRAGMENT && s.flag("sparkles")){
            int count=quality<.4?3:(fireball?9:5);
            for(int i=1;i<=count;i++){
              double u=(meteor.age()*.38+i/(double)count)%1;
              Vec3d p=point(meteor.direction(tailSeconds*u));Vec3d side=head.crossProduct(p).normalize();
              double spread=Math.sin(i*13.7+(meteor.seed()&255))*u*variedSize*1.4;
              p=p.add(side.multiply(spread)).add(0,-u*u*variedSize*.7,0);
              sprite(out,matrix,p,variedSize*.35*(1-u*.5),Colors.alpha(tailColor,alpha*Math.sin(u*Math.PI)*(1-u)*.9),MeteorArtwork.frame(meteor.age()*1.3,meteor.seed()+i),meteor.age()*2+i);
            }
          }else if(type==(fireball?MeteorArtwork.FIREBALL:MeteorArtwork.STAR)){
            double radius=variedSize*(pass==1?1.25:.85);
            sprite(out,matrix,head,radius,Colors.alpha(headColor,alpha*(pass==1?glow*.32:1)),frame,meteor.age()*(fireball?.45:.2));
          }
        }
        BUFFERS.draw();
      }
    }
    lastDrawNanos=System.nanoTime()-started;
  }

  private static Vec3d point(MeteorField.Direction d) {
    return new Vec3d(d.x() * 128, d.y() * 128, d.z() * 128);
  }

  private static void sprite(VertexConsumer out,Matrix4f m,Vec3d center,double radius,int color,int frame,double angle){
    Vec3d n=center.normalize(),right=n.crossProduct(new Vec3d(0,1,0)).normalize();
    if(right.lengthSquared()<.1)right=new Vec3d(1,0,0);
    Vec3d up=right.crossProduct(n).normalize();
    Vec3d r=right.multiply(Math.cos(angle)*radius).add(up.multiply(Math.sin(angle)*radius));
    Vec3d t=up.multiply(Math.cos(angle)*radius).subtract(right.multiply(Math.sin(angle)*radius));
    vertex(out,m,center.subtract(r).subtract(t),MeteorArtwork.u(frame,0),MeteorArtwork.v(frame,1),color);
    vertex(out,m,center.subtract(r).add(t),MeteorArtwork.u(frame,0),MeteorArtwork.v(frame,0),color);
    vertex(out,m,center.add(r).add(t),MeteorArtwork.u(frame,1),MeteorArtwork.v(frame,0),color);
    vertex(out,m,center.add(r).subtract(t),MeteorArtwork.u(frame,1),MeteorArtwork.v(frame,1),color);
    renderedQuads++;
  }

  private static void ribbon(
      VertexConsumer out,
      Matrix4f m,
      Vec3d a,
      Vec3d b,
      Vec3d side,
      double wa,
      double wb,
      double u,
      double v,
      int ca,
      int cb, int frame) {
    vertex(out, m, a.subtract(side.multiply(wa)), MeteorArtwork.u(frame,.094+u*.812), MeteorArtwork.v(frame,0), ca);
    vertex(out, m, a.add(side.multiply(wa)), MeteorArtwork.u(frame,.094+u*.812), MeteorArtwork.v(frame,1), ca);
    vertex(out, m, b.add(side.multiply(wb)), MeteorArtwork.u(frame,.094+v*.812), MeteorArtwork.v(frame,1), cb);
    vertex(out, m, b.subtract(side.multiply(wb)), MeteorArtwork.u(frame,.094+v*.812), MeteorArtwork.v(frame,0), cb);
    renderedQuads++;
  }

  private static void vertex(VertexConsumer out, Matrix4f m, Vec3d p, float u, float v, int color) {
    out.vertex(m, (float) p.x, (float) p.y, (float) p.z).color(color).texture(u, v);
  }

  public static int count() {
    return FIELD.meteors().size();
  }

  public static void resetForPreview(long seed) {
    FIELD.reset(seed);
  }

  private ShootingStars() {}
}
