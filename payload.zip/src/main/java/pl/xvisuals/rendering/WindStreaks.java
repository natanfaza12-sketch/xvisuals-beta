package pl.xvisuals.rendering;

import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import pl.xvisuals.mixins.RenderLayerAccessor;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.RaycastContext;
import org.joml.Vector3f;
import java.util.*;

/** Camera-facing ribbons along local wind paths. Uses ordinary depth testing, not terrain shaders. */
public final class WindStreaks {
 private static final int CAP=48,HISTORY=16;
 private static final List<Trail> TRAILS=new ArrayList<>();
 private static final Random RANDOM=new Random();
 private static Object world;
 private static double credit,clock,force;
 private static boolean failed;
 private static final BufferAllocator ALLOCATOR=new BufferAllocator(262144);
 private static final VertexConsumerProvider.Immediate BUFFERS=VertexConsumerProvider.immediate(ALLOCATOR);
 private static final RenderLayer LAYER=RenderLayerAccessor.visuals$of("visual_wind_streaks",RenderSetup.builder(RenderPipeline.builder()
  .withLocation(Identifier.of("xvisuals","pipeline/wind_streaks"))
  .withVertexShader(Identifier.of("xvisuals","core/wind_streaks"))
  .withFragmentShader(Identifier.of("xvisuals","core/wind_streaks"))
  .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER).withUniform("Fog",UniformType.UNIFORM_BUFFER)
  .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS)
  .withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withDepthWrite(false).withCull(false).build())
  .translucent().expectedBufferSize(262144).build());
 private static final class Trail {
  final List<Vec3d> path=new ArrayList<>(HISTORY);
  final double phase=RANDOM.nextDouble()*Math.PI*2,width=.035+RANDOM.nextDouble()*.035;
  final int life=50+RANDOM.nextInt(35);
  int age;
  double light=.7;
 }
 public static void init(){
  WorldRenderEvents.END_MAIN.register(c->render(c.matrices()));
  ClientLifecycleEvents.CLIENT_STOPPING.register(c->{clear();ALLOCATOR.close();});
 }
 public static void clear(){TRAILS.clear();credit=clock=force=0;failed=false;}
 public static void tick(MinecraftClient c,boolean enabled,double windX,double windZ,double speed){
  if(world!=c.world){clear();world=c.world;}
  if(!enabled||c.world==null||c.player==null){clear();return;}
  if(c.isPaused()||failed)return;
  clock+=.05;force=Math.hypot(windX,windZ);
  var camera=c.gameRenderer.getCamera().getCameraPos();
  double length=Math.max(.001,force),dx=windX/length,dz=windZ/length;
  double movement=WindMath.streakSpeed(force,speed)*.05;
  for(var it=TRAILS.iterator();it.hasNext();){
   var trail=it.next();var pos=trail.path.getLast();trail.age++;
   if(trail.age>=trail.life||pos.squaredDistanceTo(camera)>24*24||force<.01){it.remove();continue;}
   double curl=Math.sin(clock*2+trail.phase)*.28;
   var next=pos.add((dx-dz*curl)*movement,Math.sin(clock*1.7+trail.phase)*movement*.15,(dz+dx*curl)*movement);
   var block=BlockPos.ofFloored(next);
   if(!c.world.isChunkLoaded(block.getX()>>4,block.getZ()>>4)||!c.world.getFluidState(block).isEmpty()
    ||c.world.raycast(new RaycastContext(pos,next,RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.ANY,c.player)).getType()!=HitResult.Type.MISS){it.remove();continue;}
   trail.light=.2+.8*Math.clamp(c.world.getBaseLightLevel(block,c.world.getAmbientDarkness())/15d,0,1);
   trail.path.add(next);if(trail.path.size()>HISTORY)trail.path.removeFirst();
  }
  credit=Math.min(2,credit+WindMath.streakRate(force)*.05);
  while(credit>=1){credit--;if(TRAILS.size()>=CAP)break;spawn(c,camera);}
 }
 private static void spawn(MinecraftClient c,Vec3d camera){
  var rotation=c.gameRenderer.getCamera().getRotation();
  var f=new Vector3f(0,0,-1).rotate(rotation);var r=new Vector3f(1,0,0).rotate(rotation);
  var forward=new Vec3d(f.x,f.y,f.z);var right=new Vec3d(r.x,r.y,r.z);
  // Bias towards the visible scene instead of spending almost every particle behind the camera.
  for(int attempt=0;attempt<3;attempt++){
   var pos=camera.add(forward.multiply(4+RANDOM.nextDouble()*12)).add(right.multiply((RANDOM.nextDouble()-.5)*18)).add(0,(RANDOM.nextDouble()-.5)*6,0);
   var at=BlockPos.ofFloored(pos);
   if(!c.world.isChunkLoaded(at.getX()>>4,at.getZ()>>4)||!c.world.getBlockState(at).isAir()||!c.world.getFluidState(at).isEmpty())continue;
   // Exclude sealed interiors and tunnels; overhead foliage still permits outdoor wind.
   if(!c.world.isSkyVisible(at)&&!c.world.isSkyVisible(at.up(3)))continue;
   var trail=new Trail();trail.path.add(pos);TRAILS.add(trail);return;
  }
 }
 private static void render(MatrixStack matrices){
  var c=MinecraftClient.getInstance();
  if(c.world==null||c.player==null||world!=c.world||failed||TRAILS.isEmpty()||!WindFX.enabled()
   ||!XVisuals.visualModule("windfx").flag("airborne")||!CameraEnvironment.surface())return;
  var camera=c.gameRenderer.getCamera().getCameraPos();float delta=c.getRenderTickCounter().getTickProgress(false);
  var matrix=matrices.peek().getPositionMatrix();var up=new Vector3f(0,1,0).rotate(c.gameRenderer.getCamera().getRotation());
  try{
   TRAILS.sort(Comparator.comparingDouble((Trail t)->-t.path.getLast().squaredDistanceTo(camera)));
   var out=BUFFERS.getBuffer(LAYER);
   for(var trail:TRAILS){
    int count=trail.path.size()-1;if(count<3)continue;
    double alpha=WindMath.streakAlpha(trail.age+delta,trail.life,trail.path.getLast().distanceTo(camera),force);
    if(alpha<.002)continue;
    Vec3d[] points=new Vec3d[count],sides=new Vec3d[count];
    for(int i=0;i<count;i++)points[i]=trail.path.get(i).lerp(trail.path.get(i+1),delta);
    for(int i=0;i<count;i++){
     var tangent=points[Math.min(count-1,i+1)].subtract(points[Math.max(0,i-1)]);
     var side=tangent.crossProduct(camera.subtract(points[i]));
     if(side.lengthSquared()<1e-8)side=new Vec3d(up.x,up.y,up.z);
     sides[i]=side.normalize().multiply(trail.width);
    }
    int red=(int)(218*trail.light),green=(int)(231*trail.light),blue=(int)(235*trail.light);
    for(int i=0;i<count-1;i++){
     float a=i/(float)(count-1),b=(i+1)/(float)(count-1);
     vertex(out,matrix,points[i].subtract(sides[i]).subtract(camera),a,0,red,green,blue,alpha);
     vertex(out,matrix,points[i].add(sides[i]).subtract(camera),a,1,red,green,blue,alpha);
     vertex(out,matrix,points[i+1].add(sides[i+1]).subtract(camera),b,1,red,green,blue,alpha);
     vertex(out,matrix,points[i+1].subtract(sides[i+1]).subtract(camera),b,0,red,green,blue,alpha);
    }
   }
   BUFFERS.draw();
  }catch(RuntimeException ex){failed=true;org.slf4j.LoggerFactory.getLogger("VisualClient").warn("Wind streak renderer unavailable",ex);}
 }
 private static void vertex(VertexConsumer out,org.joml.Matrix4f matrix,Vec3d p,float u,float v,int r,int g,int b,double alpha){
  out.vertex(matrix,(float)p.x,(float)p.y,(float)p.z).texture(u,v).color(r,g,b,(int)(alpha*255));
 }
 private WindStreaks(){}
}
