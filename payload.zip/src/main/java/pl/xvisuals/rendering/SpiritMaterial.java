package pl.xvisuals.rendering;

import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.mixins.RenderLayerAccessor;
import java.util.*;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.util.Identifier;

/** Skin-textured, depth-tested translucent geometry. No full-screen post process. */
public final class SpiritMaterial {
  private static final RenderPipeline PIPE = pipeline(false,true), AFTERGLOW=pipeline(true,true), DUST=pipeline(false,false);
  private static RenderPipeline pipeline(boolean glow,boolean skin){return RenderPipeline.builder()
          .withLocation(Identifier.of("xvisuals", "pipeline/spirit"+(glow?"_afterglow":"")+(skin?"":"_dust")))
          .withVertexShader(Identifier.of("xvisuals", "core/spirit"))
          .withFragmentShader(Identifier.of("xvisuals", glow?"core/afterglow_spirit":"core/spirit"))
          .withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
          .withUniform("Projection", UniformType.UNIFORM_BUFFER)
          .withSampler("Sampler0").withSampler("Dissolve")
          .withVertexFormat(
              VertexFormats.POSITION_COLOR_TEXTURE_OVERLAY_LIGHT_NORMAL,
              VertexFormat.DrawMode.QUADS)
          .withBlend(BlendFunction.TRANSLUCENT)
          .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
          .withDepthWrite(false)
          // Skin UVs differ on opposite faces. Drawing the inside of a translucent
          // head exposes its face through the back and makes echoes look reversed.
          .withCull(skin)
          .build();}
  private static final Map<Identifier,RenderLayer> GLOW_LAYERS=new pl.xvisuals.util.BoundedCache<>(128);
  public static RenderLayer afterglowLayer(Identifier texture){return GLOW_LAYERS.computeIfAbsent(texture,t->RenderLayerAccessor.visuals$of("afterglow_spirit",RenderSetup.builder(AFTERGLOW).texture("Sampler0",t).texture("Dissolve",Identifier.of("xvisuals","textures/crafted/dissolve.png")).translucent().expectedBufferSize(32768).build()));}
  private static final Map<Identifier, RenderLayer> LAYERS = new pl.xvisuals.util.BoundedCache<>(128);
  private static final Map<Identifier, RenderLayer> DUST_LAYERS = new pl.xvisuals.util.BoundedCache<>(128);

  /** Dissolve fragments are crossed sheets, so both sides must remain visible. */
  public static RenderLayer particleLayer(Identifier texture) {
    return DUST_LAYERS.computeIfAbsent(texture,t->RenderLayerAccessor.visuals$of("spirit_dust",
        RenderSetup.builder(DUST).texture("Sampler0",t)
            .texture("Dissolve",Identifier.of("xvisuals","textures/crafted/dissolve.png"))
            .translucent().expectedBufferSize(32768).build()));
  }

  public static RenderLayer layer(Identifier texture) {
    return LAYERS.computeIfAbsent(
        texture,
        t ->
            RenderLayerAccessor.visuals$of(
                "xvisuals_spirit",
                RenderSetup.builder(PIPE)
                    .texture("Sampler0", t).texture("Dissolve",Identifier.of("xvisuals","textures/crafted/dissolve.png"))
                    .translucent()
                    .expectedBufferSize(32768)
                    .build()));
  }

  public static VertexConsumer wrap(
      VertexConsumer target, double dissolve, double glow, double skin) {
    return new Parameters(
        target,
        (int) (Math.clamp(dissolve, 0, 1) * 32767) | ((int) (Math.clamp(glow, 0, 1) * 32767) << 16),
        (int) (Math.clamp(skin, 0, 1) * 32767));
  }

  private record Parameters(VertexConsumer out, int params, int surface) implements VertexConsumer {
    public VertexConsumer vertex(float x, float y, float z) {
      out.vertex(x, y, z);
      return this;
    }

    public VertexConsumer color(int r, int g, int b, int a) {
      out.color(r, g, b, a);
      return this;
    }

    public VertexConsumer color(int argb) {
      out.color(argb);
      return this;
    }

    public VertexConsumer texture(float u, float v) {
      out.texture(u, v);
      return this;
    }

    public VertexConsumer overlay(int u, int v) {
      out.overlay(params);
      return this;
    }

    public VertexConsumer light(int u, int v) {
      out.light(surface);
      return this;
    }

    public VertexConsumer normal(float x, float y, float z) {
      out.normal(x, y, z);
      return this;
    }

    public VertexConsumer lineWidth(float w) {
      return this;
    }

    public void vertex(
        float x,
        float y,
        float z,
        int c,
        float u,
        float v,
        int o,
        int l,
        float nx,
        float ny,
        float nz) {
      out.vertex(x, y, z, c, u, v, params, surface, nx, ny, nz);
    }
  }

  private SpiritMaterial() {}
}
