package pl.xvisuals.rendering;
/** Same nearest-texel/clamped addressing as NativeImage sampling, including UV endpoints. */
public final class ArtworkSampling {
 public static int index(double u,double v,int width,int height){
  return Math.clamp((int)(v*height),0,height-1)*width+Math.clamp((int)(u*width),0,width-1);
 }
 private ArtworkSampling(){}
}
