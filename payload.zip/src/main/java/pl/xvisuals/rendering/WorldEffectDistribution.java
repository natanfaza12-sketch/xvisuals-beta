package pl.xvisuals.rendering;

/** Camera-independent coverage around the player's current position. */
public final class WorldEffectDistribution {
  public static int sector(double x,double z) {
    return Math.floorMod((int)Math.floor(Math.atan2(z,x)/(Math.PI/2)),4);
  }
  public static int least(int[] counts,int start) {
    int best=Math.floorMod(start,4);
    for(int i=1;i<4;i++){int candidate=(start+i)%4;if(counts[candidate]<counts[best])best=candidate;}
    return best;
  }
  public static double angle(int sector,double random) {return (sector+random)*Math.PI/2;}
  public static double radius(double range,double random) {return range*(.18+.65*random);}
  private WorldEffectDistribution(){}
}
