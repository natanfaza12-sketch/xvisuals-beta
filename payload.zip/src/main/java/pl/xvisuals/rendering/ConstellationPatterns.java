package pl.xvisuals.rendering;
import java.util.Random;
public final class ConstellationPatterns {
 public record Point(double x,double y){}
 public record Appearance(double phase,double brightness,double size,double warmth){}
 public static Appearance appearance(int pattern,int star){
  double phase=pattern*1.72+star*2.39,sin=Math.sin(phase),cos=Math.cos(phase);
  return new Appearance(phase,.65+.25*sin*sin,.75+.25*cos*cos,.95+.05*sin);
 }
 private static final double[][][] DESIGNS={
  {{-.9,.4},{-.55,.5},{-.2,.35},{.05,.1},{.6,.2},{.7,-.4},{.1,-.45}},
  {{-.9,.25},{-.5,-.3},{0,.35},{.45,-.2},{.9,.4}},
  {{-.6,.8},{.55,.7},{.2,.05},{0,0},{-.2,-.05},{-.6,-.8},{.6,-.75}},
  {{0,.9},{0,.2},{-.65,.15},{0,.2},{.65,.15},{0,.2},{0,-.8}}
 };
 public static Point[] pattern(int index,boolean custom){
  if(custom&&index%2==1){Random r=new Random(9341L+index);Point[] result=new Point[6+index%3];for(int i=0;i<result.length;i++){double a=i*2.399963;double radius=.3+r.nextDouble()*.6;result[i]=new Point(Math.cos(a)*radius,Math.sin(a)*radius);}return result;}
  var points=DESIGNS[Math.floorMod(index,DESIGNS.length)];Point[] out=new Point[points.length];for(int i=0;i<out.length;i++)out[i]=new Point(points[i][0],points[i][1]);return out;
 }
 public static double night(long time){double t=Math.floorMod(time,24000);return smooth((t-12000)/1800)*(1-smooth((t-22200)/1800));}
 private static double smooth(double t){t=Math.clamp(t,0,1);return t*t*(3-2*t);}
 private ConstellationPatterns(){}
}
