package pl.xvisuals.rendering;
/** Pure bounded wind parameters, independent of game state. */
public final class WindMath {
 public static double strength(double base,double rain,boolean thunder){return Math.clamp(base,0,3)*(1+Math.clamp(rain,0,1)*.45+(thunder?.55:0));}
 public static double gust(double time,double frequency){if(frequency<=0)return 1;double t=time*frequency;double pulse=Math.max(0,Math.sin(t*.43)*.55+Math.sin(t*.17+1.3)*.45);return 1+.8*pulse*pulse*pulse;}
 public static int weight(double height,double plantHeight){return (int)Math.round(Math.clamp(height/plantHeight,0,1)*127);}
 public static double streakRate(double force){return force<=.01?0:Math.min(16,8+force*5);}
 public static double streakSpeed(double force,double speed){return force<=.01?0:Math.min(12,(1+force*4)*Math.clamp(speed,.1,3));}
 public static double streakAlpha(double age,double life,double distance,double force){
  double fade=Math.clamp(age/10,0,1)*Math.clamp((life-age)/16,0,1);
  double range=Math.clamp((distance-.8)/1.8,0,1)*Math.clamp((24-distance)/6,0,1);
  return fade*range*Math.min(.45,.23+force*.1)*Math.clamp(force/.12,0,1);
 }
 private WindMath(){}
}
