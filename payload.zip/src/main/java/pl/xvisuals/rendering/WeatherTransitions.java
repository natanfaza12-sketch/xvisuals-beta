package pl.xvisuals.rendering;
import pl.xvisuals.XVisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.world.World;
/** Client-only weather envelope. Sampling vanilla bypasses our own gradient hooks. */
public final class WeatherTransitions {
  private static Object world;
  private static boolean sampling,active;
  private static final WeatherEnvelope envelope = new WeatherEnvelope();
  public static float approach(float value,float target,float step){return value+Math.clamp(target-value,-step,step);}
  public static void tick(MinecraftClient c){
    if(world!=c.world){world=c.world;envelope.reset();active=false;}
    if(c.world==null || !XVisuals.ready())return;
    var s=XVisuals.config().module("weatherfx");
    boolean enabled=s.enabled&&s.flag("transitions")&&c.world.getRegistryKey()==World.OVERWORLD;
    if(!enabled){active=false;return;}
    if(c.isPaused())return;
    float rawRain,rawThunder;
    sampling=true;
    try{rawRain=c.world.getRainGradient(1);rawThunder=c.world.getThunderGradient(1);}finally{sampling=false;}
    
    String mode=s.text("weather");
    envelope.update(mode,rawRain,rawThunder,(float)s.number("transitionTime"),!active);
    active=true;
  }
  public static boolean sampling(){return sampling;}
  public static boolean overrides(){return active&&world==MinecraftClient.getInstance().world&&!sampling&&XVisuals.config().on("weatherfx")&&XVisuals.config().module("weatherfx").flag("transitions");}
  public static float rain(){return envelope.rain();}
  public static float thunder(){return envelope.thunder();}
  public static float cloud(){return overrides()?envelope.cloud():0;}
  private WeatherTransitions(){}
}
