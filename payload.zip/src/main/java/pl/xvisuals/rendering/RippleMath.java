package pl.xvisuals.rendering;
public final class RippleMath {
 public static double strength(double speed){return Math.clamp(.08+Math.max(0,speed)*3, .08,1.5);}
 public static int interval(double frequency,double speed){return (int)Math.max(3,Math.ceil(20/Math.max(.2,frequency)/(speed<.01? .15:1)));}
 public static double radius(double t){return .08+.92*(1-Math.pow(1-Math.clamp(t,0,1),2));}
 public static double fade(double t){t=Math.clamp(t,0,1);return Math.min(1,t*12)*Math.pow(1-t,1.5);}
 private RippleMath(){}
}
