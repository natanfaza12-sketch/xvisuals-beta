package pl.xvisuals.rendering;
import pl.xvisuals.XVisuals;
import pl.xvisuals.config.VisualConfig.ModuleState;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.DefaultFramebufferSet;
import net.minecraft.client.util.memory.ObjectAllocator;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.*;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import org.joml.Matrix4f;
import java.nio.*;
import java.util.*;
/** Client precipitation presentation, surface wetness and world-only lens droplets. */
public final class RealisticRain {
 private static final pl.xvisuals.rendering.rain.RainSettings STREAK_SETTINGS=new pl.xvisuals.rendering.rain.RainSettings();
 private static final pl.xvisuals.rendering.rain.RainRenderer STREAKS=new pl.xvisuals.rendering.rain.RainRenderer(STREAK_SETTINGS);
 public static double strength(MinecraftClient c,float delta){return Storm.running()?Storm.rain():c.world==null?0:c.world.getRainGradient(delta);}
 public static void renderStreaks(net.minecraft.client.render.VertexConsumerProvider buffers,Vec3d camera){if(active())STREAKS.render(buffers,camera);}

 private static final Map<BlockPos,Double> PUDDLES=new LinkedHashMap<>();private static final List<Drop> DROPS=new ArrayList<>();private static final Random RANDOM=new Random();
 private static class Drop {double x,y,previousY,size;int age,life;}
 private static final ModuleState PROFILE=new ModuleState();private static boolean shaders,failed;private static Object world;private static double rain,dropCredit;private static int ticks;
 private static final Matrix4f VP=new Matrix4f(),INV=new Matrix4f();private static final float[] MATRIX=new float[16];private static final ByteBuffer DATA=ByteBuffer.allocateDirect(912).order(ByteOrder.nativeOrder());
 public static void init(){ClientTickEvents.END_CLIENT_TICK.register(RealisticRain::tick);}
 public static boolean active(){var c=MinecraftClient.getInstance();return XVisuals.ready()&&c.world!=null&&c.world.getRegistryKey().equals(World.OVERWORLD)&&XVisuals.visualModule("realisticrain").enabled&&!ShaderPackSupport.active();}
 public static ModuleState precipitation(ModuleState base){if(!active())return base;RealisticRainMath.profile(PROFILE,base,Storm.running(),XVisuals.visualModule("realisticrain").number("density"));return PROFILE;}

 public static double opacity(){return active()?XVisuals.visualModule("realisticrain").number("opacity"):1;}
 public static Vec3d wind(double magnitude){if(WindFX.enabled()){var flow=AtmosphericWind.sample(ticks*.05);return new Vec3d(flow.x()*magnitude,0,flow.z()*magnitude);}double angle=Math.toRadians(XVisuals.visualModule("realisticrain").number("direction"));return new Vec3d(Math.cos(angle)*magnitude,0,Math.sin(angle)*magnitude);}
 public static double rainfall(){return rain;}
 private static boolean externalShaders(){if(!net.fabricmc.loader.api.FabricLoader.getInstance().isModLoaded("iris"))return false;try{var api=Class.forName("net.irisshaders.iris.api.v0.IrisApi");return (boolean)api.getMethod("isShaderPackInUse").invoke(api.getMethod("getInstance").invoke(null));}catch(ReflectiveOperationException|LinkageError ex){return true;}}
 private static boolean rainAt(MinecraftClient c,BlockPos p){return rainAt(c.world,p);}
 public static boolean rainAt(net.minecraft.client.world.ClientWorld w,BlockPos p){
  if(!w.isSkyVisible(p))return false;if(Storm.running())return true;
  var weather=XVisuals.visualModule("weatherfx");if(weather.enabled){String mode=weather.text("weather");if(mode.equals("Snow")||mode.equals("Blizzard")||mode.equals("Clear"))return false;if(mode.equals("Rain")||mode.equals("Storm"))return true;}
  return w.getBiome(p).value().getPrecipitation(p,w.getSeaLevel())==Biome.Precipitation.RAIN;
 }

 private static boolean surface(MinecraftClient c,BlockPos p){return c.world.isChunkLoaded(p.getX()>>4,p.getZ()>>4)&&c.world.getBlockState(p).isFullCube(c.world,p)&&!c.world.getBlockState(p).isIn(net.minecraft.registry.tag.BlockTags.LEAVES)&&c.world.getFluidState(p).isEmpty()&&c.world.isSkyVisible(p.up())&&c.world.getBlockState(p.up()).getCollisionShape(c.world,p.up()).isEmpty();}
 private static void tick(MinecraftClient c){
  if(!XVisuals.ready()){STREAKS.clear();return;}
  STREAK_SETTINGS.sync(XVisuals.visualModule("realisticrain"),active());STREAKS.tick(c);
  shaders=externalShaders();if(world!=c.world||!active()){world=c.world;PUDDLES.clear();DROPS.clear();dropCredit=rain=0;failed=false;}
  if(!active()||c.player==null||c.isPaused())return;ticks++;var s=XVisuals.visualModule("realisticrain");rain=Storm.running()?Storm.rain():c.world.getRainGradient(1);
  var camera=c.gameRenderer.getCamera().getCameraPos();var eye=BlockPos.ofFloored(camera);
  if(!s.flag("puddles"))PUDDLES.clear();
  for(var it=PUDDLES.entrySet().iterator();it.hasNext();){var e=it.next();if(e.getKey().getSquaredDistance(eye)>24*24||!surface(c,e.getKey())){it.remove();continue;}double wet=RealisticRainMath.wetness(e.getValue(),rainAt(c,e.getKey().up())?rain:0);if(wet<=0)it.remove();else e.setValue(wet);}
  if(rain>.01)for(int i=0;i<6;i++){
   int x=eye.getX()+RANDOM.nextInt(25)-12,z=eye.getZ()+RANDOM.nextInt(25)-12;if(!c.world.isChunkLoaded(x>>4,z>>4))continue;
   var p=new BlockPos(x,c.world.getTopY(Heightmap.Type.MOTION_BLOCKING,x,z)-1,z);
   if(Math.abs(p.getY()-camera.y)>12||!surface(c,p)||!rainAt(c,p.up()))continue;
   if(s.flag("puddles")&&!PUDDLES.containsKey(p)&&PUDDLES.size()<64)PUDDLES.put(p,0d);

  }
  if(!s.flag("droplets")||c.player.isSubmergedInWater())DROPS.clear();
  for(var it=DROPS.iterator();it.hasNext();){var d=it.next();d.previousY=d.y;d.age++;d.y-=.0008+d.size*.04;if(d.age>=d.life||d.y<-.05)it.remove();}
  if(s.flag("droplets")&&!c.player.isSubmergedInWater()&&rainAt(c,eye)){
   double motion=Math.min(2,c.player.getVelocity().length()*5);dropCredit+=rain*s.number("dropletIntensity")*(1+motion)*.04;
   if(dropCredit>=1){dropCredit=0;if(DROPS.size()<16){var d=new Drop();d.x=.05+RANDOM.nextDouble()*.9;d.y=d.previousY=.3+RANDOM.nextDouble()*.65;d.size=.008+RANDOM.nextDouble()*.012;d.life=100+RANDOM.nextInt(100);DROPS.add(d);}}
  }else dropCredit=0;
 }
 private static void vec(double a,double b,double c,double d){DATA.putFloat((float)a).putFloat((float)b).putFloat((float)c).putFloat((float)d);}
 public static void render(ObjectAllocator pool){var c=MinecraftClient.getInstance();if(!active()||world!=c.world||failed||!CameraEnvironment.surface()||c.getFramebuffer().getDepthAttachment()==null||!Projection.copyWorldMatrix(VP))return;
  var s=XVisuals.visualModule("realisticrain");if(PUDDLES.isEmpty()&&DROPS.isEmpty()||s.number("opacity")<=0)return;
  var camera=c.gameRenderer.getCamera().getCameraPos();var patches=new ArrayList<>(PUDDLES.entrySet());patches.sort(Comparator.comparingDouble(e->e.getKey().getSquaredDistance(BlockPos.ofFloored(camera))));
  DATA.clear();INV.set(VP).invert().get(MATRIX);for(float f:MATRIX)DATA.putFloat(f);VP.get(MATRIX);for(float f:MATRIX)DATA.putFloat(f);
  vec(Math.min(32,patches.size()),DROPS.size(),s.number("opacity"),s.flag("reflections")?1:0);
  for(int i=0;i<32;i++){if(i<patches.size()){var e=patches.get(i);var p=e.getKey();vec(p.getX()+.5-camera.x,p.getY()+1-camera.y,p.getZ()+.5-camera.z,e.getValue());}else vec(0,0,0,0);}
  float delta=c.getRenderTickCounter().getTickProgress(false);for(int i=0;i<16;i++){if(i<DROPS.size()){var d=DROPS.get(i);vec(d.x,d.previousY+(d.y-d.previousY)*delta,d.size,RealisticRainMath.dropFade(d.age+delta,d.life));}else vec(0,0,0,0);}DATA.flip();
  try{var effect=c.getShaderLoader().loadPostEffect(Identifier.of("xvisuals","realistic_rain"),DefaultFramebufferSet.MAIN_ONLY);if(effect==null)return;pl.xvisuals.rendering.shaders.PostEffectUniforms.upload(effect,"RainConfig",DATA);effect.render(c.getFramebuffer(),pool);}catch(RuntimeException ex){failed=true;org.slf4j.LoggerFactory.getLogger("VisualClient").warn("Realistic Rain unavailable for current pipeline",ex);}
 }
 private RealisticRain(){}
}
