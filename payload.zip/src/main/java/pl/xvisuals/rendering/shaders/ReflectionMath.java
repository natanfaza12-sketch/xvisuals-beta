package pl.xvisuals.rendering.shaders;
public final class ReflectionMath {
 public static int material(String id){
  if(id.equals("minecraft:water"))return 1;
  if(id.equals("minecraft:ice")||id.equals("minecraft:packed_ice")||id.equals("minecraft:blue_ice"))return 2;
  if(id.equals("minecraft:glass")||id.endsWith("_stained_glass")||id.equals("minecraft:tinted_glass"))return 3;
  if(id.equals("minecraft:iron_block")||id.equals("minecraft:gold_block")||id.equals("minecraft:copper_block")||id.equals("minecraft:cut_copper")||id.equals("minecraft:waxed_copper_block")||id.equals("minecraft:waxed_cut_copper") )return 4;
  if(id.equals("minecraft:polished_deepslate")||id.equals("minecraft:polished_blackstone")||id.equals("minecraft:polished_andesite")||id.equals("minecraft:polished_diorite")||id.equals("minecraft:polished_granite"))return 5;
  return 0;
 }
 public static int quality(String quality){return switch(quality){case "Low"->0;case "High"->2;case "Ultra"->3;default->1;};}
 public static int steps(int q){return new int[]{12,20,32,48}[Math.clamp(q,0,3)];}
 public static boolean visibleSurface(int material,boolean exposed,boolean fullCube){return material>0&&exposed&&(material==1||fullCube);}
 private ReflectionMath(){}
}
