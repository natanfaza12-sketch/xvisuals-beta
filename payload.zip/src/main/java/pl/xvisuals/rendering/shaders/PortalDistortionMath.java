package pl.xvisuals.rendering.shaders;

public final class PortalDistortionMath {
  public static double proximity(double distance,double radius) {
    double t=Math.clamp(1-distance/Math.max(.01,radius),0,1);return t*t*(3-2*t);
  }
  public static double approach(double current,double target,boolean smooth) {
    return smooth?current+(target-current)*.18:target;
  }
  private PortalDistortionMath() {}
}
