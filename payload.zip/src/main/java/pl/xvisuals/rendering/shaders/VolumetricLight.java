package pl.xvisuals.rendering.shaders;
import pl.xvisuals.XVisuals;
import pl.xvisuals.rendering.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.DefaultFramebufferSet;
import net.minecraft.client.util.memory.ObjectAllocator;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import java.nio.*;
/** Conservative screen-space volumetric scattering; unknown occluders never emit light. */
public final class VolumetricLight {
 private static final ByteBuffer DATA=ByteBuffer.allocateDirect(192).order(ByteOrder.nativeOrder());
 private static final Matrix4f VP=new Matrix4f(),INV=new Matrix4f();private static final float[] MATRIX=new float[16];
 private static float sun,moon,rain;private static boolean captured,failed;private static Object world;private static long last;private static double visibility;
 public static void beginFrame(){captured=false;}
 public static void capture(float sunAngle,float moonAngle,float weatherAlpha){sun=sunAngle;moon=moonAngle;rain=1-weatherAlpha;captured=true;}
 private static boolean externalShaders(){
  if(!net.fabricmc.loader.api.FabricLoader.getInstance().isModLoaded("iris"))return false;
  try{var api=Class.forName("net.irisshaders.iris.api.v0.IrisApi");return (boolean)api.getMethod("isShaderPackInUse").invoke(api.getMethod("getInstance").invoke(null));}catch(ReflectiveOperationException|LinkageError ex){return true;}
 }
 private static void vec(double a,double b,double c,double d){DATA.putFloat((float)a).putFloat((float)b).putFloat((float)c).putFloat((float)d);}
 public static void render(ObjectAllocator pool){
  var c=MinecraftClient.getInstance();long now=System.nanoTime();double dt=last==0?0:(now-last)*1e-9;last=now;
  if(world!=c.world){world=c.world;visibility=0;failed=false;}
  if(!XVisuals.ready()||c.world==null||!XVisuals.visualModule("volumetriclight").enabled){visibility=0;failed=false;return;}
  if(failed||!captured||!CameraEnvironment.surface()||externalShaders()||c.getFramebuffer().getDepthAttachment()==null||!Projection.copyWorldMatrix(VP)){visibility=0;return;}
  var s=XVisuals.visualModule("volumetriclight");double x=-Math.sin(sun),y=Math.cos(sun),power=1;
  if(y<=0&&!s.flag("sunOnly")){x=Math.sin(moon);y=-Math.cos(moon);power=.16;}
  double target=VolumetricLightMath.visibility(y,rain)*power;visibility=VolumetricLightMath.approach(visibility,target,dt);
  if(visibility<.001||s.number("intensity")<=0||s.number("density")<=0)return;
  DATA.clear();INV.set(VP).invert().get(MATRIX);for(float f:MATRIX)DATA.putFloat(f);VP.get(MATRIX);for(float f:MATRIX)DATA.putFloat(f);
  vec(x,y,0,visibility);vec(s.number("intensity"),s.number("density"),s.number("length"),s.number("distance"));int color=s.color("color");
  vec(((color>>16)&255)/255d,((color>>8)&255)/255d,(color&255)/255d,s.flag("smooth")?1:0);vec(VolumetricLightMath.samples(s.text("quality")),6,0,0);DATA.flip();
  try{String quality=s.text("quality").toLowerCase(java.util.Locale.ROOT);var effect=c.getShaderLoader().loadPostEffect(Identifier.of("xvisuals","volumetric_light_"+quality),DefaultFramebufferSet.MAIN_ONLY);if(effect==null)return;
   PostEffectUniforms.upload(effect,"LightConfig",DATA);effect.render(c.getFramebuffer(),pool);
  }catch(RuntimeException ex){failed=true;org.slf4j.LoggerFactory.getLogger("VisualClient").warn("Volumetric Light unavailable for current pipeline",ex);}
 }
 private VolumetricLight(){}
}
