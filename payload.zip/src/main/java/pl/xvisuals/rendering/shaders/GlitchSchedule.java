package pl.xvisuals.rendering.shaders;
import java.util.Random;
/** A bounded, deterministic-testable burst scheduler. No frame-dependent random sampling. */
public final class GlitchSchedule {
 private final Random random;
 private double age=-1,duration=.45,wait=-1,boost=1;
 private int pattern;
 public GlitchSchedule(long seed){random=new Random(seed);}
 public void reset(){age=-1;wait=-1;boost=1;pattern=0;}
 public void tick(double dt,double frequency,double seconds,boolean randomized){
  dt=Math.clamp(dt,0,.1);
  if(age>=0){age+=dt;if(age>=duration){age=-1;wait=interval(frequency,randomized);}return;}
  if(wait<0)wait=interval(frequency,randomized);
  wait-=dt;
  if(wait<=0){duration=Math.clamp(seconds,.15,1.5);age=0;pattern=randomized?random.nextInt(10000):17;boost=randomized&&random.nextDouble()<.12?1.35:1;}
 }
 private double interval(double frequency,boolean randomized){return 60/Math.clamp(frequency,1,30)*(randomized?.7+random.nextDouble()*.6:1);}
 public double amount(double fraction){if(age<0)return 0;double t=Math.clamp((age+Math.clamp(fraction,0,.05))/duration,0,1);double rise=smooth(t/.25),fall=smooth((1-t)/.4);return rise*fall*boost;}
 private double smooth(double t){t=Math.clamp(t,0,1);return t*t*(3-2*t);}
 public double phase(double fraction){return age<0?0:Math.clamp((age+fraction)/duration,0,1);}
 public int pattern(){return pattern;}
}
