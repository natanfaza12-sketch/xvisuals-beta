package pl.xvisuals.rendering.shaders;

import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

public final class BackdropPipeline {
  public static final RenderPipeline BLURRED =
      RenderPipeline.builder()
          .withLocation(Identifier.of("xvisuals", "pipeline/backdrop"))
          .withVertexShader(Identifier.of("xvisuals", "core/backdrop"))
          .withFragmentShader(Identifier.of("xvisuals", "core/backdrop"))
          .withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
          .withUniform("Projection", UniformType.UNIFORM_BUFFER)
          .withSampler("Sampler0")
          .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, VertexFormat.DrawMode.QUADS)
          .withBlend(BlendFunction.TRANSLUCENT)
          .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
          .withDepthWrite(false)
          .withCull(false)
          .build();

  private BackdropPipeline() {}
}
