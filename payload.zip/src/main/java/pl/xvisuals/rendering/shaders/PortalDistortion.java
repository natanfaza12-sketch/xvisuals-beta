package pl.xvisuals.rendering.shaders;

import pl.xvisuals.XVisuals;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.DefaultFramebufferSet;
import net.minecraft.client.util.memory.ObjectAllocator;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.*;
import net.minecraft.block.Blocks;
import java.nio.*;
import java.util.*;

/** Bounded local portal search and world-only post process, before hand/HUD rendering. */
public final class PortalDistortion {
  private static final Identifier ID=Identifier.of("xvisuals","portal_distortion");
  private static final Set<BlockPos> PORTALS=new HashSet<>();
  private static final ByteBuffer DATA=ByteBuffer.allocateDirect(48).order(ByteOrder.nativeOrder());
  private static Object world;
  private static BlockPos origin,nearest;
  private static int cursor,ticks,diameter;
  private static double strength,previous;
  private static boolean shaders,failed;
  public static void init(){ClientTickEvents.END_CLIENT_TICK.register(PortalDistortion::tick);}
  private static boolean enabled(){return XVisuals.ready()&&XVisuals.visualModule("portaldistortion").enabled;}
  private static void reset(){PORTALS.clear();origin=nearest=null;cursor=0;strength=previous=0;failed=false;shaders=FabricLoader.getInstance().isModLoaded("iris");}
  private static void tick(MinecraftClient c) {
    if(world!=c.world){world=c.world;reset();}
    if(!enabled()||c.world==null||c.player==null){reset();return;}
    if(c.isPaused())return;
    ticks++;previous=strength;
    if(ticks%20==1) {
      shaders=false;
      if(FabricLoader.getInstance().isModLoaded("iris"))try {
        var api=Class.forName("net.irisshaders.iris.api.v0.IrisApi");
        shaders=(boolean)api.getMethod("isShaderPackInUse").invoke(api.getMethod("getInstance").invoke(null));
      }catch(ReflectiveOperationException|LinkageError ex){shaders=true;}
    }
    var s=XVisuals.visualModule("portaldistortion");var pos=c.player.getEntityPos();
    int radius=(int)Math.ceil(s.number("radius")),nextDiameter=radius*2+1;
    if(origin==null||diameter!=nextDiameter||origin.getSquaredDistance(c.player.getBlockPos())>16||cursor>=diameter*diameter*diameter){origin=c.player.getBlockPos();cursor=0;diameter=nextDiameter;}
    PORTALS.removeIf(p->p.getSquaredDistance(c.player.getBlockPos())>(radius+2)*(radius+2)||!c.world.isChunkLoaded(p.getX()>>4,p.getZ()>>4)||!c.world.getBlockState(p).isOf(Blocks.NETHER_PORTAL));
    int budget=s.text("quality").equals("Low")?256:s.text("quality").equals("High")?1024:512;
    for(int n=0;n<budget&&cursor<diameter*diameter*diameter;n++,cursor++) {
      var p=origin.add(cursor%diameter-radius,(cursor/diameter)%diameter-radius,cursor/(diameter*diameter)-radius);
      if(PORTALS.size()<256&&c.world.isChunkLoaded(p.getX()>>4,p.getZ()>>4)&&c.world.getBlockState(p).isOf(Blocks.NETHER_PORTAL))PORTALS.add(p);
    }
    nearest=null;double distance=Double.MAX_VALUE;
    for(var p:PORTALS){double d=Vec3d.ofCenter(p).distanceTo(pos);if(d<distance){nearest=p;distance=d;}}
    double target=PortalDistortionMath.proximity(Math.max(0,distance-.5),s.number("radius"))*s.number("intensity");
    // Vanilla owns nausea/portal entry. Never stack distortion over its transition.
    if(c.player.nauseaIntensity>.001f||c.player.isSpectator())target=0;
    strength=PortalDistortionMath.approach(strength,target,s.flag("smooth"));
    if(nearest!=null&&strength>.01&&s.flag("particles")&&ticks%4==0&&c.player.nauseaIntensity<=.001f) {
      var random=c.world.random;
      c.world.addParticleClient(net.minecraft.particle.ParticleTypes.PORTAL,nearest.getX()+random.nextDouble(),nearest.getY()+random.nextDouble(),nearest.getZ()+random.nextDouble(),
          (random.nextDouble()-.5)*.1,(random.nextDouble()-.5)*.1,(random.nextDouble()-.5)*.1);
    }
  }
  public static void render(ObjectAllocator pool) {
    var c=MinecraftClient.getInstance();
    if(!enabled()||c.world==null||world!=c.world||c.player==null||c.currentScreen!=null||pl.xvisuals.rendering.ShaderPackSupport.active()||failed||c.player.nauseaIntensity>.001f||c.getFramebuffer().getDepthAttachment()==null)return;
    float delta=c.getRenderTickCounter().getTickProgress(false);
    float amount=(float)(previous+(strength-previous)*delta);if(amount<.001)return;
    var s=XVisuals.visualModule("portaldistortion");
    try {
      var effect=c.getShaderLoader().loadPostEffect(ID,DefaultFramebufferSet.MAIN_ONLY);if(effect==null)return;
      DATA.clear();DATA.putFloat(amount).putFloat((ticks%12000+delta)/20f).putFloat(s.flag("ripples")?1:0).putFloat(s.flag("chromatic")?1:0);
      DATA.putFloat(s.flag("glow")?1:0).putFloat(s.flag("edges")?1:0).putFloat(s.text("quality").equals("Low")?0:s.text("quality").equals("High")?2:1).putFloat(0);
      DATA.putFloat(0).putFloat(0).putFloat(0).putFloat(0).flip();
      PostEffectUniforms.upload(effect,"PortalConfig",DATA);
      effect.render(c.getFramebuffer(),pool);
    }catch(RuntimeException ex){failed=true;org.slf4j.LoggerFactory.getLogger("VisualClient").warn("Portal distortion disabled for this world: incompatible post-processing",ex);}
  }
  private PortalDistortion(){}
}
