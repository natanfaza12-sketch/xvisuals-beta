package pl.xvisuals.rendering.shaders;
import pl.xvisuals.XVisuals;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.DefaultFramebufferSet;
import net.minecraft.client.util.memory.ObjectAllocator;
import net.minecraft.util.Identifier;
import java.nio.*;

/** GPU luminance metering and persistent 1x1 exposure history; no CPU readback or gamma writes. */
public final class EyeAdaptation {
 private static final Identifier ID=Identifier.of("xvisuals","eye_adaptation");
 private static final ByteBuffer DATA=ByteBuffer.allocateDirect(48).order(ByteOrder.nativeOrder());
 private static Object world;private static boolean shaders,failed,reset=true;private static long frame;private static int ticks;
 public static void init(){ClientTickEvents.END_CLIENT_TICK.register(EyeAdaptation::tick);}
 private static boolean enabled(){return XVisuals.ready()&&XVisuals.visualModule("eyeadaptation").enabled;}
 private static void tick(MinecraftClient c){
  if(world!=c.world||!enabled()){world=c.world;frame=0;reset=true;failed=false;shaders=FabricLoader.getInstance().isModLoaded("iris");}
  if(!enabled()||c.world==null)return;
  if(ticks++%20==0){shaders=false;if(FabricLoader.getInstance().isModLoaded("iris"))try{var api=Class.forName("net.irisshaders.iris.api.v0.IrisApi");shaders=(boolean)api.getMethod("isShaderPackInUse").invoke(api.getMethod("getInstance").invoke(null));}catch(ReflectiveOperationException|LinkageError ex){shaders=true;}}
  if(shaders){frame=0;reset=true;}
 }
 private static void vec(double a,double b,double c,double d){DATA.putFloat((float)a).putFloat((float)b).putFloat((float)c).putFloat((float)d);}
 public static void render(ObjectAllocator pool){
  var c=MinecraftClient.getInstance();if(!enabled()||world!=c.world||c.world==null||c.player==null||c.currentScreen!=null||pl.xvisuals.rendering.ShaderPackSupport.active()||failed){frame=0;return;}
  var s=XVisuals.visualModule("eyeadaptation");if(s.number("strength")<=0||!s.flag("darkness")&&!s.flag("light")){frame=0;reset=true;return;}
  long now=System.nanoTime();double dt=frame==0||c.isPaused()?0:Math.min(.1,(now-frame)/1e9);frame=now;
  DATA.clear();vec(dt,s.number("speed"),s.number("minimum"),s.number("maximum"));
  vec(s.number("strength"),s.flag("darkness")?1:0,s.flag("light")?1:0,s.flag("smooth")?1:0);
  vec(s.flag("cinematic")?1:0,reset?1:0,0,0);DATA.flip();
  try{var effect=c.getShaderLoader().loadPostEffect(ID,DefaultFramebufferSet.MAIN_ONLY);if(effect==null)return;
   PostEffectUniforms.upload(effect,"ExposureConfig",DATA);effect.render(c.getFramebuffer(),pool);reset=false;
  }catch(RuntimeException ex){failed=true;org.slf4j.LoggerFactory.getLogger("VisualClient").warn("Eye Adaptation disabled for incompatible post-processing",ex);}
 }
 private EyeAdaptation(){}
}
