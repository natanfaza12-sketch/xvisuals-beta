package pl.xvisuals.rendering.shaders;
public final class FocusMath {
 public static double approach(double current,double target,double speed,double dt,boolean smooth){target=Math.clamp(target,.1,512);return smooth?current+(target-current)*(1-Math.exp(-Math.clamp(speed,.5,15)*Math.clamp(dt,0,.1))):target;}
 public static double coc(double depth,double focus,double range,boolean foreground,boolean background){double delta=depth-focus;if(delta<0&&!foreground||delta>=0&&!background)return 0;double t=Math.clamp((Math.abs(delta)-range*.5)/Math.max(.01,range*2),0,1);return t*t*(3-2*t);}
 public static int samples(String quality){return quality.equals("Low")?8:quality.equals("High")?24:16;}
 private FocusMath(){}
}
