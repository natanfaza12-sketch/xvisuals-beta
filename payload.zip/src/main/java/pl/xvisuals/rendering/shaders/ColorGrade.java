package pl.xvisuals.rendering.shaders;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;
import pl.xvisuals.XVisuals;
import pl.xvisuals.mixins.*;
import java.nio.*;
import java.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.*;
import net.minecraft.client.render.DefaultFramebufferSet;
import net.minecraft.client.util.memory.ObjectAllocator;
import net.minecraft.util.Identifier;

public final class ColorGrade {
  private static final Identifier ID = Identifier.of("xvisuals", "grading");
  private static final Map<PostEffectProcessor, Integer> REVISIONS = new WeakHashMap<>();
  private static final ByteBuffer DATA =
      ByteBuffer.allocateDirect(48).order(ByteOrder.nativeOrder());

  public static void render(ObjectAllocator pool) {
    if (pl.xvisuals.rendering.ShaderPackSupport.active()) return;
    var c = MinecraftClient.getInstance();
    var s = XVisuals.config().module("grading");
    if (!s.enabled || c.world == null) return;
    PostEffectProcessor effect =
        c.getShaderLoader().loadPostEffect(ID, DefaultFramebufferSet.MAIN_ONLY);
    if (effect == null) return;
    int hash = s.values.hashCode();
    if (!Objects.equals(REVISIONS.get(effect), hash)) {
      int tint = s.color("tint");
      DATA.clear();
      DATA.putFloat((float) s.number("saturation"))
          .putFloat((float) s.number("contrast"))
          .putFloat((float) s.number("exposure"))
          .putFloat((float) s.number("vignette"));
      DATA.putFloat(((tint >> 16) & 255) / 255f)
          .putFloat(((tint >> 8) & 255) / 255f)
          .putFloat((tint & 255) / 255f)
          .putFloat((float) s.number("strength"));
      DATA.putFloat((float) s.number("aberration"))
          .putFloat((float) s.number("sharpen"))
          .putFloat((float) s.number("grain"))
          .putFloat(0)
          .flip();
      for (var pass : ((PostProcessorAccessor) effect).visuals$passes()) {
        var map = ((PostPassAccessor) pass).visuals$uniforms();
        var old = map.get("GradeConfig");
        if (old == null) continue;
        old.close();
        map.put(
            "GradeConfig",
            RenderSystem.getDevice()
                .createBuffer(() -> "X Visuals color grade", GpuBuffer.USAGE_UNIFORM, DATA));
        DATA.rewind();
      }
      REVISIONS.put(effect, hash);
    }
    effect.render(c.getFramebuffer(), pool);
  }

  private ColorGrade() {}
}
