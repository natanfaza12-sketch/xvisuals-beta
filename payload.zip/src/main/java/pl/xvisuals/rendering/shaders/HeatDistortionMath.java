package pl.xvisuals.rendering.shaders;
public final class HeatDistortionMath {
 public static int kind(String id,boolean lit){return switch(id){case "minecraft:lava"->1;case "minecraft:fire","minecraft:soul_fire"->2;case "minecraft:magma_block"->3;case "minecraft:campfire","minecraft:soul_campfire"->lit?4:0;case "minecraft:furnace","minecraft:blast_furnace","minecraft:smoker"->lit?2:0;default->0;};}
 public static double strength(int kind,int area){double base=switch(kind){case 1->1;case 2->.42;case 3->.32;case 4->.55;default->0;};return Math.min(2,base*(1+Math.log(Math.max(1,area))*.24));}
 public static double visibleLength(double start,double end,double scene){return Math.max(0,Math.min(end,scene)-Math.max(0,start));}
 public static double fade(double distance,double range,boolean enabled){return enabled?Math.clamp((range-distance)/(range*.4),0,1):1;}
 public static int volumes(String quality){return quality.equals("Low")?8:quality.equals("High")?24:16;}
 public static boolean admit(double candidateDistance,double furthestDistance,boolean hasRoom){return hasRoom||candidateDistance<furthestDistance;}
 private HeatDistortionMath(){}
}
