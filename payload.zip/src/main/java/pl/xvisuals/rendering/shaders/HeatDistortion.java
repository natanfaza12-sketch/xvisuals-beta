package pl.xvisuals.rendering.shaders;

import pl.xvisuals.XVisuals;
import pl.xvisuals.rendering.Projection;
import pl.xvisuals.rendering.CameraEnvironment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.DefaultFramebufferSet;
import net.minecraft.client.util.memory.ObjectAllocator;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.*;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import java.nio.*;
import java.util.*;

/** Loaded-block discovery and source-relative GPU refraction. No world/entity mutations. */
public final class HeatDistortion {
 private static final Identifier ID=Identifier.of("xvisuals","heat_distortion");
 private static final Map<BlockPos,Cell> CELLS=new HashMap<>();private static final List<Volume> VOLUMES=new ArrayList<>();
 private record Cell(int kind,double top,double height,int born){}
 private record Volume(Box box,double strength,double phase){}
 private record Visible(Volume volume,float minX,float minY,float maxX,float maxY){}
 private static final ByteBuffer DATA=ByteBuffer.allocateDirect(1248).order(ByteOrder.nativeOrder());
 private static final Matrix4f MATRIX=new Matrix4f(),INVERSE=new Matrix4f();private static final Vector4f POINT=new Vector4f();
 private static final int[] NEAR_SCAN=offsets(3);
 private static Object world;private static BlockPos origin;private static int[] scan=new int[0];private static int cursor,nearCursor,ticks,range;private static boolean shaders,failed;private static double clock;
 public static void init(){ClientTickEvents.END_CLIENT_TICK.register(HeatDistortion::tick);}
 private static boolean enabled(){return XVisuals.ready()&&pl.xvisuals.rendering.LavafallMistMath.haze(XVisuals.visualModule("heatdistortion").enabled,pl.xvisuals.rendering.LavafallMist.heatHaze())!=0;}
 private static final pl.xvisuals.config.VisualConfig.ModuleState MIST_HEAT=new pl.xvisuals.config.VisualConfig.ModuleState();
 private static pl.xvisuals.config.VisualConfig.ModuleState settings(){
  var own=XVisuals.visualModule("heatdistortion");if(own.enabled)return own;
  var mist=XVisuals.visualModule("lavafallmist");
  MIST_HEAT.values.put("intensity",.25);MIST_HEAT.values.put("radius",.6);MIST_HEAT.values.put("speed",1d);
  MIST_HEAT.values.put("height",Math.min(6,mist.number("height")));MIST_HEAT.values.put("quality",mist.text("quality"));
  MIST_HEAT.values.put("rising",true);MIST_HEAT.values.put("fade",true);return MIST_HEAT;
 }
 private static void reset(){CELLS.clear();VOLUMES.clear();origin=null;cursor=0;failed=false;clock=0;}
 private static boolean selected(int kind){var s=XVisuals.visualModule("heatdistortion");return kind==1&&pl.xvisuals.rendering.LavafallMist.heatHaze()||s.enabled&&switch(kind){case 1->s.flag("lava");case 2->s.flag("fire");case 3->s.flag("magma");case 4->s.flag("campfire");default->false;};}
 private static Cell cell(MinecraftClient c,BlockPos p,int born){
  if(!c.world.isChunkLoaded(p.getX()>>4,p.getZ()>>4))return null;
  var state=c.world.getBlockState(p);int kind=HeatDistortionMath.kind(Registries.BLOCK.getId(state.getBlock()).toString(),state.contains(Properties.LIT)&&state.get(Properties.LIT));
  if(!selected(kind))return null;
  double top=p.getY()+1;
  if(kind==1){if(c.world.getFluidState(p.up()).isIn(FluidTags.LAVA))return null;top=p.getY()+state.getFluidState().getHeight(c.world,p);}
  if(kind==4)top=p.getY()+.45;
  if(kind==2&&state.getCollisionShape(c.world,p).isEmpty())top=p.getY()+.12;
  double height=settings().number("height");
  // Heat cannot continue through a roof, slab or the block directly above its source.
  for(int y=(int)Math.floor(top);y<=Math.ceil(top+height);y++){
   var above=new BlockPos(p.getX(),y,p.getZ());var shape=c.world.getBlockState(above).getCollisionShape(c.world,above);
   if(!shape.isEmpty()&&y+shape.getMax(Direction.Axis.Y)>top+.02){height=Math.min(height,Math.max(0,y+shape.getMin(Direction.Axis.Y)-top));break;}
  }
  return height<.12?null:new Cell(kind,top,height,born);
 }
 private static int[] offsets(int radius){
  int[] values=new int[(radius*2+1)*(radius*2+1)*21];int index=0;
  for(int r=0;r<=radius;r++)for(int x=-r;x<=r;x++)for(int z=-r;z<=r;z++)if(Math.max(Math.abs(x),Math.abs(z))==r){
   for(int i=0;i<21;i++){int y=i==0?0:(i+1)/2*(i%2==1?-1:1);values[index++]=(x+32)|((z+32)<<7)|((y+16)<<14);}
  }
  return values;
 }
 private static void tick(MinecraftClient c){
  if(world!=c.world||!enabled()){world=c.world;reset();}
  if(!enabled()||c.world==null||c.player==null||c.isPaused())return;
  shaders=false;if(FabricLoader.getInstance().isModLoaded("iris"))try{var api=Class.forName("net.irisshaders.iris.api.v0.IrisApi");shaders=(boolean)api.getMethod("isShaderPackInUse").invoke(api.getMethod("getInstance").invoke(null));}catch(ReflectiveOperationException|LinkageError ex){shaders=true;}
  if(shaders){CELLS.clear();VOLUMES.clear();origin=null;return;}
  var s=settings();ticks++;clock+=.05*s.number("speed");int limit=HeatDistortionMath.volumes(s.text("quality")),radius=limit+8;
  var camera=BlockPos.ofFloored(c.gameRenderer.getCamera().getCameraPos());
  if(range!=radius||scan.length==0){range=radius;scan=offsets(radius);origin=null;}
  if(origin==null||origin.getSquaredDistance(camera)>16){
   if(origin==null||origin.getSquaredDistance(camera)>radius*radius){CELLS.clear();VOLUMES.clear();}
   else{CELLS.keySet().removeIf(p->p.getSquaredDistance(camera)>radius*radius);var nearest=new ArrayList<>(CELLS.keySet());nearest.sort(Comparator.comparingDouble(p->p.getSquaredDistance(camera)));for(int i=limit*24;i<nearest.size();i++)CELLS.remove(nearest.get(i));}
   origin=camera;cursor=0;
  }
  if(cursor>=scan.length)cursor=0;
  var farthest=new PriorityQueue<BlockPos>(Comparator.comparingDouble((BlockPos p)->p.getSquaredDistance(camera)).reversed());farthest.addAll(CELLS.keySet());
  for(int n=0;n<limit*32;n++){
   boolean local=n<limit*8;int packed;
   if(local){packed=NEAR_SCAN[nearCursor];nearCursor=(nearCursor+1)%NEAR_SCAN.length;}
   else{packed=scan[cursor];cursor=(cursor+1)%scan.length;}
   var p=(local?camera:origin).add((packed&127)-32,((packed>>14)&63)-16,((packed>>7)&127)-32);
   if(p.getSquaredDistance(camera)>radius*radius)continue;
   Cell old=CELLS.get(p),next=cell(c,p,old==null?ticks:old.born);
   if(next==null){CELLS.remove(p);continue;}
   if(old==null){
    while(!farthest.isEmpty()&&!CELLS.containsKey(farthest.peek()))farthest.poll();
    if(!HeatDistortionMath.admit(p.getSquaredDistance(camera),farthest.isEmpty()?Double.POSITIVE_INFINITY:farthest.peek().getSquaredDistance(camera),CELLS.size()<limit*32))continue;
    if(CELLS.size()>=limit*32)CELLS.remove(farthest.poll());
    farthest.add(p);
   }
   CELLS.put(p,next);
  }
  if(ticks%4!=0)return;
  for(var it=CELLS.entrySet().iterator();it.hasNext();){var e=it.next();Cell next=e.getKey().getSquaredDistance(camera)>radius*radius?null:cell(c,e.getKey(),e.getValue().born);if(next==null)it.remove();else e.setValue(next);}
  VOLUMES.clear();var positions=new ArrayList<>(CELLS.keySet());positions.sort(Comparator.comparingDouble(p->p.getSquaredDistance(camera)));var used=new HashSet<BlockPos>();
  for(var p:positions){if(VOLUMES.size()>=limit)break;if(used.contains(p))continue;var base=CELLS.get(p);int width=1,depth=1;
   if(base.kind==1||base.kind==3){while(width<8&&compatible(p.add(width,0,0),base,used))width++;boolean extend=true;
    while(depth<8&&extend){for(int x=0;x<width;x++)if(!compatible(p.add(x,0,depth),base,used)){extend=false;break;}if(extend)depth++;}
   }
   int born=ticks;for(int x=0;x<width;x++)for(int z=0;z<depth;z++){var pos=p.add(x,0,z);used.add(pos);born=Math.min(born,CELLS.get(pos).born);}
   double spread=s.number("radius"),fade=Math.clamp((ticks-born)/8d,0,1);
   var box=new Box(p.getX()-spread,base.top,p.getZ()-spread,p.getX()+width+spread,base.top+base.height,p.getZ()+depth+spread);
   VOLUMES.add(new Volume(box,HeatDistortionMath.strength(base.kind,width*depth)*fade,((p.asLong()*31)&65535)/65536d*6.28318));
  }
 }
 private static boolean compatible(BlockPos p,Cell base,Set<BlockPos> used){var next=CELLS.get(p);return next!=null&&!used.contains(p)&&next.kind==base.kind&&Math.abs(next.top-base.top)<.02&&Math.abs(next.height-base.height)<.02;}
 private static Visible visible(Volume v,Vec3d camera){float minX=Float.POSITIVE_INFINITY,minY=Float.POSITIVE_INFINITY,maxX=Float.NEGATIVE_INFINITY,maxY=Float.NEGATIVE_INFINITY;boolean front=false,back=false;
  for(int i=0;i<8;i++){var b=v.box;POINT.set((float)(((i&1)==0?b.minX:b.maxX)-camera.x),(float)(((i&2)==0?b.minY:b.maxY)-camera.y),(float)(((i&4)==0?b.minZ:b.maxZ)-camera.z),1);MATRIX.transform(POINT);if(POINT.w<=.01){back=true;continue;}front=true;float x=POINT.x/POINT.w*.5f+.5f,y=POINT.y/POINT.w*.5f+.5f;minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);}
  if(!front)return null;if(back)return new Visible(v,0,0,1,1);if(maxX<0||maxY<0||minX>1||minY>1)return null;return new Visible(v,Math.max(0,minX),Math.max(0,minY),Math.min(1,maxX),Math.min(1,maxY));
 }
 private static void vec(double a,double b,double c,double d){DATA.putFloat((float)a).putFloat((float)b).putFloat((float)c).putFloat((float)d);}
 public static void render(ObjectAllocator pool){
  var c=MinecraftClient.getInstance();if(!enabled()||world!=c.world||c.world==null||c.player==null||pl.xvisuals.rendering.ShaderPackSupport.active()||failed||VOLUMES.isEmpty()||!CameraEnvironment.surface()||c.getFramebuffer().getDepthAttachment()==null||!Projection.copyWorldMatrix(MATRIX))return;
  var s=settings();if(s.number("intensity")<=0)return;
  var camera=c.gameRenderer.getCamera().getCameraPos();var visible=new ArrayList<Visible>();for(var volume:VOLUMES){var v=visible(volume,camera);if(v!=null)visible.add(v);}if(visible.isEmpty())return;
  DATA.clear();float[] matrix=new float[16];INVERSE.set(MATRIX).invert().get(matrix);for(float f:matrix)DATA.putFloat(f);
  int samples=s.text("quality").equals("Low")?3:s.text("quality").equals("High")?7:5;
  vec(s.number("intensity"),clock+(c.isPaused()?0:c.getRenderTickCounter().getTickProgress(false)*.05*s.number("speed")),visible.size(),samples);
  vec(s.flag("rising")?1:0,s.flag("fade")?1:0,range,0);
  for(int i=0;i<24;i++){if(i<visible.size()){var v=visible.get(i).volume;var b=v.box;vec(b.minX-camera.x,b.minY-camera.y,b.minZ-camera.z,v.strength);vec(b.maxX-camera.x,b.maxY-camera.y,b.maxZ-camera.z,v.phase);}else{vec(0,0,0,0);vec(0,0,0,0);}}
  for(int i=0;i<24;i++){if(i<visible.size()){var v=visible.get(i);vec(v.minX,v.minY,v.maxX,v.maxY);}else vec(0,0,0,0);}DATA.flip();
  try{var effect=c.getShaderLoader().loadPostEffect(ID,DefaultFramebufferSet.MAIN_ONLY);if(effect==null)return;
   PostEffectUniforms.upload(effect,"HeatConfig",DATA);effect.render(c.getFramebuffer(),pool);
  }catch(RuntimeException ex){failed=true;org.slf4j.LoggerFactory.getLogger("VisualClient").warn("Heat Distortion disabled for incompatible rendering pipeline",ex);}
 }
 private HeatDistortion(){}
}
