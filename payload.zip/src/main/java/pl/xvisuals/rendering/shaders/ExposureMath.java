package pl.xvisuals.rendering.shaders;
public final class ExposureMath {
 public static double target(double luminance,double minimum,double maximum,double strength,boolean darkness,boolean light){
  double ev=Math.log(.18/Math.max(1./4096,luminance))/Math.log(2);
  if(ev>0&&!darkness||ev<0&&!light)return 0;
  return Math.clamp(ev,Math.log(minimum)/Math.log(2),Math.log(maximum)/Math.log(2))*strength;
 }
 public static double approach(double current,double target,double speed,double dt,boolean smooth,boolean cinematic){
  if(!smooth)return target;
  double rate=speed*(target>current?.35:1.7)*(cinematic?.65:1);
  return current+(target-current)*(1-Math.exp(-rate*Math.clamp(dt,0,.1)));
 }
 private ExposureMath(){}
}
