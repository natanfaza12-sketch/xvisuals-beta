package pl.xvisuals.rendering.shaders;
import pl.xvisuals.XVisuals;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.DefaultFramebufferSet;
import net.minecraft.client.util.memory.ObjectAllocator;
import net.minecraft.util.Identifier;
import java.nio.*;

public final class RealityGlitch {
 private static final Identifier ID=Identifier.of("xvisuals","reality_glitch");
 private static final ByteBuffer DATA=ByteBuffer.allocateDirect(64).order(ByteOrder.nativeOrder());
 private static final GlitchSchedule CLOCK=new GlitchSchedule(System.nanoTime());
 private static Object world;private static boolean shaders,failed;private static int ticks;
 public static void init(){ClientTickEvents.END_CLIENT_TICK.register(RealityGlitch::tick);}
 private static boolean enabled(){return XVisuals.ready()&&XVisuals.visualModule("realityglitch").enabled;}
 private static void tick(MinecraftClient c){
  if(world!=c.world||!enabled()){world=c.world;CLOCK.reset();failed=false;shaders=FabricLoader.getInstance().isModLoaded("iris");}
  if(!enabled()||c.world==null||c.player==null||c.isPaused()||c.currentScreen!=null)return;
  if(ticks++%20==0){shaders=false;if(FabricLoader.getInstance().isModLoaded("iris"))try{var api=Class.forName("net.irisshaders.iris.api.v0.IrisApi");shaders=(boolean)api.getMethod("isShaderPackInUse").invoke(api.getMethod("getInstance").invoke(null));}catch(ReflectiveOperationException|LinkageError ex){shaders=true;}}
  var s=XVisuals.visualModule("realityglitch");
  if(shaders||c.player.nauseaIntensity>.001f){CLOCK.reset();return;}
  CLOCK.tick(.05,s.number("frequency"),s.number("duration"),s.flag("random"));
 }
 private static void vec(double a,double b,double c,double d){DATA.putFloat((float)a).putFloat((float)b).putFloat((float)c).putFloat((float)d);}
 public static void render(ObjectAllocator pool){
  var c=MinecraftClient.getInstance();if(!enabled()||c.world==null||world!=c.world||c.player==null||c.currentScreen!=null||pl.xvisuals.rendering.ShaderPackSupport.active()||failed||c.player.nauseaIntensity>.001f)return;
  var s=XVisuals.visualModule("realityglitch");double fraction=c.isPaused()?0:c.getRenderTickCounter().getTickProgress(false)*.05;
  double amount=Math.min(1,CLOCK.amount(fraction)*s.number("intensity"));if(amount<.001)return;
  if(!s.flag("chromatic")&&!s.flag("rgb")&&!s.flag("scanlines")&&!s.flag("flicker")&&!s.flag("distortion"))return;
  int color=s.color("color");DATA.clear();
  vec(amount,CLOCK.phase(fraction),CLOCK.pattern(),s.flag("chromatic")?1:0);
  vec(s.flag("rgb")?1:0,s.flag("scanlines")?1:0,s.flag("flicker")?1:0,s.flag("distortion")?1:0);
  vec(((color>>16)&255)/255d,((color>>8)&255)/255d,(color&255)/255d,0);vec(0,0,0,0);DATA.flip();
  try{var effect=c.getShaderLoader().loadPostEffect(ID,DefaultFramebufferSet.MAIN_ONLY);if(effect==null)return;
   PostEffectUniforms.upload(effect,"GlitchConfig",DATA);effect.render(c.getFramebuffer(),pool);
  }catch(RuntimeException ex){failed=true;org.slf4j.LoggerFactory.getLogger("VisualClient").warn("Reality Glitch disabled for incompatible post-processing",ex);}
 }
 private RealityGlitch(){}
}
