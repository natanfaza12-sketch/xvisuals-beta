package pl.xvisuals.rendering.shaders;

import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.gui.*;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.TextureSetup;
import org.joml.Matrix3x2f;

/** One anti-aliased signed-distance quad per shape; a whole particle field is one GUI state. */
public final class SdfRenderer {
  private static final VertexFormat FORMAT =
      VertexFormat.builder()
          .add("Position", VertexFormatElement.POSITION)
          .add("Color", VertexFormatElement.COLOR)
          .add("UV0", VertexFormatElement.UV0)
          .add("UV1", VertexFormatElement.UV1)
          .add("UV2", VertexFormatElement.UV2)
          .build();
  public static final RenderPipeline PIPELINE =
      RenderPipeline.builder()
          .withLocation(net.minecraft.util.Identifier.of("xvisuals", "pipeline/material"))
          .withVertexShader(net.minecraft.util.Identifier.of("xvisuals", "core/gui_sdf"))
          .withFragmentShader(net.minecraft.util.Identifier.of("xvisuals", "core/gui_sdf"))
          .withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
          .withUniform("Projection", UniformType.UNIFORM_BUFFER)
          .withVertexFormat(FORMAT, VertexFormat.DrawMode.QUADS)
          .withBlend(BlendFunction.TRANSLUCENT)
          .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
          .withDepthWrite(false)
          .withCull(false)
          .build();

  public static void rect(
      DrawContext g, float x, float y, float w, float h, float radius, int color, int material) {
    gradient(g, x, y, w, h, radius, color, color, color, color, material);
  }

  /** Four corner colors interpolate on the GPU: one quad, including rounded clipping. */
  public static void gradient(DrawContext g, float x, float y, float w, float h,
      float radius, int tl, int tr, int bl, int br, int material) {
    int color = tl | tr | bl | br;
    if (w <= 0 || h <= 0 || (color >>> 24) == 0) return;
    GuiAccess access = (GuiAccess) g;
    Matrix3x2f pose = new Matrix3x2f(g.getMatrices());
    ScreenRect bounds =
        new ScreenRect((int) x - 1, (int) y - 1, (int) Math.ceil(w) + 2, (int) Math.ceil(h) + 2)
            .transformEachVertex(pose);
    if (access.visuals$clip() != null) {
      bounds = bounds.intersection(access.visuals$clip());
      if (bounds == null) return;
    }
    access
        .visuals$state()
        .addSimpleElement(
            new Quad(pose, x, y, w, h, radius, tl, tr, bl, br, material, access.visuals$clip(), bounds));
  }

  private record Quad(
      Matrix3x2f pose,
      float x,
      float y,
      float w,
      float h,
      float radius,
      int color,
      int topRight,
      int bottomLeft,
      int bottomRight,
      int material,
      ScreenRect scissorArea,
      ScreenRect bounds)
      implements SimpleGuiElementRenderState {
    public RenderPipeline pipeline() {
      return PIPELINE;
    }

    public TextureSetup textureSetup() {
      return TextureSetup.empty();
    }

    public void setupVertices(VertexConsumer v) {
      int param = material * 1024;
      vertex(v, pose, x, y, 0, 0, w, h, radius, color, param);
      vertex(v, pose, x, y + h, 0, 1, w, h, radius, bottomLeft, param);
      vertex(v, pose, x + w, y + h, 1, 1, w, h, radius, bottomRight, param);
      vertex(v, pose, x + w, y, 1, 0, w, h, radius, topRight, param);
    }
  }

  public static final class Batch implements SimpleGuiElementRenderState {
    private final float[] data;
    private final int[] colors;
    private int count;
    private ScreenRect bounds;

    public Batch(int capacity) {
      data = new float[capacity * 8];
      colors = new int[capacity];
    }

    public void clear() {
      count = 0;
    }

    public void add(float x, float y, float w, float h, float mode, float rotation, int color) {
      add(x, y, w, h, mode, rotation, color, (float) pl.xvisuals.rendering.Quality.glow());
    }

    public void add(
        float x, float y, float w, float h, float mode, float rotation, int color, float glow) {
      if (count >= colors.length) return;
      int i = count * 8;
      data[i] = x;
      data[i + 1] = y;
      data[i + 2] = w;
      data[i + 3] = h;
      data[i + 4] = mode;
      data[i + 5] = rotation;
      data[i + 6] = glow;
      colors[count++] = color;
    }

    public void submit(DrawContext g) {
      if (count == 0) return;
      bounds = new ScreenRect(0, 0, g.getScaledWindowWidth(), g.getScaledWindowHeight());
      ((GuiAccess) g).visuals$state().addSimpleElement(this);
    }

    public RenderPipeline pipeline() {
      return PIPELINE;
    }

    public TextureSetup textureSetup() {
      return TextureSetup.empty();
    }

    public ScreenRect scissorArea() {
      return null;
    }

    public ScreenRect bounds() {
      return bounds;
    }

    public void setupVertices(VertexConsumer v) {
      for (int n = 0; n < count; n++) {
        int i = n * 8;
        quad(
            v,
            null,
            data[i],
            data[i + 1],
            data[i + 2],
            data[i + 3],
            data[i + 6],
            colors[n],
            (int) data[i + 4],
            data[i + 5]);
      }
    }

    public int count() {
      return count;
    }
  }

  /** A cached vector icon submits one GUI state for all of its antialiased strokes. */
  public static void icon(DrawContext g,float x,float y,float size,float[] strokes,int color) {
    GuiAccess access=(GuiAccess)g;
    Matrix3x2f pose=new Matrix3x2f(g.getMatrices()).translate(x,y).scale(size/24);
    ScreenRect bounds=new ScreenRect(-2,-2,28,28).transformEachVertex(pose);
    if(access.visuals$clip()!=null) {bounds=bounds.intersection(access.visuals$clip());if(bounds==null)return;}
    access.visuals$state().addSimpleElement(new Icon(pose,strokes,color,access.visuals$clip(),bounds));
  }
  private record Icon(Matrix3x2f pose,float[] strokes,int color,ScreenRect scissorArea,ScreenRect bounds)
      implements SimpleGuiElementRenderState {
    public RenderPipeline pipeline(){return PIPELINE;}
    public TextureSetup textureSetup(){return TextureSetup.empty();}
    public void setupVertices(VertexConsumer v) {
      for(int i=0;i<strokes.length;i+=9) {
        float w=strokes[i+8];
        vertex(v,pose,strokes[i],strokes[i+1],0,0,w,1.6f,.8f,color,0);
        vertex(v,pose,strokes[i+2],strokes[i+3],0,1,w,1.6f,.8f,color,0);
        vertex(v,pose,strokes[i+4],strokes[i+5],1,1,w,1.6f,.8f,color,0);
        vertex(v,pose,strokes[i+6],strokes[i+7],1,0,w,1.6f,.8f,color,0);
      }
    }
  }

  private static void quad(
      VertexConsumer v,
      Matrix3x2f pose,
      float x,
      float y,
      float w,
      float h,
      float radius,
      int color,
      int mode,
      float rotation) {
    int param = mode * 1024 + ((int) (rotation * 1024 / (Math.PI * 2)) & 1023);
    vertex(v, pose, x, y, 0, 0, w, h, radius, color, param);
    vertex(v, pose, x, y + h, 0, 1, w, h, radius, color, param);
    vertex(v, pose, x + w, y + h, 1, 1, w, h, radius, color, param);
    vertex(v, pose, x + w, y, 1, 0, w, h, radius, color, param);
  }

  private static void vertex(
      VertexConsumer v,
      Matrix3x2f pose,
      float x,
      float y,
      float u,
      float t,
      float w,
      float h,
      float r,
      int color,
      int param) {
    if (pose == null) v.vertex(x, y, 0);
    else v.vertex(pose, x, y);
    v.color(color)
        .texture(u, t)
        .overlay(Math.max(1, Math.round(w * 8)), Math.max(1, Math.round(h * 8)))
        .light(Math.round(r * 16), param);
  }

  private SdfRenderer() {}
}
