package pl.xvisuals.rendering.shaders;

import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.GuiRenderState;

public interface GuiAccess {
  GuiRenderState visuals$state();

  ScreenRect visuals$clip();
}
