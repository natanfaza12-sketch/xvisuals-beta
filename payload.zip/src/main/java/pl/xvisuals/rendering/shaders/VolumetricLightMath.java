package pl.xvisuals.rendering.shaders;
public final class VolumetricLightMath {
 public static int samples(String quality){return quality.equals("Low")?12:quality.equals("High")?32:20;}
 public static double visibility(double elevation,double rain){return Math.clamp(elevation/.18,0,1)*(1-Math.clamp(rain,0,1)*.9);}
 public static double approach(double current,double target,double seconds){return current+(target-current)*(1-Math.exp(-Math.clamp(seconds,0,.1)*3));}
 private VolumetricLightMath(){}
}
