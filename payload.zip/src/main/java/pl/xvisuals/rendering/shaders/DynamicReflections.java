package pl.xvisuals.rendering.shaders;
import pl.xvisuals.XVisuals;
import pl.xvisuals.rendering.Projection;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.DefaultFramebufferSet;
import net.minecraft.client.util.memory.ObjectAllocator;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.*;
import net.minecraft.registry.Registries;
import java.util.*;
import java.nio.*;
import org.joml.Matrix4f;

/** Bounded analytic material mask + depth raymarch. Does not replace shader-pack targets. */
public final class DynamicReflections {
 private static final Identifier ID=Identifier.of("xvisuals","dynamic_reflections");
 private static final Map<BlockPos,Integer> MATERIALS=new HashMap<>();
 private static final List<Surface> SURFACES=new ArrayList<>();
 private static final ByteBuffer DATA=ByteBuffer.allocateDirect((8+3+96+64)*16).order(ByteOrder.nativeOrder());
 private static final Matrix4f MATRIX=new Matrix4f(),INVERSE=new Matrix4f();
 private static Object world;private static BlockPos origin;private static int cursor,nearCursor,diameter,ticks;private static boolean shaders,failed;
 private record Surface(Box box,int material){}
 public static void init(){ClientTickEvents.END_CLIENT_TICK.register(DynamicReflections::tick);}
 private static boolean enabled(){return XVisuals.ready()&&XVisuals.visualModule("dynamicreflections").enabled;}
 private static boolean selected(int m){var s=XVisuals.visualModule("dynamicreflections");return switch(m){case 1->s.flag("water");case 2->s.flag("ice");case 3->s.flag("glass");case 4,5->s.flag("metal");default->false;};}
 private static void tick(MinecraftClient c){
  if(world!=c.world||!enabled()){world=c.world;MATERIALS.clear();SURFACES.clear();origin=null;cursor=nearCursor=0;failed=false;shaders=FabricLoader.getInstance().isModLoaded("iris");}
  if(!enabled()||c.world==null||c.player==null||c.isPaused())return;
  ticks++;
  if(ticks%20==1){shaders=false;if(FabricLoader.getInstance().isModLoaded("iris"))try{var api=Class.forName("net.irisshaders.iris.api.v0.IrisApi");shaders=(boolean)api.getMethod("isShaderPackInUse").invoke(api.getMethod("getInstance").invoke(null));}catch(ReflectiveOperationException|LinkageError ex){shaders=true;}}
  if(shaders)return;
  var s=XVisuals.visualModule("dynamicreflections");int q=ReflectionMath.quality(s.text("quality"));
  int radius=(int)Math.min(48,s.number("distance")),d=radius*2+1;
  if(origin==null||diameter!=d||origin.getSquaredDistance(c.player.getBlockPos())>64||cursor>=d*d*d){origin=c.player.getBlockPos();diameter=d;cursor=0;}
  MATERIALS.keySet().removeIf(p->p.getSquaredDistance(c.player.getBlockPos())>(radius+2)*(radius+2)||!c.world.isChunkLoaded(p.getX()>>4,p.getZ()>>4));
  var center=c.player.getBlockPos();
  for(int i=0;i<1024*(q+1);i++){
   BlockPos p;
   if(i<256){int index=nearCursor;nearCursor=(nearCursor+1)%729;p=center.add(index%9-4,(index/9)%9-4,index/81-4);}
   else{if(cursor>=d*d*d)break;int index=cursor++;p=origin.add(index%d-radius,(index/d)%d-radius,index/(d*d)-radius);}
   if(p.getSquaredDistance(center)>(radius+1)*(radius+1)||!c.world.isChunkLoaded(p.getX()>>4,p.getZ()>>4))continue;
   int material=ReflectionMath.material(Registries.BLOCK.getId(c.world.getBlockState(p).getBlock()).toString());
   // The cache is for exposed reflective surfaces, never whole oceans of submerged blocks.
   if(material>0&&selected(material)&&visible(c,p,material)){
    if(MATERIALS.containsKey(p)||MATERIALS.size()<8192)MATERIALS.put(p,material);
   }else MATERIALS.remove(p);
  }
  if(ticks%4!=0)return;
  SURFACES.clear();var positions=new ArrayList<>(MATERIALS.keySet());
  var camera=c.gameRenderer.getCamera().getCameraPos();var look=new org.joml.Vector3f(0,0,-1).rotate(c.gameRenderer.getCamera().getRotation());
  positions.sort(Comparator.comparingDouble(p->{var delta=Vec3d.ofCenter(p).subtract(camera);return delta.lengthSquared()+(delta.x*look.x+delta.y*look.y+delta.z*look.z<0?radius*radius:0);}));
  int limit=new int[]{12,24,36,48}[q];Set<BlockPos> used=new HashSet<>();
  for(var p:positions){if(SURFACES.size()>=limit)break;if(used.contains(p))continue;
   int m=ReflectionMath.material(Registries.BLOCK.getId(c.world.getBlockState(p).getBlock()).toString());if(!selected(m)||!visible(c,p,m)){MATERIALS.remove(p);continue;}
   var state=c.world.getBlockState(p);double h=1;
   if(m==1){if(!c.world.getFluidState(p.up()).isEmpty())continue;h=state.getFluidState().getHeight(c.world,p);}
   else if(!state.isFullCube(c.world,p))continue;
   // Merge coplanar sheets in both axes, preserving gaps and material boundaries.
   int left=p.getX(),right=left,front=p.getZ(),back=front;
   while(p.getX()-left<8&&matches(c,new BlockPos(left-1,p.getY(),front),m,h,used))left--;
   while(right-left<15&&matches(c,new BlockPos(right+1,p.getY(),front),m,h,used))right++;
   while(p.getZ()-front<8&&row(c,left,right,p.getY(),front-1,m,h,used))front--;
   while(back-front<15&&row(c,left,right,p.getY(),back+1,m,h,used))back++;
   for(int x=left;x<=right;x++)for(int z=front;z<=back;z++)used.add(new BlockPos(x,p.getY(),z));
   SURFACES.add(new Surface(new Box(left,p.getY(),front,right+1,p.getY()+h,back+1),m));
  }
 }
 private static boolean visible(MinecraftClient c,BlockPos p,int material){
  if(material==0)return false;
  var state=c.world.getBlockState(p);boolean exposed=false;
  if(material==1)exposed=c.world.getFluidState(p.up()).isEmpty()&&c.world.getBlockState(p.up()).getCollisionShape(c.world,p.up()).isEmpty();
  else for(var direction:Direction.values()){
   var next=p.offset(direction);if(c.world.isChunkLoaded(next.getX()>>4,next.getZ()>>4)&&!c.world.getBlockState(next).isOpaqueFullCube()){exposed=true;break;}
  }
  return ReflectionMath.visibleSurface(material,exposed,state.isFullCube(c.world,p));
 }
 private static boolean matches(MinecraftClient c,BlockPos p,int material,double height,Set<BlockPos> used){
  if(used.contains(p)||!MATERIALS.containsKey(p)||!c.world.isChunkLoaded(p.getX()>>4,p.getZ()>>4))return false;
  var state=c.world.getBlockState(p);if(ReflectionMath.material(Registries.BLOCK.getId(state.getBlock()).toString())!=material||!visible(c,p,material))return false;
  return material!=1||Math.abs(state.getFluidState().getHeight(c.world,p)-height)<.001;
 }
 private static boolean row(MinecraftClient c,int left,int right,int y,int z,int material,double height,Set<BlockPos> used){
  for(int x=left;x<=right;x++)if(!matches(c,new BlockPos(x,y,z),material,height,used))return false;return true;
 }
 private static void vec(double x,double y,double z,double w){DATA.putFloat((float)x).putFloat((float)y).putFloat((float)z).putFloat((float)w);}
 private static void matrix(Matrix4f m){float[] values=new float[16];m.get(values);for(float v:values)DATA.putFloat(v);}
 public static void render(ObjectAllocator pool){
  var c=MinecraftClient.getInstance();if(!enabled()||world!=c.world||c.world==null||c.player==null||c.currentScreen!=null||pl.xvisuals.rendering.ShaderPackSupport.active()||failed||SURFACES.isEmpty()||c.getFramebuffer().getDepthAttachment()==null||!Projection.copyWorldMatrix(MATRIX))return;
  var s=XVisuals.visualModule("dynamicreflections");if(s.number("intensity")<=0)return;
  var camera=c.gameRenderer.getCamera().getCameraPos();int q=ReflectionMath.quality(s.text("quality"));
  var entities=c.world.getOtherEntities(null,c.player.getBoundingBox().expand(s.number("distance")),e->!e.isSpectator());entities.sort(Comparator.comparingDouble(e->e.squaredDistanceTo(camera)));int count=Math.min(32,entities.size());
  DATA.clear();matrix(MATRIX);matrix(INVERSE.set(MATRIX).invert());
  vec(SURFACES.size(),ReflectionMath.steps(q),s.number("intensity"),s.number("distance"));
  vec(s.number("roughness"),(ticks%12000+c.getRenderTickCounter().getTickProgress(false))/20d,s.flag("entities")?1:0,s.flag("sky")?1:0);
  vec(s.flag("fresnel")?1:0,s.flag("smooth")?1:0,count,q);
  for(int i=0;i<48;i++){if(i<SURFACES.size()){var a=SURFACES.get(i);var b=a.box;vec(b.minX-camera.x,b.minY-camera.y,b.minZ-camera.z,a.material);vec(b.maxX-camera.x,b.maxY-camera.y,b.maxZ-camera.z,0);}else{vec(0,0,0,0);vec(0,0,0,0);}}
  for(int i=0;i<32;i++){if(i<count){var b=entities.get(i).getBoundingBox().expand(.08);vec(b.minX-camera.x,b.minY-camera.y,b.minZ-camera.z,0);vec(b.maxX-camera.x,b.maxY-camera.y,b.maxZ-camera.z,0);}else{vec(0,0,0,0);vec(0,0,0,0);}}DATA.flip();
  try{var effect=c.getShaderLoader().loadPostEffect(ID,DefaultFramebufferSet.MAIN_ONLY);if(effect==null)return;
   PostEffectUniforms.upload(effect,"ReflectionConfig",DATA);effect.render(c.getFramebuffer(),pool);
  }catch(RuntimeException ex){failed=true;org.slf4j.LoggerFactory.getLogger("VisualClient").warn("Dynamic reflections disabled for incompatible rendering pipeline",ex);}
 }
 private DynamicReflections(){}
}
