package pl.xvisuals.rendering.shaders;
import pl.xvisuals.XVisuals;
import pl.xvisuals.rendering.Projection;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.DefaultFramebufferSet;
import net.minecraft.client.util.memory.ObjectAllocator;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import java.nio.*;

public final class DepthOfField {
 private static final Identifier ID=Identifier.of("xvisuals","depth_of_field");
 private static final ByteBuffer DATA=ByteBuffer.allocateDirect(128).order(ByteOrder.nativeOrder());
 private static final Matrix4f MATRIX=new Matrix4f();
 private static Object world;private static int ticks;private static boolean initialized,shaders,failed;
 private static double focus=12,previous=12,target=12;
 private static String mode="";
 public static void init(){ClientTickEvents.END_CLIENT_TICK.register(DepthOfField::tick);}
 private static boolean enabled(){return XVisuals.ready()&&XVisuals.visualModule("depthoffield").enabled;}
 private static Vec3d forward(MinecraftClient c){var v=new Vector3f(0,0,-1).rotate(c.gameRenderer.getCamera().getRotation());return new Vec3d(v.x,v.y,v.z);}
 private static void tick(MinecraftClient c){
  if(world!=c.world||!enabled()){world=c.world;initialized=false;failed=false;mode="";shaders=FabricLoader.getInstance().isModLoaded("iris");}
  if(!enabled()||c.world==null||c.player==null||c.isPaused()||c.currentScreen!=null)return;
  if(ticks++%20==0){shaders=false;if(FabricLoader.getInstance().isModLoaded("iris"))try{var api=Class.forName("net.irisshaders.iris.api.v0.IrisApi");shaders=(boolean)api.getMethod("isShaderPackInUse").invoke(api.getMethod("getInstance").invoke(null));}catch(ReflectiveOperationException|LinkageError ex){shaders=true;}}
  if(shaders)return;
  var s=XVisuals.visualModule("depthoffield");String next=s.text("mode");
  if(!initialized||ticks%4==0||!next.equals(mode)||next.equals("Manual")){
   var camera=c.gameRenderer.getCamera().getCameraPos();var direction=forward(c);target=s.number("distance");
   if(next.equals("Crosshair")){if(c.crosshairTarget!=null&&c.crosshairTarget.getType()!=HitResult.Type.MISS)target=Math.max(.1,c.crosshairTarget.getPos().subtract(camera).dotProduct(direction));}
   else if(next.equals("Automatic")){
    double maximum=Math.min(128,c.options.getViewDistance().getValue()*16d);var end=camera.add(direction.multiply(maximum));
    var hit=c.world.raycast(new RaycastContext(camera,end,RaycastContext.ShapeType.OUTLINE,RaycastContext.FluidHandling.ANY,c.player));
    target=hit.getType()==HitResult.Type.MISS?maximum:camera.distanceTo(hit.getPos());
    var search=new Box(camera,end).expand(1);
    for(var e:c.world.getOtherEntities(c.getCameraEntity(),search,e->!e.isSpectator()&&e.canHit())){
     var intersection=e.getBoundingBox().expand(e.getTargetingMargin()).raycast(camera,end);
     if(intersection.isPresent())target=Math.min(target,camera.distanceTo(intersection.get()));
    }
   }
   mode=next;
  }
  if(!initialized){focus=target;initialized=true;}
  previous=focus;focus=FocusMath.approach(focus,target,s.number("speed"),.05,s.flag("smooth"));
 }
 private static void vec(double a,double b,double c,double d){DATA.putFloat((float)a).putFloat((float)b).putFloat((float)c).putFloat((float)d);}
 public static void render(ObjectAllocator pool){
  var c=MinecraftClient.getInstance();if(!enabled()||world!=c.world||c.world==null||c.player==null||!initialized||c.currentScreen!=null||pl.xvisuals.rendering.ShaderPackSupport.active()||failed||c.getFramebuffer().getDepthAttachment()==null||!Projection.copyWorldMatrix(MATRIX))return;
  var s=XVisuals.visualModule("depthoffield");if(s.number("blur")<=0||!s.flag("foreground")&&!s.flag("background"))return;
  double f=previous+(focus-previous)*c.getRenderTickCounter().getTickProgress(false);var direction=forward(c);
  DATA.clear();float[] matrix=new float[16];MATRIX.invert().get(matrix);for(float value:matrix)DATA.putFloat(value);
  vec(f,s.number("range"),s.number("blur"),FocusMath.samples(s.text("quality")));
  vec(s.flag("foreground")?1:0,s.flag("background")?1:0,s.flag("bokeh")?s.number("bokehIntensity"):0,0);
  vec(direction.x,direction.y,direction.z,0);vec(0,0,0,0);DATA.flip();
  try{var effect=c.getShaderLoader().loadPostEffect(ID,DefaultFramebufferSet.MAIN_ONLY);if(effect==null)return;
   PostEffectUniforms.upload(effect,"FocusConfig",DATA);effect.render(c.getFramebuffer(),pool);
  }catch(RuntimeException ex){failed=true;org.slf4j.LoggerFactory.getLogger("VisualClient").warn("Depth of Field disabled for incompatible post-processing",ex);}
 }
 private DepthOfField(){}
}

