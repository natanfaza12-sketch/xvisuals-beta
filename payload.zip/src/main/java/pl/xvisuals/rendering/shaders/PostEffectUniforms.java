package pl.xvisuals.rendering.shaders;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;
import pl.xvisuals.mixins.PostPassAccessor;
import pl.xvisuals.mixins.PostProcessorAccessor;
import java.nio.ByteBuffer;
import net.minecraft.client.gl.PostEffectProcessor;

/** Updates pass-owned uniforms in place; the processor closes them on resource reload. */
public final class PostEffectUniforms {
    static boolean needsReplacement(GpuBuffer buffer, int bytes) {
        return buffer.isClosed() || buffer.size() != bytes
            || (buffer.usage() & GpuBuffer.USAGE_COPY_DST) == 0;
    }

    public static void upload(PostEffectProcessor effect, String name, ByteBuffer data) {
        var device = RenderSystem.getDevice();
        for (var pass : ((PostProcessorAccessor) effect).visuals$passes()) {
            var uniforms = ((PostPassAccessor) pass).visuals$uniforms();
            var old = uniforms.get(name);
            if (old == null) continue;
            // Each pass receives the full payload without changing the caller's cursor.
            var payload = data.duplicate();
            if (needsReplacement(old, payload.remaining())) {
                var next = device.createBuffer(() -> "Visual post effect " + name,
                    GpuBuffer.USAGE_UNIFORM | GpuBuffer.USAGE_COPY_DST, payload);
                uniforms.put(name, next);
                old.close();
            } else {
                device.createCommandEncoder().writeToBuffer(old.slice(), payload);
            }
        }
    }

    private PostEffectUniforms() {}
}
