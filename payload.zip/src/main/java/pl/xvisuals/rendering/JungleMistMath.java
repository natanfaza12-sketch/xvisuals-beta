package pl.xvisuals.rendering;
public final class JungleMistMath {
 public static boolean supported(String biome){return biome.equals("minecraft:jungle")||biome.equals("minecraft:bamboo_jungle")||biome.equals("minecraft:sparse_jungle");}
 public static int cap(String quality){return quality.equals("Low")?48:quality.equals("High")?144:96;}
 public static double approach(double current,boolean jungle){double target=jungle?1:0;return current+(target-current)*.035;}
 public static double fade(double distance,double limit){return Math.clamp((limit-distance)/Math.max(4,limit*.25),0,1);}
 private JungleMistMath(){}
}
