package pl.xvisuals.rendering;
public final class DynamicMistMath {
 public static int cap(String quality){return "Low".equals(quality)?48:"High".equals(quality)?144:96;}
 public static double placement(boolean ground,boolean valley,boolean forest,boolean isForest,double depression){return Math.min(2,(ground?.65:0)+(valley?Math.clamp((depression-.75)/4,0,1):0)+(forest&&isForest?.7:0));}
 public static double altitude(double height,double limit){double t=Math.clamp(height/Math.max(.1,limit),0,1);return 1-t*t*(3-2*t);}
 public static double approach(double current,double target){return current+(target-current)*.035;}
 public static double weather(boolean integration,double rain,boolean storm){return integration?1+.45*Math.clamp(rain,0,1)+(storm?.3:0):1;}
 private DynamicMistMath(){}
}
