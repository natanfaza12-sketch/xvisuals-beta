package pl.xvisuals.rendering;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.mixins.RenderLayerAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
/** Bounded, sorted textured world sprites shared by ambient effects and fireflies. */
public final class CraftedSprites {
 public static final Identifier ATLAS=Identifier.of("xvisuals","textures/crafted/effects.png");
 private static final BufferAllocator ALLOCATOR=new BufferAllocator(262144);
 private static final VertexConsumerProvider.Immediate BUFFER=VertexConsumerProvider.immediate(ALLOCATOR);
 private static final RenderPipeline PIPE=RenderPipeline.builder().withLocation(Identifier.of("xvisuals","pipeline/crafted_sprites"))
  .withVertexShader(Identifier.of("xvisuals","core/player_sprite")).withFragmentShader(Identifier.of("xvisuals","core/player_sprite"))
  .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER).withSampler("Sampler0")
  .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS).withBlend(BlendFunction.TRANSLUCENT)
  .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withDepthWrite(false).withCull(false).build();
 private static final java.util.Map<Identifier,RenderLayer> LAYERS=new java.util.HashMap<>();
 private static final class Sprite {Vec3d p,axisX,axisY;double width,height,angle;int mode,frame,color;}
 private static final Sprite[] POOL=new Sprite[512];static{for(int i=0;i<POOL.length;i++)POOL[i]=new Sprite();}
 private static final java.util.List<Sprite> SPRITES=new java.util.ArrayList<>(512);
 static{net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING.register(c->ALLOCATOR.close());}
 public static void begin(){SPRITES.clear();}
 public static void add(Vec3d p,double width,double height,double angle,int mode,int frame,int color){if(SPRITES.size()<512){var s=POOL[SPRITES.size()];s.p=p;s.axisX=null;s.axisY=null;s.width=width;s.height=height;s.angle=angle;s.mode=mode;s.frame=frame;s.color=color;SPRITES.add(s);}}
 public static void plane(Vec3d p,Vec3d across,Vec3d vertical,int tint){
  if(SPRITES.size()>=512)return;add(p,1,1,0,0,0,tint);var s=SPRITES.getLast();s.axisX=across;s.axisY=vertical;
 }
 public static void draw(MatrixStack matrices){draw(matrices,ATLAS,true);}
 public static void draw(MatrixStack matrices,Identifier texture,boolean atlas){
  var c=MinecraftClient.getInstance();var camera=c.gameRenderer.getCamera();var eye=camera.getCameraPos();
  var right=new org.joml.Vector3f(1,0,0).rotate(camera.getRotation());var up=new org.joml.Vector3f(0,1,0).rotate(camera.getRotation());
  SPRITES.sort(java.util.Comparator.comparingDouble((Sprite s)->s.p.squaredDistanceTo(eye)).reversed());
  var layer=LAYERS.computeIfAbsent(texture,t->RenderLayerAccessor.visuals$of("crafted_"+t.getPath(),RenderSetup.builder(PIPE).texture("Sampler0",t).translucent().expectedBufferSize(262144).build()));
  var out=BUFFER.getBuffer(layer);var m=matrices.peek().getPositionMatrix();
  for(var s:SPRITES){var p=s.p.subtract(eye);if(p.lengthSquared()<.04)continue;double co=Math.cos(s.angle),si=Math.sin(s.angle);
   for(int k=0;k<4;k++){float x=k==1||k==2?.5f:-.5f,y=k>=2?.5f:-.5f;double dx=x*s.width*co-y*s.height*si,dy=x*s.width*si+y*s.height*co;
    float u=x+.5f,v=.5f-y;if(atlas){u=(s.mode+(.5f+u*63)/64)/24;v=(Math.floorMod(s.frame,8)+(.5f+v*63)/64)/8;}
    double rx=s.axisX==null?right.x:s.axisX.x,ry=s.axisX==null?right.y:s.axisX.y,rz=s.axisX==null?right.z:s.axisX.z;
    double ux=s.axisY==null?up.x:s.axisY.x,uy=s.axisY==null?up.y:s.axisY.y,uz=s.axisY==null?up.z:s.axisY.z;
    out.vertex(m,(float)(p.x+rx*dx+ux*dy),(float)(p.y+ry*dx+uy*dy),(float)(p.z+rz*dx+uz*dy)).texture(u,v).color(s.color);
   }
  }BUFFER.draw();SPRITES.clear();
 }
 private CraftedSprites(){}
}
