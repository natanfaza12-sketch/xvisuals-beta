package pl.xvisuals.rendering;
public final class MountainWindsMath {
 public static boolean supported(String biome){return biome.equals("minecraft:jagged_peaks")||biome.equals("minecraft:stony_peaks");}
 public static int cap(String quality){return quality.equals("Low")?64:quality.equals("High")?192:128;}
 public static double altitude(double y,boolean enabled){return enabled?Math.clamp(.65+(y-64)/160, .5,2.5):1;}
 private MountainWindsMath(){}
}
