package pl.xvisuals.rendering;
/** Continuous drifting motion anchored at the spawn position, independent of the camera. */
public final class LeafMotion {
 public static double x(double t,double phase){return .65*(Math.sin(t*.7+phase)-Math.sin(phase))+.16*t;}
 public static double y(double t,double phase){return -.23*t+.06*(Math.sin(t*1.4+phase)-Math.sin(phase));}
 public static double z(double t,double phase){return .48*(Math.cos(t*.53+phase)-Math.cos(phase));}
 private LeafMotion(){}
}
