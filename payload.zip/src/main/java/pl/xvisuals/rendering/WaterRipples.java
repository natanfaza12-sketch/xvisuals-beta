package pl.xvisuals.rendering;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import pl.xvisuals.mixins.RenderLayerAccessor;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.vehicle.AbstractBoatEntity;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.*;
import net.minecraft.world.Heightmap;
import net.minecraft.world.biome.Biome;
import java.util.*;

/** Local movement impulses drive the replacement water surface, without world changes. */
public final class WaterRipples {
 private static final List<Ripple> ACTIVE=new ArrayList<>();
 private static final Map<Integer,Track> TRACKS=new HashMap<>();
 private static Object world;
 private static int ticks,budget;
 private record Track(Vec3d position,int emitted){}
 private record Patch(BlockPos block,double height){}
 private record Ripple(double x,double z,int born,double size,double strength,int color,int kind,List<Patch> patches){}
 public static void init(){WaterSurface.init();ClientTickEvents.END_CLIENT_TICK.register(WaterRipples::tick);WorldRenderEvents.END_MAIN.register(c->WaterSurface.render(c.matrices()));}
 private static boolean enabled(){return XVisuals.ready()&&XVisuals.visualModule("waterripples").enabled;}
 private static int kind(Entity e){return e instanceof PlayerEntity?0:e instanceof AbstractBoatEntity?2:e instanceof ItemEntity?3:e instanceof LivingEntity?1:-1;}
 private static boolean accepts(int k){var s=XVisuals.visualModule("waterripples");return switch(k){case 0->s.flag("players");case 1->s.flag("mobs");case 2->s.flag("boats");case 3->s.flag("items");case 4->s.flag("rain");default->false;};}
 private static double surface(MinecraftClient c,BlockPos p){
   if(!c.world.isChunkLoaded(p.getX()>>4,p.getZ()>>4))return Double.NaN;
   var b=c.world.getBlockState(p);var fluid=b.getFluidState();
   if(!fluid.isIn(FluidTags.WATER)||!b.getCollisionShape(c.world,p).isEmpty()||c.world.getFluidState(p.up()).isIn(FluidTags.WATER)
       ||!c.world.getBlockState(p.up()).getCollisionShape(c.world,p.up()).isEmpty())return Double.NaN;
   return p.getY()+fluid.getHeight(c.world,p)+.012;
 }
 private static void tick(MinecraftClient c){
   if(world!=c.world||!enabled()){world=c.world;ACTIVE.clear();TRACKS.clear();}
   if(!enabled()||c.world==null||c.player==null||c.isPaused())return;
   ticks++;var s=XVisuals.visualModule("waterripples");double distance=s.number("distance");
   int quality=s.text("quality").equals("Low")?0:s.text("quality").equals("High")?2:1;
   int cap=new int[]{16,32,48}[quality];budget=new int[]{2,3,4}[quality];
   ACTIVE.removeIf(r->ticks-r.born>=32||!accepts(r.kind)||c.player.getEntityPos().squaredDistanceTo(r.x,c.player.getY(),r.z)>distance*distance);
   while(ACTIVE.size()>cap)ACTIVE.removeFirst();
   // Prune changed/drained/covered surfaces on ticks, never query terrain in the render loop.
   for(var r:ACTIVE)r.patches.removeIf(p->{double h=surface(c,p.block);return !Double.isFinite(h)||Math.abs(h-p.height)>.025;});
   var entities=c.world.getOtherEntities(null,c.player.getBoundingBox().expand(distance),e->accepts(kind(e))&&!e.isSpectator());
   entities.sort(Comparator.comparingDouble(e->e.squaredDistanceTo(c.player)));
   Set<Integer> seen=new HashSet<>();int examined=0;
   for(var e:entities){if(examined++>=64)break;seen.add(e.getId());var pos=e.getEntityPos();var old=TRACKS.get(e.getId());
     double speed=old==null?0:Math.hypot(pos.x-old.position.x,pos.z-old.position.z);
     int last=old==null?ticks-100:old.emitted;
     if(speed>4){TRACKS.put(e.getId(),new Track(pos,ticks));continue;}
     if(budget>0&&ticks-last>=RippleMath.interval(s.number("frequency"),speed)){
       int x=MathHelper.floor(pos.x),z=MathHelper.floor(pos.z);
       for(int y=MathHelper.floor(pos.y-.6);y<=Math.floor(Math.min(pos.y+2,e.getBoundingBox().maxY));y++){
         double h=surface(c,new BlockPos(x,y,z));
         if(Double.isFinite(h)&&h>=pos.y-.4&&h<=e.getBoundingBox().maxY+.05){
           spawn(c,pos.x,pos.z,h,RippleMath.strength(speed)*(e instanceof AbstractBoatEntity?1.2:1),kind(e),cap);last=ticks;break;
         }
       }
     }
     TRACKS.put(e.getId(),new Track(pos,last));
   }
   TRACKS.keySet().retainAll(seen);
   double rain=Storm.running()?Storm.rain():c.world.getRainGradient(1);
   if(s.flag("rain")&&rain>.01&&budget>0&&ticks%3==0){
     var random=c.world.random;double radius=Math.min(12,distance);
     for(int i=0;i<4&&budget>0;i++){
       int x=MathHelper.floor(c.player.getX()+(random.nextDouble()*2-1)*radius),z=MathHelper.floor(c.player.getZ()+(random.nextDouble()*2-1)*radius);
       if(random.nextDouble()>rain||!c.world.isChunkLoaded(x>>4,z>>4))continue;
       int y=c.world.getTopY(Heightmap.Type.MOTION_BLOCKING,x,z)-1;var p=new BlockPos(x,y,z);double h=surface(c,p);
       if(Double.isFinite(h)&&c.world.isSkyVisible(p.up())&&(Storm.running()||c.world.getBiome(p).value().getPrecipitation(p,c.world.getSeaLevel())==Biome.Precipitation.RAIN))
         spawn(c,x+random.nextDouble(),z+random.nextDouble(),h,.22,4,cap);
     }
   }
 }
 private static void spawn(MinecraftClient c,double x,double z,double height,double strength,int kind,int cap){
   var s=XVisuals.visualModule("waterripples");strength*=s.number("intensity");if(strength<=0)return;
   double size=Math.min(3.5,s.number("size")*(kind==4?.45:.6+strength*.4));List<Patch> patches=new ArrayList<>();
   for(int xx=(int)Math.floor(x-size);xx<=Math.floor(x+size);xx++)for(int zz=(int)Math.floor(z-size);zz<=Math.floor(z+size);zz++){
     var p=new BlockPos(xx,(int)Math.floor(height-.02),zz);double h=surface(c,p);
     if(Double.isFinite(h)&&Math.abs(h-height)<.07)patches.add(new Patch(p,h));
   }
   if(patches.isEmpty())return;
   budget--;while(ACTIVE.size()>=cap)ACTIVE.removeFirst();ACTIVE.add(new Ripple(x,z,ticks,size,strength,s.color("color"),kind,patches));
 }
 public static int waveCount(String quality){return Math.min(ACTIVE.size(),quality.equals("High")?12:quality.equals("Low")?4:8);}
 public static void writeWaves(java.nio.ByteBuffer data,Vec3d camera,float delta,int count){
  for(int i=0;i<16;i++){
   if(i<count){var r=ACTIVE.get(ACTIVE.size()-1-i);double t=(ticks-r.born+delta)/32d;
    double height=r.patches.isEmpty()?camera.y:r.patches.getFirst().height;
    data.putFloat((float)(r.x-camera.x)).putFloat((float)(height-camera.y)).putFloat((float)(r.z-camera.z)).putFloat((float)(r.size*RippleMath.radius(t)));
    data.putFloat((float)(r.strength*RippleMath.fade(t))).putFloat((float)r.size).putFloat(r.patches.isEmpty()?0:1).putFloat(0);
   }else for(int j=0;j<8;j++)data.putFloat(0);
  }
 }
 private WaterRipples(){}
}
