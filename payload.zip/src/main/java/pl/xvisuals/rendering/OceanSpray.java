package pl.xvisuals.rendering;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.*;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.world.Heightmap;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import java.nio.*;
import java.util.*;

/** Local depth-softened sea mist and water spray; no world changes. */
public final class OceanSpray {
 private record Source(BlockPos block,double base,boolean shore){}
 private static final Map<BlockPos,Source> SOURCES=new LinkedHashMap<>();
 private static BlockPos origin;private static int scan,nearScan,scanRadius;
 private static final List<Puff> PARTICLES=new ArrayList<>();private static final Random RANDOM=new Random();
 private static final ByteBuffer VERTICES=ByteBuffer.allocateDirect(192*6*24).order(ByteOrder.nativeOrder());
 private static MappableRingBuffer vertices;private static Object world;private static int ticks;private static double blend,clock,sprayCredit,mistCredit;private static boolean failed;
 private static final Matrix4f OPTIONS=new Matrix4f();private static final Vector4f WHITE=new Vector4f(1,1,1,1);private static final Vector3f ZERO=new Vector3f();
 private static final RenderPipeline PIPELINE=RenderPipeline.builder().withLocation(Identifier.of("xvisuals","pipeline/ocean_spray"))
  .withVertexShader(Identifier.of("xvisuals","core/lavafall_mist")).withFragmentShader(Identifier.of("xvisuals","core/lavafall_mist"))
  .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER).withUniform("Fog",UniformType.UNIFORM_BUFFER).withSampler("SceneDepth")
  .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.TRIANGLES).withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).build();
 private static class Puff {Vec3d pos,previous;double size,life,phase,baseY,velocity;int age;boolean mist,splash;}
 public static void init(){ClientTickEvents.END_CLIENT_TICK.register(OceanSpray::tick);WorldRenderEvents.END_MAIN.register(c->render(c.matrices()));ClientLifecycleEvents.CLIENT_STOPPING.register(c->clear());}
 private static boolean enabled(){return XVisuals.ready()&&XVisuals.visualModule("oceanspray").enabled;}
 private static void clear(){PARTICLES.clear();SOURCES.clear();origin=null;scan=nearScan=0;blend=0;clock=0;sprayCredit=mistCredit=0;failed=false;if(vertices!=null){vertices.close();vertices=null;}}
 private static Source source(MinecraftClient c,BlockPos at,Vec3d camera,double radius){
  if(!c.world.isChunkLoaded(at.getX()>>4,at.getZ()>>4))return null;
  var fluid=c.world.getFluidState(at);
  if(!fluid.isIn(FluidTags.WATER)||!c.world.getBlockState(at).getCollisionShape(c.world,at).isEmpty())return null;
  double base=at.getY()+fluid.getHeight(c.world,at);
  boolean exposed=c.world.getFluidState(at.up()).isEmpty()&&c.world.getBlockState(at.up()).getCollisionShape(c.world,at.up()).isEmpty()&&c.world.isSkyVisible(at.up());
  String biome=c.world.getBiome(at).getKey().map(k->k.getValue().toString()).orElse("");
  if(!OceanSprayMath.canSpawn(biome,exposed,camera.squaredDistanceTo(at.getX()+.5,base,at.getZ()+.5),radius))return null;
  boolean shore=false;
  for(var d:Direction.Type.HORIZONTAL){var side=at.offset(d);if(c.world.isChunkLoaded(side.getX()>>4,side.getZ()>>4)&&!c.world.getBlockState(side).getCollisionShape(c.world,side).isEmpty()){shore=true;break;}}
  return new Source(at.toImmutable(),base,shore);
 }
 private static void discover(MinecraftClient c,Vec3d camera,double radius){
  var center=BlockPos.ofFloored(camera);int range=(int)Math.ceil(radius);
  if(origin==null||origin.getSquaredDistance(center)>16||scanRadius!=range){origin=center;scanRadius=range;scan=nearScan=0;}
  SOURCES.entrySet().removeIf(e->source(c,e.getKey(),camera,radius)==null);
  // Scan columns deterministically, prioritising nearby water. Heightmaps find the actual
  // surface from cliffs or third-person cameras without an arbitrary vertical scan window.
  for(int n=0;n<64;n++){
   boolean near=n<24;int r=near?Math.min(4,range):range,d=r*2+1,index=near?nearScan:scan;
   int x=origin.getX()+index%d-r,z=origin.getZ()+index/d-r;
   if(near)nearScan=(nearScan+1)%(d*d);else scan=(scan+1)%(d*d);
   if(!c.world.isChunkLoaded(x>>4,z>>4))continue;
   int y=c.world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,x,z)-1;
   var found=source(c,new BlockPos(x,y,z),camera,radius);
   if(found!=null)SOURCES.put(found.block,found);
  }
  if(SOURCES.size()>256){
   var sorted=new ArrayList<>(SOURCES.keySet());sorted.sort(Comparator.comparingDouble(p->p.getSquaredDistance(camera)));
   for(int i=256;i<sorted.size();i++)SOURCES.remove(sorted.get(i));
  }
 }
 private static boolean shaderPack(){return ShaderPackSupport.active();}
 private static void tick(MinecraftClient c){
  if(world!=c.world||!enabled()){world=c.world;clear();}
  if(!enabled()||c.world==null||c.player==null||c.isPaused())return;
  if(shaderPack()){clear();return;}if(failed)return;ticks++;clock+=.05;
  var camera=c.gameRenderer.getCamera().getCameraPos();
  var s=XVisuals.visualModule("oceanspray");int cap=OceanSprayMath.cap(s.text("quality"));double radius=s.number("distance");var wind=AtmosphericWind.sample(clock);
  discover(c,camera,radius);boolean active=!SOURCES.isEmpty();blend=JungleMistMath.approach(blend,active);
  while(PARTICLES.size()>cap)PARTICLES.removeFirst();int mistCount=0,sprayCount=0;
  for(var it=PARTICLES.iterator();it.hasNext();){var p=it.next();p.previous=p.pos;p.age++;
   if(p.age>=p.life||p.pos.squaredDistanceTo(camera)>radius*radius||p.mist&&!s.flag("mist")||p.splash&&!s.flag("splashes")||!p.mist&&s.number("density")<=0){it.remove();continue;}
   if(p.mist)mistCount++;else sprayCount++;
   if(!p.mist)p.velocity-=.7*.05;
   var next=p.pos.add((wind.x()*s.number("wind")+Math.sin(p.phase+clock*.4)*.05)*.05,p.mist?Math.sin(clock*.3+p.phase)*.001:p.velocity*.05,(wind.z()*s.number("wind")+Math.cos(p.phase+clock*.3)*.05)*.05);
   var at=BlockPos.ofFloored(next);if(!c.world.isChunkLoaded(at.getX()>>4,at.getZ()>>4)){it.remove();continue;}
   var fluid=c.world.getFluidState(at);
   if(!p.mist&&(next.y<p.baseY+.02||next.y>p.baseY+s.number("height"))||!fluid.isEmpty()&&next.y<at.getY()+fluid.getHeight(c.world,at)){it.remove();continue;}
   var hit=c.world.raycast(new RaycastContext(p.pos,next,RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,c.player));
   if(hit.getType()==HitResult.Type.MISS)p.pos=next;else p.life=Math.min(p.life,p.age+10);
  }
  if(!active){sprayCredit=mistCredit=0;return;}
  double weather=OceanSprayMath.weather(Math.hypot(wind.x(),wind.z())*s.number("wind"),Math.max(c.world.getRainGradient(1),Storm.running()?Storm.rain():0),Storm.running());
  sprayCredit=Math.min(4,sprayCredit+s.number("density")*.05*weather);mistCredit=Math.min(2,mistCredit+(s.flag("mist")?s.number("mistDensity")*.05:0));
  var sources=new ArrayList<>(SOURCES.values());
  for(int attempt=0;attempt<4&&PARTICLES.size()<cap&&(sprayCredit>=1||mistCredit>=1);attempt++){
   boolean mist=mistCredit>=1&&mistCount<cap/3&&(sprayCredit<1||sprayCount>=cap-cap/3||RANDOM.nextBoolean());
   if(mist?mistCount>=cap/3:sprayCredit<1||sprayCount>=cap-cap/3)break;
   var selected=sources.get(RANDOM.nextInt(sources.size()));
   var current=source(c,selected.block,camera,radius);if(current==null){SOURCES.remove(selected.block);continue;}
   boolean splash=!mist&&current.shore&&s.flag("splashes")&&RANDOM.nextDouble()<.65;
   double base=current.base;
   var pos=new Vec3d(current.block.getX()+.15+RANDOM.nextDouble()*.7,base+(mist?.3:.08),current.block.getZ()+.15+RANDOM.nextDouble()*.7);
   var at=BlockPos.ofFloored(pos);if(!c.world.getBlockState(at).getCollisionShape(c.world,at).isEmpty())continue;
   var p=new Puff();p.pos=p.previous=pos;p.baseY=base;p.mist=mist;p.splash=splash;p.phase=RANDOM.nextDouble()*6.283;
   p.velocity=OceanSprayMath.launchSpeed(s.number("height"))*(splash?1:.55+RANDOM.nextDouble()*.3);
   p.size=mist?1.8+RANDOM.nextDouble()*1.2:splash?.085:.045+RANDOM.nextDouble()*.025;p.life=mist?140+RANDOM.nextInt(80):100;
   PARTICLES.add(p);if(mist){mistCredit--;mistCount++;}else{sprayCredit--;sprayCount++;}
  }
 }

 private static void vertex(Vec3d p,float u,float v,int rgb,double alpha){VERTICES.putFloat((float)p.x).putFloat((float)p.y).putFloat((float)p.z).putFloat(u).putFloat(v).put((byte)(rgb>>16)).put((byte)(rgb>>8)).put((byte)rgb).put((byte)(Math.clamp(alpha,0,1)*255));}
 private static void render(MatrixStack matrices){
  var c=MinecraftClient.getInstance();if(!enabled()||shaderPack()||world!=c.world||c.world==null||failed||PARTICLES.isEmpty()||!CameraEnvironment.surface()||c.getFramebuffer().getDepthAttachmentView()==null)return;
  var s=XVisuals.visualModule("oceanspray");var camera=c.gameRenderer.getCamera().getCameraPos();float delta=c.getRenderTickCounter().getTickProgress(false);
  var q=c.gameRenderer.getCamera().getRotation();var rr=new Vector3f(1,0,0).rotate(q);var uu=new Vector3f(0,1,0).rotate(q);var right=new Vec3d(rr.x,rr.y,rr.z);var up=new Vec3d(uu.x,uu.y,uu.z);
  PARTICLES.sort(Comparator.comparingDouble((Puff p)->-p.pos.squaredDistanceTo(camera)));VERTICES.clear();int tint=0xD8E8ED;
  for(var p:PARTICLES){double age=p.age+delta,t=age/p.life,alpha=OceanSprayMath.alpha(p.mist,age,p.life,s.number("opacity"),blend,p.pos.distanceTo(camera),s.number("distance"));if(alpha<.002)continue;
   var pos=p.previous.lerp(p.pos,delta).subtract(camera);double size=p.size*(1+t*.25);int color=tint;
   double angle=Math.sin(p.phase+.0015*age)*.08,cos=Math.cos(angle),sin=Math.sin(angle);var r=right.multiply(cos).add(up.multiply(sin)).multiply(size);var u=up.multiply(cos).subtract(right.multiply(sin)).multiply((!p.mist?size:size*.45));
   int seed=(int)(p.phase*8);float base=seed*8+(!p.mist?4:0);
   var a=pos.subtract(r).subtract(u);var b=pos.add(r).subtract(u);var d=pos.subtract(r).add(u);var e=pos.add(r).add(u);
   vertex(a,base,1,color,alpha);vertex(b,base+1,1,color,alpha);vertex(e,base+1,0,color,alpha);vertex(a,base,1,color,alpha);vertex(e,base+1,0,color,alpha);vertex(d,base,0,color,alpha);
  }
  int count=VERTICES.position()/24;if(count==0)return;VERTICES.flip();
  try{
   if(vertices==null)vertices=new MappableRingBuffer(()->"Ocean mist",GpuBuffer.USAGE_VERTEX|GpuBuffer.USAGE_COPY_DST|GpuBuffer.USAGE_MAP_WRITE,VERTICES.capacity());
   var buffer=vertices.getBlocking();var encoder=RenderSystem.getDevice().createCommandEncoder();encoder.writeToBuffer(buffer.slice(0,VERTICES.remaining()),VERTICES);
   OPTIONS.identity().m00((float)(clock+delta*.05)).m01(0);var transform=RenderSystem.getDynamicUniforms().write(new Matrix4f(RenderSystem.getModelViewMatrix()).mul(matrices.peek().getPositionMatrix()),WHITE,ZERO,OPTIONS);
   try(var pass=encoder.createRenderPass(()->"Ocean sea mist and spray",c.getFramebuffer().getColorAttachmentView(),OptionalInt.empty())){
    pass.setPipeline(PIPELINE);RenderSystem.bindDefaultUniforms(pass);pass.setUniform("DynamicTransforms",transform);pass.bindTexture("SceneDepth",c.getFramebuffer().getDepthAttachmentView(),RenderSystem.getSamplerCache().get(com.mojang.blaze3d.textures.FilterMode.NEAREST));pass.setVertexBuffer(0,buffer);pass.draw(0,count);
   }vertices.rotate();
  }catch(RuntimeException ex){failed=true;org.slf4j.LoggerFactory.getLogger("VisualClient").warn("Ocean Spray rendering unavailable",ex);}
 }
 private OceanSpray(){}
}
