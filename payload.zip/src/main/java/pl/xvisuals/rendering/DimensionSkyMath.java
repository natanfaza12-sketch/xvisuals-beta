package pl.xvisuals.rendering;

public final class DimensionSkyMath {
 public static final String[] NETHER={"Inferno","Crimson Void","Ashfall","Abyss","Custom Image"};
 public static final String[] END={"Cosmic Void","Purple Nebula","Celestial","Black Hole","Vanilla","Custom Image"};
 /** 0 panorama, 1 horizontal strip, 2 vertical strip, 3 horizontal cross, 4 packed six faces. */
 public static int layout(int w,int h){
  if(w<=0||h<=0)return -1;
  if(w==2L*h)return 0;
  if(w==6L*h)return 1;
  if(h==6L*w)return 2;
  if(w%4==0&&h%3==0&&w/4==h/3)return 3;
  if(w%3==0&&h%2==0&&w/3==h/2)return 4;
  return -1;
 }
 public static boolean selected(String option,String dimension){return dimension.equals("minecraft:the_nether")&&!option.equals("End")||dimension.equals("minecraft:the_end")&&!option.equals("Nether");}
 public static int preset(String name,boolean nether){
  if(name.equals("Custom Image"))return 8;
  if(nether)return switch(name){case "Crimson Void"->1;case "Ashfall"->2;case "Abyss"->3;default->0;};
  return switch(name){case "Purple Nebula"->5;case "Celestial"->6;case "Black Hole"->7;case "Vanilla"->-1;default->4;};
 }
 public static double approach(double value,double target,double seconds){return value+(target-value)*(1-Math.exp(-Math.max(0,seconds)*6));}
 public static boolean needsImage(int current,int previous,double blend){return current==8||previous==8&&blend<1;}
 private DimensionSkyMath(){}
}
