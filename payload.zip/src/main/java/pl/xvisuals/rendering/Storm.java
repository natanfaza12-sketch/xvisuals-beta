package pl.xvisuals.rendering;

import pl.xvisuals.XVisuals;
import pl.xvisuals.config.VisualConfig.ModuleState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;
import java.util.Random;

/** Local presentation only: no weather setters, network packets, blocks or lightning entities. */
public final class Storm {
  private static final StormEnvelope ENVELOPE = new StormEnvelope();
  private static final Random RANDOM = new Random();
  private static final ModuleState PRECIPITATION = precipitationProfile();
  private static Object world;
  private static int nextStrike = 100;
  private static float previousFlash, previousDarkness;

  private static ModuleState precipitationProfile() {
    var s = new ModuleState();
    s.values.put("weather", "Storm");
    s.values.put("intensity", 1d);
    s.values.put("radius", 18d);
    s.values.put("density", .85d);
    s.values.put("wind", 0d);
    s.values.put("splashes", true);
    // No frost, snow or additional mist pass for Storm.
    return s;
  }

  public static void tick(MinecraftClient client) {
    if (world != client.world) {
      ENVELOPE.reset(); previousFlash = previousDarkness = 0; nextStrike = 100; world = client.world;
    }
    if (client.world == null || client.player == null || !XVisuals.ready()) {
      ENVELOPE.reset(); previousFlash = previousDarkness = 0; return;
    }
    if (!client.world.getRegistryKey().equals(World.OVERWORLD)) {
      ENVELOPE.reset(); previousFlash = previousDarkness = 0; return;
    }
    if (client.isPaused()) return;
    var settings = XVisuals.visualModule("storm");
    boolean enabled = settings.enabled;
    boolean strike = enabled && --nextStrike <= 0;
    if (strike) nextStrike = 140 + RANDOM.nextInt(241);
    if (!enabled) nextStrike = 100;
    previousFlash = ENVELOPE.flash();
    previousDarkness = ENVELOPE.darkness();
    boolean thunder = ENVELOPE.tick(enabled, settings.number("intensity"), settings.number("darkness"),
        settings.flag("lightning"), settings.flag("thunder"), strike, 12 + RANDOM.nextInt(29));
    PRECIPITATION.values.put("wind", enabled && settings.flag("wind") ? 1.25d : 0d);
    if (thunder) {
      var camera = client.gameRenderer.getCamera().getCameraPos();
      boolean outdoors = client.world.isSkyVisible(net.minecraft.util.math.BlockPos.ofFloored(camera));
      client.world.playSoundClient(camera.x, camera.y, camera.z, SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER,
          SoundCategory.WEATHER, outdoors ? .8f : .32f, .85f + RANDOM.nextFloat() * .15f, false);
    }
  }

  public static boolean running(World candidate) {
    return candidate != null && candidate == world && candidate == MinecraftClient.getInstance().world
        && candidate.getRegistryKey().equals(World.OVERWORLD) && ENVELOPE.running();
  }
  public static boolean running() { return running(MinecraftClient.getInstance().world); }
  public static ModuleState precipitation() { return PRECIPITATION; }
  public static float rain() { return ENVELOPE.rain(); }
  public static float darkness() {
    if (!running()) return 0;
    float delta = MinecraftClient.getInstance().getRenderTickCounter().getTickProgress(false);
    return previousDarkness + (ENVELOPE.darkness() - previousDarkness) * Math.clamp(delta, 0, 1);
  }
  public static float flash() {
    if (!running() || !XVisuals.visualModule("storm").enabled
        || !XVisuals.visualModule("storm").flag("lightning")) return 0;
    float delta = MinecraftClient.getInstance().getRenderTickCounter().getTickProgress(false);
    return previousFlash + (ENVELOPE.flash() - previousFlash) * Math.clamp(delta, 0, 1);
  }
  public static int skyColor(int original) {
    if (!running()) return original;
    double dark = darkness() * .78, flash = flash();
    int result = original & 0xFF000000;
    for (int shift=0; shift<=16; shift+=8) {
      double channel = ((original >>> shift) & 255) * (1 - dark);
      int light = shift == 16 ? 211 : shift == 8 ? 223 : 245;
      result |= ((int)Math.clamp(channel * (1 - flash) + light * flash, 0, 255)) << shift;
    }
    return result;
  }
  private Storm() {}
}
