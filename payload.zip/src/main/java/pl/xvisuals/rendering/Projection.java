package pl.xvisuals.rendering;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;
import org.joml.*;

/** Reuses its matrix and vector scratch space for all world overlays in one frame. */
public final class Projection {
  private static final Matrix4f WORLD_MATRIX = new Matrix4f();
  private static Vec3d worldCamera = Vec3d.ZERO;
  private static boolean captured;
  public static void beginFrame() { captured = false; }
  /** Copy the exact world transform before hand rendering replaces the projection. */
  public static void capture(Matrix4f view, Matrix4f perspective, Vec3d camera) {
    WORLD_MATRIX.set(perspective).mul(view);
    worldCamera = camera;
    captured = true;
  }
  public static boolean copyWorldMatrix(Matrix4f target) {
    if (!captured) return false;
    target.set(WORLD_MATRIX); return true;
  }
  private final Matrix4f matrix = new Matrix4f();
  private final Quaternionf rotation = new Quaternionf();
  private final Vector4f scratch = new Vector4f();
  public Vec3d camera = Vec3d.ZERO;
  public int width, height;
  public float tick;

  boolean beginCaptured(int width, int height, float tick) {
    if (!captured) return false;
    this.width=width; this.height=height; this.tick=tick;
    matrix.set(WORLD_MATRIX); camera=worldCamera;
    return true;
  }

  public void begin(MinecraftClient c, float tick) {
    if (beginCaptured(c.getWindow().getScaledWidth(), c.getWindow().getScaledHeight(), tick)) return;
    this.tick = tick;
    width = c.getWindow().getScaledWidth();
    height = c.getWindow().getScaledHeight();
    camera = c.gameRenderer.getCamera().getCameraPos();
    float fov =
        ((pl.xvisuals.mixins.GameRendererAccessor) c.gameRenderer)
            .visuals$getFov(c.gameRenderer.getCamera(), tick, true);
    matrix.set(c.gameRenderer.getBasicProjectionMatrix(fov));
    rotation.set(c.gameRenderer.getCamera().getRotation()).conjugate();
    matrix.rotate(rotation);
  }

  public boolean project(double x, double y, double z, Point p) {
    scratch.set((float) (x - camera.x), (float) (y - camera.y), (float) (z - camera.z), 1);
    matrix.transform(scratch);
    if (scratch.w <= .05f) {
      p.visible = false;
      return false;
    }
    double nx = scratch.x / scratch.w, ny = scratch.y / scratch.w;
    p.x = (nx + 1) * .5 * width;
    p.y = (1 - ny) * .5 * height;
    p.depth = scratch.w;
    p.visible = nx >= -1.15 && nx <= 1.15 && ny >= -1.15 && ny <= 1.15;
    return true;
  }

  public boolean project(Vec3d v, Point p) {
    return project(v.x, v.y, v.z, p);
  }

  public static final class Point {
    public double x, y, depth;
    public boolean visible;
  }
}
