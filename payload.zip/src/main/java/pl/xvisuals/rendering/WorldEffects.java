package pl.xvisuals.rendering;

import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import pl.xvisuals.mixins.RenderLayerAccessor;
import pl.xvisuals.modules.world.WorldEffectKind;
import pl.xvisuals.util.Colors;
import java.util.*;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/** World-space effects with a shared depth-tested batch and a strict global budget. */
public final class WorldEffects {
  private static final WorldEffectKind[] KINDS=WorldEffectKind.values();
  private static final List<Instance> ACTIVE=new ArrayList<>();
  private static final List<Instance> DRAW_ORDER=new ArrayList<>();
  private static final AmbientClock CLOCK=new AmbientClock();
  private static final Random RANDOM=new Random(73921);
  private static final BufferAllocator ALLOCATOR=new BufferAllocator(1048576);
  private static final VertexConsumerProvider.Immediate BUFFERS=VertexConsumerProvider.immediate(ALLOCATOR);
  private static final RenderLayer LAYER=RenderLayerAccessor.visuals$of("xvisuals_world_effects",
      RenderSetup.builder(RenderPipeline.builder()
          .withLocation(Identifier.of("xvisuals","pipeline/world_effect"))
          .withVertexShader(Identifier.of("xvisuals","core/world_effect"))
          .withFragmentShader(Identifier.of("xvisuals","core/world_effect"))
          .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER)
          .withUniform("Projection",UniformType.UNIFORM_BUFFER).withSampler("Sampler0")
          .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS)
          .withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
          .withDepthWrite(false).withCull(false).build()).texture("Sampler0",Identifier.of("xvisuals","textures/crafted/effects.png")).translucent().expectedBufferSize(1048576).build());
  private static final RenderLayer BUBBLES=RenderLayerAccessor.visuals$of("xvisuals_bubbles",
      RenderSetup.builder(RenderPipeline.builder()
          .withLocation(Identifier.of("xvisuals","pipeline/prism_bubble"))
          .withVertexShader(Identifier.of("xvisuals","core/world_effect"))
          .withFragmentShader(Identifier.of("xvisuals","core/prism_bubble"))
          .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER)
          .withUniform("Projection",UniformType.UNIFORM_BUFFER).withSampler("Sampler0")
          .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS)
          .withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
          .withDepthWrite(false).withCull(false).build()).texture("Sampler0",Identifier.of("xvisuals","textures/crafted/effects.png")).translucent().expectedBufferSize(4096).build());
  private static Object world;
  private static final RenderLayer STRUCTURES=RenderLayerAccessor.visuals$of("xvisuals_world_structures",
      RenderSetup.builder(RenderPipeline.builder()
          .withLocation(Identifier.of("xvisuals","pipeline/world_structure"))
          .withVertexShader(Identifier.of("xvisuals","core/world_effect"))
          .withFragmentShader(Identifier.of("xvisuals","core/world_structure"))
          .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER)
          .withUniform("Projection",UniformType.UNIFORM_BUFFER).withSampler("Sampler0")
          .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS)
          .withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
          .withDepthWrite(false).withCull(false).build()).texture("Sampler0",Identifier.of("xvisuals","textures/crafted/effects.png")).translucent().expectedBufferSize(131072).build());
  private static int cursor;
  private static Vec3d camera=Vec3d.ZERO,right=new Vec3d(1,0,0),up=new Vec3d(0,1,0);
  private static VertexConsumer out;
  private static Matrix4f matrix;
  public static int renderedQuads;
  private static int artworkFrame;
  private static final Vec3d X=new Vec3d(1,0,0),Y=new Vec3d(0,1,0),Z=new Vec3d(0,0,1);
  private static final class Instance {
    final WorldEffectKind kind; final Vec3d anchor; final double phase,life,variation,born;
    double age, sortDistance, renderAge; double clearance=1, previousClearance=1;
    double retiredAt=-1;
    Vec3d renderPosition;
    Vec3d[] gardenVertices; double[] gardenLighting; double gardenSize=-1;
    Instance(WorldEffectKind kind,Vec3d anchor) {
      this.kind=kind;this.anchor=anchor;born=CLOCK.seconds();phase=RANDOM.nextDouble()*Math.PI*2;
      life=kind.grounded?18+RANDOM.nextDouble()*10:9+RANDOM.nextDouble()*7;
      variation=.8+RANDOM.nextDouble()*.4;
    }
  }
  public static void init() {
    WorldRenderEvents.END_MAIN.register(c -> render(c.matrices()));
    net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING.register(c -> ALLOCATOR.close());
  }
  public static void tick(MinecraftClient c) {
    if(c.world!=world) { ACTIVE.clear(); DRAW_ORDER.clear(); CLOCK.reset(); world=c.world; cursor=0; }
    if(c.world==null || c.player==null) { ACTIVE.clear(); return; }
    int enabled=0; for(var kind:KINDS) if(XVisuals.config().on(kind.id)) enabled++;
    if(enabled==0) { ACTIVE.clear(); return; }
    double now=CLOCK.advance(System.nanoTime(),c.isPaused());
    if(c.isPaused()) return;
    int[] counts=new int[KINDS.length],caps=new int[KINDS.length];
    for(var kind:KINDS) {
      var s=XVisuals.config().module(kind.id);
      caps[kind.ordinal()]=s.enabled && (!s.flag("night") || ShootingStars.nightVisibility(c.world.getTimeOfDay())>.02)
          ? WorldEffectKind.budget(s.integer("count"),Quality.factor(),enabled,kind==WorldEffectKind.LEAVES?160:32):0;
    }
    Vec3d player=c.player.getEntityPos();
    ACTIVE.removeIf(p -> {
      p.previousClearance=p.clearance;
      p.age=now-p.born;
      if(!p.kind.grounded) {
        var state=XVisuals.config().module(p.kind.id);
        Vec3d at=position(p,p.age*state.number("speed"));
        // Begin fading before the falling leaf intersects a surface; never flicker in and out.
        if(p.clearance<1 || !c.world.getBlockState(BlockPos.ofFloored(at.add(0,-.2,0))).isAir()
            || !c.world.getBlockState(BlockPos.ofFloored(at)).isAir()) p.clearance=Math.max(0,p.clearance-.2);
      }
      var settings=XVisuals.config().module(p.kind.id);
      double radius=settings.number("radius")+5;
      Vec3d current=position(p,p.age*settings.number("speed"));
      return (p.retiredAt>=0 && now-p.retiredAt>=.6) || p.clearance<=0 || p.age>=p.life || player.squaredDistanceTo(current)>radius*radius
          || !c.world.isChunkLoaded(MathHelper.floor(p.anchor.x)>>4,MathHelper.floor(p.anchor.z)>>4)
          || (p.retiredAt<0 && ++counts[p.kind.ordinal()]>caps[p.kind.ordinal()]);
    });
    int[][] sectors=new int[KINDS.length][4];
    Arrays.fill(counts,0);
    for(var p:ACTIVE) if(p.retiredAt<0) {
      counts[p.kind.ordinal()]++;
      Vec3d at=position(p,p.age*XVisuals.config().module(p.kind.id).number("speed")).subtract(player);
      sectors[p.kind.ordinal()][WorldEffectDistribution.sector(at.x,at.z)]++;
    }
    // Moving must replenish the newly entered space, rather than leaving the entire budget behind.
    for(var kind:KINDS) {
      int k=kind.ordinal(),least=WorldEffectDistribution.least(sectors[k],cursor%4);
      if(counts[k]<caps[k] || sectors[k][least]>=caps[k]/4)continue;
      if(ACTIVE.stream().anyMatch(p->p.kind==kind && p.retiredAt>=0))continue;
      for(var p:ACTIVE) if(p.kind==kind && p.retiredAt<0) {
        Vec3d at=position(p,p.age*XVisuals.config().module(kind.id).number("speed")).subtract(player);
        int sector=WorldEffectDistribution.sector(at.x,at.z);
        if(sectors[k][sector]>Math.max(1,caps[k]/4)) {
          p.retiredAt=now;sectors[k][sector]--;counts[k]--;break;
        }
      }
    }
    // Round-robin allocation prevents a busy first module starving later modules.
    int attempts=0;
    for(int i=0;i<KINDS.length*4 && attempts<12;i++) {
      var kind=KINDS[(cursor+i)%KINDS.length];
      if(counts[kind.ordinal()]>=caps[kind.ordinal()]) continue;
      attempts++;
      var s=XVisuals.config().module(kind.id);
      int sector=WorldEffectDistribution.least(sectors[kind.ordinal()],(cursor+i)%4);
      double angle=WorldEffectDistribution.angle(sector,RANDOM.nextDouble());
      double radius=WorldEffectDistribution.radius(s.number("radius"),RANDOM.nextDouble());
      Vec3d pos=player.add(Math.cos(angle)*radius,1+RANDOM.nextDouble()*3,Math.sin(angle)*radius);
      BlockPos block=BlockPos.ofFloored(pos);
      if(!c.world.isChunkLoaded(block.getX()>>4,block.getZ()>>4)) continue;
      if(kind.grounded) {
        var hit=c.world.raycast(new RaycastContext(pos.add(0,3,0),pos.add(0,-14,0),RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,c.player));
        if(hit.getType()!=HitResult.Type.BLOCK || hit.getSide()!=Direction.UP) continue;
        pos=hit.getPos().add(0,.025,0);
        if(!c.world.getFluidState(BlockPos.ofFloored(pos)).isEmpty()) continue;
        if(!supported(c,pos,kind.size*s.number("size"))) continue;
        boolean crowded=false;
        for(var existing:ACTIVE)if(existing.kind.grounded&&existing.retiredAt<0){
          double separation=(kind.size*s.number("size")+existing.kind.size*XVisuals.config().module(existing.kind.id).number("size"))*1.15;
          if(existing.anchor.squaredDistanceTo(pos)<separation*separation){crowded=true;break;}
        }
        if(crowded)continue;
      } else if(!c.world.getBlockState(block).isAir()) continue;
      ACTIVE.add(new Instance(kind,pos)); counts[kind.ordinal()]++;sectors[kind.ordinal()][sector]++;
    }
    cursor=(cursor+1)%KINDS.length;
  }
  private static boolean supported(MinecraftClient c,Vec3d p,double size) {
    for(int i=0;i<4;i++) {
      double x=p.x+(i%2==0?-1:1)*size*.6,z=p.z+(i<2?-1:1)*size*.6;
      if(!c.world.isChunkLoaded(MathHelper.floor(x)>>4,MathHelper.floor(z)>>4)) return false;
      var hit=c.world.raycast(new RaycastContext(new Vec3d(x,p.y+.2,z),new Vec3d(x,p.y-.3,z),
          RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,c.player));
      if(hit.getType()!=HitResult.Type.BLOCK || hit.getSide()!=Direction.UP || Math.abs(hit.getPos().y+.025-p.y)>.08) return false;
    }
    return true;
  }
  private static Vec3d position(Instance p,double t) {
    double a=p.phase;
    return switch(p.kind) {
      case LEAVES -> p.anchor.add(LeafMotion.x(t,a),LeafMotion.y(t,a),LeafMotion.z(t,a));
      case PETALS -> p.anchor.add(PetalMotion.x(t,a),PetalMotion.y(t,a),PetalMotion.z(t,a));
      case FROST -> p.anchor.add(Math.sin(t*.65+a)*.9,-t*.17,Math.cos(t*.43+a)*.65);
      case EMBERS -> p.anchor.add(Math.sin(t+a)*.45,t*.20,Math.cos(t*.7+a)*.45);
      case BUBBLES -> p.anchor.add(Math.sin(t*.45+a)*.4,t*.13,Math.cos(t*.4+a)*.4);
      case MOTHS -> p.anchor.add(Math.sin(t*1.2+a)*1.2,Math.sin(t*.9+a)*.55,Math.cos(t*.8+a)*.9);
      case SOULS -> p.anchor.add(Math.sin(t*.7+a)*1.2,Math.sin(t*.9+a)*.6,Math.cos(t*.8+a)*1.2);
      case DUST,SHARDS -> p.anchor.add(Math.sin(t*.3+a)*.45,Math.sin(t*.6+a)*.3,Math.cos(t*.4+a)*.4);
      default -> p.anchor;
    };
  }
  private static void render(MatrixStack matrices) {
    var c=MinecraftClient.getInstance(); renderedQuads=0;
    if(c.world==null || c.world!=world || ACTIVE.isEmpty()) return;
    camera=c.gameRenderer.getCamera().getCameraPos();
    var rotation=c.gameRenderer.getCamera().getRotation();
    Vector3f r=new Vector3f(1,0,0).rotate(rotation),u=new Vector3f(0,1,0).rotate(rotation);
    right=new Vec3d(r.x,r.y,r.z);up=new Vec3d(u.x,u.y,u.z);
    double now=CLOCK.advance(System.nanoTime(),c.isPaused());
    double partial=c.getRenderTickCounter().getTickProgress(false);
    DRAW_ORDER.clear();boolean bubblesOnly=true,structuresOnly=true;
    Vec3d forward=up.crossProduct(right);
    for(var p:ACTIVE) {
      var settings=XVisuals.config().module(p.kind.id);
      if(!settings.enabled)continue;
      p.renderAge=Math.max(0,now-p.born);
      p.renderPosition=position(p,p.renderAge*settings.number("speed"));
      p.sortDistance=p.renderPosition.squaredDistanceTo(camera);
      double radius=settings.number("radius")+3;
      if(p.sortDistance>=radius*radius)continue;
      boolean structure=p.kind==WorldEffectKind.GARDENS || p.kind==WorldEffectKind.PILLARS;
      if(structure) {
        double size=p.kind.size*settings.number("size")*p.variation;
        // Conservative sphere contains the tallest shaft and every crystal tip.
        Vec3d center=p.renderPosition.add(0,2*size,0);
        if(center.subtract(camera).dotProduct(forward)<-2.3*size)continue;
      }
      if(p.kind==WorldEffectKind.BUBBLES) {
        // Entire billboard is behind the eye: omit it before sorting/buffering.
        if(p.renderPosition.subtract(camera).dotProduct(forward)<0)continue;
      } else bubblesOnly=false;
      if(!structure)structuresOnly=false;
      DRAW_ORDER.add(p);
    }
    if(DRAW_ORDER.isEmpty())return;
    DRAW_ORDER.sort(Comparator.comparingDouble((Instance p)->p.sortDistance).reversed());
    matrices.push();matrix=matrices.peek().getPositionMatrix();
    // Keep mixed transparent effects in one ordered batch. The common bubbles-only
    // case avoids compiling/executing the multi-effect fragment program entirely.
    out=BUFFERS.getBuffer(bubblesOnly?BUBBLES:structuresOnly?STRUCTURES:LAYER);
    for(var p:DRAW_ORDER) {
      var s=XVisuals.config().module(p.kind.id);if(!s.enabled) continue;
      double age=p.renderAge,t=age*s.number("speed"),size=p.kind.size*s.number("size")*p.variation;
      Vec3d pos=p.renderPosition; double distance=Math.sqrt(p.sortDistance);
      double clearance=p.previousClearance+(p.clearance-p.previousClearance)*partial;
      double alpha=clearance*WorldEffectKind.fade(age,p.life)*s.number("opacity")
          *WorldEffectKind.smooth((s.number("radius")+3-distance)/4)*WorldEffectKind.smooth((distance-1.1)/1.7);
      if(p.retiredAt>=0)alpha*=WorldEffectKind.smooth(1-(now-p.retiredAt)/.6);
      if(s.flag("night")) alpha*=ShootingStars.nightVisibility(c.world.getTimeOfDay());
      if(alpha<.005) continue;
      int primary=Colors.alpha(s.flag("customColors")?s.color("color"):Colors.parse(p.kind.primary),alpha),secondary=Colors.alpha(s.flag("customColors")?s.color("secondary"):Colors.parse(p.kind.secondary),alpha);
      draw(p,pos,t,size,primary,secondary);
      if(renderedQuads>=8192) break;
    }
    BUFFERS.draw();matrices.pop();
  }
  private static void draw(Instance p,Vec3d pos,double t,double s,int color,int highlight) {
    artworkFrame=XVisuals.config().module("performance").text("animation").equals("Off")?0:Math.floorMod((int)(t*8),8);
    double a=t*.5+p.phase;
    switch(p.kind) {
      case LEAVES -> {
        double yaw=p.phase+t*.38,tilt=.65+Math.sin(t*1.3+p.phase)*.55;
        Vec3d r=new Vec3d(Math.cos(yaw),0,Math.sin(yaw));
        Vec3d u=new Vec3d(-Math.sin(yaw)*Math.sin(tilt),Math.cos(tilt),Math.cos(yaw)*Math.sin(tilt));
        int leafColor=(color&0xFF000000)|(Colors.mix(color,highlight,(p.variation-.8)/.4)&0xFFFFFF);
        quad(pos,r.multiply(s*.75),u.multiply(s),1,leafColor);
      }
      case PETALS -> {
        // A world-space plane: turning the camera must not rotate the petal itself.
        double yaw=p.phase+t*.32,tilt=.55+Math.sin(t*1.1+p.phase)*.38;
        Vec3d r=new Vec3d(Math.cos(yaw),0,Math.sin(yaw));
        Vec3d u=new Vec3d(-Math.sin(yaw)*Math.sin(tilt),Math.cos(tilt),Math.cos(yaw)*Math.sin(tilt));
        quad(pos,r.multiply(s*.8),u.multiply(s),0,color);
      }
      case FROST -> {
        double angle=a;
        Vec3d r=new Vec3d(Math.cos(angle),0,Math.sin(angle));
        Vec3d u=new Vec3d(-Math.sin(angle)*.45,.893,Math.cos(angle)*.45);
        quad(pos,r.multiply(s*(.45+.55*Math.abs(Math.cos(a)))),u.multiply(s),p.kind.ordinal(),color);
      }
      case EMBERS -> { billboard(pos,s*.6,s*1.4,3,color); billboard(pos,s*.28,s*.28,5,highlight); }
      case BUBBLES -> billboard(pos,s,s,4,color);
      case DUST -> {
        billboard(pos,s,s,5,fadeColor(color,.55+.45*Math.sin(a)*Math.sin(a)));
        for(int i=0;i<3;i++) billboard(pos.add(Math.cos(a+i*2.1)*s*2,Math.sin(a+i*2.1)*s*2,0),s*.2,s*.2,5,highlight);
      }
      case SHARDS -> crystal(pos,s,s*2,a,color,highlight);
      case MOTHS -> {
        double flap=.22+.78*Math.abs(Math.sin(t*8+p.phase));
        quad(pos.add(right.multiply(-s*flap*.5)),right.multiply(s*flap*.55),up.multiply(s),6,color);
        quad(pos.add(right.multiply(s*flap*.5)),right.multiply(-s*flap*.55),up.multiply(s),6,color);
        billboard(pos,s*.12,s*.65,3,highlight);
      }
      case SOULS -> {
        Vec3d last=pos;
        for(int i=1;i<=9;i++) {
          Vec3d next=position(p,Math.max(0,t-i*.09));
          line(last,next,s*.45*(1-i/10.0),fadeColor(color,(1-i/10.0)*.6));last=next;
        }
        billboard(pos,s,s,13,color);billboard(pos,s*.28,s*.28,5,highlight);
      }
      case RUNES -> ground(pos,s,a,8,color);
      case GARDENS -> {
        if(p.gardenVertices==null || p.gardenSize!=s)cacheGarden(p,pos,s);
        int base=(color&0xFF000000)|(Colors.mix(color,highlight,.28)&0xFFFFFF);
        for(int face=0;face<40;face++) {
          int shaded=shade(base,p.gardenLighting[face]);
          if((face&1)!=0)shaded=shade(shaded,.65);
          int v=face*3;
          emit(p.gardenVertices[v],p.gardenVertices[v+1],p.gardenVertices[v+2],p.gardenVertices[v+2],12,shaded);
        }
      }
      case LEY -> {
        for(int branch=0;branch<3;branch++) {
          double angle=p.phase+branch*Math.PI*2/3;Vec3d last=pos;
          for(int j=1;j<=5;j++) {
            Vec3d next=pos.add(Math.cos(angle)*s*j/4+Math.sin(angle)*Math.sin(j*1.4)*s*.16,0,
                Math.sin(angle)*s*j/4-Math.cos(angle)*Math.sin(j*1.4)*s*.16);
            groundRibbon(last,next,s*.035,color);
            double flow=(t*.6+branch*.23)%1;
            if(flow>=(j-1)/5.0 && flow<j/5.0) billboard(last.lerp(next,flow*5-(j-1)),s*.07,s*.07,5,highlight);
            last=next;
          }
        }
      }
      case PILLARS -> {
        ground(pos,s*.55,a*.08,8,fadeColor(color,.45));
        quad(pos.add(0,s*2,0),X.multiply(s*.3),Y.multiply(s*2),11,color);
        quad(pos.add(0,s*2,0),Z.multiply(s*.3),Y.multiply(s*2),11,color);
        for(int i=0;i<4;i++) billboard(pos.add(Math.cos(a+i)*s*.35,((t*.6+i)*.7%3)*s,Math.sin(a+i)*s*.35),s*.06,s*.15,3,highlight);
      }
      case RIFTS -> {
        double pulse=Math.pow(.5+.5*Math.sin(t*2.8+p.phase),10);
        if(pulse<.04) break;
        Vec3d last=pos.add(0,s*.3,0);
        for(int i=1;i<=9;i++) {
          Vec3d next=pos.add(Math.sin(i*19.1+p.phase)*s*.3,s*(.3+i*.27),Math.cos(i*8.7+p.phase)*s*.12);
          line(last,next,s*.12,fadeColor(color,pulse*.25));line(last,next,s*.023,fadeColor(highlight,pulse));
          if(i==4 || i==7) line(next,next.add(s*.6,s*.22,-s*.2),s*.015,fadeColor(color,pulse));last=next;
        }
      }
    }
  }
  private static int fadeColor(int color,double factor) { return Colors.alpha(color,(color >>> 24)/255.0*factor); }
  private static void cacheGarden(Instance p,Vec3d pos,double size) {
    p.gardenSize=size;p.gardenVertices=new Vec3d[120];p.gardenLighting=new double[40];
    for(int i=0;i<5;i++) {
      double angle=p.phase+i*2.399,h=size*(i==0?1.5:.55+.12*i),radius=size*.15;
      Vec3d center=pos.add(Math.cos(angle)*size*.35,h*.5,Math.sin(angle)*size*.35);
      Vec3d top=center.add(0,h*.5,0),bottom=center.add(0,-h*.325,0);
      for(int side=0;side<4;side++) {
        double a=angle+side*Math.PI/2,b=a+Math.PI/2;
        Vec3d v=center.add(Math.cos(a)*radius,0,Math.sin(a)*radius),w=center.add(Math.cos(b)*radius,0,Math.sin(b)*radius);
        int face=i*8+side*2,k=face*3;
        p.gardenVertices[k]=v;p.gardenVertices[k+1]=w;p.gardenVertices[k+2]=top;
        p.gardenVertices[k+3]=w;p.gardenVertices[k+4]=v;p.gardenVertices[k+5]=bottom;
        p.gardenLighting[face]=p.gardenLighting[face+1]=.48+.52*Math.max(0,Math.cos(a+Math.PI/4-.8));
      }
    }
  }
  private static void ground(Vec3d p,double s,double a,int mode,int color) {
    quad(p,new Vec3d(Math.cos(a)*s,0,Math.sin(a)*s),new Vec3d(-Math.sin(a)*s,0,Math.cos(a)*s),mode,color);
  }
  private static void billboard(Vec3d p,double w,double h,int mode,int color) { quad(p,right.multiply(w),up.multiply(h),mode,color); }
  private static void line(Vec3d a,Vec3d b,double width,int color) {
    if(a.squaredDistanceTo(b)<.000001) return;
    Vec3d side=b.subtract(a).crossProduct(camera.subtract(a)).normalize().multiply(width);
    emit(a.subtract(side),b.subtract(side),b.add(side),a.add(side),10,color);
  }
  private static void groundRibbon(Vec3d a,Vec3d b,double width,int color) {
    Vec3d d=b.subtract(a);if(d.lengthSquared()<.000001)return;
    Vec3d side=new Vec3d(-d.z,0,d.x).normalize().multiply(width*3);
    a=a.add(0,.035,0);b=b.add(0,.035,0);
    emit(a.subtract(side),b.subtract(side),b.add(side),a.add(side),10,color);
  }
  private static void crystal(Vec3d p,double radius,double height,double angle,int color,int highlight) {
    for(int i=0;i<4;i++) {
      double a=angle+i*Math.PI/2,b=a+Math.PI/2;
      Vec3d v=p.add(Math.cos(a)*radius,0,Math.sin(a)*radius),w=p.add(Math.cos(b)*radius,0,Math.sin(b)*radius);
      double lighting=.48+.52*Math.max(0,Math.cos(a+Math.PI/4-.8));
      int shade=shade((color & 0xFF000000) | (Colors.mix(color,highlight,.28) & 0xFFFFFF),lighting);
      emit(v,w,p.add(0,height,0),p.add(0,height,0),12,shade);
      emit(w,v,p.add(0,-height*.65,0),p.add(0,-height*.65,0),12,shade(shade,.65));
    }
  }
  private static int shade(int color,double light) {
    return (color & 0xFF000000) | ((int)((color>>16&255)*light)<<16)
        | ((int)((color>>8&255)*light)<<8) | (int)((color&255)*light);
  }
  private static void quad(Vec3d p,Vec3d r,Vec3d u,int mode,int color) { emit(p.subtract(r).subtract(u),p.subtract(r).add(u),p.add(r).add(u),p.add(r).subtract(u),mode,color); }
  private static void emit(Vec3d a,Vec3d b,Vec3d c,Vec3d d,int mode,int color) {
    if(renderedQuads>=8192) return;renderedQuads++;
    vertex(a,mode*2,0,color);vertex(b,mode*2,1,color);vertex(c,mode*2+1,1,color);vertex(d,mode*2+1,0,color);
  }
  private static void vertex(Vec3d p,float u,float v,int color) { out.vertex(matrix,(float)(p.x-camera.x),(float)(p.y-camera.y),(float)(p.z-camera.z)).color(color).texture(u,v+artworkFrame*2); }
  public static int count() { return ACTIVE.size(); }
  public static int count(WorldEffectKind kind) { return (int)ACTIVE.stream().filter(p -> p.kind==kind).count(); }
  private WorldEffects() {}
}

