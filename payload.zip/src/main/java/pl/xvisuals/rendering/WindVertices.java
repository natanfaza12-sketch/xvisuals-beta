package pl.xvisuals.rendering;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.block.*;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.state.property.Properties;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.math.BlockPos;
/** Packs sway metadata into unused light-coordinate bits only for our native terrain shader. */
public final class WindVertices implements VertexConsumer {
 private final VertexConsumer delegate;private final int type;private final double root,height;private int weight;
 private WindVertices(VertexConsumer delegate,BlockState state,BlockPos p,int type){this.delegate=delegate;this.type=type;boolean tall=state.contains(Properties.DOUBLE_BLOCK_HALF);height=tall?2:1;root=(p.getY()&15)+(state.getModelOffset(p).y)-(tall&&state.get(Properties.DOUBLE_BLOCK_HALF)==DoubleBlockHalf.UPPER?1:0);}
 public static VertexConsumer wrap(VertexConsumer target,BlockState state,BlockPos p){if(!WindFX.nativeTerrain()||state==null)return target;int type=state.isIn(BlockTags.LEAVES)?2:state.getBlock() instanceof PlantBlock||state.getBlock() instanceof SugarCaneBlock?1:0;return type==0?target:new WindVertices(target,state,p,type);}
 public VertexConsumer vertex(float x,float y,float z){weight=type==2?127:WindMath.weight(y-root,height);delegate.vertex(x,y,z);return this;}
 public VertexConsumer color(int r,int g,int b,int a){delegate.color(r,g,b,a);return this;}
 public VertexConsumer color(int c){delegate.color(c);return this;}
 public VertexConsumer texture(float u,float v){delegate.texture(u,v);return this;}
 public VertexConsumer overlay(int u,int v){delegate.overlay(u,v);return this;}
 public VertexConsumer light(int u,int v){delegate.light((u&255)|(type<<8),(v&255)|(weight<<8));return this;}
 public VertexConsumer normal(float x,float y,float z){delegate.normal(x,y,z);return this;}
 public VertexConsumer lineWidth(float w){delegate.lineWidth(w);return this;}
}
