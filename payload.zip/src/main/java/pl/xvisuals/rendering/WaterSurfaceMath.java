package pl.xvisuals.rendering;
/** Shared mesh limits and shoreline anchoring. No changes to fluid simulation. */
public final class WaterSurfaceMath {
 public static int subdivisions(String quality){return quality.equals("High")?3:quality.equals("Low")?1:2;}
 public static int radius(double requested,String quality){return (int)Math.max(4,Math.min(requested,quality.equals("High")?24:quality.equals("Low")?12:18));}
 public static double cornerWeight(double x,double z,boolean nw,boolean ne,boolean sw,boolean se){
  double north=(nw?1:0)*(1-x)+(ne?1:0)*x,south=(sw?1:0)*(1-x)+(se?1:0)*x;
  return Math.max(north*(1-z)+south*z,4.8*x*(1-x)*z*(1-z));
 }
 private WaterSurfaceMath(){}
}
