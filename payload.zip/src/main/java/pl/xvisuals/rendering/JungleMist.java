package pl.xvisuals.rendering;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.*;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import java.nio.*;
import java.util.*;

/** Local depth-softened tropical ground mist; no world changes. */
public final class JungleMist {
 private static final List<Puff> PARTICLES=new ArrayList<>();private static final Random RANDOM=new Random();
 private static final ByteBuffer VERTICES=ByteBuffer.allocateDirect(144*6*24).order(ByteOrder.nativeOrder());
 private static MappableRingBuffer vertices;private static Object world;private static int ticks;private static double blend,clock;private static boolean failed;
 private static final Matrix4f OPTIONS=new Matrix4f();private static final Vector4f WHITE=new Vector4f(1,1,1,1);private static final Vector3f ZERO=new Vector3f();
 private static final RenderPipeline PIPELINE=RenderPipeline.builder().withLocation(Identifier.of("xvisuals","pipeline/jungle_mist"))
  .withVertexShader(Identifier.of("xvisuals","core/lavafall_mist")).withFragmentShader(Identifier.of("xvisuals","core/lavafall_mist"))
  .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER).withUniform("Fog",UniformType.UNIFORM_BUFFER).withSampler("SceneDepth")
  .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.TRIANGLES).withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).build();
 private static class Puff {Vec3d pos,previous;double size,life,phase;int age;boolean haze;}
 public static void init(){ClientTickEvents.END_CLIENT_TICK.register(JungleMist::tick);WorldRenderEvents.END_MAIN.register(c->render(c.matrices()));ClientLifecycleEvents.CLIENT_STOPPING.register(c->clear());}
 private static boolean enabled(){return XVisuals.ready()&&XVisuals.visualModule("junglemist").enabled;}
 private static void clear(){PARTICLES.clear();blend=0;clock=0;failed=false;if(vertices!=null){vertices.close();vertices=null;}}
 private static boolean jungle(MinecraftClient c,BlockPos p){return JungleMistMath.supported(c.world.getBiome(p).getKey().map(k->k.getValue().toString()).orElse(""));}
 private static boolean shaderPack(){return ShaderPackSupport.active();}
 private static void tick(MinecraftClient c){
  if(world!=c.world||!enabled()){world=c.world;clear();}
  if(!enabled()||c.world==null||c.player==null||c.isPaused())return;
  if(shaderPack()){clear();return;}ticks++;
  var camera=c.gameRenderer.getCamera().getCameraPos();boolean active=jungle(c,c.player.getBlockPos());blend=JungleMistMath.approach(blend,active);
  var s=XVisuals.visualModule("junglemist");clock+=.05*s.number("speed");int cap=JungleMistMath.cap(s.text("quality"));double radius=s.number("distance");var wind=AtmosphericWind.sample(ticks*.05);
  for(var it=PARTICLES.iterator();it.hasNext();){var p=it.next();p.previous=p.pos;p.age++;
   if(p.age>=p.life||p.pos.squaredDistanceTo(camera)>radius*radius||p.haze&&!s.flag("haze")){it.remove();continue;}
   var next=p.pos.add((wind.x()*.3+Math.sin(p.phase+ticks*.015)*.08)*.05*s.number("speed"),0,(wind.z()*.3+Math.cos(p.phase+ticks*.012)*.08)*.05*s.number("speed"));
   var block=BlockPos.ofFloored(next);if(!c.world.isChunkLoaded(block.getX()>>4,block.getZ()>>4)){it.remove();continue;}
   var hit=c.world.raycast(new RaycastContext(p.pos,next,RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,c.player));
   if(hit.getType()==HitResult.Type.MISS)p.pos=next;else p.life=Math.min(p.life,p.age+20);
  }
  while(PARTICLES.size()>cap)PARTICLES.removeFirst();
  if(!active||s.number("density")<=0||PARTICLES.size()>=cap)return;
  // Fixed work budget: at most four loaded columns, 25 blocks each, per tick.
  for(int attempt=0;attempt<4&&PARTICLES.size()<cap;attempt++){
   double angle=RANDOM.nextDouble()*Math.PI*2,dist=Math.sqrt(RANDOM.nextDouble())*(radius-3);
   var start=BlockPos.ofFloored(camera.x+Math.cos(angle)*dist,camera.y+6,camera.z+Math.sin(angle)*dist);
   if(!c.world.isChunkLoaded(start.getX()>>4,start.getZ()>>4)||!jungle(c,start))continue;
   for(int dy=0;dy<25;dy++){
    var ground=start.down(dy);var state=c.world.getBlockState(ground);
    if(state.isIn(net.minecraft.registry.tag.BlockTags.LEAVES)||state.isIn(net.minecraft.registry.tag.BlockTags.LOGS))continue;
    var shape=state.getCollisionShape(c.world,ground);if(shape.isEmpty())continue;
    double base=ground.getY()+shape.getMax(Direction.Axis.Y);boolean haze=s.flag("haze")&&RANDOM.nextInt(3)==0;
    double height=s.number("height");var pos=new Vec3d(ground.getX()+.5,base+.2+RANDOM.nextDouble()*height*(haze?.8:.25),ground.getZ()+.5);
    var at=BlockPos.ofFloored(pos);if(!c.world.getBlockState(at).getCollisionShape(c.world,at).isEmpty()||!c.world.getFluidState(at).isEmpty())break;
    if(c.world.raycast(new RaycastContext(new Vec3d(pos.x,base+.02,pos.z),pos,RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,c.player)).getType()!=HitResult.Type.MISS)break;
    var p=new Puff();p.pos=p.previous=pos;p.size=(haze?3:2)+RANDOM.nextDouble()*2;p.life=160+RANDOM.nextInt(100);p.phase=RANDOM.nextDouble()*6.283;p.haze=haze;PARTICLES.add(p);break;
   }
  }
 }
 private static void vertex(Vec3d p,float u,float v,int rgb,double alpha){VERTICES.putFloat((float)p.x).putFloat((float)p.y).putFloat((float)p.z).putFloat(u).putFloat(v).put((byte)(rgb>>16)).put((byte)(rgb>>8)).put((byte)rgb).put((byte)(Math.clamp(alpha,0,1)*255));}
 private static void render(MatrixStack matrices){
  var c=MinecraftClient.getInstance();if(!enabled()||shaderPack()||world!=c.world||c.world==null||failed||PARTICLES.isEmpty()||!CameraEnvironment.surface()||c.getFramebuffer().getDepthAttachmentView()==null)return;
  var s=XVisuals.visualModule("junglemist");var camera=c.gameRenderer.getCamera().getCameraPos();float delta=c.getRenderTickCounter().getTickProgress(false);
  var q=c.gameRenderer.getCamera().getRotation();var rr=new Vector3f(1,0,0).rotate(q);var uu=new Vector3f(0,1,0).rotate(q);var right=new Vec3d(rr.x,rr.y,rr.z);var up=new Vec3d(uu.x,uu.y,uu.z);
  PARTICLES.sort(Comparator.comparingDouble((Puff p)->-p.pos.squaredDistanceTo(camera)));VERTICES.clear();int tint=s.color("color");
  for(var p:PARTICLES){double age=p.age+delta,t=age/p.life,alpha=LavafallMistMath.fade(age,p.life)*JungleMistMath.fade(p.pos.distanceTo(camera),s.number("distance"))*blend*s.number("density");if(alpha<.002)continue;
   var pos=p.previous.lerp(p.pos,delta).subtract(camera);double size=p.size*(1+t*.25);int color=tint;alpha*=p.haze?.055:.14;
   double angle=Math.sin(p.phase+.0015*age)*.08,cos=Math.cos(angle),sin=Math.sin(angle);var r=right.multiply(cos).add(up.multiply(sin)).multiply(size);var u=up.multiply(cos).subtract(right.multiply(sin)).multiply(Math.min(s.number("height")*.55,size*.45));
   int seed=(int)(p.phase*8);float base=seed*8;
   var a=pos.subtract(r).subtract(u);var b=pos.add(r).subtract(u);var d=pos.subtract(r).add(u);var e=pos.add(r).add(u);
   vertex(a,base,1,color,alpha);vertex(b,base+1,1,color,alpha);vertex(e,base+1,0,color,alpha);vertex(a,base,1,color,alpha);vertex(e,base+1,0,color,alpha);vertex(d,base,0,color,alpha);
  }
  int count=VERTICES.position()/24;if(count==0)return;VERTICES.flip();
  try{
   if(vertices==null)vertices=new MappableRingBuffer(()->"Jungle mist",GpuBuffer.USAGE_VERTEX|GpuBuffer.USAGE_COPY_DST|GpuBuffer.USAGE_MAP_WRITE,VERTICES.capacity());
   var buffer=vertices.getBlocking();var encoder=RenderSystem.getDevice().createCommandEncoder();encoder.writeToBuffer(buffer.slice(0,VERTICES.remaining()),VERTICES);
   OPTIONS.identity().m00((float)(clock+delta*.05*s.number("speed"))).m01(0);var transform=RenderSystem.getDynamicUniforms().write(new Matrix4f(RenderSystem.getModelViewMatrix()).mul(matrices.peek().getPositionMatrix()),WHITE,ZERO,OPTIONS);
   try(var pass=encoder.createRenderPass(()->"Jungle mist and humidity",c.getFramebuffer().getColorAttachmentView(),OptionalInt.empty())){
    pass.setPipeline(PIPELINE);RenderSystem.bindDefaultUniforms(pass);pass.setUniform("DynamicTransforms",transform);pass.bindTexture("SceneDepth",c.getFramebuffer().getDepthAttachmentView(),RenderSystem.getSamplerCache().get(com.mojang.blaze3d.textures.FilterMode.NEAREST));pass.setVertexBuffer(0,buffer);pass.draw(0,count);
   }vertices.rotate();
  }catch(RuntimeException ex){failed=true;org.slf4j.LoggerFactory.getLogger("VisualClient").warn("Jungle Mist rendering unavailable",ex);}
 }
 private JungleMist(){}
}
