package pl.xvisuals.rendering;
/** Smooth, spawn-relative petal flight with no camera dependence or quantised turns. */
public final class PetalMotion {
 public static double x(double t,double phase){return .7*(Math.sin(t*.65+phase)-Math.sin(phase))+.08*t;}
 public static double y(double t,double phase){return -.17*t+.035*(Math.sin(t*1.3+phase)-Math.sin(phase));}
 public static double z(double t,double phase){return .5*(Math.cos(t*.43+phase)-Math.cos(phase));}
 private PetalMotion(){}
}
