package pl.xvisuals.rendering;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.*;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import java.nio.*;
import java.util.*;

/** Bounded local vapor simulation. Draws soft depth-tested billboards, never real light or lava. */
public final class LavafallMist {
 private record Source(Vec3d pos,double strength){}
 private static final Map<BlockPos,Source> SOURCES=new HashMap<>();
 private static final List<Puff> PARTICLES=new ArrayList<>();private static final Random RANDOM=new Random();
 private static final ByteBuffer VERTICES=ByteBuffer.allocateDirect(192*6*24).order(ByteOrder.nativeOrder());
 private static MappableRingBuffer vertices;private static Object world;private static BlockPos origin;private static int cursor,nearCursor,ticks,range;private static double vaporCredit,emberCredit;private static boolean failed;
 private static final Matrix4f OPTIONS=new Matrix4f();private static final Vector4f WHITE=new Vector4f(1,1,1,1);private static final Vector3f ZERO=new Vector3f();
 private static final RenderPipeline PIPELINE=RenderPipeline.builder().withLocation(Identifier.of("xvisuals","pipeline/lavafall_mist"))
  .withVertexShader(Identifier.of("xvisuals","core/lavafall_mist")).withFragmentShader(Identifier.of("xvisuals","core/lavafall_mist"))
  .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER).withUniform("Fog",UniformType.UNIFORM_BUFFER).withSampler("SceneDepth")
  .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.TRIANGLES).withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).build();
 private static class Puff {Vec3d pos,previous;double startY,size,life,phase,rise;int age;boolean ember,smoke,blocked;}
 public static void init(){ClientTickEvents.END_CLIENT_TICK.register(LavafallMist::tick);WorldRenderEvents.END_MAIN.register(c->render(c.matrices()));ClientLifecycleEvents.CLIENT_STOPPING.register(c->clear());}
 public static boolean enabled(){return XVisuals.ready()&&XVisuals.visualModule("lavafallmist").enabled;}
 public static boolean heatHaze(){return enabled()&&XVisuals.visualModule("lavafallmist").flag("haze");}
 private static void clear(){SOURCES.clear();PARTICLES.clear();origin=null;cursor=nearCursor=0;vaporCredit=emberCredit=0;failed=false;if(vertices!=null){vertices.close();vertices=null;}}
 private static Source source(MinecraftClient c,BlockPos p){
  if(!c.world.isChunkLoaded(p.getX()>>4,p.getZ()>>4))return null;var fluid=c.world.getFluidState(p);if(!fluid.isIn(FluidTags.LAVA))return null;
  boolean falling=fluid.contains(Properties.FALLING)&&fluid.get(Properties.FALLING);Vec3d at=null;
  var above=p.up();if(!c.world.getFluidState(above).isIn(FluidTags.LAVA)&&c.world.getBlockState(above).getCollisionShape(c.world,above).isEmpty())at=new Vec3d(p.getX()+.5,p.getY()+fluid.getHeight(c.world,p)+.07,p.getZ()+.5);
  if(at==null&&falling){for(var d:Direction.Type.HORIZONTAL){var side=p.offset(d);if(c.world.isChunkLoaded(side.getX()>>4,side.getZ()>>4)&&c.world.getBlockState(side).isAir()){at=Vec3d.ofCenter(p).add(d.getOffsetX()*.63,0,d.getOffsetZ()*.63);break;}}}
  if(at==null)return null;
  var below=c.world.getFluidState(p.down());boolean impact=falling&&(!c.world.getBlockState(p.down()).getCollisionShape(c.world,p.down()).isEmpty()||below.isIn(FluidTags.LAVA)&&(!below.contains(Properties.FALLING)||!below.get(Properties.FALLING)));
  int height=0,neighbours=0;if(impact)for(int y=1;y<=12;y++){if(!c.world.getFluidState(p.up(y)).isIn(FluidTags.LAVA))break;height++;}
  for(var d:Direction.Type.HORIZONTAL){var q=p.offset(d);if(c.world.isChunkLoaded(q.getX()>>4,q.getZ()>>4)&&c.world.getFluidState(q).isIn(FluidTags.LAVA))neighbours++;}
  return new Source(at,LavafallMistMath.strength(impact,height,neighbours));
 }
 private static void tick(MinecraftClient c){
  if(world!=c.world||!enabled()){world=c.world;clear();}
  if(!enabled()||c.world==null||c.player==null||c.isPaused())return;if(shaderPack()){clear();return;}ticks++;
  var s=XVisuals.visualModule("lavafallmist");int cap=LavafallMistMath.cap(s.text("quality")),radius=(int)s.number("distance");var camera=c.gameRenderer.getCamera().getCameraPos();var center=BlockPos.ofFloored(camera);
  if(origin==null||range!=radius||origin.getSquaredDistance(center)>16){if(origin==null||origin.getSquaredDistance(center)>radius*radius)SOURCES.clear();origin=center;cursor=0;range=radius;}
  int diameter=radius*2+1,total=diameter*diameter*25,budget=cap*3;
  var farthest=new PriorityQueue<BlockPos>(Comparator.comparingDouble((BlockPos p)->p.getSquaredDistance(center)).reversed());farthest.addAll(SOURCES.keySet());
  for(int n=0;n<budget;n++){
   boolean near=n<budget/3;int index=near?nearCursor:cursor;int d=near?9:diameter,r=near?4:radius;
   var p=(near?center:origin).add(index%d-r,(index/d)%25-12,index/(d*25)-r);
   if(near)nearCursor=(nearCursor+1)%(9*9*25);else cursor=(cursor+1)%total;
   if(p.getSquaredDistance(center)>radius*radius)continue;var src=source(c,p);if(src==null){SOURCES.remove(p);continue;}
   if(!SOURCES.containsKey(p)&&SOURCES.size()>=cap*2){while(!farthest.isEmpty()&&!SOURCES.containsKey(farthest.peek()))farthest.poll();if(farthest.isEmpty()||p.getSquaredDistance(center)>=farthest.peek().getSquaredDistance(center))continue;SOURCES.remove(farthest.poll());}
   if(!SOURCES.containsKey(p))farthest.add(p);SOURCES.put(p,src);
  }
  if(ticks%10==0)for(var it=SOURCES.entrySet().iterator();it.hasNext();){var entry=it.next();var refreshed=entry.getKey().getSquaredDistance(center)>radius*radius?null:source(c,entry.getKey());if(refreshed==null)it.remove();else entry.setValue(refreshed);}
  var wind=s.flag("wind")?AtmosphericWind.sample(ticks*.05):new AtmosphericWind.Flow(0,0);double speed=s.number("speed");int vapors=0,embers=0;
  for(var it=PARTICLES.iterator();it.hasNext();){var p=it.next();p.previous=p.pos;p.age++;if(p.age>=p.life||p.pos.squaredDistanceTo(camera)>radius*radius||p.pos.y-p.startY>s.number("height")){it.remove();continue;}
   if(p.ember)embers++;else vapors++;
   double flutter=Math.sin(p.age*.09+p.phase)*.06;
   var next=p.pos.add((wind.x()+flutter)*.05*speed,(p.blocked?0:p.rise)*.05*speed,(wind.z()+Math.cos(p.age*.065+p.phase)*.04)*.05*speed);var block=BlockPos.ofFloored(next);
   if(!c.world.isChunkLoaded(block.getX()>>4,block.getZ()>>4)){it.remove();continue;}
   var hit=c.world.raycast(new RaycastContext(p.pos,next,RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,c.player));
   if(hit.getType()!=HitResult.Type.MISS){p.pos=hit.getPos().add(hit.getSide().getOffsetX()*.025,hit.getSide().getOffsetY()*.025,hit.getSide().getOffsetZ()*.025);p.blocked=true;p.life=Math.min(p.life,p.age+15);}else p.pos=next;
  }
  while(PARTICLES.size()>cap)PARTICLES.removeFirst();if(SOURCES.isEmpty()){vaporCredit=emberCredit=0;return;}
  var sources=new ArrayList<>(SOURCES.values());double activity=Math.min(2.5,Math.pow(sources.size(),.23));
  vaporCredit=Math.min(4,vaporCredit+s.number("density")*.05*activity);emberCredit=Math.min(3,emberCredit+s.number("embers")*.05*activity);
  while(vaporCredit>=1){vaporCredit--;if(vapors>=cap*3/4||PARTICLES.size()>=cap)break;if(spawn(c,sources,false)){vapors++;}}
  while(emberCredit>=1){emberCredit--;if(embers>=cap/4||PARTICLES.size()>=cap)break;if(spawn(c,sources,true)){embers++;}}
 }
 private static boolean shaderPack(){return ShaderPackSupport.active();}
 private static boolean spawn(MinecraftClient c,List<Source> sources,boolean ember){
  var first=sources.get(RANDOM.nextInt(sources.size()));var second=sources.get(RANDOM.nextInt(sources.size()));var source=RANDOM.nextDouble()<.7?(first.strength>second.strength?first:second):first;
  var s=XVisuals.visualModule("lavafallmist");var pos=source.pos.add((RANDOM.nextDouble()-.5)*.35,0,(RANDOM.nextDouble()-.5)*.35);var block=BlockPos.ofFloored(pos);
  if(!c.world.getBlockState(block).getCollisionShape(c.world,block).isEmpty()||c.world.getFluidState(block).isIn(FluidTags.LAVA)&&!LavafallMistMath.aboveLava(pos.y-block.getY(),c.world.getFluidState(block).getHeight(c.world,block)))return false;
  var p=new Puff();p.pos=p.previous=pos;p.startY=pos.y;p.ember=ember;p.smoke=!ember&&s.flag("smoke")&&RANDOM.nextInt(4)==0;p.phase=RANDOM.nextDouble()*6.283;
  p.size=ember?s.number("size")*(.65+RANDOM.nextDouble()*.6):(.25+RANDOM.nextDouble()*.25)*Math.sqrt(source.strength);
  p.rise=(ember?.55:.32)*(1+source.strength*.12)*( .8+RANDOM.nextDouble()*.4);
  p.life=Math.min(150,s.number("height")/Math.max(.1,p.rise*s.number("speed"))*20)*(.75+RANDOM.nextDouble()*.25);PARTICLES.add(p);return true;
 }
 private static void vertex(Vec3d p,float u,float v,int rgb,double alpha){VERTICES.putFloat((float)p.x).putFloat((float)p.y).putFloat((float)p.z).putFloat(u).putFloat(v).put((byte)(rgb>>16)).put((byte)(rgb>>8)).put((byte)rgb).put((byte)(Math.clamp(alpha,0,1)*255));}
 private static void render(MatrixStack matrices){
  var c=MinecraftClient.getInstance();if(!enabled()||shaderPack()||world!=c.world||c.world==null||failed||PARTICLES.isEmpty()||!CameraEnvironment.surface()||c.getFramebuffer().getDepthAttachmentView()==null)return;
  var s=XVisuals.visualModule("lavafallmist");var camera=c.gameRenderer.getCamera().getCameraPos();float delta=c.getRenderTickCounter().getTickProgress(false);
  var q=c.gameRenderer.getCamera().getRotation();var rr=new Vector3f(1,0,0).rotate(q);var uu=new Vector3f(0,1,0).rotate(q);var right=new Vec3d(rr.x,rr.y,rr.z);var up=new Vec3d(uu.x,uu.y,uu.z);
  PARTICLES.sort(Comparator.comparingDouble((Puff p)->-p.pos.squaredDistanceTo(camera)));VERTICES.clear();int tint=s.color("color");
  for(var p:PARTICLES){double age=p.age+delta,t=age/p.life,alpha=LavafallMistMath.fade(age,p.life)*Math.clamp((s.number("distance")-p.pos.distanceTo(camera))/4,0,1);if(alpha<.002)continue;
   var pos=p.previous.lerp(p.pos,delta).subtract(camera);double size=p.size*(p.ember?(s.flag("glow")?2.5:1):1+t*1.8);int color;
   if(p.ember)color=LavafallMistMath.ember(t);else{double shade=p.smoke?.24:.82;int r=(int)(((tint>>16)&255)*shade),g=(int)(((tint>>8)&255)*shade*(.74+.20*t)),b=(int)((tint&255)*shade*(.58+.27*t));color=r<<16|g<<8|b;alpha*=p.smoke?.18:.13;}
   double angle=p.phase+(p.ember?.012:.003)*age,cos=Math.cos(angle),sin=Math.sin(angle);var r=right.multiply(cos).add(up.multiply(sin)).multiply(size);var u=up.multiply(cos).subtract(right.multiply(sin)).multiply(size*(p.ember?1:1.2));
   int seed=(int)(p.phase*8);float base=(seed*2+(p.ember?1:0))*4;
   var a=pos.subtract(r).subtract(u);var b=pos.add(r).subtract(u);var d=pos.subtract(r).add(u);var e=pos.add(r).add(u);
   vertex(a,base,1,color,alpha);vertex(b,base+1,1,color,alpha);vertex(e,base+1,0,color,alpha);vertex(a,base,1,color,alpha);vertex(e,base+1,0,color,alpha);vertex(d,base,0,color,alpha);
  }
  int count=VERTICES.position()/24;if(count==0)return;VERTICES.flip();
  try{
   if(vertices==null)vertices=new MappableRingBuffer(()->"Lavafall particles",GpuBuffer.USAGE_VERTEX|GpuBuffer.USAGE_COPY_DST|GpuBuffer.USAGE_MAP_WRITE,VERTICES.capacity());
   var buffer=vertices.getBlocking();var encoder=RenderSystem.getDevice().createCommandEncoder();encoder.writeToBuffer(buffer.slice(0,VERTICES.remaining()),VERTICES);
   OPTIONS.identity().m00((ticks+delta)*.05f).m01(s.flag("glow")?1:0);var transform=RenderSystem.getDynamicUniforms().write(new Matrix4f(RenderSystem.getModelViewMatrix()).mul(matrices.peek().getPositionMatrix()),WHITE,ZERO,OPTIONS);
   try(var pass=encoder.createRenderPass(()->"Lavafall vapor and embers",c.getFramebuffer().getColorAttachmentView(),OptionalInt.empty())){
    pass.setPipeline(PIPELINE);RenderSystem.bindDefaultUniforms(pass);pass.setUniform("DynamicTransforms",transform);pass.bindTexture("SceneDepth",c.getFramebuffer().getDepthAttachmentView(),RenderSystem.getSamplerCache().get(com.mojang.blaze3d.textures.FilterMode.NEAREST));pass.setVertexBuffer(0,buffer);pass.draw(0,count);
   }vertices.rotate();
  }catch(RuntimeException ex){failed=true;org.slf4j.LoggerFactory.getLogger("VisualClient").warn("Lavafall Mist rendering unavailable",ex);}
 }
 private LavafallMist(){}
}
