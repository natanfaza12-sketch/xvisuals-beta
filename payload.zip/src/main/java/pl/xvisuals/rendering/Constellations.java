package pl.xvisuals.rendering;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import pl.xvisuals.mixins.RenderLayerAccessor;
import pl.xvisuals.modules.world.MeteorField;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.attribute.EnvironmentAttributes;
import java.util.*;

public final class Constellations {
 private static final MeteorField METEORS=new MeteorField();
 private record Star(Vec3d point,ConstellationPatterns.Appearance appearance){}
 private static final List<Star[]> PATTERNS=new ArrayList<>();
 private static Object world;private static int count;private static boolean custom;private static double time,visibility,previous;
 private static final BufferAllocator ALLOCATOR=new BufferAllocator(131072);
 private static final VertexConsumerProvider.Immediate BUFFERS=VertexConsumerProvider.immediate(ALLOCATOR);
 private static final RenderLayer LAYER=RenderLayerAccessor.visuals$of("xvisuals_constellations",RenderSetup.builder(RenderPipeline.builder()
  .withLocation(Identifier.of("xvisuals","pipeline/constellations"))
  .withVertexShader(Identifier.of("xvisuals","core/shooting_star")).withFragmentShader(Identifier.of("xvisuals","core/constellation"))
  .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER)
  .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS).withBlend(BlendFunction.TRANSLUCENT)
  .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withDepthWrite(false).withCull(false).build()).translucent().expectedBufferSize(131072).build());
 public static void init(){ClientTickEvents.END_CLIENT_TICK.register(Constellations::tick);WorldRenderEvents.END_MAIN.register(c->render(c.matrices()));ClientLifecycleEvents.CLIENT_STOPPING.register(c->ALLOCATOR.close());}
 private static boolean enabled(){return XVisuals.ready()&&XVisuals.visualModule("constellations").enabled;}
 private static void tick(MinecraftClient c){
  if(world!=c.world||!enabled()){world=c.world;visibility=previous=time=0;METEORS.reset(19341);}
  if(!enabled()||c.world==null||c.player==null||!c.world.getRegistryKey().equals(World.OVERWORLD)||c.isPaused())return;
  var s=XVisuals.visualModule("constellations");time+=.05*s.number("speed");
  double rain=Math.max(c.world.getRainGradient(1),Storm.running()?Storm.rain():0);
  previous=visibility;double target=(s.flag("night")?ConstellationPatterns.night(c.world.getTimeOfDay()):1)*(1-Math.clamp(rain,0,1)*.97);visibility+=(target-visibility)*.08;
  int next=s.integer("density");boolean varied=s.flag("custom");
  if(next!=count||varied!=custom||PATTERNS.isEmpty()){
   count=next;custom=varied;PATTERNS.clear();
   for(int i=0;i<count;i++){
    double y=1-2*(i+.5)/count,angle=i*2.399963,r=Math.sqrt(1-y*y);
    var normal=new Vec3d(Math.cos(angle)*r,y,Math.sin(angle)*r);var right=normal.crossProduct(new Vec3d(0,1,0)).normalize();var up=right.crossProduct(normal).normalize();
    var shape=ConstellationPatterns.pattern(i,custom);Star[] points=new Star[shape.length];
    for(int j=0;j<points.length;j++)points[j]=new Star(normal.add(right.multiply(shape[j].x()*.17)).add(up.multiply(shape[j].y()*.17)).normalize().multiply(128),ConstellationPatterns.appearance(i,j));
    PATTERNS.add(points);
   }
  }
  boolean owner=XVisuals.visualModule("shootingstars").enabled||MeteorShower.enabled();
  METEORS.update(.05,s.flag("shooting")&&!owner&&visibility>.1?.025:0,owner||!s.flag("shooting")?0:1,.75);
 }
 private static Vec3d rotated(Vec3d p,double angle,double drift){return p.rotateX((float)angle).rotateY((float)(-Math.PI/2+drift));}
 private static void render(MatrixStack matrices){
  var c=MinecraftClient.getInstance();if(!enabled()||world!=c.world||c.world==null||!c.world.getRegistryKey().equals(World.OVERWORLD)||c.player==null||c.player.isSubmergedInWater())return;
  var s=XVisuals.visualModule("constellations");float delta=c.getRenderTickCounter().getTickProgress(false);double alpha=previous+(visibility-previous)*delta;if(alpha<.002)return;
  double angle=Math.toRadians(c.gameRenderer.getCamera().getEnvironmentAttributeInterpolator().get(EnvironmentAttributes.STAR_ANGLE_VISUAL,delta));
  double clock=time+delta*.05*s.number("speed");var m=matrices.peek().getPositionMatrix();var out=BUFFERS.getBuffer(LAYER);int base=s.color("color");
  boolean twinkling=s.flag("twinkle"),lines=s.flag("lines");double light=s.number("brightness"),size=s.number("size"),lineOpacity=s.number("lineOpacity");
  for(var pattern:PATTERNS){Vec3d last=null;
   for(var star:pattern){var p=rotated(star.point,angle,clock*.0003);var appearance=star.appearance;double horizon=Math.clamp(p.y/12,0,1);double phase=appearance.phase();
    double twinkle=twinkling?.82+.18*Math.sin(clock*.7+phase):1;
    double brightness=alpha*horizon*light*twinkle*appearance.brightness();
    int rgb=base&0xFFFFFF;int red=(rgb>>16)&255,green=(rgb>>8)&255,blue=rgb&255;
    double warmth=appearance.warmth();rgb=((int)(red*warmth)<<16)|(green<<8)|(int)(blue*(1.95-warmth));
    sprite(out,m,p,.55*size*appearance.size(),color(rgb,brightness));
    if(last!=null&&lines){double fade=Math.clamp(Math.min(last.y,p.y)/12,0,1);line(out,m,last,p,.045,color(base,alpha*fade*lineOpacity));}
    last=p;
   }
  }
  if(s.flag("shooting")&&!XVisuals.visualModule("shootingstars").enabled&&!MeteorShower.enabled())for(var meteor:METEORS.meteors()){
   var d=meteor.direction();var head=new Vec3d(d.x(),d.y(),d.z()).multiply(128);double a=meteor.alpha()*alpha;
   sprite(out,m,head,.4,color(base,a));Vec3d last=head;
   for(int i=1;i<=10;i++){var tail=meteor.direction(i*.065);var p=new Vec3d(tail.x(),tail.y(),tail.z()).multiply(128);line(out,m,last,p,.07*(1-i/12d),color(base,a*(1-i/11d)*.5));last=p;}
  }
  BUFFERS.draw();
 }
 private static int color(int rgb,double alpha){return ((int)(Math.clamp(alpha,0,1)*255)<<24)|(rgb&0xFFFFFF);}
 private static void sprite(VertexConsumer out,org.joml.Matrix4f m,Vec3d center,double size,int color){
  var right=center.normalize().crossProduct(new Vec3d(0,1,0)).normalize();if(right.lengthSquared()<.1)right=new Vec3d(1,0,0);var up=right.crossProduct(center.normalize()).normalize();right=right.multiply(size);up=up.multiply(size);
  vertex(out,m,center.subtract(right).subtract(up),0,0,color);vertex(out,m,center.add(right).subtract(up),1,0,color);vertex(out,m,center.add(right).add(up),1,1,color);vertex(out,m,center.subtract(right).add(up),0,1,color);
 }
 private static void line(VertexConsumer out,org.joml.Matrix4f m,Vec3d a,Vec3d b,double width,int color){var side=a.crossProduct(b.subtract(a)).normalize().multiply(width);vertex(out,m,a.subtract(side),-1,0,color);vertex(out,m,a.add(side),-1,1,color);vertex(out,m,b.add(side),-1,1,color);vertex(out,m,b.subtract(side),-1,0,color);}
 private static void vertex(VertexConsumer out,org.joml.Matrix4f m,Vec3d p,float u,float v,int color){out.vertex(m,(float)p.x,(float)p.y,(float)p.z).texture(u,v).color(color);}
 private Constellations(){}
}
