package pl.xvisuals.rendering;

/** A new world starts at the selected weather; only subsequent changes transition. */
public final class WeatherEnvelope {
  private float rain, thunder, cloud;
  public void reset() { rain = thunder = cloud = 0; }
  public void update(String mode, float rawRain, float rawThunder, float seconds, boolean initial) {
    float target = mode.equals("Server") ? rawRain : mode.equals("Clear") ? 0 : 1;
    float storm = mode.equals("Server") ? rawThunder : mode.equals("Storm") ? 1 : 0;
    if (initial) {
      rain = cloud = target;
      thunder = storm;
      return;
    }
    float step = 1 / (20 * Math.max(.05f, seconds));
    cloud = approach(cloud, target, step * 1.6f);
    rain = approach(rain, target > rain ? Math.min(target, Math.max(0, (cloud-.15f)/.85f)) : target, step);
    thunder = approach(thunder, storm, step);
  }
  private static float approach(float value, float target, float step) {
    return value + Math.clamp(target-value, -step, step);
  }
  public float rain() { return rain; }
  public float thunder() { return thunder; }
  public float cloud() { return cloud; }
}
