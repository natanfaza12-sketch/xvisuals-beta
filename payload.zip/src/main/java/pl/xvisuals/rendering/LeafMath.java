package pl.xvisuals.rendering;
public final class LeafMath {
 public static int cap(String quality){return quality.equals("Low")?64:quality.equals("High")?192:128;}
 public static double weather(double rain,boolean storm){return 1+Math.clamp(rain,0,1)*(storm?1.4:.5);}
 public static double fade(double age,double lifetime){double t=Math.clamp(age/Math.max(.1,lifetime),0,1);return Math.min(1,age*4)*Math.clamp((1-t)*4,0,1);}
 public static double flutter(double time,double phase){return Math.sin(time*1.7+phase)*.6+Math.sin(time*2.9+phase*2.3)*.4;}
 private LeafMath(){}
}
