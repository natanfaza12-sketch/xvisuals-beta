package pl.xvisuals.rendering;

/** Tick-driven presentation state, independent of world weather and game entities. */
public final class StormEnvelope {
  private float amount, rain, darkness;
  private int flashAge = -1, thunderDelay = -1;

  public boolean tick(boolean enabled, double intensity, double skyDarkness,
      boolean lightning, boolean sounds, boolean strike, int delay) {
    amount = approach(amount, enabled ? 1 : 0);
    rain = approach(rain, enabled ? unit(intensity) : 0);
    darkness = approach(darkness, enabled ? unit(skyDarkness) : 0);
    if (!enabled || !lightning) flashAge = -1;
    else if (flashAge >= 0 && ++flashAge > 7) flashAge = -1;
    boolean play = false;
    if (!enabled || !sounds) thunderDelay = -1;
    else if (thunderDelay >= 0 && --thunderDelay <= 0) {
      play = true;
      thunderDelay = -1;
    }
    if (enabled && strike) {
      if (lightning) flashAge = 0;
      if (sounds && thunderDelay < 0) thunderDelay = Math.clamp(delay, 1, 60);
    }
    return play;
  }

  public float flash() {
    return switch (flashAge) {
      case 0 -> .7f;
      case 1 -> .35f;
      case 3 -> .5f;
      case 4 -> .25f;
      case 5 -> .10f;
      default -> 0;
    };
  }
  public float rain() { return rain; }
  public float darkness() { return darkness; }
  public boolean running() { return amount > .0001f; }
  public void reset() { amount = rain = darkness = 0; flashAge = thunderDelay = -1; }
  private static float approach(float value, float target) {
    return Math.abs(target - value) <= .025f ? target : value + Math.copySign(.025f, target - value);
  }
  private static float unit(double value) { return (float)Math.clamp(Double.isFinite(value) ? value : 0, 0, 1); }
}
