package pl.xvisuals.rendering;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.*;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import java.nio.*;
import java.util.*;

/** Terrain-following depth-softened mist; fixed discovery and particle budgets, no world changes. */
public final class DynamicMist {
 private static final List<Puff> PARTICLES=new ArrayList<>();private static final Random RANDOM=new Random();
 private static final ByteBuffer VERTICES=ByteBuffer.allocateDirect(144*6*24).order(ByteOrder.nativeOrder());
 private static MappableRingBuffer vertices;private static Object world;private static int ticks;private static double blend,clock,weather=1;private static boolean failed;
 private static final Matrix4f OPTIONS=new Matrix4f();private static final Vector4f WHITE=new Vector4f(1,1,1,1);private static final Vector3f ZERO=new Vector3f();
 private static final RenderPipeline PIPELINE=RenderPipeline.builder().withLocation(Identifier.of("xvisuals","pipeline/dynamic_mist"))
  .withVertexShader(Identifier.of("xvisuals","core/lavafall_mist")).withFragmentShader(Identifier.of("xvisuals","core/dynamic_mist"))
  .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER).withUniform("Fog",UniformType.UNIFORM_BUFFER).withSampler("SceneDepth")
  .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.TRIANGLES).withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).build();
 private static class Puff {Vec3d pos,previous;double size,life,phase,base,offset,depression,strength,light;int age;boolean forest;}
 public static void init(){ClientTickEvents.END_CLIENT_TICK.register(DynamicMist::tick);WorldRenderEvents.END_MAIN.register(c->render(c.matrices()));ClientLifecycleEvents.CLIENT_STOPPING.register(c->clear());}
 private static boolean enabled(){return XVisuals.ready()&&XVisuals.visualModule("dynamicmist").enabled;}
 private static void clear(){PARTICLES.clear();blend=0;clock=0;weather=1;failed=false;if(vertices!=null){vertices.close();vertices=null;}}
 private static boolean forest(MinecraftClient c,BlockPos p){var biome=c.world.getBiome(p);return biome.isIn(net.minecraft.registry.tag.BiomeTags.IS_FOREST)||biome.isIn(net.minecraft.registry.tag.BiomeTags.IS_JUNGLE)||biome.isIn(net.minecraft.registry.tag.BiomeTags.IS_TAIGA);}
 /** Find only loaded solid terrain, ignoring canopy and trunks. NaN means no suitable surface. */
 private static double ground(MinecraftClient c,int x,int z,int top,int depth){
  if(!c.world.isChunkLoaded(x>>4,z>>4))return Double.NaN;
  for(int i=0;i<depth;i++){var p=new BlockPos(x,top-i,z);var state=c.world.getBlockState(p);
   if(state.isIn(net.minecraft.registry.tag.BlockTags.LEAVES)||state.isIn(net.minecraft.registry.tag.BlockTags.LOGS))continue;
   if(!c.world.getFluidState(p).isEmpty())return Double.NaN;
   var shape=state.getCollisionShape(c.world,p);if(!shape.isEmpty())return p.getY()+shape.getMax(Direction.Axis.Y);
  }return Double.NaN;
 }
 private static double depression(MinecraftClient c,int x,int z,double base){double sum=0;int count=0;
  for(var d:Direction.Type.HORIZONTAL){double y=ground(c,x+d.getOffsetX()*5,z+d.getOffsetZ()*5,(int)base+6,13);if(Double.isFinite(y)){sum+=y;count++;}}
  return count>=3?Math.max(0,sum/count-base):0;
 }
 private static boolean shaderPack(){return ShaderPackSupport.active();}
 private static void tick(MinecraftClient c){
  if(world!=c.world||!enabled()){world=c.world;clear();}
  if(!enabled()||c.world==null||c.player==null||c.isPaused())return;
  if(shaderPack()){clear();return;}ticks++;
  var s=XVisuals.visualModule("dynamicmist");var camera=c.gameRenderer.getCamera().getCameraPos();
  boolean active=s.flag("ground")||s.flag("valley")||s.flag("forest");blend=DynamicMistMath.approach(blend,active?1:0);
  double rain=Math.max(c.world.getRainGradient(1),Storm.running()?Storm.rain():0);if(RealisticRain.active())rain=Math.max(rain,RealisticRain.rainfall());
  weather=DynamicMistMath.approach(weather,DynamicMistMath.weather(s.flag("weather"),rain,Storm.running()));
  clock+=.05*s.number("speed");int cap=DynamicMistMath.cap(s.text("quality"));double radius=s.number("distance"),height=s.number("height");var wind=AtmosphericWind.sample(ticks*.05);
  for(var it=PARTICLES.iterator();it.hasNext();){var p=it.next();p.previous=p.pos;p.age++;
   if(p.age>=p.life||p.pos.squaredDistanceTo(camera)>radius*radius){it.remove();continue;}
   p.strength=DynamicMistMath.approach(p.strength,DynamicMistMath.placement(s.flag("ground"),s.flag("valley"),s.flag("forest"),p.forest,p.depression));
   // Stagger terrain resampling; mist stays close to the ground rather than floating over cliffs.
   if(p.age%10==0){var at=BlockPos.ofFloored(p.pos);p.light+=(.16+.84*c.world.getBaseLightLevel(at,c.world.getAmbientDarkness())/15d-p.light)*.35;double floor=ground(c,at.getX(),at.getZ(),(int)Math.floor(p.pos.y),12);
    if(Double.isFinite(floor))p.base=floor;else p.life=Math.min(p.life,p.age+30);
   }
   double target=p.base+.12+p.offset*height*(1+(weather-1)*.15);
   var move=new Vec3d((wind.x()*.3+Math.sin(p.phase+clock*.4)*.09)*.05*s.number("speed"),Math.clamp((target-p.pos.y)*.025,-.025,.025),(wind.z()*.3+Math.cos(p.phase+clock*.31)*.09)*.05*s.number("speed"));
   var next=p.pos.add(move);var block=BlockPos.ofFloored(next);
   if(!c.world.isChunkLoaded(block.getX()>>4,block.getZ()>>4)){it.remove();continue;}
   var hit=c.world.raycast(new RaycastContext(p.pos,next,RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.ANY,c.player));
   if(hit.getType()==HitResult.Type.MISS)p.pos=next;
   else {var n=Vec3d.of(hit.getSide().getVector());var tangent=move.subtract(n.multiply(move.dotProduct(n)));var slide=p.pos.add(tangent);
    if(c.world.raycast(new RaycastContext(p.pos,slide,RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.ANY,c.player)).getType()==HitResult.Type.MISS)p.pos=slide;
    p.life=Math.min(p.life,p.age+35);
   }
  }
  while(PARTICLES.size()>cap)PARTICLES.removeFirst();
  if(!active||s.number("density")<=0||PARTICLES.size()>=cap)return;
  // Two candidates per tick, at most 32+4*13 block samples per candidate; never load chunks.
  for(int attempt=0;attempt<2&&PARTICLES.size()<cap;attempt++){
   if(RANDOM.nextDouble()>Math.min(1,s.number("density")*weather))continue;
   double angle=RANDOM.nextDouble()*Math.PI*2,dist=Math.sqrt(RANDOM.nextDouble())*(radius-3);
   int x=(int)Math.floor(camera.x+Math.cos(angle)*dist),z=(int)Math.floor(camera.z+Math.sin(angle)*dist);
   double base=ground(c,x,z,(int)Math.floor(camera.y),32);if(!Double.isFinite(base))continue;
   var at=new BlockPos(x,(int)base,z);boolean woodland=forest(c,at);double valley=s.flag("valley")?depression(c,x,z,base):0;
   double strength=DynamicMistMath.placement(s.flag("ground"),s.flag("valley"),s.flag("forest"),woodland,valley);if(strength<=0)continue;
   double offset=.08+RANDOM.nextDouble()*.4;var pos=new Vec3d(x+.5,base+.12+offset*height,z+.5);var pblock=BlockPos.ofFloored(pos);
   if(!c.world.getBlockState(pblock).getCollisionShape(c.world,pblock).isEmpty()||!c.world.getFluidState(pblock).isEmpty())continue;
   if(c.world.raycast(new RaycastContext(new Vec3d(pos.x,base+.02,pos.z),pos,RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.ANY,c.player)).getType()!=HitResult.Type.MISS)continue;
   var p=new Puff();p.pos=p.previous=pos;p.base=base;p.offset=offset;p.forest=woodland;p.depression=valley;p.strength=strength;p.light=.16+.84*c.world.getBaseLightLevel(pblock,c.world.getAmbientDarkness())/15d;p.size=2+RANDOM.nextDouble()*2;p.life=180+RANDOM.nextInt(120);p.phase=RANDOM.nextDouble()*6.283;PARTICLES.add(p);
  }
 }
 private static void vertex(Vec3d p,float u,float v,int rgb,double alpha){VERTICES.putFloat((float)p.x).putFloat((float)p.y).putFloat((float)p.z).putFloat(u).putFloat(v).put((byte)(rgb>>16)).put((byte)(rgb>>8)).put((byte)rgb).put((byte)(Math.clamp(alpha,0,1)*255));}
 private static void render(MatrixStack matrices){
  var c=MinecraftClient.getInstance();if(!enabled()||shaderPack()||world!=c.world||c.world==null||failed||PARTICLES.isEmpty()||!CameraEnvironment.surface()||c.getFramebuffer().getDepthAttachmentView()==null)return;
  var s=XVisuals.visualModule("dynamicmist");var camera=c.gameRenderer.getCamera().getCameraPos();float delta=c.getRenderTickCounter().getTickProgress(false);
  var q=c.gameRenderer.getCamera().getRotation();var rr=new Vector3f(1,0,0).rotate(q);var uu=new Vector3f(0,1,0).rotate(q);var right=new Vec3d(rr.x,rr.y,rr.z);var up=new Vec3d(uu.x,uu.y,uu.z);
  PARTICLES.sort(Comparator.comparingDouble((Puff p)->-p.pos.squaredDistanceTo(camera)));VERTICES.clear();int tint=s.color("color");
  for(var p:PARTICLES){double age=p.age+delta,t=age/p.life,alpha=LavafallMistMath.fade(age,p.life)*JungleMistMath.fade(p.pos.distanceTo(camera),s.number("distance"))*blend*s.number("density")*p.strength*weather*DynamicMistMath.altitude(p.pos.y-p.base,s.number("height"));if(alpha<.002)continue;
   var pos=p.previous.lerp(p.pos,delta).subtract(camera);double size=p.size*(1+t*.25);int color=0;for(int shift=0;shift<=16;shift+=8)color|=((int)(((tint>>>shift)&255)*p.light))<<shift;alpha*=.34;
   double angle=Math.sin(p.phase+.0015*age)*.08,cos=Math.cos(angle),sin=Math.sin(angle);var r=right.multiply(cos).add(up.multiply(sin)).multiply(size);var u=up.multiply(cos).subtract(right.multiply(sin)).multiply(Math.min(s.number("height")*.55,size*.45));
   int seed=(int)(p.phase*8);float base=seed*8;
   var a=pos.subtract(r).subtract(u);var b=pos.add(r).subtract(u);var d=pos.subtract(r).add(u);var e=pos.add(r).add(u);
   vertex(a,base,1,color,alpha);vertex(b,base+1,1,color,alpha);vertex(e,base+1,0,color,alpha);vertex(a,base,1,color,alpha);vertex(e,base+1,0,color,alpha);vertex(d,base,0,color,alpha);
  }
  int count=VERTICES.position()/24;if(count==0)return;VERTICES.flip();
  try{
   if(vertices==null)vertices=new MappableRingBuffer(()->"Dynamic mist",GpuBuffer.USAGE_VERTEX|GpuBuffer.USAGE_COPY_DST|GpuBuffer.USAGE_MAP_WRITE,VERTICES.capacity());
   var buffer=vertices.getBlocking();var encoder=RenderSystem.getDevice().createCommandEncoder();encoder.writeToBuffer(buffer.slice(0,VERTICES.remaining()),VERTICES);
   OPTIONS.identity().m00((float)(clock+delta*.05*s.number("speed"))).m01(0);var transform=RenderSystem.getDynamicUniforms().write(new Matrix4f(RenderSystem.getModelViewMatrix()).mul(matrices.peek().getPositionMatrix()),WHITE,ZERO,OPTIONS);
   try(var pass=encoder.createRenderPass(()->"Dynamic ground mist",c.getFramebuffer().getColorAttachmentView(),OptionalInt.empty())){
    pass.setPipeline(PIPELINE);RenderSystem.bindDefaultUniforms(pass);pass.setUniform("DynamicTransforms",transform);pass.bindTexture("SceneDepth",c.getFramebuffer().getDepthAttachmentView(),RenderSystem.getSamplerCache().get(com.mojang.blaze3d.textures.FilterMode.NEAREST));pass.setVertexBuffer(0,buffer);pass.draw(0,count);
   }vertices.rotate();
  }catch(RuntimeException ex){failed=true;org.slf4j.LoggerFactory.getLogger("VisualClient").warn("Dynamic Mist rendering unavailable",ex);}
 }
 private DynamicMist(){}
}
