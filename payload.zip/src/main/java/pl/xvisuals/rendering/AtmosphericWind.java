package pl.xvisuals.rendering;
import net.minecraft.client.MinecraftClient;
/** Shared particle-wind contract. Wind FX registers its world-space flow. */
public final class AtmosphericWind {
 public record Flow(double x,double z){public Flow{if(!Double.isFinite(x)||!Double.isFinite(z)){x=0;z=0;}x=Math.clamp(x,-3,3);z=Math.clamp(z,-3,3);}}
 @FunctionalInterface public interface Source{Flow sample(double seconds);}
 private static Source source;
 public static void setSource(Source controller){source=controller;}
 public static Flow sample(double seconds){
  if(source!=null)return source.sample(seconds);
  return fallback(seconds);
 }
 public static Flow fallback(double seconds){
  var c=MinecraftClient.getInstance();double rain=c.world==null?0:c.world.getRainGradient(1);
  double strength=(.12+rain*.23+(Storm.running()?.35:0))*(1+.2*Math.sin(seconds*.31));
  double angle=.55+Math.sin(seconds*.06)*.22;return new Flow(Math.cos(angle)*strength,Math.sin(angle)*strength);
 }
 private AtmosphericWind(){}
}
