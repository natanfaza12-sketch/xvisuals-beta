package pl.xvisuals.rendering.rain;

/** Retains sub-particle emission between ticks, including light rain and weather fades. */
public final class RainEmission {
    private double remainder;

    public int next(double rate) {
        remainder += rate;
        int count = (int) Math.floor(remainder + 1e-9);
        remainder = Math.max(0, remainder - count);
        return count;
    }

    public void reset() { remainder = 0; }
}
