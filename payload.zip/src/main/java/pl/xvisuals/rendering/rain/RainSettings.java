package pl.xvisuals.rendering.rain;




/** Settings adapter; simulation and geometry live in weather/RainRenderer. */
public final class RainSettings {
    public enum Palette { DEFAULT_WHITE, CINEMATIC_ORANGE, ICE_BLUE, CRIMSON, SOFT_PINK, VIOLET, CUSTOM_RGB }
    public enum Quality { LOW, MEDIUM, HIGH, CUSTOM }
    public Palette palette=Palette.DEFAULT_WHITE;
    public int color=0xEAF1FF;
    public double opacity=.7;
    public double density=1;
    public double length=.65;
    public double width=.022;
    public double speed=.65;
    public double wind=.025;
    public double direction=45;
    public boolean fade=true;
    public boolean trails=true;
    public boolean splashes=true;
    public double amount=.6;
    public double size=.16;
    public double splashOpacity=.85;
    public int droplets=4;
    public int duration=14;
    public boolean ripples=true;
    public boolean waterVariant=true;
    public boolean matchSplash=true;
    public int splashColor=0xEAF1FF;
    public boolean splashGlow=true;
    public boolean matchRipple=true;
    public int rippleColor=0xEAF1FF;
    public boolean glow=true;
    public double glowStrength=.3;
    public double glowRadius=2.5;
    public double brightness=.95;
    public boolean matchCore=true;
    public int coreColor=0xFFFFFF;
    public boolean matchGlow=true;
    public int glowColor=0xEAF1FF;
    public boolean haze=false;
    public boolean near=true;
    public double atmosphere=.15;
    public boolean fog=true;
    public Quality quality=Quality.MEDIUM;
    public int distance=14;
    public int limit=768;
    public boolean adaptive=true;
    public boolean enabled;
    public int rgb(){return switch(palette){case DEFAULT_WHITE->0xEAF1FF;case CINEMATIC_ORANGE->0xFF9A42;case ICE_BLUE->0x91D9FF;case CRIMSON->0xFF425A;case SOFT_PINK->0xFFA6CE;case VIOLET->0xB69AFF;case CUSTOM_RGB->color;};}
    public int budget(){return Math.min(limit,switch(quality){case LOW->192;case MEDIUM->768;case HIGH,CUSTOM->2048;});}
    public int impacts(double random){double intensity=Math.clamp(amount,0,2);int whole=(int)intensity;return whole+(random<intensity-whole?1:0);}
    public void sync(pl.xvisuals.config.VisualConfig.ModuleState m, boolean active){
        enabled=active;
        palette=Palette.valueOf(m.text("palette").toUpperCase(java.util.Locale.ROOT).replace(' ','_'));
        color=pl.xvisuals.util.Colors.parse(m.text("color"));
        opacity=m.number("opacity");
        density=m.number("density");
        length=m.number("length");
        width=m.number("width");
        speed=m.number("speed");
        wind=m.number("wind");
        direction=m.number("direction");
        fade=m.flag("fade");
        trails=m.flag("trails");
        splashes=m.flag("splashes");
        amount=m.number("splashIntensity");
        size=m.number("size");
        splashOpacity=m.number("splashOpacity");
        droplets=m.integer("splashDroplets");
        duration=m.integer("duration");
        ripples=m.flag("ripples");
        waterVariant=m.flag("waterVariant");
        matchSplash=m.flag("matchSplash");
        splashColor=pl.xvisuals.util.Colors.parse(m.text("splashColor"));
        splashGlow=m.flag("splashGlow");
        matchRipple=m.flag("matchRipple");
        rippleColor=pl.xvisuals.util.Colors.parse(m.text("rippleColor"));
        glow=m.flag("glow");
        glowStrength=m.number("glowStrength");
        glowRadius=m.number("glowRadius");
        brightness=m.number("brightness");
        matchCore=m.flag("matchCore");
        coreColor=pl.xvisuals.util.Colors.parse(m.text("coreColor"));
        matchGlow=m.flag("matchGlow");
        glowColor=pl.xvisuals.util.Colors.parse(m.text("glowColor"));
        haze=m.flag("haze");
        near=m.flag("near");
        atmosphere=m.number("atmosphere");
        fog=m.flag("fog");
        quality=Quality.valueOf(m.text("quality").toUpperCase(java.util.Locale.ROOT).replace(' ','_'));
        distance=m.integer("distance");
        limit=m.integer("limit");
        adaptive=m.flag("adaptive");
    }
}
