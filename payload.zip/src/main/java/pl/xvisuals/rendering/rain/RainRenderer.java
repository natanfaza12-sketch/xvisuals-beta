package pl.xvisuals.rendering.rain;

import pl.xvisuals.rendering.RealisticRain;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.*;
import net.minecraft.world.Heightmap;
import net.minecraft.world.biome.Biome;
import net.minecraft.registry.tag.FluidTags;
import org.joml.Matrix4f;
import java.util.*;

/** Bounded world-space simulation. No registered particles, textures, framebuffers or network state.
 * Surface queries happen on ticks and are cached per column; rendering only emits batched triangles. */
public final class RainRenderer {
    private static final int MAX=2048, IMPACTS=256;
    private final RainSettings s;
    private final Drop[] drops=new Drop[MAX];
    private final Impact[] impacts=new Impact[IMPACTS];
    private final Map<Long,Surface> surfaces=new HashMap<>();
    private final Random random=new Random(0xA1A71C);
    private final RainEmission emission=new RainEmission();
    private final Matrix4f identity=new Matrix4f();
    private Object world;
    private int clock,cursor,impactCursor;
    private double adaptive=1;
    public int renderedStreaks,renderedImpacts,activeDrops,queries;
    public long simulationNanos;
    private static final class Drop {boolean active;double x,y,z,px,py,pz,floor,speed,variation;}
    private static final class Impact {int age=1000;double x,y,z,seed;boolean water;}
    public record Surface(double height,boolean rain,boolean water){}
    public RainRenderer(RainSettings settings){s=settings;for(int i=0;i<MAX;i++)drops[i]=new Drop();for(int i=0;i<IMPACTS;i++)impacts[i]=new Impact();}
    public void clear(){for(var d:drops)d.active=false;for(var p:impacts)p.age=1000;surfaces.clear();emission.reset();activeDrops=renderedStreaks=renderedImpacts=0;world=null;adaptive=1;}
    public Surface sample(ClientWorld w,double x,double z){
        int bx=MathHelper.floor(x),bz=MathHelper.floor(z);
        if(!w.getChunkManager().isChunkLoaded(bx>>4,bz>>4))return new Surface(0,false,false);
        int y=w.getTopY(Heightmap.Type.MOTION_BLOCKING,bx,bz)-1;
        var pos=new BlockPos(bx,y,bz);var state=w.getBlockState(pos);var fluid=w.getFluidState(pos);
        var shape=state.getCollisionShape(w,pos);
        double top=shape.isEmpty()?0:shape.getEndingCoord(Direction.Axis.Y,x-bx,z-bz);
        if(!Double.isFinite(top))top=0;
        boolean water=fluid.isIn(FluidTags.WATER);
        if(water)top=Math.max(top,fluid.getHeight(w,pos));
        // Do not place a ripple over a hole in a stair/fence collision shape.
        if(top<=0)return new Surface(y,false,false);
        var sky=new BlockPos(bx,y+1,bz);
        return new Surface(y+top,RealisticRain.rainAt(w,sky)&&!fluid.isIn(FluidTags.LAVA),water);
    }
    private Surface surface(ClientWorld w,double x,double z){
        // Quarter-block cells retain partial-surface detail without per-drop world queries.
        int bx=MathHelper.floor(x*4),bz=MathHelper.floor(z*4);long key=((long)bx<<32)^(bz&0xffffffffL);
        var cached=surfaces.get(key);if(cached!=null)return cached;
        if(queries>=128)return null;
        queries++;var result=sample(w,x,z);surfaces.put(key,result);return result;
    }
    public void tick(MinecraftClient c){
        if(!s.enabled||c.world==null||c.player==null){if(world!=null||activeDrops>0)clear();return;}
        if(world!=c.world){clear();world=c.world;}
        if(c.isPaused())return;
        long start=System.nanoTime();queries=0;clock++;if(clock%10==0)surfaces.clear();
        float rain=(float)RealisticRain.strength(c,1);
        if(rain<=.001){for(var d:drops)d.active=false;for(var p:impacts)p.age=1000;emission.reset();activeDrops=0;return;}
        var cam=c.gameRenderer.getCamera().getCameraPos();
        if(s.density<=0||s.opacity<=0){clear();return;}
        if(s.adaptive){double target=c.getCurrentFps()<40?.45:1;adaptive+=(target-adaptive)*.025;}else adaptive=1;
        int budget=Math.max(32,(int)(s.budget()*adaptive));double radius=Math.min(s.distance,s.quality==RainSettings.Quality.LOW?10:24);
        var wind=RealisticRain.wind(s.wind);double wx=wind.x,wz=wind.z;
        activeDrops=0;
        for(int i=0;i<MAX;i++){
            var d=drops[i];if(i>=budget){d.active=false;continue;}if(!d.active)continue;
            d.speed=s.speed*d.variation;
            d.px=d.x;d.py=d.y;d.pz=d.z;d.x+=wx;d.z+=wz;d.y-=d.speed;
            var ground=surface(c.world,d.x,d.z);
            if(ground==null){d.x=d.px;d.y=d.py;d.z=d.pz;activeDrops++;continue;}
            d.floor=ground.height;
            if(!ground.rain||Math.abs(d.x-cam.x)>radius||Math.abs(d.z-cam.z)>radius||d.y<cam.y-18){d.active=false;continue;}
            if(d.y<=d.floor){
                int splashes=d.py>=d.floor&&s.splashes?s.impacts(random.nextDouble()):0;
                for(int splash=0;splash<splashes;splash++){
                    var p=impacts[impactCursor++%Math.min(IMPACTS,Math.max(8,budget/4))];p.age=0;p.x=d.x;p.y=d.floor+.015;p.z=d.z;p.water=ground.water;p.seed=random.nextDouble()*100;
                }d.active=false;
            }else activeDrops++;
        }
        int births=emission.next(s.density*rain*(s.quality==RainSettings.Quality.LOW?12:52)*adaptive);
        for(int i=0;i<births;i++){
            var d=drops[cursor++%budget];if(d.active)continue;
            double x=cam.x+(random.nextDouble()*2-1)*radius,z=cam.z+(random.nextDouble()*2-1)*radius;
            double nearSq=(x-cam.x)*(x-cam.x)+(z-cam.z)*(z-cam.z);
            if(nearSq<(s.near?.35:4))continue;
            var ground=surface(c.world,x,z);if(ground==null||!ground.rain)continue;
            double low=Math.max(ground.height+.05,cam.y-14),high=cam.y+12;
            if(low>=high)continue;
            d.x=d.px=x;d.z=d.pz=z;d.y=d.py=low+random.nextDouble()*(high-low);d.floor=ground.height;
            d.variation=.7+random.nextDouble()*.6;d.speed=s.speed*d.variation;d.active=true;activeDrops++;
        }
        for(var p:impacts)if(p.age<1000)p.age++;
        simulationNanos=System.nanoTime()-start;
    }
    public void render(VertexConsumerProvider buffers,Vec3d camera){
        renderedStreaks=renderedImpacts=0;var c=MinecraftClient.getInstance();if(!s.enabled||c.world==null||world!=c.world||!pl.xvisuals.rendering.CameraEnvironment.surface())return;
        float delta=c.getRenderTickCounter().getTickProgress(false),rain=(float)RealisticRain.strength(c,delta);if(rain<=.001)return;
        var out=buffers.getBuffer(RainLayer.LAYER);
        boolean detailed=s.quality!=RainSettings.Quality.LOW;
        int rgb=s.rgb(),core=s.matchCore?rgb:s.coreColor,halo=s.matchGlow?rgb:s.glowColor;
        var wind=RealisticRain.wind(s.wind);double wx=wind.x,wz=wind.z;
        var forward=c.gameRenderer.getCamera().getHorizontalPlane();
        for(var d:drops)if(d.active){
            double x=MathHelper.lerp(delta,d.px,d.x)-camera.x,y=Math.max(d.floor+.015,MathHelper.lerp(delta,d.py,d.y))-camera.y,z=MathHelper.lerp(delta,d.pz,d.z)-camera.z;
            double dist=Math.sqrt(x*x+z*z);if(dist>s.distance||x*forward.x()+y*forward.y()+z*forward.z()<-2)continue;
            double alpha=s.opacity*rain*d.variation*(s.fade?Math.max(0,1-dist/s.distance):1);
            if(s.fog)alpha*=1-.5*(dist/s.distance)*s.atmosphere;
            double length=s.length*d.variation,width=s.width;
            double ex=x-wx*length/d.speed,ey=y+length,ez=z-wz*length/d.speed;
            if(s.glow&&detailed)line(out,x,y,z,ex,ey,ez,width*s.glowRadius,halo,alpha*s.glowStrength*.2);
            line(out,x,y,z,ex,ey,ez,width*1.7,rgb,alpha*.18);
            line(out,x,y,z,ex,ey,ez,width,bright(core,s.brightness),alpha);
            if(s.trails&&detailed)line(out,ex,ey,ez,ex-wx*length/d.speed,ey+length,ez-wz*length/d.speed,width*.6,rgb,alpha*.12);
            renderedStreaks++;
        }
        for(var p:impacts){
            double age=p.age+delta,t=age/s.duration;if(t>=1||p.age>=1000)continue;
            double x=p.x-camera.x,y=p.y-camera.y,z=p.z-camera.z;
            double dist=Math.sqrt(x*x+z*z);if(dist>s.distance||x*forward.x()+y*forward.y()+z*forward.z()<-1)continue;
            double alpha=s.splashOpacity*(1-t)*rain*(s.fade?Math.max(0,1-dist/s.distance):1);
            int col=s.matchSplash?rgb:s.splashColor,ring=s.matchRipple?rgb:s.rippleColor;
            double size=s.size*(p.water&&s.waterVariant?1.6:1);
            if(s.ripples)ring(out,x,y,z,size*(.15+t),Math.max(.002,size*.05*(1-t)),ring,alpha,detailed?16:8);
            if(age<3)line(out,x,y,z,x,y+.025,z,.025*(1-age/3),col,alpha*.6);
            int count=detailed?s.droplets:Math.min(2,s.droplets);
            for(int i=0;i<count;i++){
                double angle=p.seed+i*2.39996,v=.035+.018*Math.sin(p.seed+i),a=age*.65;
                double h=v*a-.004*a*a;if(h<0)continue;
                double dx=Math.cos(angle)*a*size*.11,dz=Math.sin(angle)*a*size*.11;
                if(s.splashGlow&&s.glow&&detailed)line(out,x+dx,y+h,z+dz,x+dx,y+h+.025,z+dz,.015*s.glowRadius,col,alpha*s.glowStrength*.2);
                line(out,x+dx,y+h,z+dz,x+dx,y+h+.02,z+dz,.008,col,alpha);
            }
            if(s.haze&&detailed)ring(out,x,y+.025+t*.08,z,size*(1+t),size*.45,rgb,alpha*s.atmosphere*.1,16);
            renderedImpacts++;
        }
    }
    private static int bright(int rgb,double b){return ((int)(((rgb>>16)&255)*b)<<16)|((int)(((rgb>>8)&255)*b)<<8)|(int)((rgb&255)*b);}
    private void vertex(VertexConsumer out,double x,double y,double z,int rgb,double alpha){out.vertex(identity,(float)x,(float)y,(float)z).color((Math.clamp((int)(alpha*255),0,255)<<24)|(rgb&0xffffff));}
    private void line(VertexConsumer out,double x,double y,double z,double ex,double ey,double ez,double width,int rgb,double alpha){
        double n=Math.sqrt(x*x+z*z);double ux=n<.001?width:z/n*width,uz=n<.001?0:-x/n*width;
        vertex(out,x-ux,y,z-uz,rgb,alpha);vertex(out,x+ux,y,z+uz,rgb,alpha);vertex(out,ex+ux,ey,ez+uz,rgb,alpha*.5);
        vertex(out,x-ux,y,z-uz,rgb,alpha);vertex(out,ex+ux,ey,ez+uz,rgb,alpha*.5);vertex(out,ex-ux,ey,ez-uz,rgb,alpha*.5);
    }
    private void ring(VertexConsumer out,double x,double y,double z,double r,double width,int rgb,double alpha,int sides){
        for(int i=0;i<sides;i++){
            double a=i*Math.PI*2/sides,b=(i+1)*Math.PI*2/sides,ca=Math.cos(a),sa=Math.sin(a),cb=Math.cos(b),sb=Math.sin(b),inner=Math.max(0,r-width);
            vertex(out,x+ca*r,y,z+sa*r,rgb,alpha);vertex(out,x+cb*r,y,z+sb*r,rgb,alpha);vertex(out,x+cb*inner,y,z+sb*inner,rgb,alpha*.2);
            vertex(out,x+ca*r,y,z+sa*r,rgb,alpha);vertex(out,x+cb*inner,y,z+sb*inner,rgb,alpha*.2);vertex(out,x+ca*inner,y,z+sa*inner,rgb,alpha*.2);
        }
    }
}
