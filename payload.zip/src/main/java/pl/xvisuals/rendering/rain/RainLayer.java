package pl.xvisuals.rendering.rain;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.util.Identifier;
import pl.xvisuals.mixins.RenderLayerAccessor;
final class RainLayer {
 static final RenderLayer LAYER=RenderLayerAccessor.visuals$of("visual_rain_streaks",
  RenderSetup.builder(RenderPipeline.builder()
   .withLocation(Identifier.of("xvisuals","pipeline/rain_streaks"))
   .withVertexShader("core/position_color").withFragmentShader("core/position_color")
   .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER)
   .withVertexFormat(VertexFormats.POSITION_COLOR,VertexFormat.DrawMode.TRIANGLES)
   .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withDepthWrite(false).withCull(false)
   .withBlend(BlendFunction.TRANSLUCENT).build()).translucent().expectedBufferSize(524288).build());
 private RainLayer(){}
}
