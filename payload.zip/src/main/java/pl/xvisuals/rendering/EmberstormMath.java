package pl.xvisuals.rendering;
public final class EmberstormMath {
 public static boolean supported(String biome){return biome.equals("minecraft:nether_wastes");}
 public static int cap(String quality){return quality.equals("Low")?64:quality.equals("High")?192:128;}
 public static double gust(double seconds,double frequency){if(frequency<=0)return 0;double t=seconds*frequency;double n=.5+.25*Math.sin(t*.73)+.15*Math.sin(t*1.37+1.4)+.1*Math.sin(t*.29+2.1);return Math.pow(Math.clamp(n,0,1),3);}
 public static boolean room(int total,int type,int cap,int typeCap){return total<cap&&type<typeCap;}
 private EmberstormMath(){}
}
