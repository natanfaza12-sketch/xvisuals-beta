package pl.xvisuals.rendering;
public final class EndAtmosphereMath {
 public static boolean supported(String dimension){return dimension.equals("minecraft:the_end");}
 public static boolean energy(boolean dust,boolean energy,double random){return energy&&(!dust||random<.22);}
 private EndAtmosphereMath(){}
}
