package pl.xvisuals.rendering;

import pl.xvisuals.XVisuals;
import net.minecraft.client.MinecraftClient;

public final class Quality {
  private static double adaptive = 1;

  public static void tick() {
    var m = XVisuals.config().module("performance");
    double goal = 1;
    if (m.flag("adaptive")) {
      var c=MinecraftClient.getInstance();
      goal=adaptiveGoal(c.getCurrentFps(),m.number("targetFps"),c.options.getMaxFps().getValue());
    }
    adaptive += (goal - adaptive) * .08;
  }

  static double adaptiveGoal(int fps, double target, int fpsLimit) {
    // Minecraft represents unlimited FPS as 260. A deliberate lower cap is not GPU overload.
    if(fpsLimit>0 && fpsLimit<260)target=Math.min(target,fpsLimit);
    return fps<=0?1:Math.max(.2,Math.min(1,fps/Math.max(1,target)));
  }

  public static double factor() {
    var m = XVisuals.config().module("performance");
    double base =
        switch (m.text("quality")) {
          case "LOW" -> .25;
          case "MEDIUM" -> .5;
          case "ULTRA" -> 1.5;
          default -> 1;
        };
    return base * adaptive * (m.flag("performanceMode") ? .5 : 1);
  }

  public static double glow() {
    var m = XVisuals.config().module("performance");
    return m.flag("reducedBloom") || m.flag("performanceMode") ? 0 : Math.min(1, factor());
  }

  public static int entityCap() {
    return Math.max(
        8,
        (int)
            (XVisuals.config().module("performance").integer("entityCap")
                * Math.min(1, factor())));
  }

  private Quality() {}
}
