package pl.xvisuals.rendering;
public final class RealisticRainMath {
 public static double wetness(double current,double rain){return Math.clamp(current+(rain>0?rain*.0025:-.0007),0,1);}
 public static double dropFade(double age,double life){return Math.clamp(age/10,0,1)*Math.clamp((life-age)/25,0,1);}
 public static void profile(pl.xvisuals.config.VisualConfig.ModuleState target,pl.xvisuals.config.VisualConfig.ModuleState base,boolean storm,double density){
  target.values.clear();if(storm||base.enabled)target.values.putAll(base.values);
  else{target.values.put("weather","Server");target.values.put("intensity",1d);target.values.put("radius",18d);target.values.put("wind",.35d);}
  target.values.put("density",density);target.values.put("splashes",false);
 }
 private RealisticRainMath(){}
}
