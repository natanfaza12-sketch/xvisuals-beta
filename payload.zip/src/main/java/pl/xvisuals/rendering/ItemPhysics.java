package pl.xvisuals.rendering;

import pl.xvisuals.XVisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.ItemEntity;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import java.util.WeakHashMap;

/** Visual poses only. Never writes to an entity, velocity, inventory or world. */
public final class ItemPhysics {
 public interface State { Pose visuals$getPose(); void visuals$setPose(Pose pose); }
 public record Pose(Quaternionf rotation,float scale,float lift,int copies,double phase) {}
 private static final WeakHashMap<ItemEntity,Motion> MOTION=new WeakHashMap<>();
 private static Object world;
 private static class Motion { Quaternionf rotation=new Quaternionf(); double time,landing=-10,phase; boolean ground; }
 public static boolean enabled(){return XVisuals.ready()&&XVisuals.visualModule("itemphysics").enabled;}
 public static void update(ItemEntity entity,ItemEntityRenderState state,float delta){
  var client=MinecraftClient.getInstance();
  if(world!=client.world||!enabled()){MOTION.clear();world=client.world;}
  ((State)state).visuals$setPose(null);
  if(!enabled() || XVisuals.visualModule("itemphysics").text("mode").equals("Vanilla"))return;
  var s=XVisuals.visualModule("itemphysics");
  double time=(entity.age+delta)*.05;
  boolean ground=entity.isOnGround(),water=entity.isTouchingWater()&&s.flag("water");
  Motion m=MOTION.get(entity);boolean fresh=m==null;
  if(fresh){if(MOTION.size()>=2048)MOTION.clear();m=new Motion();m.time=time;m.ground=ground;MOTION.put(entity,m);}
  double dt=Math.clamp(time-m.time,0,.1);m.time=time;
  boolean varied=s.flag("random");int seed=entity.getId();
  double phase=varied?ItemPhysicsMath.phase(seed):0;
  if(ground&&!m.ground&&!water)m.landing=time;
  m.ground=ground;
  var bounds=state.itemRenderState.getModelBoundingBox();
  // Flat generated items lie on their broad face; volumetric models keep an upright face.
  boolean flat=bounds.getLengthZ()<=.0626;
  float pitch=0,yaw=(float)phase,roll=0;
  if(water){pitch=(flat?(float)Math.PI/2:0)+(float)Math.sin(time*1.3+phase)*.12f;yaw+=(float)(time*.18);roll=(float)Math.cos(time*.9+phase)*.08f;}
  else if(ground&&s.flag("align")){
   pitch=flat?(float)Math.PI/2:0;
   double age=time-m.landing;
   if(varied&&s.flag("bounce")&&age>=0&&age<1){
    double rocking=Math.sin(age*(12+ItemPhysicsMath.random(seed,11)*6))*Math.exp(-age*6)*(1-age)*.14*s.number("intensity");
    pitch+=(float)(rocking*Math.cos(phase));roll=(float)(rocking*Math.sin(phase));
   }
  }
  else if(s.flag("rotation")&&!ground){
   double t=time*s.number("speed"),flutter=varied?ItemPhysicsMath.flutter(seed,t):0;
   pitch=(float)(t*(varied?ItemPhysicsMath.spin(seed,0):2.3)+phase+flutter);
   yaw+=(float)(t*(varied?ItemPhysicsMath.spin(seed,1):1.7));
   roll=(float)(t*(varied?ItemPhysicsMath.spin(seed,2):1.1)+phase*.7-flutter*.65);
  }
  else if(ground&&!s.flag("align")){ // Freeze the last airborne pose instead of snapping upright.
   pitch=Float.NaN;
  }
  Quaternionf target=Float.isNaN(pitch)?new Quaternionf(m.rotation):new Quaternionf().rotationYXZ(yaw,pitch,roll);
  if(fresh||!s.flag("smooth"))m.rotation.set(target);else m.rotation.slerp(target,ItemPhysicsMath.blend(dt));
  double lift=ground&&s.flag("bounce")?ItemPhysicsMath.bounce((time-m.landing)*(varied?ItemPhysicsMath.bounceRate(seed):1),s.number("intensity")*(varied?ItemPhysicsMath.bounceStrength(seed):1)):0;
  if(water)lift=.035+Math.sin(time*1.8+phase)*.025;
  ((State)state).visuals$setPose(new Pose(new Quaternionf(m.rotation),(float)s.number("scale"),(float)lift,s.flag("stacks")?Math.min(5,state.renderedAmount):1,phase));
 }
 public static void render(ItemEntityRenderState state,Pose pose,MatrixStack matrices,OrderedRenderCommandQueue queue){
  var box=state.itemRenderState.getModelBoundingBox();
  // Transform all bounding corners to keep tilted models above the entity's ground plane.
  float min=Float.POSITIVE_INFINITY;var point=new Vector3f();
  for(int i=0;i<8;i++){point.set((float)((i&1)==0?box.minX:box.maxX),(float)((i&2)==0?box.minY:box.maxY),(float)((i&4)==0?box.minZ:box.maxZ));pose.rotation.transform(point);min=Math.min(min,point.y);}
  for(int i=0;i<pose.copies;i++){
   matrices.push();double angle=pose.phase+i*2.39996,spread=i==0?0:.045*Math.sqrt(i)*pose.scale;
   matrices.translate(Math.cos(angle)*spread,.012-min*pose.scale+pose.lift+i*.018*pose.scale,Math.sin(angle)*spread);
   matrices.multiply(pose.rotation);matrices.scale(pose.scale,pose.scale,pose.scale);
   state.itemRenderState.render(matrices,queue,state.light,OverlayTexture.DEFAULT_UV,state.outlineColor);
   matrices.pop();
  }
 }
 private ItemPhysics(){}
}
