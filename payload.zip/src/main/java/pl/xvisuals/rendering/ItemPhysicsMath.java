package pl.xvisuals.rendering;

public final class ItemPhysicsMath {
 private ItemPhysicsMath() {}
 /** Independent deterministic channels: one motion identity per dropped entity, no frame jitter. */
 public static double random(int id,int channel){
  int n=id+0x9e3779b9*(channel+1);n=(n^(n>>>16))*0x85ebca6b;n=(n^(n>>>13))*0xc2b2ae35;n^=n>>>16;
  return Integer.toUnsignedLong(n)/4294967296d;
 }
 public static int pattern(int id){return (int)(random(id,0)*4);}
 public static double spin(int id,int axis){
  double weight=switch(pattern(id)){
   case 0->axis==0?2.8:axis==1?.45:.3; // end-over-end
   case 1->axis==0?.35:axis==1?.55:2.6; // side roll
   case 2->axis==0?1.15:axis==1?2.5:.8; // corkscrew
   default->axis==0?.45:axis==1?.8:.5; // drifting flutter
  };
  return weight*(.7+random(id,axis+1)*.6)*(random(id,axis+4)<.5?-1:1);
 }
 public static double flutter(int id,double time){return pattern(id)==3?Math.sin(time*(1.5+random(id,8))+phase(id))*.3:0;}
 public static double bounceRate(int id){return .8+random(id,9)*.5;}
 public static double bounceStrength(int id){return .75+random(id,10)*.5;}

 public static double bounce(double seconds,double strength) {
  if(seconds<0 || seconds>=.8)return 0;
  return Math.abs(Math.sin(seconds*Math.PI*3/.8))*Math.exp(-seconds*5)*.18*Math.clamp(strength,0,2)*(1-seconds/.8);
 }
 public static float blend(double seconds){return (float)(1-Math.exp(-Math.max(0,seconds)*12));}
 public static double phase(int id){long n=Integer.toUnsignedLong(id)*2654435761L;return (n&65535)/65536d*Math.PI*2;}
}
