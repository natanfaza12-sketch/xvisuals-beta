package pl.xvisuals.rendering;

/** Bounded camera displacement keeps distant sky shells stable even after teleporting. */
public final class SkyDepth {
  public static float offset(double displacement,double strength){
    if(!Double.isFinite(displacement)||!Double.isFinite(strength))return 0;
    return (float)(Math.tanh(displacement/384.)*48*Math.clamp(strength,0,2));
  }
  private SkyDepth(){}
}
