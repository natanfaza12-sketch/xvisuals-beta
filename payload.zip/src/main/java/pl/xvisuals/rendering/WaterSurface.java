package pl.xvisuals.rendering;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.*;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import pl.xvisuals.mixins.RenderLayerAccessor;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.client.render.fluid.v1.*;
import net.minecraft.block.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.color.world.BiomeColors;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.client.texture.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.fluid.*;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.*;
import net.minecraft.util.math.*;
import net.minecraft.world.*;
import java.nio.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Animated surface sheen over intact vanilla water. No chunk geometry or fluid state is removed. */
public final class WaterSurface {
 private record Patch(BlockPos pos,float height,int tint,float light){}
 private record Snapshot(Object world,Map<BlockPos,Patch> patches){}
 private static volatile Snapshot desired=new Snapshot(null,Map.of());
 private static final Map<BlockPos,Patch> scanning=new HashMap<>();
 private static FluidRenderHandler original;
 private static Object world;
 private static volatile int ticks;
 private static int scan,cx,cz,cy,radius;
 private static double time;
 private static boolean initialized,failed,wasEnabled;
 private static final BufferAllocator ALLOCATOR=new BufferAllocator(2097152);
 private static final VertexConsumerProvider.Immediate BUFFERS=VertexConsumerProvider.immediate(ALLOCATOR);
 private static final ByteBuffer DATA=ByteBuffer.allocateDirect(592).order(ByteOrder.nativeOrder());
 private static GpuBuffer uniform;
 private static final RenderLayer LAYER=RenderLayerAccessor.visuals$of("visual_animated_water",RenderSetup.builder(RenderPipeline.builder()
  .withLocation(Identifier.of("xvisuals","pipeline/water_surface"))
  .withVertexShader(Identifier.of("xvisuals","core/water_surface"))
  .withFragmentShader(Identifier.of("xvisuals","core/water_surface"))
  .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER)
  .withUniform("Fog",UniformType.UNIFORM_BUFFER).withUniform("VisualWater",UniformType.UNIFORM_BUFFER).withSampler("Sampler0")
  .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS)
  .withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withDepthWrite(false).withCull(false).build())
  .texture("Sampler0",SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE).translucent().expectedBufferSize(2097152).build());
 public static void init(){
  if(initialized)return;initialized=true;original=FluidRenderHandlerRegistry.INSTANCE.get(Fluids.WATER);
  if(original==null)return;
  // Keep vanilla water geometry. The animated surface is a depth-tested sheen,
  // so asynchronous chunk rebuilds can never punch holes in the water body.
  ClientTickEvents.END_CLIENT_TICK.register(WaterSurface::tick);
  ClientLifecycleEvents.CLIENT_STOPPING.register(c->{ALLOCATOR.close();if(uniform!=null)uniform.close();});
 }
 private static boolean on(){return !failed&&XVisuals.ready()&&XVisuals.visualModule("waterripples").enabled&&!ShaderPackSupport.active();}
 private static boolean source(BlockRenderView w,BlockPos p){return w.getBlockState(p).isOf(Blocks.WATER)&&w.getFluidState(p).isStill()&&w.getFluidState(p).isIn(FluidTags.WATER);}
 private static boolean present(MinecraftClient c,BlockPos p){return c.world.isChunkLoaded(p.getX()>>4,p.getZ()>>4)&&source(c.world,p)&&c.world.getBlockState(p.up()).isAir();}
 private static boolean eligible(BlockRenderView w,BlockPos p){
  // Keep waterfalls, waterlogged blocks, slopes, shorelines and overhangs in their original renderer.
  for(int x=-1;x<=1;x++)for(int z=-1;z<=1;z++){
   var q=p.add(x,0,z);if(!source(w,q)||!w.getBlockState(q.up()).isAir())return false;
  }
  var below=p.down();return w.getFluidState(below).isIn(FluidTags.WATER)||w.getBlockState(below).isSideSolidFullSquare(w,below,Direction.UP);
 }
 private static void publish(MinecraftClient c,Map<BlockPos,Patch> next){desired=new Snapshot(c.world,Map.copyOf(next));}
 private static void tick(MinecraftClient c){
  if(world!=c.world){world=c.world;desired=new Snapshot(world,Map.of());scanning.clear();scan=0;failed=false;time=0;wasEnabled=false;}
  if(c.world==null||c.player==null||c.isPaused())return;
  ticks++;time+=.05;
  // A completed discovery sweep can take several ticks. Never keep drawing drained or
  // covered water from its previous snapshot, or republish it from an unfinished sweep.
  var retained=WaterSurfaceSnapshot.retain(desired.patches,p->present(c,p));
  if(retained!=desired.patches)publish(c,retained);
  scanning.keySet().removeIf(p->!present(c,p));
  boolean enabled=on();
  if(!enabled){if(wasEnabled){publish(c,Map.of());scanning.clear();scan=0;}wasEnabled=false;}
  else{
   var s=XVisuals.visualModule("waterripples");var camera=c.gameRenderer.getCamera().getCameraPos();
   int nr=WaterSurfaceMath.radius(s.number("distance"),s.text("quality"));
   int nx=MathHelper.floor(camera.x),nz=MathHelper.floor(camera.z),ny=MathHelper.floor(camera.y);
   if(!wasEnabled||Math.abs(cx-nx)>4||Math.abs(cz-nz)>4||Math.abs(cy-ny)>6||radius!=nr){cx=nx;cz=nz;cy=ny;radius=nr;scan=0;scanning.clear();}
   wasEnabled=true;int diameter=radius*2+1,total=diameter*diameter;
   for(int n=0;n<160;n++){
    int index=scan++,x=cx+index%diameter-radius,z=cz+index/diameter-radius;
    if(c.world.isChunkLoaded((x-1)>>4,(z-1)>>4)&&c.world.isChunkLoaded((x+1)>>4,(z+1)>>4)){
     int roof=c.world.getTopY(Heightmap.Type.MOTION_BLOCKING,x,z)-1;
     BlockPos found=null;
     if(Math.abs(roof-cy)<18){var p=new BlockPos(x,roof,z);if(eligible(c.world,p))found=p;}
     if(found==null)for(int y=cy+3;y>=cy-7;y--){var p=new BlockPos(x,y,z);if(eligible(c.world,p)){found=p;break;}}
     if(found!=null){int light=WorldRenderer.getLightmapCoordinates(c.world,found.up());float l=Math.max(light&255,(light>>16)&255)/240f;scanning.put(found,new Patch(found,.8888889f-.001f,BiomeColors.getWaterColor(c.world,found),.23f+.77f*l));}
    }
    if(scan>=total){publish(c,scanning);scanning.clear();scan=0;break;}
   }
  }

 }
 public static void bind(RenderPass pass){if(uniform!=null)pass.setUniform("VisualWater",uniform);}
 private static void vec(double x,double y,double z,double w){DATA.putFloat((float)x).putFloat((float)y).putFloat((float)z).putFloat((float)w);}
 public static void render(MatrixStack matrices){
  var c=MinecraftClient.getInstance();if(c.world==null||c.player==null||world!=c.world||original==null||!on())return;
  var patches=desired.patches;
  if(patches.isEmpty())return;
  var s=XVisuals.visualModule("waterripples");var camera=c.gameRenderer.getCamera().getCameraPos();
  var sprite=original.getFluidSprites(c.world,c.player.getBlockPos(),Fluids.WATER.getDefaultState())[0];if(sprite==null)return;
  float delta=c.getRenderTickCounter().getTickProgress(false);var wind=AtmosphericWind.sample(time);
  DATA.clear();int waves=on()?WaterRipples.waveCount(s.text("quality")):0;
  vec(time+delta*.05,on()?s.number("waves"):0,waves,radius);
  vec(wind.x(),wind.z(),s.number("speed"),s.number("opacity"));
  int color=s.color("color");vec(((color>>16)&255)/255d,((color>>8)&255)/255d,(color&255)/255d,s.number("surfaceTint"));
  vec(camera.x-Math.floor(camera.x/4096)*4096,camera.z-Math.floor(camera.z/4096)*4096,1,s.number("highlights"));
  vec(sprite.getMinU(),sprite.getMinV(),sprite.getMaxU(),sprite.getMaxV());
  WaterRipples.writeWaves(DATA,camera,delta,waves);DATA.flip();
  try{
   if(uniform==null)uniform=RenderSystem.getDevice().createBuffer(()->"Water surface waves",GpuBuffer.USAGE_UNIFORM|GpuBuffer.USAGE_COPY_DST,DATA);
   else RenderSystem.getDevice().createCommandEncoder().writeToBuffer(uniform.slice(),DATA);
   var sorted=new ArrayList<>(patches.values());sorted.sort(Comparator.comparingDouble((Patch p)->p.pos.getSquaredDistance(camera)).reversed());
   int divisions=WaterSurfaceMath.subdivisions(s.text("quality"));var matrix=matrices.peek().getPositionMatrix();var out=BUFFERS.getBuffer(LAYER);
   for(var p:sorted){
    if(!c.world.isChunkLoaded(p.pos.getX()>>4,p.pos.getZ()>>4))continue;
    boolean west=corner(desired.patches,p.pos),east=corner(desired.patches,p.pos.east()),north=corner(desired.patches,p.pos.south()),south=corner(desired.patches,p.pos.east().south());
    for(int x=0;x<divisions;x++)for(int z=0;z<divisions;z++){
     double u=x/(double)divisions,v=z/(double)divisions,d=1d/divisions;
     vertex(out,matrix,p,camera,sprite,u,v,west,east,north,south);vertex(out,matrix,p,camera,sprite,u,v+d,west,east,north,south);
     vertex(out,matrix,p,camera,sprite,u+d,v+d,west,east,north,south);vertex(out,matrix,p,camera,sprite,u+d,v,west,east,north,south);
    }
   }
   BUFFERS.draw();
  }catch(RuntimeException ex){failed=true;desired=new Snapshot(world,Map.of());org.slf4j.LoggerFactory.getLogger("VisualClient").warn("Water ripple overlay unavailable; original water remains intact",ex);}
 }
 private static boolean corner(Map<BlockPos,Patch> patches,BlockPos p){return patches.containsKey(p)&&patches.containsKey(p.west())&&patches.containsKey(p.north())&&patches.containsKey(p.west().north());}
 private static void vertex(VertexConsumer out,org.joml.Matrix4f m,Patch p,Vec3d camera,Sprite sprite,double u,double v,boolean west,boolean east,boolean north,boolean south){
  double weight=desired.patches.containsKey(p.pos)?WaterSurfaceMath.cornerWeight(u,v,west,east,north,south):0;
  int r=(int)(((p.tint>>16)&255)*p.light),g=(int)(((p.tint>>8)&255)*p.light),b=(int)((p.tint&255)*p.light);
  out.vertex(m,(float)(p.pos.getX()+u-camera.x),(float)(p.pos.getY()+p.height-camera.y),(float)(p.pos.getZ()+v-camera.z))
   .texture(MathHelper.lerp((float)u,sprite.getMinU(),sprite.getMaxU()),MathHelper.lerp((float)v,sprite.getMinV(),sprite.getMaxV())).color(r,g,b,(int)(weight*255));
 }
 private WaterSurface(){}
}
