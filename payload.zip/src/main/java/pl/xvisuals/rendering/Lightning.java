package pl.xvisuals.rendering;

import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import pl.xvisuals.mixins.RenderLayerAccessor;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import java.util.*;

/** Client-rendered bolts only. No lightning entity, weather mutation or network traffic. */
public final class Lightning {
  private static final Random RANDOM=new Random();
  private static final List<Bolt> BOLTS=new ArrayList<>(2);
  private static final ArrayDeque<Thunder> SOUNDS=new ArrayDeque<>(4);
  private static final BufferAllocator ALLOCATOR=new BufferAllocator(524288);
  private static final VertexConsumerProvider.Immediate BUFFERS=VertexConsumerProvider.immediate(ALLOCATOR);
  private static final RenderLayer LAYER=RenderLayerAccessor.visuals$of("xvisuals_lightning",
      RenderSetup.builder(RenderPipeline.builder()
        .withLocation(Identifier.of("xvisuals","pipeline/local_lightning"))
        .withVertexShader(Identifier.of("xvisuals","core/player_sprite"))
        .withFragmentShader(Identifier.of("xvisuals","core/local_lightning"))
        .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER)
        .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS)
        .withBlend(new BlendFunction(com.mojang.blaze3d.platform.SourceFactor.SRC_ALPHA,com.mojang.blaze3d.platform.DestFactor.ONE))
        .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withDepthWrite(false).withCull(false).build())
        .translucent().expectedBufferSize(524288).build());
  private static Object world;
  private static int ticks,countdown;
  private static double previousFrequency;
  private record Bolt(Vec3d origin,List<LightningPattern.Segment> segments,int born) {}
  private record Thunder(int due,double distance) {}

  public static void init() {
    WorldRenderEvents.END_MAIN.register(context->render(context.matrices()));
    net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING.register(c->ALLOCATOR.close());
  }
  private static boolean enabled() {
    var c=MinecraftClient.getInstance();
    return c.world!=null && c.player!=null && XVisuals.ready()
        && XVisuals.visualModule("lightning").enabled;
  }
  public static void tick(MinecraftClient c) {
    if(world!=c.world || !enabled()) {
      BOLTS.clear();SOUNDS.clear();ticks=0;countdown=0;previousFrequency=0;world=c.world;
    }
    if(!enabled() || c.isPaused())return;
    ticks++;
    var settings=XVisuals.visualModule("lightning");
    double frequency=settings.number("frequency");
    if(countdown==0 || frequency!=previousFrequency) {
      countdown=LightningPattern.intervalTicks(frequency,RANDOM.nextDouble());previousFrequency=frequency;
    }
    BOLTS.removeIf(b->ticks-b.born>=20);
    if(!settings.flag("thunder"))SOUNDS.clear();
    while(!SOUNDS.isEmpty() && SOUNDS.peekFirst().due<=ticks) {
      var sound=SOUNDS.removeFirst();
      var camera=c.gameRenderer.getCamera().getCameraPos();
      boolean outdoors=c.world.isSkyVisible(BlockPos.ofFloored(camera));
      float volume=(float)((outdoors?.85:.3)*(1-.45*sound.distance/96));
      c.world.playSoundClient(camera.x,camera.y,camera.z,SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER,
          SoundCategory.WEATHER,volume,.85f+RANDOM.nextFloat()*.15f,false);
    }
    if(--countdown>0)return;
    countdown=LightningPattern.intervalTicks(frequency,RANDOM.nextDouble());
    var camera=c.gameRenderer.getCamera().getCameraPos();
    double distance=LightningPattern.distance(settings.number("distance"));
    // Never request an unloaded chunk or perform per-frame terrain queries.
    var look=new org.joml.Vector3f(0,0,-1).rotate(c.gameRenderer.getCamera().getRotation());
    double heading=Math.atan2(look.z,look.x);
    for(int attempt=0;attempt<8;attempt++) {
      // Prefer the current view; keep fallback strikes around the player when terrain blocks it.
      double angle=attempt<6?heading+(RANDOM.nextDouble()-.5)*Math.toRadians(80):RANDOM.nextDouble()*Math.PI*2;
      double radius=distance*(.8+.2*RANDOM.nextDouble());
      int x=(int)Math.floor(camera.x+Math.cos(angle)*radius),z=(int)Math.floor(camera.z+Math.sin(angle)*radius);
      if(!c.world.isChunkLoaded(x>>4,z>>4))continue;
      int y=c.world.getTopY(Heightmap.Type.MOTION_BLOCKING,x,z);
      if(y<=c.world.getBottomY())continue;
      if(BOLTS.size()==2)BOLTS.removeFirst();
      BOLTS.add(new Bolt(new Vec3d(x+.5,y+.04,z+.5),LightningPattern.create(RANDOM.nextLong(),38+RANDOM.nextDouble()*70),ticks));
      if(settings.flag("thunder") && SOUNDS.size()<4)
        SOUNDS.addLast(new Thunder(ticks+LightningPattern.thunderTicks(radius),radius));
      break;
    }
  }
  public static float flash() {
    if(!enabled() || world!=MinecraftClient.getInstance().world)return 0;
    var settings=XVisuals.visualModule("lightning");
    double intensity=LightningPattern.unit(settings.number("flash")),maximum=0;
    float delta=MinecraftClient.getInstance().getRenderTickCounter().getTickProgress(false);
    for(var bolt:BOLTS)maximum=Math.max(maximum,LightningPattern.opacity((ticks-bolt.born+delta)/20d));
    return (float)(maximum*intensity*.3);
  }
  public static int color() { return enabled()?XVisuals.visualModule("lightning").color("color"):0xFFFFFF; }
  public static float flashChannel(int shift) { return flash()*((color()>>>shift)&255)/255f; }
  public static int skyColor(int original) {
    double amount=flash();if(amount==0)return original;
    int tint=color(),result=original&0xFF000000;
    for(int shift=0;shift<=16;shift+=8)result|=(int)Math.min(255,((original>>>shift)&255)+((tint>>>shift)&255)*amount)<<shift;
    return result;
  }
  private static void render(MatrixStack matrices) {
    var c=MinecraftClient.getInstance();
    if(!enabled() || world!=c.world || BOLTS.isEmpty())return;
    var camera=c.gameRenderer.getCamera().getCameraPos();
    float delta=c.getRenderTickCounter().getTickProgress(false);
    var out=BUFFERS.getBuffer(LAYER);
    int tint=color();
    for(var bolt:BOLTS) {
      double alpha=LightningPattern.opacity((ticks-bolt.born+delta)/20d);
      if(alpha<.005)continue;
      matrices.push();matrices.translate(bolt.origin.subtract(camera));
      var m=matrices.peek().getPositionMatrix();
      for(var s:bolt.segments) {
        double dx=s.x1()-s.x0(),dy=s.y1()-s.y0(),dz=s.z1()-s.z0();
        double vx=camera.x-bolt.origin.x-(s.x0()+s.x1())*.5;
        double vy=camera.y-bolt.origin.y-(s.y0()+s.y1())*.5;
        double vz=camera.z-bolt.origin.z-(s.z0()+s.z1())*.5;
        double nx=dy*vz-dz*vy,ny=dz*vx-dx*vz,nz=dx*vy-dy*vx;
        double length=Math.sqrt(nx*nx+ny*ny+nz*nz);
        if(length<.0001){nx=1;ny=nz=0;length=1;}
        nx/=length;ny/=length;nz/=length;
        // Three nested, softly feathered widths: atmospheric halo, colored channel, hot core.
        for(int layer=0;layer<3;layer++) {
          double scale=layer==0?7:layer==1?2.3:.8;
          double w0=s.width0()*scale,w1=s.width1()*scale;
          double opacity=alpha*(layer==0?.075:layer==1?.24:.95)*(s.branch()?.78:1);
          int rgb=layer<2?tint:coreColor(tint);
          int rgba=((int)(opacity*255)<<24)|(rgb&0xFFFFFF);
          out.vertex(m,(float)(s.x0()-nx*w0),(float)(s.y0()-ny*w0),(float)(s.z0()-nz*w0)).texture(0,0).color(rgba);
          out.vertex(m,(float)(s.x0()+nx*w0),(float)(s.y0()+ny*w0),(float)(s.z0()+nz*w0)).texture(1,0).color(rgba);
          out.vertex(m,(float)(s.x1()+nx*w1),(float)(s.y1()+ny*w1),(float)(s.z1()+nz*w1)).texture(1,1).color(rgba);
          out.vertex(m,(float)(s.x1()-nx*w1),(float)(s.y1()-ny*w1),(float)(s.z1()-nz*w1)).texture(0,1).color(rgba);
        }
      }
      matrices.pop();
    }
    BUFFERS.draw();
  }
  private static int coreColor(int tint) {
    int result=0;
    for(int shift=0;shift<=16;shift+=8)result|=(int)(((tint>>>shift)&255)*.45+255*.55)<<shift;
    return result;
  }
  private Lightning() {}
}
