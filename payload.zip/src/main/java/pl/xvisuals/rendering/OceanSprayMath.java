package pl.xvisuals.rendering;
import java.util.Set;
public final class OceanSprayMath {
 private static final Set<String> BIOMES=Set.of("ocean","deep_ocean","cold_ocean","deep_cold_ocean","frozen_ocean","deep_frozen_ocean","lukewarm_ocean","deep_lukewarm_ocean","warm_ocean","beach","snowy_beach","stony_shore");
 public static boolean supported(String biome){return biome.startsWith("minecraft:")&&BIOMES.contains(biome.substring(10));}
 public static int cap(String quality){return quality.equals("Low")?64:quality.equals("High")?192:128;}
 public static double launchSpeed(double height){return Math.sqrt(2*.7*Math.max(0,height-.15));}
 public static double weather(double wind,double rain,boolean storm){return Math.min(2,.6+Math.max(0,wind)*.4+Math.clamp(rain,0,1)*.3+(storm?.4:0));}
 public static boolean canSpawn(String surfaceBiome,boolean exposed,double distanceSquared,double radius){
  return supported(surfaceBiome)&&exposed&&distanceSquared<=radius*radius;
 }
 public static double alpha(boolean mist,double age,double life,double opacity,double blend,double distance,double radius){
  return LavafallMistMath.fade(age,life)*JungleMistMath.fade(distance,radius)*Math.clamp(blend,0,1)*Math.clamp(opacity,0,1)*(mist?.18:.7);
 }
 private OceanSprayMath(){}
}
