package pl.xvisuals.rendering;
/** Shared monotonic animation time. Pauses freeze time; stalls cannot launch effects forward. */
public final class AmbientClock {
 private long last=-1; private double seconds;
 public double advance(long nanos,boolean paused) {
  if(last>=0 && !paused)seconds+=Math.clamp((nanos-last)/1e9,0,.1);
  last=nanos;return seconds;
 }
 public double seconds(){return seconds;}
 public void reset(){last=-1;seconds=0;}
}
