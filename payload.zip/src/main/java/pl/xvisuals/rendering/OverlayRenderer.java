package pl.xvisuals.rendering;

import pl.xvisuals.XVisuals;
import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.modules.entity.EntityVisuals;
import pl.xvisuals.modules.world.BlockHighlights;
import pl.xvisuals.rendering.particles.ParticleEngine;
import pl.xvisuals.util.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.*;
import net.minecraft.util.math.*;

public final class OverlayRenderer {
  public static final Projection PROJECTION = new Projection();
  private static final Projection.Point[] POINTS = new Projection.Point[8];
  private static final Projection.Point A = new Projection.Point(), B = new Projection.Point();
  private static final int[][] EDGES = {
    {0, 1}, {1, 3}, {3, 2}, {2, 0}, {4, 5}, {5, 7}, {7, 6}, {6, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}
  };

  static {
    for (int i = 0; i < 8; i++) POINTS[i] = new Projection.Point();
  }

  public static void render(DrawContext g, float tick) {
    var c = MinecraftClient.getInstance();
    if (c.world == null || c.player == null) return;
    PROJECTION.begin(c, tick);
    var cfg = XVisuals.config();
    
    for (var t : EntityVisuals.TARGETS) {
      if (t.entity.isRemoved()) continue;
      if (t.entity instanceof ItemEntity) continue;
      var s = t.settings();
      if (!s.enabled || s.text("depth").equals("Visible Only") && !t.visible) continue;
      Vec3d p = t.entity.getLerpedPos(tick);
      double half = t.entity.getWidth() / 2.0;
      double alpha =
          s.number("opacity")
              * (s.flag("fade") ? Math.max(.08, 1 - t.distance / s.number("distance")) : 1);
      int color = Colors.alpha(EntityVisuals.color(t), alpha);
      String style = s.text("style");
      box(
          g,
          p.x - half,
          p.y,
          p.z - half,
          p.x + half,
          p.y + t.entity.getHeight(),
          p.z + half,
          style,
          color,
          s.number("width"),
          s.number("fill"),
          s.number("bloom") * Quality.glow(),
          s.number("radius"),
          s.color("secondary"),
          s.text("gradient"));
      if (cfg.on("nametags")) nametag(g, t, p);
    }
    pl.xvisuals.modules.entity.ItemEsp.render(g, PROJECTION);
    if (cfg.on("blocks")) {
      var s = cfg.module("blocks");
      int count = 0;
      if (s.text("mode").equals("Nearby blocks")) for (var h : BlockHighlights.nearest(c)) {
        if (count++ >= Math.max(32, Quality.entityCap() * 2)) break;
        var p = h.pos();
        if (s.flag("depth") && !BlockHighlights.visible(h)) continue;
        var state=c.world.getBlockState(p);
        var shape=state.getOutlineShape(c.world,p,net.minecraft.block.ShapeContext.of(c.player));
        if(shape.isEmpty())continue;
        var bounds=shape.getBoundingBox();
        double distance=Math.sqrt(p.getSquaredDistance(c.player.getBlockPos()));
        double fade=Math.clamp((s.number("distance")-distance)/4,0,1);
        int color = Colors.alpha(h.color(), s.number("opacity")*fade);
        String style = s.text("style");
        box(
            g,
            p.getX()+bounds.minX,
            p.getY()+bounds.minY,
            p.getZ()+bounds.minZ,
            p.getX()+bounds.maxX,
            p.getY()+bounds.maxY,
            p.getZ()+bounds.maxZ,
            style,
            color,
            s.number("width"),
            .15,
            Quality.glow() * .5,
            3,
            h.color(),
            "Vertical");
        if (PROJECTION.project(p.getX() + .5, p.getY() + .5, p.getZ() + .5, A) && A.visible) {
          if (style.equals("Beam")
              && PROJECTION.project(p.getX() + .5, p.getY() + 20, p.getZ() + .5, B))
            Glass.glowLine(g, A.x, A.y, B.x, B.y, 2, color, Quality.glow());
          if (style.equals("Distance Label"))
            Glass.center(
                g,
                (int) Math.sqrt(p.getSquaredDistance(c.player.getBlockPos())) + "m",
                (float) A.x,
                (float) A.y,
                color);
        }
      }
    }
    
    
    pl.xvisuals.modules.combat.HitEffects.render(g, PROJECTION);

    if (cfg.on("lens")) {
      int bar = (int) (PROJECTION.height * cfg.module("lens").number("letterbox"));
      if (bar > 0) {
        g.fill(0, 0, PROJECTION.width, bar, 0xFF030407);
        g.fill(0, PROJECTION.height - bar, PROJECTION.width, PROJECTION.height, 0xFF030407);
      }
    }
  }

  public static void box(
      DrawContext g,
      double x1,
      double y1,
      double z1,
      double x2,
      double y2,
      double z2,
      String style,
      int color,
      double width,
      double fill,
      double glow,
      double radius,
      int secondary,
      String gradient) {
    // Native silhouettes need no projected box or GUI geometry.
    if (style.equals("Glow Outline")) return;
    double minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
    boolean in = false;
    for (int i = 0; i < 8; i++) {
      var p = POINTS[i];
      if (!PROJECTION.project(
          (i & 1) == 0 ? x1 : x2, (i & 2) == 0 ? y1 : y2, (i & 4) == 0 ? z1 : z2, p)) return;
      in |= p.visible;
      minX = Math.min(minX, p.x);
      minY = Math.min(minY, p.y);
      maxX = Math.max(maxX, p.x);
      maxY = Math.max(maxY, p.y);
    }
    if (!in || maxX - minX > PROJECTION.width * 2 || maxY - minY > PROJECTION.height * 2) return;
    float x = (float) minX, y = (float) minY, w = (float) (maxX - minX), h = (float) (maxY - minY);
    if (w < 1 || h < 1) return;
    switch (style) {
      case "Glow Outline" -> {} // The native entity silhouette is supplied by EntityMixin.
      case "Neon Outline" -> {
        if (glow > 0) outline(g, x, y, w, h, color, width, glow);
      }
      case "Filled Glow", "Filled" -> {
        Glass.rounded(g, x, y, w, h, 2, Colors.alpha(color, fill * ((color >>> 24) / 255.0)));
        outline(g, x, y, w, h, color, width, glow);
      }
      case "Soft Aura" -> {
        for (int i = 3; i > 0; i--)
          Glass.rounded(
              g,
              x - (float) radius * i,
              y - (float) radius * i,
              w + (float) radius * i * 2,
              h + (float) radius * i * 2,
              8,
              Colors.alpha(color, .025 * glow));
      }
      case "Soft Outline" -> {
        Glass.rounded(g, x, y, w, h, 3, Colors.alpha(color, fill * .45));
        outline(g, x, y, w, h, Colors.mix(color, 0xFFFFFFFF, .45), width, glow * .35);
      }
      case "Corner Boxes", "Corner Box" -> {
        double a = Math.min(w, h) * .25;
        for (int i = 0; i < 4; i++) {
          double cx = (i & 1) == 0 ? x : x + w, cy = (i & 2) == 0 ? y : y + h;
          Glass.glowLine(g, cx, cy, cx + ((i & 1) == 0 ? a : -a), cy, width, color, glow);
          Glass.glowLine(g, cx, cy, cx, cy + ((i & 2) == 0 ? a : -a), width, color, glow);
        }
      }
      case "3D Box",
          "Wireframe",
          "Box",
          "Outline",
          "Glowing",
          "Beam",
          "Distance Label" -> {
        for (int[] edge : EDGES) {
          var a = POINTS[edge[0]];
          var b = POINTS[edge[1]];
          Glass.glowLine(g, a.x, a.y, b.x, b.y, width, color, style.equals("Glowing") ? glow : 0);
        }
        if (style.equals("Wireframe")) {
          Glass.line(
              g,
              POINTS[0].x,
              POINTS[0].y,
              POINTS[7].x,
              POINTS[7].y,
              width,
              Colors.alpha(color, .45));
          Glass.line(
              g,
              POINTS[1].x,
              POINTS[1].y,
              POINTS[6].x,
              POINTS[6].y,
              width,
              Colors.alpha(color, .45));
        }
      }
      case "Skeleton" -> {
        double cx = x + w / 2;
        Glass.dot(g, cx, y + h * .13, Math.max(2, w * .24), color, 0);
        Glass.line(g, cx, y + h * .24, cx, y + h * .64, width, color);
        Glass.line(g, x + w * .1, y + h * .5, cx, y + h * .3, width, color);
        Glass.line(g, x + w * .9, y + h * .5, cx, y + h * .3, width, color);
        Glass.line(g, cx, y + h * .64, x + w * .2, y + h, width, color);
        Glass.line(g, cx, y + h * .64, x + w * .8, y + h, width, color);
      }
      case "Gradient" -> {
        for (int i = 0; i < 12; i++) {
          double t = i / 12.0;
          int tint = Colors.alpha(Colors.mix(color, secondary, t), (color >>> 24) / 255.0);
          if (gradient.equals("Horizontal")) {
            Glass.line(g, x + w * t, y, x + w * (t + 1 / 12.0), y, width, tint);
            Glass.line(g, x + w * t, y + h, x + w * (t + 1 / 12.0), y + h, width, tint);
          } else {
            Glass.line(g, x, y + h * t, x, y + h * (t + 1 / 12.0), width, tint);
            Glass.line(g, x + w, y + h * t, x + w, y + h * (t + 1 / 12.0), width, tint);
          }
        }
      }
      case "Minimal" -> Glass.line(g, x, y + h, x + w, y + h, width, color);
      default -> outline(g, x, y, w, h, color, width, glow);
    }
  }

  private static void outline(
      DrawContext g, double x, double y, double w, double h, int color, double width, double glow) {
    Glass.glowLine(g, x, y, x + w, y, width, color, glow);
    Glass.glowLine(g, x + w, y, x + w, y + h, width, color, glow);
    Glass.glowLine(g, x + w, y + h, x, y + h, width, color, glow);
    Glass.glowLine(g, x, y + h, x, y, width, color, glow);
  }

  private static void nametag(DrawContext g, EntityVisuals.Target t, Vec3d p) {
    var s = XVisuals.config().module("nametags");
    if (t.distance > s.number("distance") || s.flag("depth") && !t.visible || t.label == null)
      return;
    if (!PROJECTION.project(p.x, p.y + t.entity.getHeight() + .25, p.z, A) || !A.visible) return;
    float scale =
        (float) (Math.clamp(s.number("scale") * .65, .35, .85) * Math.max(.8, 1 - t.distance / 400));
    String label = t.label;
    if (Glass.textWidth(label) > 170) label = MinecraftClient.getInstance().textRenderer
        .trimToWidth(Glass.label(label), 160).getString() + "…";
    int w = Glass.textWidth(label) + 12;
    g.getMatrices().pushMatrix();
    g.getMatrices().translate((float) A.x, (float) A.y);
    g.getMatrices().scale(scale, scale);
    Glass.rounded(g, -w / 2f, -11, w, 15, 3, Colors.alpha(0x191420, s.number("opacity") * .8));
    Glass.text(g, label, -w / 2f + 6, -8, 0xFFF2EDF9);
    if (t.entity instanceof LivingEntity l) {
      if (s.flag("health"))
        Glass.rounded(
            g,
            -w / 2f + 8,
            3,
            (w - 16) * Math.max(0, Math.min(1, l.getHealth() / l.getMaxHealth())),
            1,
            0,
            0xFF94DDAB);
      if (s.flag("armor")) {
        int x = -32;
        for (EquipmentSlot slot :
            new EquipmentSlot[] {
              EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
            }) {
          g.drawItem(l.getEquippedStack(slot), x, -33);
          x += 16;
        }
      }
      if (s.flag("held")) g.drawItem(l.getMainHandStack(), w / 2 + 4, -15);
      if (s.flag("status") && !l.getStatusEffects().isEmpty()) {
        String effects =
            l.getStatusEffects().stream()
                .limit(3)
                .map(e -> e.getEffectType().value().getName().getString())
                .reduce((a, b) -> a + " · " + b)
                .orElse("");
        Glass.center(g, effects, 0, 10, 0xFFB8AACD);
      }
    }
    g.getMatrices().popMatrix();
  }

  private OverlayRenderer() {}
}
