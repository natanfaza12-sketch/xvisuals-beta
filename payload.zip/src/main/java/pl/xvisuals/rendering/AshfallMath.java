package pl.xvisuals.rendering;
public final class AshfallMath {
 public static boolean supported(String biome){return biome.equals("minecraft:basalt_deltas");}
 public static double groundFade(double clearance){double t=Math.clamp(clearance/1.2,0,1);return t*t*(3-2*t);}
 private AshfallMath(){}
}
