package pl.xvisuals.rendering;
public final class PollenDriftMath {
 public static boolean supported(String biome){return biome.equals("minecraft:flower_forest")||biome.equals("minecraft:meadow");}
 public static double sunlight(int sky,long time,double rain){double daylight=Math.clamp(Math.cos((Math.floorMod(time,24000)-6000)/24000d*Math.PI*2)*2,0,1);return .15+.85*Math.clamp(sky/15d,0,1)*daylight*(1-Math.clamp(rain,0,1)*.6);}
 public static int tint(int rgb,double white){double w=Math.clamp(white,0,1);return (int)(((rgb>>16)&255)*(1-w)+255*w)<<16|(int)(((rgb>>8)&255)*(1-w)+255*w)<<8|(int)((rgb&255)*(1-w)+255*w);}
 private PollenDriftMath(){}
}
