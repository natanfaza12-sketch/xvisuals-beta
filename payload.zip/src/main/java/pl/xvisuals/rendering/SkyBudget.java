package pl.xvisuals.rendering;

/** Coarse, hysteretic adjustments: at most one resize every two seconds, slow recovery. */
public final class SkyBudget {
  private double scale = 1;
  private long next;
  private int healthy;
  public double scale() { return scale; }
  public void reset() { scale = 1; next = 0; healthy = 0; }
  public void update(long now, int fps, int target) {
    if (now < next || fps <= 0 || target <= 0) return;
    next = now + 2_000_000_000L;
    if (fps < target * .85) { scale = Math.max(.5, scale - .125); healthy = 0; }
    else if (fps >= target * .97) {
      if (++healthy >= 4) { scale = Math.min(1, scale + .125); healthy = 0; }
    } else healthy = 0;
  }
}
