package pl.xvisuals.modules.world;

import pl.xvisuals.XVisuals;
import pl.xvisuals.rendering.Quality;
import java.util.*;
import net.minecraft.block.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.*;

/** Bounded, incremental scan of already loaded client chunks. Never requests server chunks. */
public final class BlockHighlights {
  public record Highlight(BlockPos pos, int color) {}

  public static final Map<Long, Highlight> FOUND = new LinkedHashMap<>();
  private static final BlockPos.Mutable cursor = new BlockPos.Mutable();
  private static BlockPos origin = BlockPos.ORIGIN;
  private static int index, radius, tick;
  private static Object world;
  private static final Map<Block, Integer> COLORS = new IdentityHashMap<>();
  private static int settingsHash;
  private static final Set<Long> VISIBLE = new HashSet<>();
  private static final List<Highlight> NEAREST = new ArrayList<>();
  private static final List<Highlight> NEAREST_VIEW = Collections.unmodifiableList(NEAREST);

  public static boolean visible(Highlight highlight) {
    return VISIBLE.contains(highlight.pos.asLong());
  }

  public static void tick(MinecraftClient c) {
    VISIBLE.clear();
    NEAREST.clear();
    if (c.world != world) {
      world = c.world;
      FOUND.clear();
      index = 0;
    }
    var m = XVisuals.config().module("blocks");
    if (c.world == null || c.player == null || !m.enabled) {
      FOUND.clear();
      return;
    }
    if (!m.text("mode").equals("Nearby blocks")) {
      FOUND.clear(); index = 0; return;
    }
    if (settingsHash != m.values.hashCode()) {
      settingsHash = m.values.hashCode();
      COLORS.clear();
      for (Block block : Registries.BLOCK) {
        int tint = classify(block);
        if (tint != 0) COLORS.put(block, tint);
      }
      FOUND.clear();
      index = 0;
    }
    int r = m.integer("distance");
    if (r != radius || origin.getSquaredDistance(c.player.getBlockPos()) > 64) {
      radius = r;
      origin = c.player.getBlockPos();
      index = 0;
      FOUND.clear();
    }
    tick++;
      FOUND
          .values()
          .removeIf(
              h ->
                  h.pos.getSquaredDistance(c.player.getBlockPos()) > r * r
                      || !c.world.isChunkLoaded(h.pos.getX() >> 4, h.pos.getZ() >> 4)
                      || color(c.world.getBlockState(h.pos).getBlock()) == 0);
    int side = r * 2 + 1,
        total = side * side * side,
        budget = Math.max(100, (int) (m.integer("budget") * Math.min(1, Quality.factor())));
    for (int n = 0; n < budget; n++) {
      if (index >= total) {
        index = 0;
        origin = c.player.getBlockPos();
      }
      int i = index++, dx = i % side - r, dz = (i / side) % side - r, dy = i / (side * side) - r;
      if (dx * dx + dy * dy + dz * dz > r * r) continue;
      cursor.set(origin.getX() + dx, origin.getY() + dy, origin.getZ() + dz);
      if (!c.world.isChunkLoaded(cursor.getX() >> 4, cursor.getZ() >> 4)) continue;
      int color = color(c.world.getBlockState(cursor).getBlock());
      long key = cursor.asLong();
      if (color != 0 && (FOUND.containsKey(key) || FOUND.size() < 512))
        FOUND.put(key, new Highlight(cursor.toImmutable(), color));
      else if (color == 0) FOUND.remove(key);
    }
    // Block entities are already indexed by Minecraft; expose storage immediately.
    if (tick % 10 == 0)
      for (var be : c.world.getBlockEntities()) {
        if (FOUND.size() >= 512) break;
        BlockPos pos = be.getPos();
        if (pos.getSquaredDistance(c.player.getBlockPos()) <= r * r) {
          int color = color(be.getCachedState().getBlock());
          if (color != 0) FOUND.put(pos.asLong(), new Highlight(pos, color));
        }
      }
    NEAREST.addAll(FOUND.values());
    BlockPos playerPos = c.player.getBlockPos();
    NEAREST.sort(Comparator.comparingDouble(h -> h.pos.getSquaredDistance(playerPos)));
    if (m.flag("depth")) {
      int remaining = Math.max(32, Quality.entityCap() * 2);
      for (var h : nearest(c)) {
        if (remaining-- <= 0) break;
        var ray=c.world.raycast(new net.minecraft.world.RaycastContext(
            c.gameRenderer.getCamera().getCameraPos(),Vec3d.ofCenter(h.pos),
            net.minecraft.world.RaycastContext.ShapeType.OUTLINE,net.minecraft.world.RaycastContext.FluidHandling.NONE,c.player));
        if (ray.getType()==net.minecraft.util.hit.HitResult.Type.MISS || ray.getBlockPos().equals(h.pos))
          VISIBLE.add(h.pos.asLong());
      }
    }
  }

  public static java.util.List<Highlight> nearest(MinecraftClient c) {
    return NEAREST_VIEW;
  }

  private static int color(Block b) {
    return COLORS.getOrDefault(b, 0);
  }

  private static int classify(Block b) {
    var m = XVisuals.config().module("blocks");
    String id = Registries.BLOCK.getId(b).toString();
    if (m.flag("storage")
        && (b instanceof ChestBlock
            || b instanceof EnderChestBlock
            || b instanceof ShulkerBoxBlock
            || b instanceof BarrelBlock)) return m.color("storageColor");
    if (m.flag("spawners") && (id.endsWith(":spawner") || id.endsWith(":trial_spawner")))
      return m.color("spawnerColor");
    if (m.flag("ores") && (id.endsWith("_ore") || id.endsWith(":ancient_debris")))
      return m.color("oreColor");
    if (m.flag("portals") && id.contains("portal") || m.flag("beds") && b instanceof BedBlock)
      return m.color("color");
    for (String v : m.text("ids").split(",")) if (v.trim().equals(id)) return m.color("color");
    return 0;
  }

  private BlockHighlights() {}
}
