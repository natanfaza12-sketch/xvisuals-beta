package pl.xvisuals.modules.world;

/** Stable IDs: these are independent modules, not recoloured presets. */
public enum WorldEffectKind {
  PETALS("petaldrift","Cherry Petals","Soft heart-shaped petals tumble on a wandering breeze.","#FFB7DA","#FFF1F8",false,24,.18),
  LEAVES("autumnleaves","Autumn Leaves","Veined leaves sway and turn as they fall.","#EFA348","#B94C36",false,80,.24),
  FROST("frostflakes","Frost Flakes","Six-branched snow crystals rotate gently through the air.","#C2E9FF","#FFFFFF",false,24,.16),
  EMBERS("emberdrift","Ember Drift","Warm cinders rise in loose spirals with glowing tails.","#FF8A45","#FFE5A0",false,24,.12),
  BUBBLES("prismbubbles","Prismatic Bubbles","Transparent bubbles rise with coloured rims and pearly reflections.","#BDA1FF","#A6F8EE",false,18,.32),
  DUST("astraldust","Astral Dust","Tiny points of starlight breathe inside drifting constellations.","#C4AAFF","#FFFFFF",false,28,.13),
  SHARDS("prismshards","Prism Shards","Faceted floating crystals turn above the landscape.","#A893FF","#D9F6FF",false,12,.32),
  MOTHS("lunarmoths","Lunar Moths","Paired luminous wings flutter along looping flight paths.","#E8DDFF","#B88CFF",false,12,.25),
  SOULS("wanderingsouls","Wandering Souls","Soft spirit lights wander with tapering, curved wakes.","#99F4EC","#D8C0FF",false,14,.20),
  RUNES("runeblooms","Rune Blooms","Rotating sigils bloom on the ground, traced by orbiting marks.","#B88CFF","#F4DDFF",true,5,1.15),
  GARDENS("crystalgardens","Crystal Gardens","Clusters of shaded crystal spires emerge from nearby surfaces.","#9F85EA","#DDE8FF",true,5,.9),
  LEY("leylines","Ley Lines","Moving light travels through branching paths etched across the ground.","#BBA0FF","#9ADFEF",true,5,1.25),
  PILLARS("lightpillars","Light Pillars","Tapered shafts of light rise from animated ground seals.","#C4A0FF","#FFFFFF",true,4,.85),
  RIFTS("riftsparks","Rift Sparks","Forked violet fissures flicker briefly in the air above the ground.","#B984FF","#FFFFFF",true,5,.85);

  public final String id,label,description,primary,secondary;
  public final boolean grounded;
  public final int count;
  public final double size;
  WorldEffectKind(String id,String label,String description,String primary,String secondary,boolean grounded,int count,double size) {
    this.id=id;this.label=label;this.description=description;this.primary=primary;this.secondary=secondary;
    this.grounded=grounded;this.count=count;this.size=size;
  }
  public static int budget(int requested,double quality,int enabled) {
    return budget(requested,quality,enabled,32);
  }
  public static int budget(int requested,double quality,int enabled,int perKindCap) {
    int scaled=(int)Math.ceil(requested*Math.clamp(quality,0,1));
    // Keep one instance per side where the requested count permits it.
    if(quality>0)scaled=Math.max(scaled,Math.min(requested,4));
    return Math.max(0,Math.min(perKindCap,Math.min(scaled,288/Math.max(1,enabled))));
  }
  public static double fade(double age,double life) {
    return smooth(age/1.2)*smooth((life-age)/1.8);
  }
  public static double smooth(double t) { t=Math.clamp(t,0,1); return t*t*(3-2*t); }
}
