package pl.xvisuals.modules.world;

import pl.xvisuals.XVisuals;
import pl.xvisuals.mixins.RenderLayerAccessor;
import pl.xvisuals.util.Colors;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.client.render.model.ModelBaker;
import net.minecraft.client.texture.*;
import net.minecraft.util.Identifier;

/** Replaces only native destruction layers; vanilla still owns shapes, stages and cleanup. */
public final class BreakingCracks {
 private static final Identifier PALETTE=Identifier.of("xvisuals","dynamic/breaking_palette");
 private static final RenderLayer[] LAYERS=new RenderLayer[10];
 private static NativeImageBackedTexture palette;
 private static long lastFrame=Long.MIN_VALUE;
 public static RenderLayer layer(RenderLayer original) {
  if(!XVisuals.ready())return original;
  var s=XVisuals.config().module("blocks");
  if(!s.enabled||s.text("breakStyle").equals("Vanilla"))return original;
  int stage=ModelBaker.BLOCK_DESTRUCTION_RENDER_LAYERS.indexOf(original);
  if(stage<0)return original;
  update();
  if(LAYERS[stage]==null) {
   var pipeline=RenderPipeline.builder().withLocation(Identifier.of("xvisuals","pipeline/breaking_"+stage))
    .withVertexShader(Identifier.of("xvisuals","core/breaking"))
    .withFragmentShader(Identifier.of("xvisuals","core/breaking"))
    .withShaderDefine("BREAK_STAGE",stage)
    .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER)
    .withSampler("Sampler0").withSampler("Palette")
    .withVertexFormat(VertexFormats.POSITION_COLOR_TEXTURE_LIGHT_NORMAL,VertexFormat.DrawMode.QUADS)
    .withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
    .withDepthWrite(false).withDepthBias(-1,-10).withCull(false).build();
   LAYERS[stage]=RenderLayerAccessor.visuals$of("breaking_"+stage,RenderSetup.builder(pipeline)
    .texture("Sampler0",Identifier.ofVanilla("textures/block/destroy_stage_"+stage+".png"))
    .texture("Palette",PALETTE).expectedBufferSize(1536).build());
  }
  return LAYERS[stage];
 }
 private static void update() {
  long frame=net.minecraft.util.Util.getMeasuringTimeMs()/16;
  if(lastFrame==frame)return;lastFrame=frame;
  var c=MinecraftClient.getInstance();var s=XVisuals.config().module("blocks");
  if(palette==null) {
   palette=new NativeImageBackedTexture(()->"Mining crack settings",new NativeImage(3,10,false));
   c.getTextureManager().registerTexture(PALETTE,palette);
  }
  double time=c.world==null?0:(c.world.getTime()+c.getRenderTickCounter().getTickProgress(false))/20d;
  int phase=(int)((time*s.number("breakSpeed")*.5%1)*65535);
  int style=switch(s.text("breakStyle")){case "Glow"->1;case "Pulse"->2;case "Scan"->3;case "Hidden"->4;default->0;};
  for(int stage=0;stage<10;stage++) {
   int color=Colors.mix(s.color("breakColor"),s.color("breakEndColor"),s.flag("breakGradient")?stage/9d:0);
   palette.getImage().setColorArgb(0,stage,Colors.alpha(color,s.number("breakOpacity")));
   palette.getImage().setColorArgb(1,stage,0xFF000000|((phase>>8)&255)<<16|(phase&255)<<8|style);
   palette.getImage().setColorArgb(2,stage,0xFFFFFFFF);
  }
  palette.upload();
 }
 private BreakingCracks(){}
}
