package pl.xvisuals.modules.world;
import net.minecraft.client.render.fog.FogData;
public final class ClearFluidFog {
 public static void apply(FogData data){
  // Finite distances avoid NaNs in shaders. Keep the normal chunk-distance fade.
  data.environmentalStart=1_000_000f;
  data.environmentalEnd=2_000_000f;
  data.skyEnd=2_000_000f;
  data.cloudEnd=2_000_000f;
 }
 private ClearFluidFog(){}
}
