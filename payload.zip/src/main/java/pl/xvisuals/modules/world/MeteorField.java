package pl.xvisuals.modules.world;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/** Bounded, camera-independent sky animation. All time values are seconds. */
public final class MeteorField {
  private final ArrayList<Meteor> active = new ArrayList<>();
  private final List<Meteor> view = Collections.unmodifiableList(active);
  private Random random = new Random(0);
  private double time;
  private double spawnCredit;

  public void reset(long seed) {
    random = new Random(seed);
    active.clear();
    time = 0;
    spawnCredit = 0;
  }

  public List<Meteor> meteors() {
    return view;
  }

  public double time() {
    return time;
  }

  /** Long stalls advance at most 250 ms, preventing catch-up showers. */
  public void update(double dt, double rate, int cap, double speed) {
    if (!Double.isFinite(dt) || dt <= 0) return;
    dt = Math.min(dt, .25);
    rate = Double.isFinite(rate) ? Math.max(0, Math.min(64, rate)) : 0;
    speed = Double.isFinite(speed) ? Math.max(.1, Math.min(8, speed)) : 1;
    cap = Math.max(0, Math.min(64, cap));
    while (active.size() > cap) active.removeFirst();
    double end = time + dt;
    if (rate > 0 && cap > 0) {
      double next = time + (1 - spawnCredit) / rate;
      while (next <= end + 1e-10) {
        expire(next);
        if (active.size() < cap) active.add(create(next, speed));
        next += 1 / rate;
      }
      spawnCredit = Math.max(0, Math.min(.999999999999, 1 - (next - end) * rate));
    } else spawnCredit = 0;
    time = end;
    expire(time);
    for (Meteor meteor : active) meteor.age = Math.max(0, time - meteor.birth);
  }

  /** Explicit client-only emission for scheduled showers; legacy continuous scheduling is unchanged. */
  public void emit(int count,int cap,double speed) {
    cap=Math.clamp(cap,0,64);count=Math.clamp(count,0,64);
    speed=Double.isFinite(speed)?Math.clamp(speed,.1,8):1;
    while(active.size()>cap)active.removeFirst();
    for(int i=0;i<count&&active.size()<cap;i++)active.add(create(time,speed*(.8+random.nextDouble()*.4)));
  }

  private void expire(double now) {
    active.removeIf(meteor -> now - meteor.birth >= meteor.duration);
  }

  private Meteor create(double birth, double speed) {
    double azimuth = random.nextDouble() * Math.PI * 2;
    double elevation = .48 + random.nextDouble() * .82;
    Direction start =
        new Direction(
            Math.cos(elevation) * Math.cos(azimuth),
            Math.sin(elevation),
            Math.cos(elevation) * Math.sin(azimuth));
    Direction down =
        new Direction(
            Math.sin(elevation) * Math.cos(azimuth),
            -Math.cos(elevation),
            Math.sin(elevation) * Math.sin(azimuth));
    double sideways = (random.nextBoolean() ? 1 : -1) * (.45 + random.nextDouble() * .55);
    double norm = Math.sqrt(1 + sideways * sideways);
    Direction tangent =
        new Direction(
            (down.x - Math.sin(azimuth) * sideways) / norm,
            down.y / norm,
            (down.z + Math.cos(azimuth) * sideways) / norm);
    double baseDuration = 1.6 + random.nextDouble() * 1.6;
    double arc = .28 + random.nextDouble() * .16;
    return new Meteor(start, tangent, birth, baseDuration / speed, arc, random.nextLong());
  }

  public record Direction(double x, double y, double z) {}

  public static final class Meteor {
    private final Direction start;
    private final Direction tangent;
    private final double birth, duration, arc;
    private final long seed;
    private double age;

    private Meteor(
        Direction start, Direction tangent, double birth, double duration, double arc, long seed) {
      this.start = start;
      this.tangent = tangent;
      this.birth = birth;
      this.duration = duration;
      this.arc = arc;
      this.seed = seed;
    }

    public Direction start() {
      return start;
    }

    public double age() {
      return age;
    }

    public double duration() {
      return duration;
    }

    public long seed() {
      return seed;
    }

    public boolean fireball() {
      return Math.floorMod(seed, 7) == 0;
    }

    /** Slow-moving wake turbulence increases behind the head, never moving the head itself. */
    public double wakeOffset(double fraction, double strength) {
      double u = Math.clamp(fraction, 0, 1);
      double phase = (seed & 1023) * .017;
      return Math.sin(u * 11 - age * 2.8 + phase) * u * u * .7 * strength;
    }

    public Direction direction() {
      return direction(0);
    }

    /**
     * Positive offsets follow the past path. Speed shortens lifetime and lengthens a fixed-time
     * tail.
     */
    public Direction direction(double secondsBehindHead) {
      double offset = Double.isFinite(secondsBehindHead) ? Math.max(0, secondsBehindHead) : 0;
      double angle = arc * Math.max(0, Math.min(1, (age - offset) / duration));
      double c = Math.cos(angle), s = Math.sin(angle);
      return new Direction(
          start.x * c + tangent.x * s, start.y * c + tangent.y * s, start.z * c + tangent.z * s);
    }

    public double alpha() {
      return fade(age / duration);
    }

    public static double fade(double progress) {
      if (!Double.isFinite(progress) || progress <= 0 || progress >= 1) return 0;
      return smooth(Math.min(1, progress / .12)) * smooth(Math.min(1, (1 - progress) / .32));
    }

    private static double smooth(double x) {
      return x * x * (3 - 2 * x);
    }
  }
}
