package pl.xvisuals.modules.world;
import net.minecraft.util.Identifier;
/** Four authored looping atlases; texture timing stays independent of the flight simulation. */
public final class MeteorArtwork {
 public static final String[] NAMES={"star_head","fireball","wake","fragment"};
 public static final int STAR=0,FIREBALL=1,WAKE=2,FRAGMENT=3;
 private static final Identifier[] TEXTURES=java.util.Arrays.stream(NAMES).map(n->Identifier.of("xvisuals","textures/meteors/"+n+".png")).toArray(Identifier[]::new);
 public static Identifier texture(int type){return TEXTURES[type];}
 public static int frame(double seconds,long seed){if(!Double.isFinite(seconds))return 0;return Math.floorMod((int)Math.floor((seconds%120)*20+1e-7)+Math.floorMod(seed,24),24);}
 public static float u(int frame,double x){return (float)((frame%6+Math.clamp(x,0,1))/6.);}
 public static float v(int frame,double y){return (float)((frame/6+Math.clamp(y,0,1))/4.);}
 private MeteorArtwork(){}
}
