package pl.xvisuals.modules.world;

/** Colour treatment for atlas pixels; alpha and the original surface grain are retained. */
public final class BlockVisibilityPattern {
 public static int pixel(int original,double u,double v,boolean snow,boolean rainbow,int colour,double time){
  int alpha=original>>>24;
  double grain=(((original>>16)&255)*.2126+((original>>8)&255)*.7152+(original&255)*.0722)/255.;
  int tint=rainbow?java.awt.Color.HSBtoRGB((float)((time*.12+u*.18+v*.12)%1),.85f,1):colour;
  double light=snow?.65+.35*grain:.55+.45*grain;
  // Repeating diagonal bands distinguish powder snow even without relying on colour alone.
  if(snow && ((int)Math.floor((u+v)*8)&3)==0)light*=.65;
  int r=(int)(((tint>>16)&255)*light),g=(int)(((tint>>8)&255)*light),b=(int)((tint&255)*light);
  return (alpha<<24)|(r<<16)|(g<<8)|b;
 }
 private BlockVisibilityPattern(){}
}
