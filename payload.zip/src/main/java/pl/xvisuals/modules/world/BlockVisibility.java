package pl.xvisuals.modules.world;

import pl.xvisuals.XVisuals;
import pl.xvisuals.mixins.FirePlusImageAccessor;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.texture.*;
import net.minecraft.util.Identifier;
import java.util.*;

/** Local atlas recolouring: vanilla depth, geometry and resource-pack textures stay intact. */
public final class BlockVisibility {
 private static final Identifier[] IDS={Identifier.ofVanilla("block/powder_snow"),Identifier.ofVanilla("block/ancient_debris_side"),Identifier.ofVanilla("block/ancient_debris_top")};
 private static final Map<SpriteAtlasTexture,List<Slot>> CACHE=new IdentityHashMap<>();
 public static void clear(SpriteAtlasTexture atlas){var slots=CACHE.remove(atlas);if(slots!=null)slots.forEach(Slot::close);}
 public static void tick(SpriteAtlasTexture atlas){
  if(!atlas.getId().equals(SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE)||atlas.getGlTexture()==null||atlas.getGlTexture().isClosed())return;
  boolean ready=XVisuals.ready();
  boolean snow=ready&&XVisuals.config().on("visiblepowdersnow"),debris=ready&&XVisuals.config().on("clearancientdebris");
  if(!snow&&!debris&&!CACHE.containsKey(atlas))return;
  var slots=CACHE.get(atlas);
  if(slots==null){slots=new ArrayList<>();for(int i=0;i<IDS.length;i++){var sprite=atlas.getSprite(IDS[i]);if(sprite.getContents().getId().equals(IDS[i]))slots.add(new Slot(atlas,sprite,i==0));}CACHE.put(atlas,slots);}
  double time=net.minecraft.util.Util.getMeasuringTimeMs()/1000.;
  for(var slot:slots){
   boolean active=slot.snow?snow:debris;
   if(active){var settings=XVisuals.config().module(slot.snow?"visiblepowdersnow":"clearancientdebris");
    boolean rainbow=!slot.snow&&settings.text("style").equals("Rainbow");
    double t=rainbow&&!XVisuals.config().module("performance").text("animation").equals("Off")?time*settings.number("speed"):0;
    slot.draw(rainbow,settings.color("color"),t);slot.write(atlas,false);slot.changed=true;
   }else if(slot.changed){slot.write(atlas,true);slot.changed=false;}
  }
 }
 private static final class Slot {
  final boolean snow;final int x,y;final NativeImage[] frames,original;final int[] widths,heights,pads;boolean changed,painted,lastRainbow;int lastColour;double lastTime;
  Slot(SpriteAtlasTexture atlas,Sprite sprite,boolean snow){
   this.snow=snow;x=sprite.getX();y=sprite.getY();int w=sprite.getContents().getWidth(),h=sprite.getContents().getHeight();
   int pad=Math.round(sprite.getMinU()*atlas.getGlTexture().getWidth(0))-x;
   int levels=Math.min(atlas.getGlTexture().getMipLevels(),1+Integer.numberOfTrailingZeros(Integer.highestOneBit(Math.min(w,h))));
   frames=new NativeImage[levels];original=new NativeImage[levels];widths=new int[levels];heights=new int[levels];pads=new int[levels];
   var nativeLevels=((FirePlusImageAccessor)(Object)sprite.getContents()).fireplus$images();
   for(int m=0;m<levels;m++){
    int mw=Math.max(1,w>>m),mh=Math.max(1,h>>m),mp=pad>>m;widths[m]=mw;heights[m]=mh;pads[m]=mp;
    frames[m]=new NativeImage(mw+mp*2,mh+mp*2,false);original[m]=new NativeImage(mw+mp*2,mh+mp*2,false);
    var source=nativeLevels[Math.min(m,nativeLevels.length-1)];
    for(int py=0;py<original[m].getHeight();py++)for(int px=0;px<original[m].getWidth();px++)original[m].setColorArgb(px,py,source.getColorArgb(Math.clamp(px-mp,0,source.getWidth()-1),Math.clamp(py-mp,0,source.getHeight()-1)));
   }
  }
  void draw(boolean rainbow,int colour,double time){
   if(painted&&lastRainbow==rainbow&&lastColour==colour&&(!rainbow||lastTime==time))return;
   painted=true;lastRainbow=rainbow;lastColour=colour;lastTime=time;
   for(int m=0;m<frames.length;m++)for(int py=0;py<frames[m].getHeight();py++)for(int px=0;px<frames[m].getWidth();px++){
    double u=(Math.clamp(px-pads[m],0,widths[m]-1)+.5)/widths[m],v=(Math.clamp(py-pads[m],0,heights[m]-1)+.5)/heights[m];
    frames[m].setColorArgb(px,py,BlockVisibilityPattern.pixel(original[m].getColorArgb(px,py),u,v,snow,rainbow,colour,time));
   }
  }
  void write(SpriteAtlasTexture atlas,boolean restore){var encoder=RenderSystem.getDevice().createCommandEncoder();var images=restore?original:frames;for(int m=0;m<images.length;m++){var image=images[m];encoder.writeToTexture(atlas.getGlTexture(),image,m,0,x>>m,y>>m,image.getWidth(),image.getHeight(),0,0);}}
  void close(){for(var image:frames)image.close();for(var image:original)image.close();}
 }
 private BlockVisibility(){}
}
