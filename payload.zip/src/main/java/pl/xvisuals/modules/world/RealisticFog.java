package pl.xvisuals.modules.world;

import pl.xvisuals.XVisuals;
import net.minecraft.client.render.fog.FogData;

/** Applied only by the normal atmospheric modifier, never fluid or status modifiers. */
public final class RealisticFog {
  public static void apply(FogData data) {
    if (!XVisuals.ready()) return;
    var settings = XVisuals.visualModule("realisticfog");
    if (!settings.enabled) return;
    var range = RealisticFogMath.range(settings.text("mode").equals("Everywhere"),
        settings.number("start"), settings.number("thickness"),
        settings.number("density"), settings.number("nearbyHaze"));
    // Preserve the engine's independent chunk-distance fade.
    data.environmentalStart = range.start();
    data.environmentalEnd = range.end();
    if (settings.flag("fogSky")) {
      data.skyEnd = range.end();
      data.cloudEnd = range.end();
    }
  }

  public static int color(int natural) {
    if (!XVisuals.ready()) return natural;
    var settings = XVisuals.visualModule("realisticfog");
    if (!settings.enabled) return natural;
    return RealisticFogMath.color(natural, settings.color("color"), settings.number("tint"));
  }

  private RealisticFog() {}
}
