package pl.xvisuals.modules.world;
import java.util.Random;
/** Random opportunities per minute, with staggered bursts and no catch-up after stalls. */
public final class MeteorShowerSchedule {
 private final Random random;private double opportunity,single,gap;private int pending;
 public MeteorShowerSchedule(long seed){random=new Random(seed);opportunity=interval();single=interval();}
 private double interval(){return .6+random.nextDouble()*.8;}
 public static int cap(String quality){return "Low".equals(quality)?8:"High".equals(quality)?32:16;}
 public int update(double dt,boolean eligible,double frequency,double chance,int count,boolean shooting){
  if(!Double.isFinite(dt)||dt<=0)return 0;dt=Math.min(.25,dt);
  frequency=Double.isFinite(frequency)?Math.clamp(frequency,0,6):0;chance=Double.isFinite(chance)?Math.clamp(chance,0,1):0;
  if(!eligible||frequency<=0){pending=0;gap=0;return 0;}
  opportunity-=dt*frequency/60;single-=dt*frequency/120;
  if(opportunity<=0){opportunity=interval();if(pending==0&&random.nextDouble()<chance)pending=Math.clamp(count,1,32);}
  gap-=dt;
  if(pending>0&&gap<=0){pending--;gap=.12+random.nextDouble()*.42;return 1;}
  if(pending==0&&single<=0){single=interval();if(shooting)return 1;}
  return 0;
 }
}
