package pl.xvisuals.modules.world;

/** Camera-relative atmospheric fog. No world state, allocation-heavy geometry or particles. */
public final class RealisticFogMath {
  public record Range(float start, float end) {}

  public static Range range(boolean everywhere, double start, double thickness,
      double density, double nearbyHaze) {
    start = bounded(start, 16, 0, 512);
    thickness = bounded(thickness, 96, 8, 1024);
    density = bounded(density, 1, .1, 4);
    nearbyHaze = bounded(nearbyHaze, .12, 0, .6);
    double end = (everywhere ? 0 : start) + thickness / density;
    // Negative start removes the clear bubble around the camera in Everywhere mode.
    // The fraction at distance zero is nearbyHaze, with continuous distance falloff.
    double begin = everywhere ? -end * nearbyHaze / (1 - nearbyHaze) : start;
    return new Range((float) begin, (float) end);
  }

  public static int color(int natural, int tint, double strength) {
    double mix = bounded(strength, .65, 0, 1);
    int result = 0;
    for (int shift = 0; shift <= 16; shift += 8) {
      int channel = (int) Math.round(((natural >>> shift) & 255) * (1 - mix)
          + ((tint >>> shift) & 255) * mix);
      result |= channel << shift;
    }
    return (natural & 0xFF000000) | result;
  }

  private static double bounded(double value, double fallback, double min, double max) {
    return Math.clamp(Double.isFinite(value) ? value : fallback, min, max);
  }

  private RealisticFogMath() {}
}
