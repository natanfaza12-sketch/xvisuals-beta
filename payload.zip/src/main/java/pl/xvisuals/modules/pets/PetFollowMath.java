package pl.xvisuals.modules.pets;
/** Shortest-arc heading damping with a bounded turn speed. */
public final class PetFollowMath {
 public static double horizontalProgress(double partial,double rise){partial=Math.clamp(partial,0,1);return rise>.04?Math.max(0,partial*2-1):rise<-.04?Math.min(1,partial*2):partial;}
 public static double verticalProgress(double partial,double rise){partial=Math.clamp(partial,0,1);return rise>.04?Math.min(1,partial*2):rise<-.04?Math.max(0,partial*2-1):partial;}
 public static double turn(double current,double target,double maxStep){double delta=Math.atan2(Math.sin(target-current),Math.cos(target-current));return current+Math.clamp(delta*.22,-maxStep,maxStep);}
 // A lagging companion must catch up, not respawn at a distance threshold.
 public static boolean ownerTeleported(double displacementSquared){return displacementSquared>256;}
 public static double followStep(double distance,double ownerSpeed){return Math.min(distance,Math.min(.65,.09+distance*.06+Math.min(ownerSpeed,.65)*.65));}
 public static double travelHeading(double current,double dx,double dz){return Math.hypot(dx,dz)>.005?turn(current,Math.atan2(-dx,dz),.14):current;}
 public static boolean following(boolean wasFollowing,double distance){return distance>.7||wasFollowing&&distance>.22;}
 public static double forwardOffset(String mode,double distance){return mode.equals("Behind")?-distance:mode.equals("Smart")?distance:-.25;}
 private PetFollowMath(){}
}
