package pl.xvisuals.modules.pets;
final class PetAnimationMath {
 static float hop(double time,boolean moving,boolean animated){return moving&&animated?(float)((time*2.55)%1):0;}
 static float limbSpeed(double distance,boolean animated){return animated?(float)Math.clamp(distance*3,0,1):0;}
 private PetAnimationMath(){}
}
