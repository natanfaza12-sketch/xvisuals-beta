package pl.xvisuals.modules.pets;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.*;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.mixins.RenderLayerAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.RaycastContext;
import java.util.Random;
/** A finite, depth-tested silhouette breakup and seeded rising light field. No screen-space overlay. */
final class PetDeathLights {
 private static final BufferAllocator ALLOCATOR=new BufferAllocator(131072);
 private static final VertexConsumerProvider.Immediate BUFFERS=VertexConsumerProvider.immediate(ALLOCATOR);
 private static RenderLayer layer(boolean glow){var pipeline=RenderPipeline.builder().withLocation(Identifier.of("xvisuals","pipeline/pet_farewell"+(glow?"_light":"_splash")))
  .withVertexShader(Identifier.of("xvisuals","core/player_sprite")).withFragmentShader(Identifier.of("xvisuals",glow?"core/afterglow_light":"core/player_sprite"))
  .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER).withSampler("Sampler0")
  .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS).withBlend(glow?new BlendFunction(SourceFactor.SRC_ALPHA,DestFactor.ONE):BlendFunction.TRANSLUCENT)
  .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withDepthWrite(false).withCull(false).build();
  return RenderLayerAccessor.visuals$of("afterglow"+(glow?"_light":"_splash"),RenderSetup.builder(pipeline).texture("Sampler0",Identifier.of("xvisuals","textures/armorfx/white.png")).translucent().expectedBufferSize(131072).build());}
 private static final RenderLayer SPLASH=layer(false),LIGHT=layer(true);
 static {net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING.register(c->ALLOCATOR.close());}
 static void draw(MatrixStack m){
  if(!PetDeathScene.active())return;double age=PetDeathScene.age(),size=PetDeathScene.size();
  var c=MinecraftClient.getInstance();var p=PetDeathScene.origin().subtract(c.gameRenderer.getCamera().getCameraPos());m.push();m.translate(p.x,p.y,p.z);
  var out=BUFFERS.getBuffer(LIGHT);Random random=new Random(391);
  if(age<1.65){
   double yaw=Pets.facing();
   for(int i=0;i<10;i++){double fall=(age*1.5+i*.1)%1,x=(i%2==0?-.16:.16)*size,z=-.38*size,y=(.36-fall*.3)*size;
    m.push();m.translate(x*Math.cos(yaw)-z*Math.sin(yaw),y,x*Math.sin(yaw)+z*Math.cos(yaw));m.multiply(c.gameRenderer.getCamera().getRotation());double q=.025*size;quad(out,m,-q,-q,0,q,-q,0,q,q,0,-q,q,0,argb(0xb9e8ff,(1-fall)*.8));m.pop();
   }
  }else{
   double t=(age-1.65)/3.45,burst=1-Math.exp(-t*10),fade=Math.pow(Math.max(0,1-t),1.5);
   for(int i=0;i<96;i++){double a=random.nextDouble()*Math.PI*2,r=random.nextDouble()*.42,h=random.nextDouble()*.55;
    double x=Math.cos(a)*(r+burst*(.2+random.nextDouble()*.65))*size,z=Math.sin(a)*(r+burst*.65)*size,y=h*size+t*(1.4+random.nextDouble()*1.4)+t*t*1.5;
    double q=(.025+random.nextDouble()*.03)*size*(1-.5*t);
    m.push();m.translate(x,y,z);m.multiply(c.gameRenderer.getCamera().getRotation());quad(out,m,-q,-q,0,q,-q,0,q,q,0,-q,q,0,argb(PetDeathScene.color(),fade));m.pop();
   }
  }BUFFERS.draw();m.pop();
 }
 private static int argb(int c,double a){return ((int)(255*Math.clamp(a,0,1))<<24)|(c&0xffffff);}
 private static void quad(VertexConsumer o,MatrixStack m,double x,double y,double z,double a,double b,double c,double d,double e,double f,double g,double h,double i,int color){var mat=m.peek().getPositionMatrix();o.vertex(mat,(float)x,(float)y,(float)z).texture(0,0).color(color);o.vertex(mat,(float)a,(float)b,(float)c).texture(1,0).color(color);o.vertex(mat,(float)d,(float)e,(float)f).texture(1,1).color(color);o.vertex(mat,(float)g,(float)h,(float)i).texture(0,1).color(color);}
 private PetDeathLights(){}
}
