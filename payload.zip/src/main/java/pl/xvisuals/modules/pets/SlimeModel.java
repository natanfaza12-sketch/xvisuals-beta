package pl.xvisuals.modules.pets;
import com.google.gson.Gson;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;
/** Original resource mesh and painted expression skins, shared by both renderers. */
public final class SlimeModel {
 public static final String[] VARIANTS={"Classic Blue","Forest Green","Sunset Orange","Bubblegum Pink","Shadow Purple","Frost White","Lava Red","Galaxy"};
 private static float[][][] mesh;
 public static void clear(){mesh=null;}
 public static float[][][] mesh(){if(mesh==null)try(var reader=new java.io.InputStreamReader(MinecraftClient.getInstance().getResourceManager().open(Identifier.of("xvisuals","models/pets/slime.json")),java.nio.charset.StandardCharsets.UTF_8)){mesh=new Gson().fromJson(com.google.gson.JsonParser.parseReader(reader).getAsJsonObject().get("quads"),float[][][].class);}catch(java.io.IOException e){throw new IllegalStateException("Slime model missing",e);}return mesh;}
 public static Identifier texture(String variant,String expression){String key=switch(variant){case "Forest Green"->"green";case "Sunset Orange"->"orange";case "Bubblegum Pink"->"pink";case "Shadow Purple"->"purple";case "Frost White"->"white";case "Lava Red"->"red";case "Galaxy"->"galaxy";default->"blue";};return Identifier.of("xvisuals","textures/pets/"+key+"_"+expression+".png");}
 public record Pose(double width,double height,double lift,String expression){}
 public static Pose pose(double seconds,boolean moving,boolean sleeping,boolean animate){
  if(!animate)return new Pose(1,1,0,"idle");
  if(sleeping)return new Pose(1.12,.72+.025*Math.sin(seconds*2),0,"sleep");
  double phase=(seconds*(moving?1.8:.5))%1;boolean bounce=moving||seconds%6<2;
  double hop=bounce?Math.max(0,Math.sin(phase*Math.PI)):0;
  double squash=bounce?Math.cos(phase*Math.PI*2)*.10:.025*Math.sin(seconds*3);
  String face=seconds%4.6<.14?"blink":seconds%13>11?"happy":"idle";
  return new Pose(1+squash,1-squash*1.5,hop*(moving?.24:.07),face);
 }
 private SlimeModel(){}
}
