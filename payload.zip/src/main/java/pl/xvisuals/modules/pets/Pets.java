package pl.xvisuals.modules.pets;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import pl.xvisuals.mixins.RenderLayerAccessor;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
/** One local cosmetic companion. Terrain queries occur only at tick rate, never per vertex. */
public final class Pets {
 private static double fallSpeed;
 private static Object world;private static Vec3d previous,position;private static double yaw,previousYaw,time;private static int idle,stuck;private static boolean moving;private static Vec3d ownerPrevious;private static double heading;private static boolean following;
 private static final BufferAllocator ALLOCATOR=new BufferAllocator(262144);
 private static final VertexConsumerProvider.Immediate BUFFER=VertexConsumerProvider.immediate(ALLOCATOR);
 private static final java.util.Map<Identifier,RenderLayer> LAYERS=new java.util.HashMap<>();
 private static final RenderPipeline PIPE=RenderPipeline.builder().withLocation(Identifier.of("xvisuals","pipeline/slime_pet"))
  .withVertexShader(Identifier.of("xvisuals","core/player_sprite")).withFragmentShader(Identifier.of("xvisuals","core/player_sprite"))
  .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER).withSampler("Sampler0")
  .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS).withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withDepthWrite(true).withCull(false).build();
 public static int renderedQuads;public static Vec3d position(){return position;}
 public static void init(){WorldRenderEvents.END_MAIN.register(c->{render(c.matrices());PetDeathLights.draw(c.matrices());});net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING.register(c->ALLOCATOR.close());
 net.fabricmc.fabric.api.resource.v1.ResourceLoader.get(net.minecraft.resource.ResourceType.CLIENT_RESOURCES).registerReloader(Identifier.of("xvisuals","slime_pet"),(net.minecraft.resource.SynchronousResourceReloader)r->SlimeModel.clear());}
 private static Vec3d ground(MinecraftClient c,Vec3d candidate){return PetTerrain.floor(c,candidate,.58*XVisuals.visualModule("pets").number("size"));}

 // Covers the widest sleeping pose, every yaw, and the top of a moving hop.
 private static net.minecraft.util.math.Box body(Vec3d p,double size){double radius=.58*size;return new net.minecraft.util.math.Box(p.x-radius,p.y+.005,p.z-radius,p.x+radius,p.y+1.01*size,p.z+radius);}
 private static boolean clear(MinecraftClient c,Vec3d p,double size){return c.world.isSpaceEmpty(null,body(p,size));}
 private static boolean passage(MinecraftClient c,Vec3d from,Vec3d to,double size){
  // Ascend before crossing a riser; cross the ledge before descending.
  Vec3d corner=to.y>from.y?new Vec3d(from.x,to.y,from.z):new Vec3d(to.x,from.y,to.z);
  return c.world.isSpaceEmpty(null,body(from,size).union(body(corner,size)))
      &&c.world.isSpaceEmpty(null,body(corner,size).union(body(to,size)));
 }
 private static Vec3d safeGround(MinecraftClient c,Vec3d p,double size){Vec3d floor=ground(c,p);return floor!=null&&clear(c,floor,size)?floor:null;}
 private static Vec3d destination(MinecraftClient c,Vec3d target,double size){
  Vec3d best=safeGround(c,target,size);if(best!=null)return best;
  for(int ring=1;ring<=2;ring++)for(int i=0;i<8;i++){double a=i*Math.PI/4;best=safeGround(c,target.add(Math.cos(a)*ring*.65,0,Math.sin(a)*ring*.65),size);if(best!=null)return best;}return null;
 }
 public static void tick(MinecraftClient c){PetDeathScene.tick(c);var s=XVisuals.visualModule("pets");
 if(world!=c.world||!s.enabled||c.player==null){position=previous=ownerPrevious=null;world=c.world;idle=stuck=0;fallSpeed=0;moving=following=false;renderedQuads=0;}
 if(c.world==null||c.player==null||!s.enabled||c.isPaused())return;
 if(c.player.isDead()){previous=position;previousYaw=yaw;moving=false;return;}time+=.05;
 Vec3d owner=c.player.getEntityPos();
 double moveX=ownerPrevious==null?0:owner.x-ownerPrevious.x,moveZ=ownerPrevious==null?0:owner.z-ownerPrevious.z;
 double ownerSpeed=Math.hypot(moveX,moveZ);
 // Use camera yaw only for initial placement. Afterwards only actual horizontal travel
 // changes the follow direction, including strafing and walking backwards.
 if(ownerPrevious==null)heading=Math.toRadians(c.player.getYaw());
 else heading=PetFollowMath.travelHeading(heading,moveX,moveZ);
 Vec3d forward=new Vec3d(-Math.sin(heading),0,Math.cos(heading)),side=new Vec3d(-forward.z,0,forward.x);
 double ahead=PetFollowMath.forwardOffset(s.text("position"),s.number("distance"));
 double lateral=s.number("side");if(!s.text("position").equals("Behind")&&Math.abs(lateral)<.65)lateral=lateral<0?-.65:.65;
 Vec3d target=owner.add(forward.multiply(ahead)).add(side.multiply(lateral));double size=s.number("size");
 if(position==null||(ownerPrevious!=null&&PetFollowMath.ownerTeleported(owner.squaredDistanceTo(ownerPrevious)))){position=destination(c,target,size);previous=position;ownerPrevious=owner;fallSpeed=0;if(position==null)return;var face=owner.subtract(position);yaw=previousYaw=Math.atan2(face.x,-face.z);}
 previous=position;previousYaw=yaw;
 Vec3d delta=target.subtract(position);double horizontal=Math.hypot(delta.x,delta.z);
 ownerPrevious=owner;
 // Hysteresis avoids repeatedly changing between follow and idle near the target.
 if(horizontal>.7||position.squaredDistanceTo(owner)<.7)following=true;else if(horizontal<.22)following=false;
 if(following&&horizontal>.001){
  double step=PetFollowMath.followStep(horizontal,ownerSpeed);
  Vec3d direction=new Vec3d(delta.x/horizontal,0,delta.z/horizontal),best=null;double score=Double.POSITIVE_INFINITY;
  for(double angle:new double[]{0,.55,-.55,1.1,-1.1,1.57,-1.57}){
   double co=Math.cos(angle),si=Math.sin(angle);Vec3d next=position.add((direction.x*co-direction.z*si)*step,0,(direction.x*si+direction.z*co)*step);Vec3d floor=safeGround(c,next,size);
   if(floor==null||floor.y-position.y>1.05||position.y-floor.y>1.05)continue;
   if(!passage(c,position,floor,size))continue;
   double cost=floor.subtract(target).horizontalLengthSquared()+Math.abs(angle)*.06;if(cost<score){score=cost;best=floor;}
  }if(best!=null)position=best;
 }
 Vec3d travel=position.subtract(previous);moving=travel.horizontalLengthSquared()>.0001;
 if(moving){idle=0;stuck=0;}else{idle++;if(following)stuck++;else stuck=0;}
 // Keep interpolation history when obstructed. Reposition only on initial spawn or owner teleport.
 Vec3d support=ground(c,position);
 if(support==null||support.y<position.y-.04){
  fallSpeed=Math.min(.6,fallSpeed+.08);
  double nextY=position.y-fallSpeed;
  if(support!=null&&nextY<=support.y){nextY=support.y;fallSpeed=0;}
  position=new Vec3d(position.x,nextY,position.z);
 }else{fallSpeed=0;if(Math.abs(support.y-position.y)<.4)position=new Vec3d(position.x,support.y,position.z);}
 Vec3d look=moving?travel:owner.subtract(position);
 if(look.horizontalLengthSquared()>.002){double desired=Math.atan2(look.x,-look.z);yaw=PetFollowMath.turn(yaw,desired,.16);}
 }
 private static void render(MatrixStack matrices){renderedQuads=0;var c=MinecraftClient.getInstance();var s=XVisuals.visualModule("pets");if(!s.enabled||position==null||previous==null||c.world==null)return;
 double partial=c.getRenderTickCounter().getTickProgress(false);double rise=position.subtract(previous).horizontalLengthSquared()>.000001?position.y-previous.y:0;
 double horizontal=PetFollowMath.horizontalProgress(partial,rise),vertical=PetFollowMath.verticalProgress(partial,rise);
 var p=new Vec3d(previous.x+(position.x-previous.x)*horizontal,previous.y+(position.y-previous.y)*vertical,previous.z+(position.z-previous.z)*horizontal).subtract(c.gameRenderer.getCamera().getCameraPos());if(p.lengthSquared()>4096)return;
 if(PetDeathScene.hidden())return;
 double t=time+partial*.05;var pose=SlimeModel.pose(t,moving,s.flag("sleep")&&idle>240,s.flag("animated"));if(PetDeathScene.active())pose=new SlimeModel.Pose(1.08+.012*Math.sin(PetDeathScene.age()*45),.84,0,"cry");double size=s.number("size"),angle=previousYaw+(yaw-previousYaw)*partial,co=Math.cos(angle),si=Math.sin(angle);
 var tex=SlimeModel.texture(s.text("variant"),pose.expression());var layer=LAYERS.computeIfAbsent(tex,k->RenderLayerAccessor.visuals$of("slime_pet",RenderSetup.builder(PIPE).texture("Sampler0",k).expectedBufferSize(262144).build()));var out=BUFFER.getBuffer(layer);var matrix=matrices.peek().getPositionMatrix();
 for(var quad:SlimeModel.mesh()){for(var v:quad){double x=v[0]*pose.width()*size,z=v[2]*pose.width()*size,y=v[1]*pose.height()*size;out.vertex(matrix,(float)(p.x+x*co-z*si),(float)(p.y+y+pose.lift()*size),(float)(p.z+x*si+z*co)).texture(v[3],v[4]).color(0xffffffff);}renderedQuads++;}BUFFER.draw();
 }
 public static double facing(){return yaw;}
 private Pets(){}
}
