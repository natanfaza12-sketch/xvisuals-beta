package pl.xvisuals.modules.pets;

import pl.xvisuals.XVisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.HitResult;

/** Local presentation only: retains the real death screen and never requests a respawn. */
public final class PetDeathScene {
 private static DeathScreen pending;
 private static Object world,owner;
 private static long started;
 private static Vec3d origin,eye;
 private static double size;
 private static int color;
 private static boolean finished;
 public static boolean active(){return pending!=null;}
 public static double age(){return active()?(System.nanoTime()-started)/1e9:0;}
 public static boolean hidden(){return finished||active()&&age()>=1.65;}
 public static Vec3d origin(){return origin;}
 public static Vec3d eye(){return eye;}
 public static Vec3d focus(){double t=Math.clamp((age()-1.65)/3.4,0,1);return origin.add(0,size*.35+t*t*2.4,0);}
 public static double size(){return size;}
 public static int color(){return color;}
 public static boolean intercept(Screen screen){
  var c=MinecraftClient.getInstance();var s=XVisuals.visualModule("pets");
  if(active()&&(screen==null||screen instanceof DeathScreen))return true;
  if(!(screen instanceof DeathScreen death)||c.player==null||c.world==null||!s.enabled||!s.flag("deathAnimation")||Pets.position()==null||finished)return false;
  if(active())return true;
  pending=death;world=c.world;owner=c.player;started=System.nanoTime();origin=Pets.position();size=s.number("size");
  color=switch(s.text("variant")){case "Forest Green"->0x78c043;case "Sunset Orange"->0xf79d28;case "Bubblegum Pink"->0xeb76ad;case "Shadow Purple"->0x875bcf;case "Frost White"->0xafd5ee;case "Lava Red"->0xe94422;case "Galaxy"->0x4d50be;default->0x2ea6ef;};
  // Film the face, with a collision-tested close-up. Never move the player itself.
  double yaw=Pets.facing();Vec3d center=origin.add(0,.4*size,0);
  Vec3d desired=center.add(Math.sin(yaw)*(1.8+size),.65*size,-Math.cos(yaw)*(1.8+size));
  var hit=c.world.raycast(new RaycastContext(center,desired,RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,c.player));
  eye=hit.getType()==HitResult.Type.MISS?desired:hit.getPos().lerp(center,.12);
  c.setScreen(new PetFarewellScreen());
  return true;
 }
 public static void tick(MinecraftClient c){
  if(c.world!=world||c.player==null||(active()&&c.player!=owner)||(!active()&&!c.player.isDead())){
   pending=null;finished=false;origin=eye=null;world=c.world;
   if(c.currentScreen instanceof PetFarewellScreen)c.setScreen(null);return;
  }
  if(active()&&(age()>=5.1||!XVisuals.visualModule("pets").enabled||!XVisuals.visualModule("pets").flag("deathAnimation"))){
   finish();
  }
 }
 public static void finish(){if(pending==null)return;Screen screen=pending;pending=null;finished=true;MinecraftClient.getInstance().setScreen(screen);}
 private PetDeathScene(){}
}
