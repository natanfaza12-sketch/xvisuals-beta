package pl.xvisuals.modules.pets;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
/** Holds the screen slot during the world-rendered cinematic, without pausing the world. */
final class PetFarewellScreen extends Screen {
 PetFarewellScreen(){super(Text.literal("Pet farewell"));}
 @Override public boolean shouldPause(){return false;}
 @Override public void render(DrawContext context,int mouseX,int mouseY,float delta){}
 @Override public void renderBackground(DrawContext context,int mouseX,int mouseY,float delta){}
 @Override public void close(){PetDeathScene.finish();}
}
