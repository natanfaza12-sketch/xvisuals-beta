package pl.xvisuals.modules.pets;
/** Fit the creature itself to the card, rather than a minimum one-block envelope. */
public final class PetPreviewLayout {
 public static float scale(float width,float height,float bodyWidth,float bodyHeight,boolean dragon){
  float visualWidth=dragon?16:Math.max(.2f,bodyWidth*1.8f);
  float visualHeight=dragon?8:Math.max(.2f,bodyHeight);
  return Math.max(0,Math.min(width*.82f/visualWidth,height*.82f/visualHeight));
 }
 private PetPreviewLayout(){}
}
