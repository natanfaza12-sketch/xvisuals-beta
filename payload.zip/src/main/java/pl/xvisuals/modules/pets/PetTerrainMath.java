package pl.xvisuals.modules.pets;
/** Footprint support, including risers contacted before the centre crosses an edge. */
public final class PetTerrainMath {
 public static double support(double x,double y,double z,double radius,double[][] boxes){
  double top=Double.NEGATIVE_INFINITY;
  for(double[] b:boxes)if(x+radius>b[0]+1e-6&&x-radius<b[3]-1e-6&&z+radius>b[2]+1e-6&&z-radius<b[5]-1e-6&&b[4]+.025<=y+1.05&&b[4]>=y-3)top=Math.max(top,b[4]);
  return Double.isFinite(top)?top+.025:Double.NaN;
 }
 private PetTerrainMath(){}
}
