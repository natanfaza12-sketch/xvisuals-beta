package pl.xvisuals.modules.pets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
final class PetTerrain {
 static Vec3d floor(MinecraftClient c,Vec3d point,double radius){
  var search=new Box(point.x-radius,point.y-3,point.z-radius,point.x+radius,point.y+1.05,point.z+radius);
  var boxes=new java.util.ArrayList<double[]>();
  for(var shape:c.world.getBlockCollisions(null,search))for(var box:shape.getBoundingBoxes())boxes.add(new double[]{box.minX,box.minY,box.minZ,box.maxX,box.maxY,box.maxZ});
  double y=PetTerrainMath.support(point.x,point.y,point.z,radius,boxes.toArray(double[][]::new));
  return Double.isNaN(y)?null:new Vec3d(point.x,y,point.z);
 }
 private PetTerrain(){}
}
