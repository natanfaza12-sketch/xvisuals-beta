package pl.xvisuals.modules.emote;

/** Shared timings in game ticks; has no Minecraft dependencies. */
public final class SmokingTimeline {
    public static final int IGNITION = 32;
    public static final int DRAW = 28;
    public static final int CYCLE = 92;
    public static final int EXHALE_DELAY = 12;
    public static final int EXHALE_LENGTH = 24;
    public static final int MIN_DRAW = 12;
    public static final int LIFETIME = 2400;
    private SmokingTimeline() {}

    public static int phase(int elapsed, boolean startedLit) {
        return Math.max(0, elapsed - (startedLit ? 0 : IGNITION)) % CYCLE;
    }

    public static float smooth(float value) {
        float t = Math.clamp(value, 0, 1);
        return t * t * (3 - 2 * t);
    }

    public static float drawPose(float phase) {
        return smooth(phase / 8f) * (1 - smooth((phase - DRAW) / 12f));
    }

    public static boolean shouldExhale(int drawTicks) { return drawTicks >= MIN_DRAW; }
}
