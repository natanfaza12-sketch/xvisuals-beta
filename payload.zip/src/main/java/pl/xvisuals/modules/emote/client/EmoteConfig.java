package pl.xvisuals.modules.emote.client;
import pl.xvisuals.XVisuals;
/** Preferences are owned by Visual Client's regular module config. */
public final class EmoteConfig {
 public static boolean enabled(){return XVisuals.ready()&&XVisuals.config().on("cigaremote");}
 public static boolean smoke(){return XVisuals.config().module("cigaremote").flag("smoke");}
 public static boolean sounds(){return XVisuals.config().module("cigaremote").flag("sounds");}
 public static double volume(){return XVisuals.config().module("cigaremote").number("volume");}
 private EmoteConfig(){}
}
