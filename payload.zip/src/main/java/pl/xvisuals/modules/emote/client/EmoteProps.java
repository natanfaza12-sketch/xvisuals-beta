package pl.xvisuals.modules.emote.client;
import pl.xvisuals.modules.emote.SmokingModule;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.CustomModelDataComponent;
import net.minecraft.item.*;
import java.util.List;
/** Render-model descriptors only. These stacks never enter any inventory or cross the network. */
public final class EmoteProps {
    public static final ItemStack CIGARETTE=prop("cigarette"),LIGHTER=prop("lighter");
    private static int stage=-1;private static boolean lit,open;
    private static ItemStack prop(String model){var stack=new ItemStack(Items.PAPER);stack.set(DataComponentTypes.ITEM_MODEL,SmokingModule.id(model));return stack;}
    public static void update(boolean glowing,float burn,boolean lighterOpen){
        int next=burn>=.66?2:burn>=.33?1:0;
        if(next!=stage||lit!=glowing){stage=next;lit=glowing;CIGARETTE.set(DataComponentTypes.CUSTOM_MODEL_DATA,new CustomModelDataComponent(List.of(burn),List.of(glowing),List.of(),List.of()));}
        if(open!=lighterOpen||!LIGHTER.contains(DataComponentTypes.CUSTOM_MODEL_DATA)){open=lighterOpen;LIGHTER.set(DataComponentTypes.CUSTOM_MODEL_DATA,new CustomModelDataComponent(List.of(),List.of(open),List.of(),List.of()));}
    }
}
