package pl.xvisuals.modules.emote;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
/** Resource identifiers only. No registries, items, packets, or server initializer. */
public final class SmokingModule {
    public static final String ID="smoking_module";
    public static Identifier id(String path){return Identifier.of(ID,path);}
    public static final SoundEvent OPEN=sound("lighter_open"),STRIKE=sound("lighter_strike"),CLOSE=sound("lighter_close"),
        IGNITE=sound("ignite"),DRAW=sound("draw"),EXHALE=sound("exhale"),EXTINGUISH=sound("extinguish");
    private static SoundEvent sound(String path){return SoundEvent.of(id(path));}
    private SmokingModule(){}
}
