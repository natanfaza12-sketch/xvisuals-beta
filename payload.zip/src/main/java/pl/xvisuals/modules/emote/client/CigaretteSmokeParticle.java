package pl.xvisuals.modules.emote.client;

import net.minecraft.client.particle.BillboardParticle;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.world.ClientWorld;

/** Soft, translucent smoke grows as it cools, loses forward momentum and drifts upward. */
final class CigaretteSmokeParticle extends BillboardParticle {
    CigaretteSmokeParticle(ClientWorld world, double x, double y, double z, double vx, double vy, double vz, Sprite sprite) {
        super(world, x, y, z, sprite);
        setVelocity(vx, vy, vz);
        scale = .035f;
        maxAge = 38 + random.nextInt(18);
        velocityMultiplier = .96f;
        gravityStrength = -.008f;
        collidesWithWorld = true;
        setColor(.88f, .89f, .91f);
        alpha = 0;
        zRotation = random.nextFloat() * (float) Math.PI * 2;
        lastZRotation = zRotation;
    }
    @Override public void tick() {
        super.tick();
        float life = age / (float) maxAge;
        alpha = .5f * Math.min(1, age / 5f) * (1-life) * (1-life);
        scale = .035f + life * .13f;
        lastZRotation = zRotation;
        zRotation += .008f;
    }
    @Override protected RenderType getRenderType() { return RenderType.PARTICLE_ATLAS_TRANSLUCENT; }
}
