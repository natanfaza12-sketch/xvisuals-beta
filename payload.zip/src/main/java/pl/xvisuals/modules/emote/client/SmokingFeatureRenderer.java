package pl.xvisuals.modules.emote.client;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.*;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.util.Arm;
import net.minecraft.util.math.RotationAxis;

/** Local third-person emote only; remote players are never inferred or animated. */
public final class SmokingFeatureRenderer {
    private SmokingFeatureRenderer(){}
    public static boolean local(PlayerEntityRenderState state){var c=MinecraftClient.getInstance();return SmokingClient.active()&&c.player!=null&&state.id==c.player.getId();}
    public static void render(PlayerEntityModel model,MatrixStack matrices,OrderedRenderCommandQueue queue,int light,PlayerEntityRenderState state,float yaw,float pitch){
        if(!local(state)||state.invisible)return;
        draw(model,matrices,queue,light,state,state.mainArm,true);
        if(SmokingClient.light(1)>.05)draw(model,matrices,queue,light,state,state.mainArm.getOpposite(),false);
        SmokingClient.renderedThirdPerson++;
    }
    private static void draw(PlayerEntityModel model,MatrixStack matrices,OrderedRenderCommandQueue queue,int light,PlayerEntityRenderState state,Arm arm,boolean cigarette){
        var c=MinecraftClient.getInstance();matrices.push();model.setArmAngle(state,arm,matrices);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90));matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180));
        matrices.translate((arm==Arm.LEFT?-1f:1f)/16,.125f,-.625f);
        if(cigarette)matrices.scale(.75f,.75f,.75f);
        c.getEntityRenderDispatcher().getHeldItemRenderer().renderItem(c.player,cigarette?EmoteProps.CIGARETTE:EmoteProps.LIGHTER,
            cigarette?ItemDisplayContext.NONE:arm==Arm.RIGHT?ItemDisplayContext.THIRD_PERSON_RIGHT_HAND:ItemDisplayContext.THIRD_PERSON_LEFT_HAND,matrices,queue,light);
        matrices.pop();
    }
}
