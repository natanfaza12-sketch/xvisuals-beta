package pl.xvisuals.modules.emote.client;

import pl.xvisuals.modules.emote.*;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.sound.*;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.*;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import java.util.*;

/** Local emote controller. Never touches player input, held stacks, inventory, or the network. */
public final class SmokingClient {
    private static boolean initialized,active;
    private static int ticks;
    private static float previousRaise,raise,previousLight,light;
    private static Object world;
    private static KeyBinding toggle;
    private static String configuredKey="";
    private static final List<SoundInstance> sounds=new ArrayList<>();
    public static int emittedParticles,playedSounds,renderedHands,renderedThirdPerson;
    public static boolean active(){return active && EmoteConfig.enabled();}
    public static boolean lit(){return active&&ticks>=SmokingTimeline.IGNITION;}
    public static int time(){return ticks;}
    public static float raise(float delta){return previousRaise+(raise-previousRaise)*delta;}
    public static float light(float delta){return previousLight+(light-previousLight)*delta;}
    public static float burn(){return Math.min(1,ticks/(float)SmokingTimeline.LIFETIME);}
    
    public static synchronized void initialize(){
        if(initialized)return;initialized=true;
        var category=KeyBinding.Category.create(SmokingModule.id("emotes"));
        toggle=KeyBindingHelper.registerKeyBinding(new KeyBinding("key.smoking_module.emote",GLFW.GLFW_KEY_H,category));
        ClientTickEvents.END_CLIENT_TICK.register(SmokingClient::tick);


    }
    public static boolean start(){
        var c=MinecraftClient.getInstance();if(!EmoteConfig.enabled()||c.currentScreen!=null||c.getOverlay()!=null||pl.xvisuals.gui.world.WorldStudio.active()||c.isPaused()||c.player==null||c.world==null||!c.player.isAlive()||c.player.isSpectator()||c.player.isSubmergedInWater()||c.player.isUsingItem())return false;
        stop(false);active=true;ticks=0;raise=previousRaise=light=previousLight=0;world=c.world;
        EmoteProps.update(false,0,false);sound(SmokingModule.OPEN,.65f);return true;
    }
    public static void toggle(){if(active)stop(true);else start();}
    public static void stop(boolean audible){
        boolean wasActive=active,wasLit=lit();active=false;ticks=0;raise=previousRaise=light=previousLight=0;
        var c=MinecraftClient.getInstance();for(var instance:sounds)c.getSoundManager().stop(instance);sounds.clear();
        if(audible&&wasActive&&c.player!=null&&c.world!=null)sound(wasLit?SmokingModule.EXTINGUISH:SmokingModule.CLOSE,.45f);
    }
    private static void tick(MinecraftClient c){
        if(!pl.xvisuals.XVisuals.ready()){if(active)stop(false);return;}
        var settings=pl.xvisuals.XVisuals.config().module("cigaremote");
        if(!configuredKey.equals(settings.text("key"))){
            configuredKey=settings.text("key");try{toggle.setBoundKey(net.minecraft.client.util.InputUtil.fromTranslationKey(configuredKey));KeyBinding.updateKeysByCode();}catch(IllegalArgumentException ignored){}
        }else if(!toggle.getBoundKeyTranslationKey().equals(configuredKey)){
            configuredKey=toggle.getBoundKeyTranslationKey();settings.values.put("key",configuredKey);pl.xvisuals.XVisuals.STORE.dirty();
        }
        if(world!=c.world){stop(false);world=c.world;}
        if(!EmoteConfig.enabled()){if(active)stop(false);while(toggle.wasPressed()){}return;}
        while(toggle.wasPressed())if(c.currentScreen==null)toggle();
        if(!active)return;
        if(c.player==null||c.world==null||!c.player.isAlive()||c.player.isSpectator()||c.player.isSubmergedInWater()
            ||c.getOverlay()!=null||pl.xvisuals.gui.world.WorldStudio.active()||c.player.isSwimming()||c.player.isGliding()||c.player.isSleeping()||c.currentScreen!=null
            ||c.options.attackKey.isPressed()||c.options.useKey.isPressed()||c.player.isUsingItem()){
            stop(false);return;
        }
        if(c.isPaused())return;
        sounds.removeIf(s->!c.getSoundManager().isPlaying(s));
        previousRaise=raise;previousLight=light;int t=ticks++;
        if(t==8)sound(SmokingModule.STRIKE,.7f);
        if(t==SmokingTimeline.IGNITION){sound(SmokingModule.IGNITE,.5f);sound(SmokingModule.DRAW,.38f);}
        if(t==SmokingTimeline.IGNITION+5)sound(SmokingModule.CLOSE,.55f);
        float targetRaise,targetLight;
        if(t<SmokingTimeline.IGNITION){targetRaise=SmokingTimeline.smooth(t/10f);targetLight=SmokingTimeline.smooth((t-3)/9f);}
        else{
            int phase=SmokingTimeline.phase(t,false);targetRaise=SmokingTimeline.drawPose(phase);
            targetLight=1-SmokingTimeline.smooth((t-SmokingTimeline.IGNITION)/10f);
            if(phase==0&&t>SmokingTimeline.IGNITION)sound(SmokingModule.DRAW,.38f);
            int breath=phase-SmokingTimeline.DRAW-SmokingTimeline.EXHALE_DELAY;
            if(breath==0)sound(SmokingModule.EXHALE,.5f);
            if(breath>=0&&breath<SmokingTimeline.EXHALE_LENGTH&&t%2==0)exhale(c,breath);
            if(t%8==0)idleSmoke(c);
        }
        raise+=(targetRaise-raise)*.48f;light+=(targetLight-light)*.4f;
        EmoteProps.update(lit(),burn(),light>.6f);
        if(ticks>=SmokingTimeline.LIFETIME)stop(true);
    }
    private static void sound(SoundEvent event,float volume){
        var c=MinecraftClient.getInstance();if(c.player==null||!EmoteConfig.sounds()||EmoteConfig.volume()<=0)return;
        var s=new PositionedSoundInstance(event.id(),SoundCategory.PLAYERS,volume*(float)EmoteConfig.volume(),.96f+c.player.getRandom().nextFloat()*.08f,
            c.player.getRandom(),false,0,SoundInstance.AttenuationType.NONE,0,0,0,true);
        c.getSoundManager().play(s);sounds.add(s);playedSounds++;
    }
    private static void smoke(MinecraftClient c,Vec3d pos,Vec3d velocity){
        if(!EmoteConfig.smoke())return;
        var texture=c.getTextureManager().getTexture(SpriteAtlasTexture.PARTICLE_ATLAS_TEXTURE);
        if(texture instanceof SpriteAtlasTexture atlas){
            var sprite=atlas.getSprite(SmokingModule.id("cigarette_smoke"));
            c.particleManager.addParticle(new CigaretteSmokeParticle(c.world,pos.x,pos.y,pos.z,velocity.x,velocity.y,velocity.z,sprite));
        }else c.particleManager.addParticle(ParticleTypes.SMOKE,pos.x,pos.y,pos.z,velocity.x,velocity.y,velocity.z);
        emittedParticles++;
    }
    private static void idleSmoke(MinecraftClient c){
        var p=c.player;Vec3d look=p.getRotationVec(1),right=new Vec3d(-look.z,0,look.x).normalize();
        int side=p.getMainArm()==net.minecraft.util.Arm.RIGHT?1:-1;
        Vec3d pos=p.getEyePos().add(look.multiply(.55)).add(right.multiply((.22-.2*raise)*side)).add(0,-.5+.35*raise,0);
        smoke(c,pos,new Vec3d(0,.008,0));
    }
    private static void exhale(MinecraftClient c,int breath){
        var p=c.player;Vec3d direction=p.getRotationVec(1),pos=p.getEyePos().add(direction.multiply(.6)).add(0,-.12,0);
        double speed=.05*(1-breath/(double)SmokingTimeline.EXHALE_LENGTH)+.025;
        for(int i=0;i<3;i++)smoke(c,pos,direction.multiply(speed).add((p.getRandom().nextDouble()-.5)*.012,.01,(p.getRandom().nextDouble()-.5)*.012));
    }
}
