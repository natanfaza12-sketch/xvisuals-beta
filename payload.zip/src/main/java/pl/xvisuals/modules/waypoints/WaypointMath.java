package pl.xvisuals.modules.waypoints;

public final class WaypointMath {
  public static double scaled(double coordinate,double from,double to) {
    if(!Double.isFinite(to)||to<=0)throw new IllegalArgumentException("Invalid dimension scale");
    return coordinate*from/to;
  }
  public static boolean visible(Waypoint point,String dimension,boolean shared) {
    return point.enabled() && (shared || point.dimension().equals(dimension));
  }
  public static double distance(double x,double y,double z,double px,double py,double pz) {
    return Math.sqrt((x-px)*(x-px)+(y-py)*(y-py)+(z-pz)*(z-pz));
  }
  public static double smoothAngle(double current,double target,double seconds) {
    double difference=Math.atan2(Math.sin(target-current),Math.cos(target-current));
    return current+difference*(1-Math.exp(-12*Math.clamp(seconds,0,.1)));
  }
  private WaypointMath() {}
}
