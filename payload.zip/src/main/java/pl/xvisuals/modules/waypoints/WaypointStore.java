package pl.xvisuals.modules.waypoints;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;

/** One bounded, atomic JSON document per server/world. No paths are derived from waypoint names. */
public final class WaypointStore {
  private static final Gson JSON=new GsonBuilder().setPrettyPrinting().create();
  private record Data(int version,List<Waypoint> points,Map<String,String> selected) {}
  private final Path path;
  private Data data=new Data(1,List.of(),Map.of());
  public WaypointStore(Path root,String scope) throws IOException {
    try {
      String hash=HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(scope.getBytes(StandardCharsets.UTF_8)));
      path=root.resolve(hash+".json");
    } catch(java.security.NoSuchAlgorithmException impossible) {throw new IllegalStateException(impossible);}
    if(Files.exists(path)) {
      if(Files.size(path)>524288)throw new IOException("Waypoint file is too large; original file was kept.");
      try {
        var loaded=decode(Files.readString(path));
        if(loaded==null || loaded.version!=1 || loaded.points==null || loaded.selected==null
            || loaded.points.size()>256 || loaded.selected.size()>256)throw new IllegalArgumentException();
        var ids=new HashSet<String>();
        for(var p:loaded.points)if(p==null || !ids.add(p.id()))throw new IllegalArgumentException();
        for(var entry:loaded.selected.entrySet())if(entry.getKey()==null || entry.getValue()==null
            || !ids.contains(entry.getValue()))throw new IllegalArgumentException();
        var selected=new HashMap<>(loaded.selected);
        // Older files could retain navigation to a disabled point.
        selected.values().removeIf(id->loaded.points.stream().noneMatch(p->p.id().equals(id)&&p.enabled()));
        data=new Data(1,List.copyOf(loaded.points),Map.copyOf(selected));
      } catch(RuntimeException invalid) {throw new IOException("Waypoint file could not be read; original file was kept.",invalid);}
    }
  }
  public List<Waypoint> points() {return data.points;}
  public String selected(String dimension) {return data.selected.get(dimension);}
  public void put(Waypoint point) throws IOException {
    var points=new ArrayList<>(data.points);points.removeIf(p->p.id().equals(point.id()));
    if(points.size()>=256)throw new IOException("This server already has 256 waypoints.");
    points.add(point);
    var selected=new HashMap<>(data.selected);
    if(!point.enabled())selected.values().removeIf(point.id()::equals);
    commit(new Data(1,List.copyOf(points),Map.copyOf(selected)));
  }
  public void delete(String id) throws IOException {
    var points=new ArrayList<>(data.points);points.removeIf(p->p.id().equals(id));
    var selected=new HashMap<>(data.selected);selected.values().removeIf(id::equals);
    commit(new Data(1,List.copyOf(points),Map.copyOf(selected)));
  }
  public void select(String dimension,String id) throws IOException {
    if(id!=null && data.points.stream().noneMatch(p->p.id().equals(id)&&p.enabled()))throw new IOException("Enable this waypoint before navigating.");
    var selected=new HashMap<>(data.selected);
    if(id==null)selected.remove(dimension);else selected.put(dimension,id);
    if(selected.size()>256)throw new IOException("Too many saved dimension selections.");
    commit(new Data(1,data.points,Map.copyOf(selected)));
  }
  // Never serialize records reflectively: release obfuscation renames their fields
  // and accessors independently. Explicit keys also keep saves stable across releases.
  private static String encode(Data data) {
    var json=new JsonObject();json.addProperty("version",data.version);
    var points=new JsonArray();
    for(var p:data.points) {
      var item=new JsonObject();item.addProperty("id",p.id());item.addProperty("name",p.name());
      item.addProperty("color",p.color());item.addProperty("x",p.x());item.addProperty("y",p.y());item.addProperty("z",p.z());
      item.addProperty("dimension",p.dimension());item.addProperty("coordinateScale",p.coordinateScale());item.addProperty("enabled",p.enabled());
      points.add(item);
    }
    json.add("points",points);var selected=new JsonObject();
    data.selected.forEach(selected::addProperty);json.add("selected",selected);
    return JSON.toJson(json);
  }
  private static Data decode(String text) {
    var json=JsonParser.parseString(text).getAsJsonObject();
    int version=json.get("version").getAsInt();
    var rows=json.getAsJsonArray("points");var selections=json.getAsJsonObject("selected");
    if(version!=1||rows.size()>256||selections.size()>256)throw new IllegalArgumentException("Invalid waypoint file");
    var points=new ArrayList<Waypoint>();
    for(var row:rows) {
      var p=row.getAsJsonObject();
      points.add(new Waypoint(p.get("id").getAsString(),p.get("name").getAsString(),p.get("color").getAsInt(),
          p.get("x").getAsDouble(),p.get("y").getAsDouble(),p.get("z").getAsDouble(),p.get("dimension").getAsString(),
          p.get("coordinateScale").getAsDouble(),p.get("enabled").getAsBoolean()));
    }
    var selected=new HashMap<String,String>();selections.entrySet().forEach(e->selected.put(e.getKey(),e.getValue().getAsString()));
    return new Data(version,List.copyOf(points),Map.copyOf(selected));
  }
  private void commit(Data next) throws IOException {
    Files.createDirectories(path.getParent());
    Path temporary=Files.createTempFile(path.getParent(),"waypoints-",".tmp");
    try {
      Files.writeString(temporary,encode(next),StandardCharsets.UTF_8);
      try {Files.move(temporary,path,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}
      catch(AtomicMoveNotSupportedException unsupported) {Files.move(temporary,path,StandardCopyOption.REPLACE_EXISTING);}
      data=next;
    } finally {Files.deleteIfExists(temporary);}
  }
}
