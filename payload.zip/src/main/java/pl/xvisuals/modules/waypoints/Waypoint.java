package pl.xvisuals.modules.waypoints;

import java.util.UUID;

public record Waypoint(String id,String name,int color,double x,double y,double z,
    String dimension,double coordinateScale,boolean enabled) {
  public Waypoint {
    UUID.fromString(id);
    if(name==null || name.isBlank() || name.length()>48 || name.chars().anyMatch(Character::isISOControl))
      throw new IllegalArgumentException("Use a name of 1–48 characters.");
    if(dimension==null || dimension.length()>128 || !dimension.matches("[a-z0-9_.-]+:[a-z0-9_./-]+"))
      throw new IllegalArgumentException("Invalid dimension.");
    if(!Double.isFinite(x)||!Double.isFinite(y)||!Double.isFinite(z)||Math.abs(x)>30_000_000
        ||Math.abs(z)>30_000_000||Math.abs(y)>2048 || !Double.isFinite(coordinateScale)
        ||coordinateScale<=0 || coordinateScale>1_000_000)
      throw new IllegalArgumentException("Coordinates or dimension scale are out of range.");
    color &= 0xFFFFFF;
  }
  public Waypoint enabled(boolean value) {return new Waypoint(id,name,color,x,y,z,dimension,coordinateScale,value);}
}
