package pl.xvisuals.modules.waypoints;

/** An open editor belongs to one loaded store and dimension, never the next connection. */
public record WaypointSession(WaypointStore store,String scope,String dimension) {
  public boolean matches(WaypointStore current,String currentScope,String currentDimension) {
    return store!=null && store==current && scope.equals(currentScope) && dimension.equals(currentDimension);
  }
}
