package pl.xvisuals.modules.waypoints;

import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import pl.xvisuals.mixins.RenderLayerAccessor;
import pl.xvisuals.rendering.Projection;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.render.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.WorldSavePath;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import java.util.*;

public final class SmartWaypoints {
  private static WaypointStore store;
  private static Object lastWorld;
  private static String scope="",dimension="",error="";
  private static double dimensionScale=1;
  private static final List<View> VISIBLE=new ArrayList<>(32);
  private static final Map<String,Boolean> OCCLUSION=new HashMap<>();
  private static final Projection PROJECTION=new Projection();
  private static final Projection.Point POINT=new Projection.Point();
  private static final float[][] LABEL_BOUNDS=new float[32][4];
  private static final BufferAllocator ALLOCATOR=new BufferAllocator(131072);
  private static final VertexConsumerProvider.Immediate BUFFERS=VertexConsumerProvider.immediate(ALLOCATOR);
  private static final RenderLayer DEPTH=layer(false),THROUGH=layer(true);
  private static int tick;
  private static long lastArrowTime;
  private static double arrowAngle;
  private static String arrowTarget="";
  private record View(Waypoint point,Vec3d position,double distance,boolean selected) {}

  public static void init() {
    ClientTickEvents.END_CLIENT_TICK.register(SmartWaypoints::tick);
    WorldRenderEvents.END_MAIN.register(c->renderWorld(c.matrices()));
    HudElementRegistry.addLast(Identifier.of("xvisuals","smart_waypoints"),(g,t)->renderHud(g,t.getTickProgress(false)));
    ClientLifecycleEvents.CLIENT_STOPPING.register(c->ALLOCATOR.close());
  }
  public static void context() {
    var c=MinecraftClient.getInstance();
    if(lastWorld!=c.world){lastWorld=c.world;VISIBLE.clear();OCCLUSION.clear();arrowTarget="";}
    if(c.world==null || c.player==null) {store=null;scope=dimension="";VISIBLE.clear();OCCLUSION.clear();return;}
    String next;
    if(c.isInSingleplayer() && c.getServer()!=null)
      next="world:"+c.getServer().getSavePath(WorldSavePath.ROOT).toAbsolutePath().normalize();
    else if(c.getCurrentServerEntry()!=null) {
      var a=ServerAddress.parse(c.getCurrentServerEntry().address);
      next="server:"+a.getAddress().toLowerCase(Locale.ROOT)+":"+a.getPort();
    } else {store=null;scope="";error="Connect to a world first.";return;}
    String nextDimension=c.world.getRegistryKey().getValue().toString();
    if(!nextDimension.equals(dimension)) {VISIBLE.clear();OCCLUSION.clear();arrowTarget="";}
    dimension=nextDimension;dimensionScale=c.world.getDimension().coordinateScale();
    if(!next.equals(scope)) {
      scope=next;store=null;error="";VISIBLE.clear();OCCLUSION.clear();arrowTarget="";
      try {store=new WaypointStore(FabricLoader.getInstance().getConfigDir().resolve("xvisuals/waypoints"),scope);}
      catch(java.io.IOException failure) {error=failure.getMessage();}
    }
  }
  public static WaypointStore store() {return store;}
  public static String dimension() {return dimension;}
  public static double dimensionScale() {return dimensionScale;}
  public static String error() {return error;}
  public static String scope() {return scope;}
  public static boolean sharing() {return XVisuals.visualModule("smartwaypoints").flag("shareDimensions");}
  private static boolean active() {
    return XVisuals.ready() && XVisuals.visualModule("smartwaypoints").enabled
        && MinecraftClient.getInstance().world!=null && store!=null;
  }
  private static void tick(MinecraftClient c) {
    context();VISIBLE.clear();
    if(!active() || c.player==null)return;
    var s=XVisuals.visualModule("smartwaypoints");
    String selected=store.selected(dimension);double maximum=s.number("distance");
    var player=c.player.getEntityPos();
    for(var point:store.points()) {
      if(!WaypointMath.visible(point,dimension,sharing()))continue;
      double x=WaypointMath.scaled(point.x(),point.coordinateScale(),dimensionScale);
      double z=WaypointMath.scaled(point.z(),point.coordinateScale(),dimensionScale);
      if(Math.abs(x)>30_000_000 || Math.abs(z)>30_000_000)continue;
      var position=new Vec3d(x,point.y(),z);double distance=position.distanceTo(player);
      if(distance<=maximum)VISIBLE.add(new View(point,position,distance,point.id().equals(selected)));
    }
    VISIBLE.sort(Comparator.comparing((View v)->!v.selected).thenComparingDouble(View::distance));
    if(VISIBLE.size()>32)VISIBLE.subList(32,VISIBLE.size()).clear();
    var camera=c.gameRenderer.getCamera().getCameraPos();
    for(int j=0;j<Math.min(2,VISIBLE.size()) && !s.flag("through");j++) {
      var view=VISIBLE.get(Math.floorMod(tick*2+j,VISIBLE.size()));
      if(!c.world.isChunkLoaded((int)Math.floor(view.position.x)>>4,(int)Math.floor(view.position.z)>>4)) {
        OCCLUSION.put(view.point.id(),false);
      } else {
        var hit=c.world.raycast(new RaycastContext(camera,view.position.add(0,2,0),RaycastContext.ShapeType.VISUAL,RaycastContext.FluidHandling.NONE,c.player));
        OCCLUSION.put(view.point.id(),hit.getType()==HitResult.Type.MISS);
      }
    }
    OCCLUSION.keySet().removeIf(id->VISIBLE.stream().noneMatch(v->v.point.id().equals(id)));
    tick++;
  }
  private static RenderLayer layer(boolean through) {
    return RenderLayerAccessor.visuals$of("xvisuals_waypoint_"+through,RenderSetup.builder(RenderPipeline.builder()
        .withLocation(Identifier.of("xvisuals","pipeline/waypoint_"+through))
        .withVertexShader(Identifier.of("xvisuals","core/player_sprite"))
        .withFragmentShader(Identifier.of("xvisuals","core/waypoint_beam"))
        .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER)
        .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS)
        .withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(through?DepthTestFunction.NO_DEPTH_TEST:DepthTestFunction.LEQUAL_DEPTH_TEST)
        .withDepthWrite(false).withCull(false).build()).translucent().expectedBufferSize(131072).build());
  }
  private static void renderWorld(MatrixStack matrices) {
    if(!active())return;
    var s=XVisuals.visualModule("smartwaypoints");if(!s.flag("beams"))return;
    var camera=MinecraftClient.getInstance().gameRenderer.getCamera().getCameraPos();
    var out=BUFFERS.getBuffer(s.flag("through")?THROUGH:DEPTH);
    for(var v:VISIBLE) {
      matrices.push();matrices.translate(v.position.subtract(camera));var m=matrices.peek().getPositionMatrix();
      int tint=beamColor(v.point.color(),s.color("beamColor"));
      for(int shell=0;shell<2;shell++) {
        float radius=shell==0?.32f:.08f,height=v.selected?36:24;
        int rgba=(shell==0?0x45000000:0xB0000000)|tint;
        for(int face=0;face<4;face++) {
          double a=face*Math.PI/2,b=(face+1)*Math.PI/2;
          float x0=(float)Math.cos(a)*radius,z0=(float)Math.sin(a)*radius,x1=(float)Math.cos(b)*radius,z1=(float)Math.sin(b)*radius;
          out.vertex(m,x0,0,z0).texture(0,0).color(rgba);out.vertex(m,x1,0,z1).texture(1,0).color(rgba);
          out.vertex(m,x1,height,z1).texture(1,1).color(rgba);out.vertex(m,x0,height,z0).texture(0,1).color(rgba);
        }
      }
      matrices.pop();
    }
    BUFFERS.draw();
  }
  private static int beamColor(int point,int global) {
    int color=0;for(int shift=0;shift<=16;shift+=8)color|=(((point>>>shift)&255)*((global>>>shift)&255)/255)<<shift;
    return color;
  }
  private static void renderHud(DrawContext g,float delta) {
    var c=MinecraftClient.getInstance();
    if(!active() || c.options.hudHidden || c.currentScreen!=null)return;
    var s=XVisuals.visualModule("smartwaypoints");PROJECTION.begin(c,delta);
    int width=c.getWindow().getScaledWidth(),height=c.getWindow().getScaledHeight();
    int labelsPlaced=0;
    for(var v:VISIBLE) {
      boolean visible=s.flag("through") || OCCLUSION.getOrDefault(v.point.id(),false);
      int color=0xFF000000|v.point.color();
      if(visible && PROJECTION.project(v.position.add(0,2,0),POINT) && POINT.visible
          && POINT.x>=0 && POINT.x<=width && POINT.y>=0 && POINT.y<=height) {
        if(s.flag("tracers"))line(g,width*.5,height*.5,POINT.x,POINT.y,color&0xFFFFFF|0x90000000);
        if(s.flag("labels")) {
          String name=v.point.name()+" · "+String.format(Locale.ROOT,"%.1f m",v.distance);
          if(!v.point.dimension().equals(dimension))name+=" [shared]";
          float scale=(float)Math.clamp(s.number("labelScale"),.5,1.8);
          name=c.textRenderer.trimToWidth(name,Math.max(12,(int)((width-24)/scale)-10));
          int textWidth=c.textRenderer.getWidth(name);float half=(textWidth/2f+5)*scale;
          float labelX=(float)Math.clamp(POINT.x,half+4,width-half-4),labelY=(float)Math.clamp(POINT.y,8,height-16*scale);
          boolean overlaps=false;
          for(int i=0;i<labelsPlaced;i++){var box=LABEL_BOUNDS[i];if(labelX+half>box[0]&&labelX-half<box[2]&&labelY+13*scale>box[1]&&labelY-4*scale<box[3]){overlaps=true;break;}}
          if(!overlaps) {
            var box=LABEL_BOUNDS[labelsPlaced++];box[0]=labelX-half;box[1]=labelY-4*scale;box[2]=labelX+half;box[3]=labelY+13*scale;
            var m=g.getMatrices();m.pushMatrix();m.translate(labelX,labelY);m.scale(scale,scale);
            g.fill(-textWidth/2-5,-3,textWidth/2+5,12,0xB0101420);
            g.drawTextWithShadow(c.textRenderer,name,-textWidth/2,0,color);m.popMatrix();
          }
        }
      }
      if(v.selected && s.flag("arrows")) {
        var local=new org.joml.Vector3f((float)(v.position.x-PROJECTION.camera.x),(float)(v.position.y-PROJECTION.camera.y),(float)(v.position.z-PROJECTION.camera.z))
            .rotate(new org.joml.Quaternionf(c.gameRenderer.getCamera().getRotation()).conjugate());
        double target=Math.atan2(local.x,-local.z);long now=System.nanoTime();
        if(!arrowTarget.equals(v.point.id())){arrowAngle=target;arrowTarget=v.point.id();lastArrowTime=now;}
        arrowAngle=WaypointMath.smoothAngle(arrowAngle,target,(now-lastArrowTime)/1e9);lastArrowTime=now;
        var m=g.getMatrices();m.pushMatrix();m.translate(width/2f,height-66);m.rotate((float)arrowAngle);
        for(int row=0;row<9;row++)g.fill(-row/2,row-7,row/2+1,row-6,color);
        m.popMatrix();
        String text=c.textRenderer.trimToWidth(v.point.name(),180);
        g.drawCenteredTextWithShadow(c.textRenderer,text,width/2,height-49,color);
      }
    }
  }
  private static void line(DrawContext g,double x,double y,double toX,double toY,int color) {
    double dx=toX-x,dy=toY-y;var m=g.getMatrices();m.pushMatrix();m.translate((float)x,(float)y);m.rotate((float)Math.atan2(dy,dx));
    g.fill(0,0,(int)Math.hypot(dx,dy),1,color);m.popMatrix();
  }
  private SmartWaypoints() {}
}
