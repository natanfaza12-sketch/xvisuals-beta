package pl.xvisuals.modules;
import java.util.List;
/** Authored layered skies only. Stable scene IDs preserve existing colour grades. */
public final class SkyScenes {
 public static final List<String> ALL = List.of("Aurora Veil", "Polar Silk", "Velvet Nebula", "Rose Horizon",
     "Golden Hour", "Blue Hour", "Moonlit Cirrus", "Milky Way", "Silver Storm", "Jade Aurora", "Velvet Rift", "Astral Tide", "Ember Veil", "Opal Sanctuary", "Sapphire Cathedral", "Roseglass Aurora", "Emerald Reverie", "Chrome Nebula", "Violet Eventide", "Solar Drift", "Glacial Cosmos", "Rose Chrome", "Custom Image");
 public static int shaderId(String name) {
   return switch(migrate(name)) {
     case "Opal Sanctuary" -> 31;
case "Sapphire Cathedral" -> 32;
case "Roseglass Aurora" -> 33;
case "Emerald Reverie" -> 34;
     case "Velvet Rift" -> 28;
     case "Astral Tide" -> 29;
     case "Ember Veil" -> 30;
     case "Chrome Nebula" -> 35;
     case "Violet Eventide" -> 36;
     case "Solar Drift" -> 37;
     case "Glacial Cosmos" -> 38;
     case "Rose Chrome" -> 39;
     case "Polar Silk" -> 4;
     case "Velvet Nebula" -> 18;
     case "Rose Horizon" -> 19;
     case "Golden Hour" -> 22;
     case "Blue Hour" -> 23;
     case "Moonlit Cirrus" -> 24;
     case "Milky Way" -> 25;
     case "Silver Storm" -> 26;
     case "Jade Aurora" -> 27;
     default -> 0;
   };
 }
 public static String migrate(String name) {
   return switch(name) {
     case "Amethyst Tides", "Galaxy Ocean" -> "Glacial Cosmos";
     case "Titan's Wake" -> "Solar Drift";
     case "Eclipse Rift" -> "Violet Eventide";
     case "Emerald Choir", "Astral Garden", "Duck Universe" -> "Jade Aurora";
     case "Brushed Chrome", "Chrome" -> "Chrome Nebula";
     case "Frozen Halo" -> "Moonlit Cirrus";
     case "Solar Cathedral" -> "Golden Hour";
     case "Cobalt Crown", "Rosefall", "Orrery of Glass", "Monochrome Eclipse", "Candy Cosmos",
         "Cosmic Cats", "Orrery", "Obsidian Procession", "Pelagic Vault", "The Meridian Engine", "Prism Monsoon" -> "Aurora Veil";
     default -> name;
   };
 }
 public static String artwork(String name) {
   return switch(migrate(name)) {
     case "Aurora Veil", "Polar Silk", "Jade Aurora" -> "aurora_silk";
     case "Velvet Nebula", "Milky Way", "Velvet Rift", "Ember Veil" -> "velvet_rift";
     case "Astral Tide" -> "astral_tide";
     case "Opal Sanctuary" -> "opal_sanctuary";
     case "Sapphire Cathedral" -> "sapphire_cathedral";
     case "Roseglass Aurora" -> "roseglass_aurora";
     case "Emerald Reverie" -> "emerald_reverie";
     case "Chrome Nebula" -> "chrome_nebula";
     case "Violet Eventide" -> "violet_eventide";
     case "Solar Drift" -> "solar_drift";
     case "Glacial Cosmos" -> "glacial_cosmos";
     case "Rose Chrome" -> "rose_chrome";
     case "Rose Horizon", "Golden Hour", "Blue Hour", "Moonlit Cirrus", "Silver Storm" -> "silk_atmosphere";
     default -> "";
   };
 }
 public static String veil(String name){int id=shaderId(name);return id>=31&&id<=39?artwork(name)+"_veil":"silk_veil";}
 public static boolean layered(String name){return !artwork(name).isEmpty();}
 public static String description(String name){return name.equals("Custom Image")?"Imported panorama":"Custom artwork · animated 3D layers";}
 private SkyScenes() {}
}
