package pl.xvisuals.modules;

import pl.xvisuals.config.VisualConfig;
import java.util.*;

/** Temporary render override: never edits the user's saved module switches. */
public final class ParticleVisibility {
  private static final Set<String> EFFECTS=Set.of("footsteps","particles","playerfx","playertrails","fireflies","hitfx","totemparticles","shootingstars","explosionfx","anchorfx","meteorshower","fallingleaves","lavafallmist","junglemist","swampfog","ashfall","emberstorm","endatmosphere","pollendrift","oceanspray","mountainwinds","dynamicmist","constellations","landingfx");
  private static final Map<String,List<String>> MIXED=Map.of("windfx",List.of("leaves","airborne"),"portaldistortion",List.of("particles"),"dimensionskies",List.of("particles"),"realisticrain",List.of("splashes"));
  private static final Map<String,VisualConfig.ModuleState> MUTED=new HashMap<>();
  public static VisualConfig.ModuleState settings(VisualConfig config,String id,VisualConfig.ModuleState original){
    if((!EFFECTS.contains(id)&&!MIXED.containsKey(id)) || !config.on("noparticles") || !config.module("noparticles").flag("custom"))return original;
    var result=MUTED.computeIfAbsent(id,key->new VisualConfig.ModuleState());
    result.favorite=original.favorite;
    if(MIXED.containsKey(id)){
      result.enabled=original.enabled;result.values.clear();result.values.putAll(original.values);
      for(String flag:MIXED.get(id))result.values.put(flag,false);
    }else{result.enabled=false;result.values=original.values;}
    return result;
  }
  private ParticleVisibility(){}
}
