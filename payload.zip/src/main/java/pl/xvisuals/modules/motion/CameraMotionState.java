package pl.xvisuals.modules.motion;

/** Independent positional, rotational and field-of-view impulses for optional camera motion. */
public final class CameraMotionState {
  private final CameraSpring translation = new CameraSpring();
  private final CameraSpring rotation = new CameraSpring();
  public void jump(double dip, double tilt, double fov) {
    translation.impulse(-.9 * dip, fov);
    rotation.impulse(-.9 * tilt, 0);
  }
  public void land(double impact, double bounce, double tilt) {
    translation.impulse(-impact * 1.4 * bounce, 0);
    rotation.impulse(-impact * 1.4 * bounce * tilt, 0);
  }
  public void advance(double seconds, double stiffness) {
    translation.advance(seconds, stiffness); rotation.advance(seconds, stiffness);
  }
  public double position() { return translation.position(); }
  public double tilt() { return rotation.position(); }
  public double fov() { return translation.fov(); }
  public void clear() { translation.clear(); rotation.clear(); }
}
