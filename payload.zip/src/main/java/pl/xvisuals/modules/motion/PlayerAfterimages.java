package pl.xvisuals.modules.motion;

import pl.xvisuals.XVisuals;
import pl.xvisuals.rendering.Quality;
import pl.xvisuals.rendering.SpiritMaterial;
import pl.xvisuals.util.Colors;
import java.util.*;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.*;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerSkinType;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.*;

/** Detached pose snapshots with distance gating and a shared geometry budget. */
public final class PlayerAfterimages {
  private static final class Track {
    Vec3d position, echoPosition;
    double lastEcho = Double.NEGATIVE_INFINITY;
    Track(Vec3d position) { this.position = this.echoPosition = position; }
  }
  private record Echo(UUID owner, boolean local, Vec3d position, float yaw,
      PlayerEntityModel model, Identifier texture, double born, List<PoseDust.Point> dust, Vec3d offset, float scale) {}
  private static final Map<UUID, Track> TRACKS = new HashMap<>();
  private static final List<Echo> ECHOES = new ArrayList<>();
  private static final BufferAllocator ALLOCATOR = new BufferAllocator(262144);
  private static final VertexConsumerProvider.Immediate BUFFERS = VertexConsumerProvider.immediate(ALLOCATOR);
  private static Object world;
  private static double time;
  private static long lastClock;

  public static void init() {
    WorldRenderEvents.END_MAIN.register(context -> render(context.matrices()));
    ClientLifecycleEvents.CLIENT_STOPPING.register(c -> ALLOCATOR.close());
  }

  private static double clock(MinecraftClient c) {
    long now = System.nanoTime();
    if (lastClock != 0 && !c.isPaused()) time += Math.min(.1, (now - lastClock) / 1e9);
    lastClock = now;
    return time;
  }

  public static int count() { return ECHOES.size(); }
  public static Vec3d latestPosition(UUID owner){for(int i=ECHOES.size()-1;i>=0;i--)if(ECHOES.get(i).owner.equals(owner))return ECHOES.get(i).position;return null;}

  public static void tick(MinecraftClient c) {
    double now = clock(c);
    var s = XVisuals.visualModule("playerafterimage");
    if (world != c.world || !s.enabled) { TRACKS.clear(); ECHOES.clear(); world = c.world; }
    if (!s.enabled || c.world == null || c.player == null || c.isPaused()) return;
    ECHOES.removeIf(e -> now - e.born >= s.number("duration") ||
        !(e.local ? s.flag("local") : s.flag("others")) || c.world.getPlayerByUuid(e.owner) == null);
    Set<UUID> seen = new HashSet<>();
    int budget = 4;
    var players = new ArrayList<>(c.world.getPlayers());
    players.sort(Comparator.comparingInt(p -> p == c.player ? 0 : 1));
    for (var p : players) {
      boolean local = p == c.player;
      if (!(local ? s.flag("local") : s.flag("others")) || !p.isAlive() || p.isInvisible() ||
          p.isSpectator() || p.hasVehicle() || p.isGliding() || p.isSwimming() ||
          p.getEntityPos().squaredDistanceTo(c.player.getEntityPos()) > 1024) continue;
      UUID id = p.getUuid();
      seen.add(id);
      Vec3d pos = p.getEntityPos();
      Track old = TRACKS.get(id);
      if (old == null || pos.squaredDistanceTo(old.position) > 9) {
        TRACKS.put(id, new Track(pos));
        ECHOES.removeIf(e -> e.owner.equals(id));
        continue;
      }
      double movement = pos.distanceTo(old.position);
      old.position = pos;
      boolean moving = movement > .015;
      boolean separated=pos.squaredDistanceTo(old.echoPosition)>=.0256;
      boolean capture=moving && separated && budget>0 && now-old.lastEcho>=s.number("interval");
      if(!capture)continue;
      old.lastEcho=now;
      budget--;
      old.echoPosition = pos;
      int count = Math.max(1, (int)(s.integer("count") * Math.min(1, Quality.factor())));
      while (ECHOES.stream().filter(e -> e.owner.equals(id)).count() >= count)
        ECHOES.remove(ECHOES.stream().filter(e -> e.owner.equals(id)).min(Comparator.comparingDouble(Echo::born)).orElseThrow());
      while (ECHOES.size() >= 32) ECHOES.remove(ECHOES.stream().min(Comparator.comparingDouble(Echo::born)).orElseThrow());
      boolean slim = p.getSkin().model() == PlayerSkinType.SLIM;
      var model = new PlayerEntityModel(TexturedModelData.of(
          PlayerEntityModel.getTexturedModelData(Dilation.NONE, slim), 64, 64).createModel(), slim);
      var renderer = c.getEntityRenderDispatcher().getPlayerRenderer(p);
      var state = renderer.createRenderState();
      renderer.updateRenderState(p, state, 1);
      model.setAngles(state);
      ECHOES.add(new Echo(id, local, pos, state.bodyYaw, model, p.getSkin().body().texturePath(), now, PoseDust.capture(model),renderer.getPositionOffset(state),state.baseScale*.9375f));
    }
    TRACKS.keySet().retainAll(seen);
  }

  private static void render(MatrixStack matrices) {
    var c = MinecraftClient.getInstance();
    double now = clock(c);
    var s = XVisuals.visualModule("playerafterimage");
    if (!s.enabled || c.world == null || ECHOES.isEmpty()) return;
    Vec3d camera = c.gameRenderer.getCamera().getCameraPos();
    ECHOES.sort(Comparator.comparingDouble((Echo e) -> -e.position.squaredDistanceTo(camera)));
    for (Echo e : ECHOES) {
      if (!(e.local ? s.flag("local") : s.flag("others")) ||
          e.position.squaredDistanceTo(camera) > 1024 ||
          (e.local && c.options.getPerspective().isFirstPerson())) continue;
      double t = Math.clamp((now - e.born) / s.number("duration"), 0, 1);
      boolean dust=s.text("style").equals("Dust")||s.text("style").equals("Dissolve");
      double alpha = s.number("opacity") * Math.min(1,t*16) * (1-Easing.apply("Quintic",t));
      if (alpha < .004) continue;
      int tint = s.flag("gradient") ? Colors.mix(s.color("color"), s.color("secondary"), t) : s.color("color");
      int color = ((int)(255 * alpha) << 24) | (tint & 0xffffff);
      matrices.push();
      matrices.translate(e.position.add(e.offset).subtract(camera));
      matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180 - e.yaw));
      matrices.scale(-e.scale, -e.scale, e.scale);
      matrices.translate(0, -1.501, 0);
      e.model.render(matrices, SpiritMaterial.wrap(BUFFERS.getBuffer(SpiritMaterial.layer(e.texture)),
          dust ? Easing.apply("Quintic",Math.clamp((t-.2)/.8,0,1)) : 0,
          s.number("glow") * Quality.glow(), s.text("style").equals("Neon") ? .12 : 1), 0xf000f0, 0, color);
      if(dust)PoseDust.draw(matrices,BUFFERS,e.texture,e.dust,t,s.number("opacity"),tint);
      matrices.pop();
    }
    BUFFERS.draw();
  }
  private PlayerAfterimages() {}
}

