package pl.xvisuals.modules.motion;
/** Hand-authored camera-space poses. Quintic easing gives every pose zero endpoint acceleration. */
public final class SwordInspectMotion {
  public static final java.util.List<String> STYLES=java.util.List.of(
      "Showcase","Flourish","Reverse Grip","Wrist Spin","Double Spin","Backspin",
      "Figure Eight","Blade Salute","Edge Check","Cross Sweep","Guard Roll","Orbit","Draw and Return","Ground Plunge");
  public static String select(String requested,String previous,java.util.random.RandomGenerator random){
    if(!"Random".equals(requested))return requested!=null&&STYLES.contains(requested)?requested:"Showcase";
    int excluded=previous==null?-1:STYLES.indexOf(previous);
    int index=random.nextInt(STYLES.size()-(excluded>=0?1:0));
    if(excluded>=0&&index>=excluded)index++;
    return STYLES.get(index);
  }
  private static double ease(double t){t=Math.clamp(t,0,1);return t*t*t*(t*(t*6-15)+10);}
  public record Pose(double x,double y,double z,double pitch,double yaw,double roll) {}
  private static final double[] TIMES={0,.18,.40,.66,.84,1};
  private static final double[][] SHOWCASE={
    {0,0,0,0,0,0},{-.20,.06,-.12,-12,-35,-18},{-.26,.10,-.16,16,38,-25},
    {-.20,.07,-.14,-9,-30,14},{-.12,.04,-.06,5,12,7},{0,0,0,0,0,0}};
  private static final double[][] FLOURISH={
    {0,0,0,0,0,0},{-.18,.09,-.15,-15,-28,-22},{-.28,.13,-.24,30,65,-135},
    {-.20,.08,-.22,-20,-35,-300},{-.09,.025,-.08,4,12,-360},{0,0,0,0,0,-360}};
  private static final double[][] REVERSE={
    {0,0,0,0,0,0},{-.16,.08,-.16,-10,-22,-20},{-.24,.14,-.25,25,38,-175},
    {-.24,.14,-.25,-15,-35,-185},{-.12,.06,-.12,7,15,-340},{0,0,0,0,0,-360}};
  public static Pose pose(String style,double progress){
    double t=Math.clamp(progress,0,1);
    if("Ground Plunge".equals(style))return plunge(t);
    int variant=STYLES.indexOf(style);
    if(variant>=3)return extended(variant,t);
    int i=0;while(i<TIMES.length-2&&t>TIMES[i+1])i++;
    double u=(t-TIMES[i])/(TIMES[i+1]-TIMES[i]);u=u*u*u*(u*(u*6-15)+10);
    double[][] frames=style.equals("Flourish")?FLOURISH:style.equals("Reverse Grip")?REVERSE:SHOWCASE;
    double[] v=new double[6];for(int n=0;n<6;n++)v[n]=frames[i][n]+(frames[i+1][n]-frames[i][n])*u;
    return new Pose(v[0],v[1],v[2],v[3],v[4],v[5]);
  }
  /** Continuous wrist paths: enter, perform the gesture, then settle back into the grip. */
  private static Pose extended(int variant,double t){
    double envelope=ease(t/.20)*(1-ease((t-.80)/.20));
    double phase=ease((t-.18)/.64),angle=phase*Math.PI*2;
    double x=-.20,y=.08,z=-.17,pitch=0,yaw=0,roll=0,turn=0;
    switch(variant){
      case 3 -> {turn=-360*phase;pitch=18*Math.sin(angle);yaw=32*Math.cos(angle);}
      case 4 -> {turn=-720*phase;pitch=24*Math.sin(angle);yaw=38*Math.sin(angle+.6);z=-.23;}
      case 5 -> {turn=360*phase;pitch=-25*Math.sin(angle);yaw=-40*Math.cos(angle);x=-.24;}
      case 6 -> {x+=.10*Math.sin(angle);y+=.08*Math.sin(2*angle);pitch=28*Math.sin(2*angle);yaw=48*Math.sin(angle);roll=65*Math.sin(angle);}
      case 7 -> {y=.20;z=-.22;pitch=-38+12*Math.sin(angle);yaw=30*Math.sin(angle+.8);roll=-18;}
      case 8 -> {x=-.28;z=-.12;pitch=12*Math.sin(angle);yaw=65*Math.cos(angle);roll=-50;}
      case 9 -> {x+=.12*Math.cos(angle);y+=.08*Math.sin(angle);pitch=32*Math.sin(angle);yaw=60*Math.cos(angle);roll=70*Math.sin(angle);}
      case 10 -> {turn=-360*phase;pitch=38*Math.cos(angle);yaw=45*Math.sin(angle);y=.13;}
      case 11 -> {x+=.10*Math.cos(angle);y+=.10*Math.sin(angle);z-=.06*Math.sin(angle);pitch=25*Math.cos(angle);yaw=50*Math.sin(angle);turn=-360*phase;}
      case 12 -> {x=-.28*Math.sin(Math.PI*phase);y=.12*Math.sin(Math.PI*phase);z=-.26;pitch=-30*Math.sin(Math.PI*phase);yaw=55*Math.cos(Math.PI*phase);roll=-65*Math.sin(Math.PI*phase);}
      default -> throw new IllegalArgumentException("Unknown inspect gesture");
    }
    return new Pose(x*envelope,y*envelope,z*envelope,pitch*envelope,yaw*envelope,roll*envelope+turn);
  }
  public static double support(double t){return ease((t-.06)/.14)*(1-ease((t-.80)/.14));}
  private static Pose plunge(double t){
    double[] times={0,.20,.43,.49,.525,.70,.86,1};
    double[][] frames={{0,0,0,0,0,0},{-.32,.12,-.18,-12,30,155},
      {-.32,.42,-.20,-15,0,180},{-.32,-.92,-.30,-15,0,180},
      {-.32,-.80,-.30,-15,0,180},{-.32,-.80,-.30,-15,0,180},
      {-.25,.02,-.16,-12,-25,335},{0,0,0,0,0,360}};
    int i=0;while(i<times.length-2&&t>times[i+1])i++;
    double local=(t-times[i])/(times[i+1]-times[i]);
    // Accelerate all the way into impact; recoil supplies the abrupt stop.
    double u=i==2?local*local:ease(local);
    double[] v=new double[6];for(int n=0;n<6;n++)v[n]=frames[i][n]+(frames[i+1][n]-frames[i][n])*u;
    return new Pose(v[0],v[1],v[2],v[3],v[4],v[5]);
  }
  private SwordInspectMotion(){}
}
