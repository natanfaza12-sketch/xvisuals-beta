package pl.xvisuals.modules.motion;

import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import pl.xvisuals.mixins.RenderLayerAccessor;
import pl.xvisuals.rendering.Quality;
import pl.xvisuals.util.*;
import java.util.*;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.*;

/** Bounded world-space trails, with soft density patches for smoke and meshes for solid motifs. */
public final class PlayerTrails {
  private static final int MAX=128, LAT=6, LON=10;
  private static final double[][] UNIT=new double[(LAT+1)*(LON+1)][3];
  private static final Map<UUID,Track> TRACKS=new HashMap<>();
  private static final List<Puff> PUFFS=new ArrayList<>();
  private static final List<Puff> SORTED=new ArrayList<>(MAX);
  private static final EffectClock CLOCK=new EffectClock();
  private static final Random RANDOM=new Random();
  private static Object world;
  private static String style="";
  private static Vec3d eye=Vec3d.ZERO;
  private static final int[][] SMOKE_COLORS=new int[17][17];
  private static final BufferAllocator ALLOCATOR=new BufferAllocator(2_097_152);
  private static final VertexConsumerProvider.Immediate BUFFERS=VertexConsumerProvider.immediate(ALLOCATOR);
  private static final RenderLayer LAYER=RenderLayerAccessor.visuals$of("xvisuals_player_trails",
      RenderSetup.builder(RenderPipeline.builder()
          .withLocation(Identifier.of("xvisuals","pipeline/player_trails"))
          .withVertexShader(Identifier.of("xvisuals","core/player_sprite"))
          .withFragmentShader(Identifier.of("xvisuals","core/player_sprite"))
          .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER)
          .withUniform("Projection",UniformType.UNIFORM_BUFFER).withSampler("Sampler0")
          .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS)
          .withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
          .withDepthWrite(false).withCull(false).build()).texture("Sampler0",pl.xvisuals.rendering.CraftedSprites.ATLAS).translucent().expectedBufferSize(2_097_152).build());
  private record RibbonPoint(Vec3d position,double born,boolean local) {}
  private static final Map<UUID,ArrayDeque<RibbonPoint>> RIBBONS=new HashMap<>();
  private record Track(Vec3d position,double carry) {}
  private static final class Puff {
    final Vec3d origin; final double born,life,phase,size; final boolean local;
    Vec3d position; double distance;
    Puff(Vec3d origin,double born,double life,double size,boolean local) {
      this.origin=origin;this.born=born;this.life=life;this.size=size;this.local=local;
      phase=RANDOM.nextDouble()*Math.PI*2;
    }
  }
  static {
    for(int a=0;a<=LAT;a++)for(int b=0;b<=LON;b++) {
      double phi=-Math.PI/2+a*Math.PI/LAT,theta=b*Math.PI*2/LON;
      UNIT[a*(LON+1)+b]=new double[]{Math.cos(phi)*Math.cos(theta),Math.sin(phi),Math.cos(phi)*Math.sin(theta)};
    }
  }
  public static void init() {
    WorldRenderEvents.END_MAIN.register(c->render(c.matrices()));
    ClientLifecycleEvents.CLIENT_STOPPING.register(c->ALLOCATOR.close());
  }
  private static double now(MinecraftClient c) {return CLOCK.sample(System.nanoTime(),c.world==null || c.isPaused());}
  public static void tick(MinecraftClient c) {
    double time=now(c);var s=XVisuals.visualModule("playertrails");
    if(world!=c.world || !s.enabled || !style.equals(s.text("style"))) {
      TRACKS.clear();PUFFS.clear();RIBBONS.clear();world=c.world;style=s.text("style");
    }
    if(c.world==null || c.player==null || !s.enabled)return;
    PUFFS.removeIf(p->time-p.born>=p.life || !(p.local?s.flag("local"):s.flag("others"))
        || p.origin.squaredDistanceTo(c.player.getEntityPos())>4096);
    RIBBONS.values().forEach(points->points.removeIf(p->time-p.born>=s.number("lifetime") || !(p.local?s.flag("local"):s.flag("others"))));
    RIBBONS.entrySet().removeIf(e->e.getValue().isEmpty());
    if(c.isPaused())return;
    int cap=Math.max(24,(int)(MAX*Math.min(1,Quality.factor())));
    while(PUFFS.size()>cap)PUFFS.removeFirst();
    var players=new ArrayList<>(c.world.getPlayers());
    players.sort(Comparator.comparingDouble(p->p==c.player?-1:c.player.squaredDistanceTo(p)));
    Set<UUID> seen=new HashSet<>();int budget=12,tracked=0;
    for(var player:players) {
      boolean local=player==c.player;
      if(!(local?s.flag("local"):s.flag("others")) || player.isSpectator() || !player.isAlive()
          || player.isInvisible() || player.hasVehicle() || player.squaredDistanceTo(c.player)>2304)continue;
      if(tracked++>=12)break;
      Vec3d pos=player.getEntityPos();seen.add(player.getUuid());Track previous=TRACKS.get(player.getUuid());
      if(style.equals("Ribbon")) {
        var points=RIBBONS.computeIfAbsent(player.getUuid(),id->new ArrayDeque<>());
        Vec3d at=pos.add(0,.8,0);
        if(!points.isEmpty() && points.getLast().position.distanceTo(at)>6)points.clear();
        if(points.isEmpty() || points.getLast().position.distanceTo(at)>.025){
          while(points.size()>=240)points.removeFirst();
          points.addLast(new RibbonPoint(at,time,local));
        }
        TRACKS.put(player.getUuid(),new Track(pos,0));continue;
      }
      double carry=0;
      if(previous!=null) {
        double distance=pos.distanceTo(previous.position);
        double spacing=.19/s.number("density");
        var emission=TrailMotion.emit(distance,previous.carry,spacing,Math.min(4,budget));
        carry=emission.remainder();
        for(int i=0;i<emission.count();i++) {
          Vec3d at=previous.position.lerp(pos,TrailMotion.fraction(distance,previous.carry,spacing,i,emission.count())).add(
              (RANDOM.nextDouble()-.5)*.12,.18+(RANDOM.nextDouble()*.14),(RANDOM.nextDouble()-.5)*.12);
          if(!c.world.isChunkLoaded(MathHelper.floor(at.x)>>4,MathHelper.floor(at.z)>>4)
              || !c.world.getBlockState(BlockPos.ofFloored(at)).getCollisionShape(c.world,BlockPos.ofFloored(at)).isEmpty())continue;
          while(PUFFS.size()>=cap)PUFFS.removeFirst();
          PUFFS.add(new Puff(at,time,s.number("lifetime"),(.16+RANDOM.nextDouble()*.08)*s.number("size"),local));budget--;
        }
      }
      TRACKS.put(player.getUuid(),new Track(pos,carry));
    }
    TRACKS.keySet().retainAll(seen);
    RIBBONS.keySet().retainAll(seen);
  }
  public static int count(){return PUFFS.size();}
  public static int renderedQuads;
  private static void render(MatrixStack matrices) {
    var c=MinecraftClient.getInstance();double time=now(c);renderedQuads=0;
    var s=XVisuals.visualModule("playertrails");
    if(c.world==null || c.world!=world || !s.enabled)return;
    if(style.equals("Ribbon")){renderRibbons(matrices,c,time,s);return;}
    if(PUFFS.isEmpty())return;
    Vec3d camera=c.gameRenderer.getCamera().getCameraPos();
    eye=Vec3d.ZERO;
    for(var p:PUFFS) {
      double age=Math.max(0,time-p.born),swirl=age*s.number("speed")*2;
      double curl=style.equals("Soul Mist")?.34:style.equals("Embers")?.07:.17;
      p.position=p.origin.add((Math.sin(p.phase+swirl)-Math.sin(p.phase))*curl,
          age*s.number("rise")*(style.equals("Embers")?1.1:.45),(Math.cos(p.phase+swirl)-Math.cos(p.phase))*curl);
      p.distance=p.position.squaredDistanceTo(camera);
      // Subtract in double precision before sending float vertices to the GPU.
      p.position=p.position.subtract(camera);
    }
    SORTED.clear();SORTED.addAll(PUFFS);
    SORTED.sort(Comparator.comparingDouble((Puff p)->p.distance).reversed());
    int basePrimary=s.flag("customColors")?s.color("color"):switch(style){case "Hearts"->0xFFFF5294;case "Soul Mist"->0xFF32DFC8;case "Embers"->0xFFFF7030;case "Stardust"->0xFFBBA0FF;default->0xFF7B899E;};
    int baseSecondary=s.flag("customColors")?s.color("secondary"):switch(style){case "Hearts"->0xFFFFCEE4;case "Soul Mist"->0xFFD3BCFF;case "Embers"->0xFFFFE8A0;case "Stardust"->0xFFE8F7FF;default->0xFFE1E7EE;};
    matrices.push();
    var matrix=matrices.peek().getPositionMatrix();var out=BUFFERS.getBuffer(LAYER);
    for(var p:SORTED) {
      if(!(p.local?s.flag("local"):s.flag("others")) || (p.local && !s.flag("firstPerson") && c.options.getPerspective().isFirstPerson()))continue;
      double age=Math.max(0,time-p.born),t=age/p.life;
      double alpha=TrailMotion.fade(age,p.life)*s.number("opacity")*Math.clamp((Math.sqrt(p.distance)-.35)/.6,0,1);
      if(alpha<.004 || p.distance>4096)continue;
      int primary=!p.local && s.flag("otherCustomColors")?s.color("otherColor"):basePrimary;
      int secondary=!p.local && s.flag("otherCustomColors")?s.color("otherSecondary"):baseSecondary;
      drawPuff(out,matrix,style,p.position,p.size,p.phase,age,p.life,s.number("speed"),primary,secondary,alpha);

    }
    BUFFERS.draw();matrices.pop();SORTED.clear();
  }
  /** Shared mesh path for world trails and gallery previews. */
  public static void drawPuff(VertexConsumer out,org.joml.Matrix4f matrix,String style,Vec3d position,double size,double phase,double age,double life,double speed,int primary,int secondary,double alpha){
    double progress=age/life,r=size*TrailMotion.expansion(progress);int mode=switch(style){case "Hearts"->19;case "Stardust"->18;case "Embers"->3;case "Soul Mist"->13;default->14;};
    Vec3d facing=eye.subtract(position).normalize(),right=new Vec3d(0,1,0).crossProduct(facing);
    if(right.lengthSquared()<.00001)right=new Vec3d(1,0,0);else right=right.normalize();
    Vec3d up=facing.crossProduct(right).normalize();int frame=Math.floorMod((int)(age*speed*8+phase),8);
    int tint=Colors.alpha(Colors.mix(primary,secondary,progress*.7),alpha);
    for(int k=0;k<4;k++){double x=k==1||k==2?1:-1,y=k>=2?1:-1;var v=position.add(right.multiply(x*r)).add(up.multiply(y*r));
      out.vertex(matrix,(float)v.x,(float)v.y,(float)v.z).texture((mode+(float)(.5+(x+1)*.5*63)/64)/24,(frame+(float)(.5+(1-y)*.5*63)/64)/8).color(tint);
    }renderedQuads++;
  }
  public static void previewPuff(VertexConsumer out,org.joml.Matrix4f matrix,String style,Vec3d position,double size,double phase,double age,double life,double speed,int primary,int secondary,double alpha){
    Vec3d oldEye=eye;int oldQuads=renderedQuads;
    try{eye=new Vec3d(0,0,6);drawPuff(out,matrix,style,position,size,phase,age,life,speed,primary,secondary,alpha);}
    finally{eye=oldEye;renderedQuads=oldQuads;}
  }
  private static void renderRibbons(MatrixStack matrices,MinecraftClient c,double time,pl.xvisuals.config.VisualConfig.ModuleState s){
    var camera=c.gameRenderer.getCamera().getCameraPos();
    var matrix=matrices.peek().getPositionMatrix();var out=BUFFERS.getBuffer(LAYER);
    for(var points:RIBBONS.values()){
      RibbonPoint previous=null;
      for(var point:points){
        if(point.local && !s.flag("firstPerson") && c.options.getPerspective().isFirstPerson())break;
        if(previous!=null){
          Vec3d a=previous.position.subtract(camera),b=point.position.subtract(camera);
          double fade=TrailMotion.fade(Math.max(0,time-previous.born),s.number("lifetime"));
          Vec3d direction=b.subtract(a).normalize();
          Vec3d side=direction.crossProduct(a.add(b).multiply(-.5).normalize());
          if(side.lengthSquared()<.000001)side=new Vec3d(0,1,0);else side=side.normalize();
          double half=.085*s.number("size")*Math.sqrt(fade);
          side=side.multiply(half);
          int first=!point.local&&s.flag("otherCustomColors")?s.color("otherColor"):s.color("color");
          int second=!point.local&&s.flag("otherCustomColors")?s.color("otherSecondary"):s.color("secondary");
          int color=s.flag("rainbow")?Colors.rainbow(previous.born*.25):Colors.mix(first,second,1-fade);
          color=Colors.alpha(color,fade*s.number("opacity"));
          Vec3d[] vertices={a.add(side),b.add(side),b.subtract(side),a.subtract(side)};
          int corner=0;for(var v:vertices){
            float u=(10+((corner==1||corner==2)?63.5f:.5f)/64)/24,vv=(corner++>=2?63.5f:.5f)/64/8;
            out.vertex(matrix,(float)v.x,(float)v.y,(float)v.z).texture(u,vv).color(color);
          }
          renderedQuads++;
        }
        previous=point;
      }
    }
    BUFFERS.draw();
  }
  private static void heart(VertexConsumer out,org.joml.Matrix4f m,Vec3d p,double r,double angle,int tint) {
    // Closed extruded silhouette, with two lobes, a notch and a tapered point.
    for(int i=0;i<32;i++) {
      double a=i*Math.PI*2/32,b=(i+1)*Math.PI*2/32;
      double ax=Math.pow(Math.sin(a),3),ay=(13*Math.cos(a)-5*Math.cos(2*a)-2*Math.cos(3*a)-Math.cos(4*a))/17;
      double bx=Math.pow(Math.sin(b),3),by=(13*Math.cos(b)-5*Math.cos(2*b)-2*Math.cos(3*b)-Math.cos(4*b))/17;
      for(int face:new int[]{-1,1}) {
        double z=face*.14;
        double[][] v=face==1?new double[][]{{bx,by,z},{ax,ay,z},{0,0,z},{0,0,z}}:new double[][]{{ax,ay,z},{bx,by,z},{0,0,z},{0,0,z}};
        for(double[] q:v)heartVertex(out,m,p,r,angle,q,tint);
        renderedQuads++;
      }
      for(double[] q:new double[][]{{ax,ay,.14},{bx,by,.14},{bx,by,-.14},{ax,ay,-.14}})
        heartVertex(out,m,p,r,angle,q,(tint&0xFF000000)|(Colors.mix(tint,(tint&0x00FEFEFE)>>>1,.3)&0xFFFFFF));
      renderedQuads++;
    }
  }
  private static void heartVertex(VertexConsumer out,org.joml.Matrix4f m,Vec3d p,double r,double angle,double[] q,int tint) {
    double x=q[0]*Math.cos(angle)+q[2]*Math.sin(angle),z=q[2]*Math.cos(angle)-q[0]*Math.sin(angle);
    out.vertex(m,(float)(p.x+x*r),(float)(p.y+q[1]*r),(float)(p.z+z*r)).color(tint);
  }
  private static void sphere(VertexConsumer out,org.joml.Matrix4f matrix,Vec3d p,double r,double stretch,int tint,double alpha) {
    Vec3d view=eye.subtract(p).normalize();
    for(int lat=0;lat<LAT;lat++)for(int lon=0;lon<LON;lon++) {
      point(out,matrix,p,r,stretch,UNIT[lat*(LON+1)+lon],tint,alpha,view);
      point(out,matrix,p,r,stretch,UNIT[(lat+1)*(LON+1)+lon],tint,alpha,view);
      point(out,matrix,p,r,stretch,UNIT[(lat+1)*(LON+1)+lon+1],tint,alpha,view);
      point(out,matrix,p,r,stretch,UNIT[lat*(LON+1)+lon+1],tint,alpha,view);renderedQuads++;
    }
  }
  private static void point(VertexConsumer out,org.joml.Matrix4f matrix,Vec3d p,double r,double stretch,double[] n,int tint,double alpha,Vec3d view) {
    double light=.64+.36*Math.max(0,n[0]*.3+n[1]*.8+n[2]*.4);
    double facing=Math.max(0,n[0]*view.x+n[1]*view.y+n[2]*view.z);
    // Soft edges without multiplying away almost all of the surface opacity.
    alpha*=Math.sqrt(facing);
    out.vertex(matrix,(float)(p.x+n[0]*r),(float)(p.y+n[1]*r*stretch),(float)(p.z+n[2]*r))
        .color((int)((tint>>16&255)*light),(int)((tint>>8&255)*light),(int)((tint&255)*light),(int)(255*alpha));
  }
  private static void gem(VertexConsumer out,org.joml.Matrix4f m,Vec3d p,double r,double angle,int tint) {
    for(int side=0;side<4;side++) {
      double a=angle+side*Math.PI/2,b=a+Math.PI/2;
      Vec3d v=p.add(Math.cos(a)*r,0,Math.sin(a)*r),w=p.add(Math.cos(b)*r,0,Math.sin(b)*r);
      for(int half:new int[]{1,-1}) {
        Vec3d tip=p.add(0,r*1.6*half,0),first=half==1?w:v,second=half==1?v:w;
        double light=.55+.45*Math.max(0,Math.cos(a+.7))*(half==1?1:.6);
        int face=(tint&0xFF000000)|((int)((tint>>16&255)*light)<<16)|((int)((tint>>8&255)*light)<<8)|(int)((tint&255)*light);
        for(Vec3d q:new Vec3d[]{first,second,tip,tip})out.vertex(m,(float)q.x,(float)q.y,(float)q.z).color(face);
        renderedQuads++;
      }
    }
  }
  private PlayerTrails(){}
}
