package pl.xvisuals.modules.motion;

import pl.xvisuals.XVisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;

/** Optional controls layered onto the existing hand renderer. */
public final class AnimationControls {
  public static double number(String module,String key,double fallback) {
    if(!XVisuals.ready())return fallback;
    var s=XVisuals.config().module(module);
    return s!=null && s.enabled && s.values.containsKey(key)?s.number(key):fallback;
  }
  public static boolean flag(String module,String key,boolean fallback) {
    if(!XVisuals.ready())return fallback;
    var s=XVisuals.config().module(module);
    return s!=null && s.enabled && s.values.containsKey(key)?s.flag(key):fallback;
  }
  public static float hand(String key) {return (float)number("handanimations",key,1);}
  public static float equip(float value) {return flag("handanimations","equip",true)?value*hand("depth"):0;}
  public static boolean vanillaDrops() {
    return XVisuals.ready() && XVisuals.config().on("itemphysics")
        && XVisuals.config().module("itemphysics").text("mode").equals("Vanilla");
  }
  public static void block(MatrixStack matrices,ItemStack stack,ItemDisplayContext context) {
    var p=MinecraftClient.getInstance().player;
    if(p==null || !flag("handanimations","oldBlock",false) || !p.isUsingItem()
        || p.getActiveHand()!=Hand.OFF_HAND || !p.getActiveItem().isOf(Items.SHIELD) || !stack.isIn(ItemTags.SWORDS))return;
    boolean right=context==ItemDisplayContext.FIRST_PERSON_RIGHT_HAND;
    if(context!=ItemDisplayContext.FIRST_PERSON_LEFT_HAND && !right)return;
    if(right!=(p.getMainArm()==Arm.RIGHT))return;
    int sign=right?1:-1;
    matrices.translate(sign*-.14142136f,.08f,.14142136f);
    matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-102.25f));
    matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(sign*13.365f));
    matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(sign*78.05f));
  }
  private AnimationControls(){}
}
