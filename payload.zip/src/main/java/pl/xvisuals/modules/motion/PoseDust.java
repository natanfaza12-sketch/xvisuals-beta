package pl.xvisuals.modules.motion;
import java.util.*;
import pl.xvisuals.rendering.SpiritMaterial;
import net.minecraft.client.render.*;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
/** Dust seeds are sampled from the captured, posed mesh, never from the live player. */
final class PoseDust {
 record Point(float x,float y,float z,float u,float v){}
 static List<Point> capture(PlayerEntityModel model){var sink=new Capture();model.render(new MatrixStack(),sink,0xf000f0,0,-1);sink.finish();return List.copyOf(sink.points);}
 static void draw(MatrixStack m,VertexConsumerProvider buffers,Identifier texture,List<Point> points,double t,double opacity,int tint){
  double age=Math.clamp((t-.18)/.82,0,1);if(age<=0||age>=1)return;
  var out=SpiritMaterial.wrap(buffers.getBuffer(SpiritMaterial.particleLayer(texture)),0,.35,1);var matrix=m.peek().getPositionMatrix();
  for(int i=0;i<points.size();i++){var p=points.get(i);double phase=i*2.399963;
   float x=p.x+(float)(Math.sin(phase)*age*.18),y=p.y-(float)(age*age*.45),z=p.z+(float)(Math.cos(phase)*age*.18);
   float size=(float)(.014*(1-age)*Math.min(1,age*8));int col=pl.xvisuals.util.Colors.alpha(tint,opacity*Math.sin(Math.PI*age)*.8);
   for(int plane=0;plane<2;plane++)for(int v=0;v<4;v++){float a=(v==0||v==3?-size:size),b=v<2?-size:size;
    out.vertex(matrix,x+(plane==0?a:0),y+b,z+(plane==1?a:0)).color(col).texture(p.u,p.v).overlay(0).light(0xf000f0).normal(0,0,1);
   }
  }
 }
 private static final class Capture implements VertexConsumer {
  final List<Point> points=new ArrayList<>();int vertices,faces;float x,y,z,u,v,sx,sy,sz,su,sv;boolean pending;
  void finish(){if(!pending)return;pending=false;sx+=x;sy+=y;sz+=z;su+=u;sv+=v;if(++vertices%4==0){if(faces++%2==0&&points.size()<32)points.add(new Point(sx/4,sy/4,sz/4,su/4,sv/4));sx=sy=sz=su=sv=0;}}
  public VertexConsumer vertex(float x,float y,float z){finish();this.x=x;this.y=y;this.z=z;pending=true;return this;}
  public VertexConsumer texture(float u,float v){this.u=u;this.v=v;return this;}
  public VertexConsumer color(int r,int g,int b,int a){return this;}
  public VertexConsumer color(int c){return this;}
  public VertexConsumer overlay(int u,int v){return this;}
  public VertexConsumer light(int u,int v){return this;}
  public VertexConsumer normal(float x,float y,float z){return this;}
  public VertexConsumer lineWidth(float width){return this;}
 }
 private PoseDust(){}
}
