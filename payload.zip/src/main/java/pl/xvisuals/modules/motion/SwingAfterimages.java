package pl.xvisuals.modules.motion;

import pl.xvisuals.XVisuals;
import pl.xvisuals.rendering.SpiritMaterial;
import java.lang.reflect.*;
import java.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.command.*;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.util.Identifier;

/** Bounded snapshots of actual submitted geometry in first-person camera space. */
public final class SwingAfterimages {
  private record Mesh(Identifier texture, float[] vertices,float[] next,float blend) {
    Mesh(Identifier texture,float[] vertices){this(texture,vertices,null,0);}
    float position(int i){return next==null?vertices[i]:vertices[i]+(next[i]-vertices[i])*blend;}
  }

  private record Frame(double time, List<Mesh> meshes) {}

  private static final Deque<Frame> HISTORY = new ArrayDeque<>();
  private static List<Mesh> capturing;
  private static double now, lastSample;
  private static long lastClock;
  private static int capturedVertices;
  private static boolean captureHand;
  private static Object world;
  private static net.minecraft.item.ItemStack mainItem,offItem;
  private static boolean waitForRest;
  private static final MatrixStack IDENTITY = new MatrixStack();

  public static int historySize() {
    return HISTORY.size();
  }

  public static void clear() {
    HISTORY.clear();
    capturing = null;
    world = null;mainItem=offItem=null;waitForRest=false;
    lastSample = 0;
  }

  public static void hand(net.minecraft.util.Hand hand){captureHand=SwingMotion.moving(hand);}

  public static OrderedRenderCommandQueue begin(OrderedRenderCommandQueue queue) {
    var c = MinecraftClient.getInstance();
    var s = XVisuals.visualModule("afterimage");
    if (!s.enabled || c.player == null || SwingMotion.mining()) {
      HISTORY.clear();
      capturing = null;
      return queue;
    }
    var main = c.player.getMainHandStack();var off = c.player.getOffHandStack();
    if (world != c.world || mainItem==null || !net.minecraft.item.ItemStack.areItemsAndComponentsEqual(mainItem,main) || !net.minecraft.item.ItemStack.areItemsAndComponentsEqual(offItem,off)) {
      HISTORY.clear();
      world = c.world;
      waitForRest=mainItem!=null&&SwingMotion.moving();
      mainItem = main.copy();
      offItem = off.copy();
    }
    if(waitForRest){capturing=null;if(SwingMotion.moving())return queue;waitForRest=false;}
    long clock = System.nanoTime();
    if (lastClock != 0 && !c.isPaused()) now += Math.min(.1, (clock - lastClock) / 1e9);
    lastClock = clock;
    while (!HISTORY.isEmpty()
        && (now - HISTORY.getFirst().time > s.number("lifetime")*s.number("linger") || HISTORY.size() > 96))
      HISTORY.removeFirst();
    double spacing = s.number("spacing") / 1000.0;
    boolean silky=s.flag("silky");
    double lifetime=s.number("lifetime")*s.number("linger");
    Frame[] frames = HISTORY.toArray(Frame[]::new);
    int emitted = 0;
    int limit = Math.max(1, (int)(s.integer("count") * Math.min(1, pl.xvisuals.rendering.Quality.factor())));
    double last = Double.NEGATIVE_INFINITY;
    List<Frame> selected = new ArrayList<>();
    for (int i = frames.length - 1; i >= 0; i--) {
      Frame f = frames[i];
      double age = now - f.time;
      if (age < spacing * .7 || age - last < spacing * .8) continue;
      if (emitted++ >= limit) break;
      last = age;
      selected.add(f);
    }
    if(silky && frames.length>1){
      selected.clear();
      int vertices=frames[frames.length-1].meshes.stream().mapToInt(mesh->mesh.vertices.length/6).sum();
      int samples=Math.clamp(Math.min(limit*3,16000/Math.max(1,vertices)),2,16);
      double oldest=Math.min(lifetime,now-frames[0].time),newest=Math.max(.004,now-frames[frames.length-1].time);
      for(int i=0;i<samples;i++){
        double age=newest+(oldest-newest)*(i+.5)/samples;
        Frame f=interpolate(frames,now-age);if(f!=null)selected.add(f);
      }
      limit=samples;
    }
    // Composite older echoes first so the freshest silhouettes stay readable.
    Collections.reverse(selected);
    for (Frame f : selected) {
      double age = now - f.time;
      double progress = Math.clamp(age / lifetime, 0, 1),
          fade = 1 - Easing.apply(s.text("fade"), progress);
      float alpha = (float) (s.number("opacity") * fade * Math.min(1, age / Math.max(.008, spacing))
          / (silky?Math.pow(limit,.72):Math.sqrt(limit)));
      int tint =
          switch (s.text("mode")) {
            case "Custom" -> s.color("color");
            case "Gradient" -> mix(s.color("color"), s.color("secondary"), progress);
            case "Rainbow" ->
                java.awt.Color.HSBtoRGB((float) ((now * .12 + progress * .35) % 1), .55f, 1);
            default -> 0xffffff;
          };
      float scale = (float) s.number("scale"), strength = (float) s.number("strength");
      double glow = s.number("glow") * pl.xvisuals.rendering.Quality.glow();
      for (Mesh mesh : f.meshes)
        queue.submitCustom(
            IDENTITY,
            silky?pl.xvisuals.rendering.SwingTrailMaterial.layer(mesh.texture):SpiritMaterial.layer(mesh.texture),
            (entry, consumer) -> {
              var out = SpiritMaterial.wrap(consumer, 0, glow, s.text("mode").equals("Original") ? 1 : 0);
              float[] v = mesh.vertices;
              org.joml.Vector3f normal = new org.joml.Vector3f();
              for (int n = 0; n < v.length; n += 6) {
                if (n % 24 == 0) {
                  normal.set(mesh.position(n+6)-mesh.position(n),mesh.position(n+7)-mesh.position(n+1),mesh.position(n+8)-mesh.position(n+2));
                  normal.cross(mesh.position(n+12)-mesh.position(n),mesh.position(n+13)-mesh.position(n+1),mesh.position(n+14)-mesh.position(n+2));
                  if (normal.lengthSquared() > 1e-10f) normal.normalize(); else normal.set(0, 0, 1);
                }
                int col = Float.floatToRawIntBits(v[n + 5]);
                boolean original=s.text("mode").equals("Original");
                int r = (original?((col >> 16) & 255):255) * ((tint >> 16) & 255) / 255,
                    g = (original?((col >> 8) & 255):255) * ((tint >> 8) & 255) / 255,
                    b = (original?(col & 255):255) * (tint & 255) / 255;
                int argb = ((int) (((col >>> 24) & 255) * alpha) << 24) | (r << 16) | (g << 8) | b;
                // Strength extends the recorded screen-space arc around the held item's resting
                // area.
                float extension = 1 + (strength - 1) * (float) progress;
                float x = mesh.position(n) * scale * extension,
                    y = (mesh.position(n+1) + .35f) * scale * extension - .35f,
                    z = (mesh.position(n+2) + .7f) * scale - .7f;
                out.vertex(x, y, z, argb, v[n + 3], v[n + 4], 0, 0, normal.x, normal.y, normal.z);
              }
            });
    }
    capturing = !c.isPaused() && SwingMotion.moving() && now - lastSample >= (silky?1./90.:Math.max(.008, spacing * .5)) ? new ArrayList<>() : null;
    capturedVertices = 0;
    return capturing == null ? queue : (OrderedRenderCommandQueue) proxy(queue, true);
  }

  private static Frame interpolate(Frame[] frames,double time){
    for(int i=1;i<frames.length;i++)if(frames[i].time>=time){
      Frame a=frames[i-1],b=frames[i];
      if(b.time-a.time>.1||a.meshes.size()!=b.meshes.size())return a;
      float blend=(float)Math.clamp((time-a.time)/Math.max(.000001,b.time-a.time),0,1);
      List<Mesh> meshes=new ArrayList<>(a.meshes.size());
      for(int j=0;j<a.meshes.size();j++){
        Mesh left=a.meshes.get(j),right=b.meshes.get(j);
        if(!left.texture.equals(right.texture)||left.vertices.length!=right.vertices.length)return a;
        // Animated model frames may change topology: never stretch unrelated UV vertices together.
        for(int v=0;v<left.vertices.length;v+=6){
          if(left.vertices[v+3]!=right.vertices[v+3]||left.vertices[v+4]!=right.vertices[v+4])return a;
          double dx=left.vertices[v]-right.vertices[v],dy=left.vertices[v+1]-right.vertices[v+1],dz=left.vertices[v+2]-right.vertices[v+2];
          if(dx*dx+dy*dy+dz*dz>.25)return a;
        }
        meshes.add(new Mesh(left.texture,left.vertices,right.vertices,blend));
      }return new Frame(time,meshes);
    }return frames.length==0?null:frames[frames.length-1];
  }

  public static void end() {
    if (capturing != null && !capturing.isEmpty()) {
      HISTORY.addLast(new Frame(now, List.copyOf(capturing)));
      lastSample = now;
    }
    capturing = null;
  }

  private static Object proxy(Object target, boolean ordered) {
    return Proxy.newProxyInstance(
        SwingAfterimages.class.getClassLoader(),
        new Class<?>[] {ordered ? OrderedRenderCommandQueue.class : RenderCommandQueue.class},
        (proxy, method, args) -> {
          // Match stable Java signatures, not method names: production Minecraft names are
          // remapped.
          if (method.getReturnType() == RenderCommandQueue.class) {
            return proxy(method.invoke(target, args), false);
          }
          if (capturing != null && captureHand && args != null) {
            if (args.length == 9
                && args[0] instanceof MatrixStack matrices
                && args[1] instanceof ItemDisplayContext
                && args[6] instanceof List<?> quads) {
              if (!quads.isEmpty() && quads.getFirst() instanceof BakedQuad first) {
                Capture out = new Capture();
                int[] tints = (int[]) args[5];
                for (Object object : quads) {
                  BakedQuad q = (BakedQuad) object;
                  int color =
                      q.hasTint() && q.tintIndex() < tints.length ? tints[q.tintIndex()] : -1;
                  out.quad(
                      matrices.peek(),
                      q,
                      ((color >> 16) & 255) / 255f,
                      ((color >> 8) & 255) / 255f,
                      (color & 255) / 255f,
                      1,
                      0xf000f0,
                      0);
                }
                add(first.sprite().getAtlasId(), out);
              }
            } else if (args.length >= 5
                && args[0] instanceof ModelPart part
                && args[1] instanceof MatrixStack matrices) {
              Capture out = new Capture();
              VertexConsumer sink =
                  args.length > 5 && args[5] instanceof net.minecraft.client.texture.Sprite sprite
                      ? sprite.getTextureSpecificVertexConsumer(out)
                      : out;
              part.render(matrices, sink, 0xf000f0, 0, -1);
              Identifier texture = texture((net.minecraft.client.render.RenderLayer) args[2]);
              if (texture != null) add(texture, out);
            } else if (args.length >= 8
                && args[0] instanceof net.minecraft.client.model.Model model
                && args[2] instanceof MatrixStack matrices) {
              Capture out = new Capture();
              model.setAngles(args[1]);
              VertexConsumer sink =
                  args[7] instanceof net.minecraft.client.texture.Sprite sprite
                      ? sprite.getTextureSpecificVertexConsumer(out)
                      : out;
              model.render(
                  matrices, sink, 0xf000f0, 0, args[6] instanceof Integer color ? color : -1);
              Identifier texture = texture((net.minecraft.client.render.RenderLayer) args[3]);
              if (texture != null) add(texture, out);
            }
          }
          try {
            return method.invoke(target, args);
          } catch (InvocationTargetException e) {
            throw e.getCause();
          }
        });
  }

  private static Identifier texture(net.minecraft.client.render.RenderLayer layer) {
    var setup = ((pl.xvisuals.mixins.RenderLayerAccessor) (Object) layer).visuals$setup();
    Object texture =
        ((pl.xvisuals.mixins.RenderSetupAccessor) (Object) setup)
            .visuals$textures()
            .get("Sampler0");
    return texture instanceof pl.xvisuals.mixins.TextureSpecAccessor accessor
        ? accessor.visuals$location()
        : null;
  }

  private static void add(Identifier texture, Capture out) {
    float[] data = out.finish();
    if (data.length > 0 && capturing.size() < 8 && capturedVertices + data.length / 6 <= 4096) {
      capturedVertices += data.length / 6;
      capturing.add(new Mesh(texture, data));
    }
  }

  private static int mix(int a, int b, double t) {
    int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t),
        g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t),
        bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
    return r << 16 | g << 8 | bl;
  }

  private static final class Capture implements VertexConsumer {
    private float[] data = new float[1536];
    private int count;
    private float x, y, z, u, v;
    private int color = -1;
    private boolean pending;

    private void flush() {
      if (!pending) return;
      pending = false;
      if (count >= 24576) return;
      if (count + 6 > data.length) data = Arrays.copyOf(data, Math.min(24576, data.length * 2));
      data[count++] = x;
      data[count++] = y;
      data[count++] = z;
      data[count++] = u;
      data[count++] = v;
      data[count++] = Float.intBitsToFloat(color);
    }

    float[] finish() {
      flush();
      return Arrays.copyOf(data, count - count % 24);
    }

    public VertexConsumer vertex(float x, float y, float z) {
      flush();
      this.x = x;
      this.y = y;
      this.z = z;
      pending = true;
      return this;
    }

    public VertexConsumer color(int r, int g, int b, int a) {
      color = (a << 24) | (r << 16) | (g << 8) | b;
      return this;
    }

    public VertexConsumer color(int c) {
      color = c;
      return this;
    }

    public VertexConsumer texture(float u, float v) {
      this.u = u;
      this.v = v;
      return this;
    }

    public VertexConsumer overlay(int u, int v) {
      return this;
    }

    public VertexConsumer light(int u, int v) {
      return this;
    }

    public VertexConsumer normal(float x, float y, float z) {
      return this;
    }

    public VertexConsumer lineWidth(float w) {
      return this;
    }
  }

  private SwingAfterimages() {}
}
