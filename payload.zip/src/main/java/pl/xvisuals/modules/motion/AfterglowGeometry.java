package pl.xvisuals.modules.motion;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.*;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.mixins.RenderLayerAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.RaycastContext;
import java.util.Random;
/** A finite, depth-tested silhouette breakup and seeded rising light field. No screen-space overlay. */
final class AfterglowGeometry {
 private static final BufferAllocator ALLOCATOR=new BufferAllocator(131072);
 private static final VertexConsumerProvider.Immediate BUFFERS=VertexConsumerProvider.immediate(ALLOCATOR);
 private static RenderLayer layer(boolean glow){var pipeline=RenderPipeline.builder().withLocation(Identifier.of("xvisuals","pipeline/afterglow"+(glow?"_light":"_splash")))
  .withVertexShader(Identifier.of("xvisuals","core/player_sprite")).withFragmentShader(Identifier.of("xvisuals",glow?"core/afterglow_light":"core/player_sprite"))
  .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER).withSampler("Sampler0")
  .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS).withBlend(glow?new BlendFunction(SourceFactor.SRC_ALPHA,DestFactor.ONE):BlendFunction.TRANSLUCENT)
  .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withDepthWrite(false).withCull(false).build();
  return RenderLayerAccessor.visuals$of("afterglow"+(glow?"_light":"_splash"),RenderSetup.builder(pipeline).texture("Sampler0",Identifier.of("xvisuals","textures/armorfx/white.png")).translucent().expectedBufferSize(131072).build());}
 private static final RenderLayer SPLASH=layer(false),LIGHT=layer(true);
 static {net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING.register(c->ALLOCATOR.close());}
 static void draw(MatrixStack m,double t,double scale,double opacity,int rgb,int seed,double glow,int amount,double density){
  double fade=Math.min(1,t*14)*Math.min(1,(1-t)*4)*opacity;
  if(fade<=0)return;
  var out=BUFFERS.getBuffer(SPLASH);
  Random random=new Random(seed);int count=Math.clamp((int)(amount*density*Math.min(1,pl.xvisuals.rendering.Quality.factor())),0,48);
  // Small luminous pixel flecks detach from the silhouette before turning into light.
  for(int i=0;i<count;i++){double phase=random.nextDouble(),u=(t-phase*.35)/.65;if(u<=0||u>=1)continue;double a=random.nextDouble()*Math.PI*2,r=.25+random.nextDouble()*.35,y=.3+random.nextDouble()*1.5+u*.9,size=(.025+random.nextDouble()*.035)*Math.sin(Math.PI*u)*scale;
   m.push();m.translate(Math.cos(a)*r*scale,y*scale,Math.sin(a)*r*scale);m.multiply(MinecraftClient.getInstance().gameRenderer.getCamera().getRotation());quad(out,m,-size,-size,0,size,-size,0,size,size,0,-size,size,0,argb(0xffefff,fade*Math.sin(Math.PI*u)));m.pop();
  }BUFFERS.draw();
  out=BUFFERS.getBuffer(LIGHT);random=new Random(seed+731);
  for(int i=0;i<count;i++){double start=random.nextDouble()*.33,u=(t-start)/(.8-start);double angle=random.nextDouble()*Math.PI*2,r=.22+random.nextDouble()*.48,y=.35+random.nextDouble()*1.35;double size=.23+random.nextDouble()*.19;
   if(u<=0||u>=1)continue;double envelope=Math.pow(Math.sin(Math.PI*u),.75);double x=Math.cos(angle+u*.65)*r,z=Math.sin(angle+u*.65)*r;
   m.push();m.translate(x*scale,(y+u*1.8)*scale,z*scale);m.multiply(MinecraftClient.getInstance().gameRenderer.getCamera().getRotation());double q=size*scale*(.6+.4*envelope);
   quad(out,m,-q,-q,0,q,-q,0,q,q,0,-q,q,0,argb(rgb,fade*envelope*(.5+glow*.5)));m.pop();
  }BUFFERS.draw();
 }
 private static int argb(int c,double a){return ((int)(255*Math.clamp(a,0,1))<<24)|(c&0xffffff);}
 private static void quad(VertexConsumer o,MatrixStack m,double x,double y,double z,double a,double b,double c,double d,double e,double f,double g,double h,double i,int color){var mat=m.peek().getPositionMatrix();o.vertex(mat,(float)x,(float)y,(float)z).texture(0,0).color(color);o.vertex(mat,(float)a,(float)b,(float)c).texture(1,0).color(color);o.vertex(mat,(float)d,(float)e,(float)f).texture(1,1).color(color);o.vertex(mat,(float)g,(float)h,(float)i).texture(0,1).color(color);}
 private AfterglowGeometry(){}
}
