package pl.xvisuals.modules.motion;

/** Distance-based emission: standing still never builds a cloud, teleports never draw a bridge. */
public final class TrailMotion {
  public record Emission(int count,double remainder) {}
  public static Emission emit(double distance,double carry,double spacing,int budget) {
    if(!Double.isFinite(distance) || distance<0 || distance>4 || spacing<=0)return new Emission(0,0);
    double total=distance+Math.max(0,carry);
    int count=Math.min(Math.max(0,budget),(int)(total/spacing));
    return new Emission(count,total%spacing);
  }
  public static double fade(double age,double lifetime) {
    if(lifetime<=0 || age<0 || age>=lifetime)return 0;
    double t=age/lifetime;
    // Hold enough opacity to remain visible at normal trail size, then ease out.
    // The previous curve faded most of each puff while it was still close to the player.
    double tail=Math.clamp((t-.2)/.8,0,1);
    return Math.min(1,t*12)*(1-tail*tail*(3-2*tail));
  }
  /** Keep accumulated spacing across ticks; spread samples when the emission budget is capped. */
  public static double fraction(double distance,double carry,double spacing,int index,int count) {
    if(distance<=0 || count<=0)return 0;
    int available=(int)((distance+Math.max(0,carry))/spacing);
    int sample=available>count ? (int)Math.floor((index+.5)*available/count) : index;
    return Math.clamp((spacing-Math.max(0,carry)+sample*spacing)/distance,0,1);
  }
  public static double expansion(double progress) { return .6+Math.clamp(progress,0,1)*1.6; }
  private TrailMotion(){}
}
