package pl.xvisuals.modules.motion;

/** Tracks a complete airborne interval; resets on excluded movement and discontinuities. */
public final class LandingImpact {
  private boolean known, grounded;
  private double previousY, peak, speed;
  private int air;
  public void reset() { known=false; air=0; speed=0; }
  public double update(double y, boolean ground, boolean excluded, double minimum) {
    if(excluded || !Double.isFinite(y)) { reset(); return 0; }
    if(!known) { known=true; grounded=ground; previousY=peak=y; return 0; }
    double dy=y-previousY;
    if(Math.abs(dy)>16) { reset(); return 0; }
    double result=0;
    if(!ground) {
      if(grounded) { peak=Math.max(previousY,y); air=0; speed=0; }
      peak=Math.max(peak,y); air++; speed=Math.max(speed,-dy);
    } else {
      double distance=peak-y;
      if(!grounded && air>=2 && distance>=minimum && distance>.05)
        result=Math.clamp(.18+Math.sqrt(distance)*.23+Math.max(speed,-dy)*.18,0,1.6);
      peak=y; air=0; speed=0;
    }
    grounded=ground; previousY=y; return result;
  }
}
