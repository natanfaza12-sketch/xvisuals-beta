package pl.xvisuals.modules.motion;
import pl.xvisuals.XVisuals;
import pl.xvisuals.util.EffectClock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.*;
import net.minecraft.util.math.RotationAxis;
public final class SwordInspect {
  public static KeyBinding binding;
  private static final EffectClock CLOCK=new EffectClock();
  private static Object world;
  private static ItemStack held=ItemStack.EMPTY;
  private static Hand hand=Hand.MAIN_HAND;
  private static boolean active,impacted;
  private static int selectedSlot;
  private static String configuredKey="";
  private static double start,duration;
  private static String style;
  public static boolean active(){return active;}
  private static double now(MinecraftClient c){return CLOCK.sample(System.nanoTime(),c.isPaused()||c.world==null);}
  public static void tick(MinecraftClient c){
    var s=XVisuals.config().module("swordinspect");double time=now(c);
    if(!configuredKey.equals(s.text("key"))){
      configuredKey=s.text("key");try{binding.setBoundKey(InputUtil.fromTranslationKey(configuredKey));KeyBinding.updateKeysByCode();}catch(IllegalArgumentException ignored){}
    }else if(!binding.getBoundKeyTranslationKey().equals(configuredKey)){
      configuredKey=binding.getBoundKeyTranslationKey();s.values.put("key",configuredKey);XVisuals.STORE.dirty();
    }
    if(world!=c.world){world=c.world;active=false;}
    if(c.player==null||!s.enabled||c.currentScreen!=null||c.getOverlay()!=null||pl.xvisuals.gui.world.WorldStudio.active()||!c.options.getPerspective().isFirstPerson()
        ||c.player.isSpectator()||!c.player.isAlive()||c.player.isUsingItem()||c.player.handSwinging
        ||c.options.attackKey.isPressed()||c.options.useKey.isPressed())active=false;
    if(active && (selectedSlot!=c.player.getInventory().getSelectedSlot() || !ItemStack.areItemsAndComponentsEqual(held,c.player.getStackInHand(hand))||time-start>=duration))active=false;
    if(active&&!impacted&&"Ground Plunge".equals(style)&&(time-start)/duration>=.49){
      impacted=true;
      var forward=c.player.getRotationVec(1).multiply(1,0,1).normalize();
      var top=c.player.getEntityPos().add(forward.multiply(.85)).add(0,.7,0);
      var hit=c.world.raycast(new net.minecraft.world.RaycastContext(top,top.add(0,-2,0),
          net.minecraft.world.RaycastContext.ShapeType.COLLIDER,net.minecraft.world.RaycastContext.FluidHandling.NONE,c.player));
      if(hit.getType()==net.minecraft.util.hit.HitResult.Type.BLOCK){
        var at=hit.getPos().add(0,.035,0);
        for(int i=0;i<9;i++){
          double a=i*Math.PI*2/9;
          c.world.addParticleClient(net.minecraft.particle.ParticleTypes.SMOKE,
              at.x+Math.cos(a)*.10,at.y,at.z+Math.sin(a)*.10,Math.cos(a)*.025,.018,Math.sin(a)*.025);
        }
      }
    }
    while(binding.wasPressed()){
      if(active||c.player==null||!s.enabled||c.currentScreen!=null||c.getOverlay()!=null||pl.xvisuals.gui.world.WorldStudio.active()||c.isPaused()
          ||!c.options.getPerspective().isFirstPerson()||c.player.isSpectator()||!c.player.isAlive()||c.player.isUsingItem()
          ||c.player.handSwinging||c.options.attackKey.isPressed()||c.options.useKey.isPressed())continue;
      Hand candidate=c.player.getMainHandStack().isIn(ItemTags.SWORDS)?Hand.MAIN_HAND:Hand.OFF_HAND;
      if(!c.player.getStackInHand(candidate).isIn(ItemTags.SWORDS))continue;
      selectedSlot=c.player.getInventory().getSelectedSlot();
      hand=candidate;held=c.player.getStackInHand(hand).copy();start=time;duration=s.number("duration");impacted=false;style=SwordInspectMotion.select(s.text("style"),style,java.util.concurrent.ThreadLocalRandom.current());active=true;
    }
  }
  public static boolean applies(Hand target){
    var c=MinecraftClient.getInstance();
    return active&&target==hand&&c.world==world&&c.currentScreen==null&&c.getOverlay()==null
        &&c.options.getPerspective().isFirstPerson()&&!pl.xvisuals.gui.world.WorldStudio.active()
        &&XVisuals.config().on("swordinspect")&&c.player!=null
        &&selectedSlot==c.player.getInventory().getSelectedSlot()&&!c.player.isUsingItem()&&!c.player.handSwinging
        &&!c.options.attackKey.isPressed()&&!c.options.useKey.isPressed()
        &&ItemStack.areItemsAndComponentsEqual(held,c.player.getStackInHand(hand));
  }
  public static boolean plunging(){return active&&"Ground Plunge".equals(style);}
  public static void undoRotation(MatrixStack matrices,Arm arm){
    var p=SwordInspectMotion.pose(style,(now(MinecraftClient.getInstance())-start)/duration);
    int sign=arm==Arm.RIGHT?1:-1;
    matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float)-p.pitch()));
    matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((float)-p.yaw()*sign));
    matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float)-p.roll()*sign));
  }
  public static double support(){return active&&"Ground Plunge".equals(style)?SwordInspectMotion.support((now(MinecraftClient.getInstance())-start)/duration):0;}
  public static boolean hideOther(Hand target){return target!=hand&&applies(hand)&&support()>0;}
  public static void apply(MatrixStack matrices,Hand target){
    if(!applies(target))return;var c=MinecraftClient.getInstance();
    double progress=(now(c)-start)/duration;
    var p=SwordInspectMotion.pose(style,progress);
    int sign=(hand==Hand.MAIN_HAND?c.player.getMainArm():c.player.getMainArm().getOpposite())==Arm.RIGHT?1:-1;
    // Rotate around the grip rather than the camera; mirror for left-handed players.
    double x=.56*sign,y=-.52,z=-.72;
    double moveX=p.x()*sign;
    if(plunging()){
      var grip=InspectGrip.position(InspectGrip.custom(held),sign==1);
      x=grip.x;y=grip.y;z=grip.z;
      double enter=Math.clamp(progress/.20,0,1),leave=Math.clamp((progress-.86)/.14,0,1);
      enter=enter*enter*enter*(enter*(enter*6-15)+10);
      leave=leave*leave*leave*(leave*(leave*6-15)+10);
      moveX=-x*enter*(1-leave);
    }
    matrices.translate(moveX,p.y(),p.z());matrices.translate(x,y,z);
    matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float)p.roll()*sign));
    matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((float)p.yaw()*sign));
    matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float)p.pitch()));
    matrices.translate(-x,-y,-z);
  }
  private SwordInspect(){}
}
