package pl.xvisuals.modules.motion;

import pl.xvisuals.XVisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;

/** Independent render clock: never changes swing packets, cooldowns or entity swing duration. */
public final class SwingMotion {
  private static final SwingTimeline[] CLOCKS = {new SwingTimeline(), new SwingTimeline()};
  private static final double[] PROGRESS = {0, 0}, PULSE = {0, 0}, ARC = {0, 0};
  private static long previous;
  private static final SwingGate GATE=new SwingGate();

  private static boolean miningInput() {
    var c=MinecraftClient.getInstance();
    return c.interactionManager!=null && c.interactionManager.isBreakingBlock()
        || c.options.attackKey.isPressed() && c.crosshairTarget!=null
        && c.crosshairTarget.getType()==net.minecraft.util.hit.HitResult.Type.BLOCK;
  }
  public static boolean mining() {
    var c=MinecraftClient.getInstance();
    return GATE.update(miningInput(),false,false,c.player!=null && c.player.handSwinging);
  }
  public static boolean customActive() { return !SwordInspect.active() && XVisuals.config().on("swing") && !mining(); }

  public static void trigger(Hand hand) {
    if(miningInput()){mining();clearClock();return;}
    GATE.reset();
    var speed=XVisuals.config().module("swingspeed");
    CLOCKS[hand == Hand.MAIN_HAND ? 0 : 1].trigger(speed.enabled && speed.flag("finish"));
  }

  public static void frame() {
    if(mining() || SwordInspect.active() || (!XVisuals.config().on("swing") && !XVisuals.config().on("swingspeed"))){clearClock();return;}
    long now = System.nanoTime();
    double dt = previous == 0 ? 1 / 60.0 : (now - previous) / 1e9;
    previous = now;
    dt=MinecraftClient.getInstance().isPaused()?0:Math.clamp(dt,0,.1);
    var s = XVisuals.config().module("swing");
    for (int i = 0; i < 2; i++) {
      boolean custom=s.enabled;
      var speed=XVisuals.config().module("swingspeed");
      double multiplier=speed.enabled?speed.number("speed"):1;
      var player=MinecraftClient.getInstance().player;
      double vanillaDuration=player==null?.3:((pl.xvisuals.mixins.SwingDurationAccessor)player).visuals$swingDuration()/20.0;
      double duration = custom?s.number("duration"):vanillaDuration;
      duration *= custom ?
          switch (s.text("preset")) {
            case "Snappy" -> .7;
            case "Slow" -> 1.6;
            case "Cinematic" -> 1.25;
            default -> 1;
          } : 1;
      double t = CLOCKS[i].advance(dt,duration,multiplier);
      if (!CLOCKS[i].active()) {
        PROGRESS[i] = 0;
        PULSE[i] = Easing.damp(PULSE[i], 0, 25 / (.1 + s.number("smoothness")), dt);
        ARC[i] = Easing.damp(ARC[i], 0, 25 / (.1 + s.number("smoothness")), dt);
        continue;
      }
      if(!custom){PROGRESS[i]=t;PULSE[i]=0;ARC[i]=0;continue;}
      String curve = s.text("easing");
      if (curve.equals("Preset"))
        curve =
            switch (s.text("preset")) {
              case "Vanilla" -> "Linear";
              case "Snappy" -> "Ease Out";
              case "Slow" -> "Smoothstep";
              default -> "Sine";
            };
      double progress =
          s.flag("custom")
              ? Easing.bezier(t, s.number("control1"), s.number("control2"))
              : Easing.apply(curve, t);
      PROGRESS[i] = progress;
      double targetArc=Math.sin(progress*Math.PI*2)*Math.pow(Math.sin(progress*Math.PI),2);
      ARC[i]=s.number("smoothness")<.01?targetArc:Easing.damp(ARC[i],targetArc,35/(.15+s.number("smoothness")),dt);
      double pulse = Math.sin(Math.PI * progress);
      pulse *= pulse;
      PULSE[i] =
          s.number("smoothness") < .01
              ? pulse
              : Easing.damp(PULSE[i], pulse, 35 / (.15 + s.number("smoothness")), dt);
    }
  }

  public static float progress(Hand hand, float vanilla) {
    if (customActive() && hand==Hand.OFF_HAND && !XVisuals.config().module("swing").flag("offhand")) return 0;
    return (customActive() || (!SwordInspect.active() && XVisuals.config().on("swingspeed") && !mining()))
        ? (float) PROGRESS[hand == Hand.MAIN_HAND ? 0 : 1]
        : vanilla;
  }

  public static boolean moving() {
    var p = MinecraftClient.getInstance().player;
    return p != null && (p.handSwinging || PULSE[0] > .025 || PULSE[1] > .025);
  }

  public static boolean moving(Hand hand){
    var p=MinecraftClient.getInstance().player;
    return p!=null&&((p.handSwinging&&(p.preferredHand==hand||p.preferredHand==null&&hand==Hand.MAIN_HAND))
        || (XVisuals.config().on("swing") || XVisuals.config().on("swingspeed")) && CLOCKS[hand==Hand.MAIN_HAND?0:1].active());
  }

  public static boolean transform(MatrixStack matrices, Arm arm) {
    var s = XVisuals.config().module("swing");
    if (!customActive()) return false;
    var p = MinecraftClient.getInstance().player;
    if (p == null) return false;
    int index = arm == p.getMainArm() ? 0 : 1, sign = arm == Arm.RIGHT ? 1 : -1;
    if (index==1 && !s.flag("offhand")) return true;
    return SwingPose.apply(matrices,s.text("preset"),sign,PROGRESS[index],PULSE[index],ARC[index],
        s.number("strength"),s.number("distance"),s.number("followThrough"));
  }

  public static void clear() {
    GATE.reset();clearClock();
  }
  private static void clearClock() {
    for(var clock:CLOCKS)clock.clear();
    java.util.Arrays.fill(PULSE, 0);
    java.util.Arrays.fill(ARC, 0);
    java.util.Arrays.fill(PROGRESS, 0);
    previous = 0;
  }

  private SwingMotion() {}
}
