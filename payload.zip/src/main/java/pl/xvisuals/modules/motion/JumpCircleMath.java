package pl.xvisuals.modules.motion;

/** Pure, frame-rate independent timing and grounded-transition rules. */
final class JumpCircleMath {
  static boolean tookOff(double rise) { return rise > .05 && rise < 2; }

  static boolean landed(boolean groundedBefore, boolean grounded, int airborneTicks, boolean excluded) {
    return !groundedBefore && grounded && airborneTicks >= 2 && !excluded;
  }

  static double progress(double age, double duration, double speed) {
    return Math.clamp(age * speed / Math.max(.05, duration), 0, 1);
  }

  static double radius(double t) { return .12 + .88 * (1 - Math.pow(1 - t, 3)); }
  static double fade(double t) { return pl.xvisuals.util.EffectEnvelope.fade(t,.08,.1); }
  private JumpCircleMath() {}
}
