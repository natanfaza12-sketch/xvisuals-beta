package pl.xvisuals.modules.motion;

import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import pl.xvisuals.mixins.RenderLayerAccessor;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.*;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.RaycastContext;
import java.util.*;

/** Bounded client-side terrain tiles. Collision sampling happens only on landing. */
public final class Shockwave {
 private record Track(Vec3d pos,boolean ground,boolean excluded,double peak,int air){}
 private record Face(net.minecraft.client.render.model.BakedQuad quad,int color){}
 private record Tile(double x,double y,double z,double distance,int color,BlockPos support,net.minecraft.block.BlockState state,net.minecraft.client.render.model.BlockStateModel model,List<Face> faces){}
 private record Wave(Vec3d center,double born,double radius,double duration,double power,List<Tile> tiles,boolean local){}
 private static final Map<UUID,Track> TRACKS=new HashMap<>();
 private static final List<Wave> WAVES=new ArrayList<>();
 private static Object world;private static double time;private static long last;private static int budget;
 private static final BufferAllocator ALLOCATOR=new BufferAllocator(262144);
 private static final BufferAllocator TERRAIN_ALLOCATOR=new BufferAllocator(262144);
 private static final VertexConsumerProvider.Immediate TERRAIN_BUFFERS=VertexConsumerProvider.immediate(TERRAIN_ALLOCATOR);
 private static final VertexConsumerProvider.Immediate BUFFERS=VertexConsumerProvider.immediate(ALLOCATOR);
 private static final RenderPipeline PIPE=RenderPipeline.builder().withLocation(Identifier.of("xvisuals","pipeline/shockwave"))
 .withVertexShader(Identifier.of("xvisuals","core/player_sprite")).withFragmentShader(Identifier.of("xvisuals","core/player_sprite"))
 .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER).withSampler("Sampler0")
 .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS).withBlend(BlendFunction.TRANSLUCENT)
 .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withDepthWrite(true).withCull(false).build();
 private static final RenderLayer LAYER=RenderLayerAccessor.visuals$of("shockwave_tiles",RenderSetup.builder(PIPE).texture("Sampler0",Identifier.of("xvisuals","textures/armorfx/white.png")).translucent().expectedBufferSize(262144).build());
 private static final RenderLayer TERRAIN=RenderLayerAccessor.visuals$of("shockwave_terrain",RenderSetup.builder(PIPE).texture("Sampler0",net.minecraft.client.texture.SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE).translucent().expectedBufferSize(262144).build());
 public static int renderedQuads;
 public static int count(){return WAVES.size();}
 public static void init(){WorldRenderEvents.END_MAIN.register(c->render(c.matrices()));net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING.register(c->{ALLOCATOR.close();TERRAIN_ALLOCATOR.close();});}
 private static double clock(){var c=MinecraftClient.getInstance();long n=System.nanoTime();if(last!=0&&!c.isPaused())time+=Math.min(.1,(n-last)/1e9);last=n;return time;}
 public static void tick(MinecraftClient c){double now=clock();var s=XVisuals.visualModule("shockwave");
  if(world!=c.world||!s.enabled){TRACKS.clear();WAVES.clear();world=c.world;}if(c.world==null||c.player==null||!s.enabled)return;
  WAVES.removeIf(w->now-w.born>w.duration||(w.local?!s.flag("local"):!s.flag("others")));budget=2;Set<UUID> seen=new HashSet<>();
  for(var p:c.world.getPlayers()){
   boolean local=p==c.player;if(!(local?s.flag("local"):s.flag("others"))||p.squaredDistanceTo(c.player)>1600)continue;
   seen.add(p.getUuid());Vec3d pos=p.getEntityPos();boolean ground=p.isOnGround(),excluded=p.isSpectator()||!p.isAlive()||p.hasVehicle()||p.isTouchingWater()||p.isInLava()||p.isClimbing()||p.isGliding()||p.getAbilities().flying;
   Track old=TRACKS.get(p.getUuid());boolean continuous=old!=null&&!old.excluded&&!excluded&&old.pos.squaredDistanceTo(pos)<16;
   double peak=continuous&&!old.ground?Math.max(old.peak,pos.y):pos.y;int air=ground?0:continuous?old.air+1:1;
   if(continuous&&ground&&!old.ground&&old.air>=3&&peak-pos.y>=s.number("minimum")&&budget-->0)spawn(c,p,pos,now,Math.clamp((peak-pos.y)/2,.45,1.5),local);
   TRACKS.put(p.getUuid(),new Track(pos,ground,excluded,peak,air));
  }TRACKS.keySet().retainAll(seen);
 }
 private static void spawn(MinecraftClient c,net.minecraft.client.network.AbstractClientPlayerEntity p,Vec3d pos,double now,double power,boolean local){
  var s=XVisuals.visualModule("shockwave");double radius=s.number("radius");List<Tile> tiles=new ArrayList<>();int bx=MathHelper.floor(pos.x),bz=MathHelper.floor(pos.z),r=(int)Math.ceil(radius);
  for(int z=-r;z<=r;z++)for(int x=-r;x<=r;x++){
   double wx=bx+x+.5,wz=bz+z+.5,d=Math.hypot(wx-pos.x,wz-pos.z);if(d>radius)continue;
   var hit=c.world.raycast(new RaycastContext(new Vec3d(wx,pos.y+.4,wz),new Vec3d(wx,pos.y-1.1,wz),RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,p));
   if(hit.getType()!=HitResult.Type.BLOCK||Math.abs(hit.getPos().y-pos.y)>.55)continue;
   BlockPos support=BlockPos.ofFloored(hit.getPos().add(0,-.01,0));var state=c.world.getBlockState(support);var shape=state.getCollisionShape(c.world,support);
   if(shape.isEmpty()||!state.getFluidState().isEmpty()||!c.world.getBlockState(support.up()).getCollisionShape(c.world,support.up()).isEmpty())continue;var bounds=shape.getBoundingBox();
   if(bounds.minX>.001||bounds.minZ>.001||bounds.maxX<.999||bounds.maxZ<.999)continue;
   double y=hit.getPos().y;boolean flat=true;for(double dx:new double[]{-.46,.46})for(double dz:new double[]{-.46,.46}){
    var corner=c.world.raycast(new RaycastContext(new Vec3d(wx+dx,y+.3,wz+dz),new Vec3d(wx+dx,y-.15,wz+dz),RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,p));
    if(corner.getType()!=HitResult.Type.BLOCK||Math.abs(corner.getPos().y-y)>.025)flat=false;
   }if(!flat)continue;
   var model=c.getBlockRenderManager().getModel(state);List<Face> faces=new ArrayList<>();
   for(var part:model.getParts(net.minecraft.util.math.random.Random.create(state.getRenderingSeed(support)))){
    for(Direction direction:Direction.values())for(var q:part.getQuads(direction))faces.add(face(c,state,support,q));
    for(var q:part.getQuads(null))faces.add(face(c,state,support,q));
   }
   if(faces.isEmpty())continue;
   tiles.add(new Tile(wx,y,wz,d,state.getMapColor(c.world,support).color,support,state,model,faces));
  }
  if(tiles.isEmpty())return;while(WAVES.size()>=4)WAVES.removeFirst();WAVES.add(new Wave(pos,now,radius,s.number("duration"),power,tiles,local));
 }
 public static double pulse(double age,double distance,double radius,double duration){double u=(age-distance/Math.max(1,radius)*duration*.55)/(duration*.45);return u<=0||u>=1?0:Math.pow(Math.sin(Math.PI*u),2);}
 public static double shake(){var c=MinecraftClient.getInstance();if(c.player==null||!XVisuals.visualModule("shockwave").enabled)return 0;double now=clock(),sum=0;for(var w:WAVES){double age=now-w.born;if(age<.55)sum+=Math.sin(age*42)*Math.exp(-age*9)*w.power*Math.max(0,1-c.player.getEntityPos().distanceTo(w.center)/12);}return Math.clamp(sum,-1,1)*XVisuals.visualModule("shockwave").number("shake")*1.5;}
 private static void render(MatrixStack m){renderedQuads=0;var c=MinecraftClient.getInstance();double now=clock();if(c.world==null||!XVisuals.visualModule("shockwave").enabled)return;var s=XVisuals.visualModule("shockwave");var camera=c.gameRenderer.getCamera().getCameraPos();var out=BUFFERS.getBuffer(LAYER);
  for(var w:WAVES){if(w.center.squaredDistanceTo(camera)>1600)continue;for(var tile:w.tiles){double p=pulse(now-w.born,tile.distance,w.radius,w.duration);if(p<.005||!c.world.getBlockState(tile.support).equals(tile.state))continue;
   double lift=p*s.number("height")*w.power*(1-.3*tile.distance/w.radius);m.push();m.translate(tile.x-camera.x,tile.y-camera.y+.008,tile.z-camera.z);
   if(c.getBlockRenderManager().getModel(tile.state)!=tile.model){m.pop();continue;}
   var terrain=TERRAIN_BUFFERS.getBuffer(TERRAIN);var matrix=m.peek().getPositionMatrix();
   // Keep the world's exact baked UVs, random rotation, tint and model geometry.
   double top=tile.y-tile.support.getY();
   for(var f:tile.faces){var q=f.quad;for(int i=0;i<4;i++){var v=q.getPosition(i);long uv=q.getTexcoords(i);
    terrain.vertex(matrix,(float)(v.x()-.5),(float)(v.y()-top+lift),(float)(v.z()-.5)).texture(net.minecraft.client.util.math.Vector2f.getX(uv),net.minecraft.client.util.math.Vector2f.getY(uv)).color(f.color);
   }renderedQuads++;}
   // A narrow fading seam sits on the moving block, not a second panel covering it.
   if(s.flag("outlines")){
   int edge=pl.xvisuals.util.Colors.alpha(s.color("color"),Math.min(1,p*1.3));double y=lift+.003,seam=.008;
   quad(out,m,edge,-.5,y,-.5,.5,y,-.5,.5,y,-.5+seam,-.5,y,-.5+seam);
   quad(out,m,edge,-.5,y,.5-seam,.5,y,.5-seam,.5,y,.5,-.5,y,.5);
   quad(out,m,edge,-.5,y,-.5,-.5+seam,y,-.5,-.5+seam,y,.5,-.5,y,.5);
   quad(out,m,edge,.5-seam,y,-.5,.5,y,-.5,.5,y,.5,.5-seam,y,.5);
   }
   m.pop();
  }}TERRAIN_BUFFERS.draw();BUFFERS.draw();
 }
 private static Face face(MinecraftClient c,net.minecraft.block.BlockState state,BlockPos pos,net.minecraft.client.render.model.BakedQuad q){
  int tint=q.hasTint()?c.getBlockColors().getColor(state,c.world,pos,q.tintIndex()):0xffffff;
  double brightness=q.shade()?c.world.getBrightness(q.face(),true):1;
  brightness*=.35+.65*c.world.getLightLevel(pos.up())/15.;
  return new Face(q,shade(tint,brightness));
 }
 private static int shade(int c,double f){return 0xff000000|((int)(((c>>16)&255)*f)<<16)|((int)(((c>>8)&255)*f)<<8)|(int)((c&255)*f);}
 private static void box(VertexConsumer v,MatrixStack m,double x,double y,double z,double a,double b,double d,int col){quad(v,m,col,x,b,z,a,b,z,a,b,d,x,b,d);quad(v,m,shade(col,.7),x,y,z,a,y,z,a,b,z,x,b,z);quad(v,m,shade(col,.8),a,y,z,a,y,d,a,b,d,a,b,z);quad(v,m,shade(col,.7),a,y,d,x,y,d,x,b,d,a,b,d);quad(v,m,shade(col,.8),x,y,d,x,y,z,x,b,z,x,b,d);}
 private static void quad(VertexConsumer v,MatrixStack m,int color,double... xyz){var matrix=m.peek().getPositionMatrix();for(int i=0;i<4;i++)v.vertex(matrix,(float)xyz[i*3],(float)xyz[i*3+1],(float)xyz[i*3+2]).texture(.5f,.5f).color(color);renderedQuads++;}
 private Shockwave(){}
}
