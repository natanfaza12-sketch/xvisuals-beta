package pl.xvisuals.modules.motion;
/** A bounded render clock. Speed changes affect future motion without jumping the current pose. */
public final class SwingTimeline {
 private double phase;
 private boolean active,queued;
 public void trigger(boolean finish){
  if(active&&finish){queued=true;return;}
  phase=0;active=true;queued=false;
 }
 public double advance(double seconds,double duration,double speed){
  if(!active)return 0;
  phase+=Math.max(0,seconds)*Math.clamp(speed,.2,5)/Math.max(.03,duration);
  if(phase>=1){
   if(queued){phase=Math.min(phase-1,.99);queued=false;}
   else {clear();return 0;}
  }
  return phase;
 }
 public boolean active(){return active;}
 public void clear(){phase=0;active=false;queued=false;}
}
