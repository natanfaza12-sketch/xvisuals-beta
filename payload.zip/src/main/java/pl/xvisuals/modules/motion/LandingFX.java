package pl.xvisuals.modules.motion;

import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import pl.xvisuals.mixins.RenderLayerAccessor;
import pl.xvisuals.rendering.Quality;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.particle.*;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.*;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.RaycastContext;
import java.util.*;

/** Local cosmetic landings. No entities, packets, damage or block changes. */
public final class LandingFX {
  private static final LandingImpact TRACK=new LandingImpact();
  private static final List<Ring> RINGS=new ArrayList<>();
  private static final Random RANDOM=new Random();
  private static Object world,player;
  private static Vec3d previous;
  private static int ticks;
  private static final BufferAllocator ALLOCATOR=new BufferAllocator(131072);
  private static final VertexConsumerProvider.Immediate BUFFERS=VertexConsumerProvider.immediate(ALLOCATOR);
  private static final RenderLayer LAYER=RenderLayerAccessor.visuals$of("xvisuals_landing_ring",RenderSetup.builder(RenderPipeline.builder()
      .withLocation(Identifier.of("xvisuals","pipeline/landing_ring"))
      .withVertexShader(Identifier.of("xvisuals","core/player_sprite"))
      .withFragmentShader(Identifier.of("xvisuals","core/landing_ring"))
      .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER)
      .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS)
      .withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
      .withDepthWrite(false).withCull(false).build()).translucent().expectedBufferSize(131072).build());
  private record Patch(double x0,double z0,double x1,double z1,double y) {}
  private record Ring(Vec3d pos,int born,double size,double strength,int color,List<Patch> patches) {}
  public static void init() {
    ClientTickEvents.END_CLIENT_TICK.register(LandingFX::tick);
    WorldRenderEvents.END_MAIN.register(c->render(c.matrices()));
    ClientLifecycleEvents.CLIENT_STOPPING.register(c->ALLOCATOR.close());
  }
  private static boolean enabled() { return XVisuals.ready() && XVisuals.visualModule("landingfx").enabled; }
  private static void tick(MinecraftClient c) {
    if(world!=c.world || player!=c.player || !enabled()) {
      world=c.world;player=c.player;TRACK.reset();RINGS.clear();previous=null;
    }
    if(!enabled() || c.world==null || c.player==null || c.isPaused())return;
    ticks++;RINGS.removeIf(r->ticks-r.born>=22);
    var p=c.player;var pos=p.getEntityPos();
    boolean excluded=!p.isAlive() || p.isSpectator() || p.hasVehicle() || p.getAbilities().flying
        || p.isGliding() || p.isTouchingWater() || p.isInLava() || p.isClimbing();
    if(previous!=null && (Math.abs(pos.x-previous.x)>8 || Math.abs(pos.z-previous.z)>8))TRACK.reset();
    previous=pos;
    var s=XVisuals.visualModule("landingfx");
    double impact=TRACK.update(pos.y,p.isOnGround(),excluded,s.number("minimum"))*s.number("impact");
    if(impact<=0)return;
    var hit=c.world.raycast(new RaycastContext(pos.add(0,.15,0),pos.add(0,-.6,0),RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,p));
    if(hit.getType()!=HitResult.Type.BLOCK || hit.getSide()!=Direction.UP)return;
    var state=c.world.getBlockState(hit.getBlockPos());
    if(!state.getFluidState().isEmpty())return;
    double quality=Math.clamp(Quality.factor(),.1,1);
    if(s.flag("dust") && !s.text("mode").equals("Shockwave")) {
      int count=(int)Math.min(100,s.number("amount")*impact*quality);
      ParticleEffect effect=s.flag("surface")?new BlockStateParticleEffect(ParticleTypes.BLOCK,state):new DustParticleEffect(s.color("color"),.7f);
      for(int i=0;i<count;i++) {
        double angle=RANDOM.nextDouble()*Math.PI*2, speed=(.025+RANDOM.nextDouble()*.08)*impact;
        c.world.addParticleClient(effect,pos.x+Math.cos(angle)*.22,hit.getPos().y+.08,pos.z+Math.sin(angle)*.22,
            Math.cos(angle)*speed,.025+RANDOM.nextDouble()*.07*impact,Math.sin(angle)*speed);
      }
    }
    if(s.flag("sounds")) {
      var sound=state.getSoundGroup();
      c.world.playSoundClient(pos.x,pos.y,pos.z,sound.getFallSound(),net.minecraft.sound.SoundCategory.PLAYERS,
          (float)Math.min(.7,.22*impact),.9f+RANDOM.nextFloat()*.15f,false);
    }
    if(!s.flag("rings") || s.text("mode").equals("Dust"))return;
    double size=Math.min(4,s.number("size")*(.65+impact*.45));
    List<Patch> patches=new ArrayList<>();
    // Sample collision boxes once per impact; never bridge stairs or gaps with a flat decal.
    for(int x=(int)Math.floor(pos.x-size);x<=Math.floor(pos.x+size);x++)
      for(int z=(int)Math.floor(pos.z-size);z<=Math.floor(pos.z+size);z++) {
        if(!c.world.isChunkLoaded(x>>4,z>>4))continue;
        for(int y=(int)Math.floor(pos.y-1.1);y<=Math.floor(pos.y+.3);y++) {
          var bp=new BlockPos(x,y,z);var block=c.world.getBlockState(bp);
          if(!block.getFluidState().isEmpty())continue;
          for(var box:block.getCollisionShape(c.world,bp).getBoundingBoxes()) {
            double top=y+box.maxY;
            if(top<pos.y-1 || top>pos.y+.35)continue;
            double mx=x+(box.minX+box.maxX)/2,mz=z+(box.minZ+box.maxZ)/2;
            var surface=c.world.raycast(new RaycastContext(new Vec3d(mx,pos.y+.4,mz),new Vec3d(mx,top-.02,mz),RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,p));
            if(surface.getType()!=HitResult.Type.BLOCK || Math.abs(surface.getPos().y-top)>.025)continue;
            if(patches.size()<512)patches.add(new Patch(x+box.minX,z+box.minZ,x+box.maxX,z+box.maxZ,top+.018));
          }
        }
      }
    while(RINGS.size()>=4)RINGS.removeFirst();
    RINGS.add(new Ring(pos,ticks,size,impact,s.color("color"),patches));
  }
  private static void render(MatrixStack matrices) {
    var c=MinecraftClient.getInstance();
    if(!enabled() || world!=c.world || c.world==null || RINGS.isEmpty())return;
    var s=XVisuals.visualModule("landingfx");
    if(!s.flag("rings") || s.text("mode").equals("Dust"))return;
    var camera=c.gameRenderer.getCamera().getCameraPos();
    matrices.push();matrices.translate(-camera.x,-camera.y,-camera.z);
    var m=matrices.peek().getPositionMatrix();var out=BUFFERS.getBuffer(LAYER);
    for(var ring:RINGS) {
      double t=Math.clamp((ticks-ring.born+c.getRenderTickCounter().getTickProgress(false))/22d,0,1);
      double radius=ring.size*(.08+.92*(1-Math.pow(1-t,3)));
      int color=((int)(Math.min(.65,ring.strength*.4)*Math.pow(1-t,1.6)*255)<<24)|(ring.color&0xFFFFFF);
      for(var patch:ring.patches) {
        double[] xs={patch.x0,patch.x1,patch.x1,patch.x0},zs={patch.z0,patch.z0,patch.z1,patch.z1};
        for(int i=0;i<4;i++)out.vertex(m,(float)xs[i],(float)patch.y,(float)zs[i])
            .texture((float)((xs[i]-ring.pos.x)/radius),(float)((zs[i]-ring.pos.z)/radius)).color(color);
      }
    }
    BUFFERS.draw();matrices.pop();
  }
  private LandingFX() {}
}
