package pl.xvisuals.modules.motion;

import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.mixins.RenderLayerAccessor;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import java.util.Random;

/** Bounded, detached visual geometry; never modifies terrain or entities. */
final class KillAnimationGeometry {
 private static final BufferAllocator ALLOCATOR=new BufferAllocator(131072);
 private static final VertexConsumerProvider.Immediate BUFFERS=VertexConsumerProvider.immediate(ALLOCATOR);
 private static final RenderLayer LAYER=RenderLayerAccessor.visuals$of("visuals_kill_animation",
  RenderSetup.builder(RenderPipeline.builder()
   .withLocation(Identifier.of("xvisuals","pipeline/kill_animation"))
   .withVertexShader(Identifier.of("xvisuals","core/player_sprite"))
   .withFragmentShader(Identifier.of("xvisuals","core/player_sprite"))
   .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER).withSampler("Sampler0")
   .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS)
   .withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
   .withDepthWrite(false).withCull(false).build()).texture("Sampler0",Identifier.of("xvisuals","textures/crafted/metal.png")).translucent().expectedBufferSize(131072).build());
 static { net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING.register(c->ALLOCATOR.close()); }
 static void draw(MatrixStack m,String style,double t,double scale,double opacity,int tint,int seed) {
  var out=BUFFERS.getBuffer(LAYER);
  double fade=Math.min(1,t*12)*Math.min(1,(1-t)*5)*opacity;
  Random random=new Random(seed);
  if(!style.equals("Prismatic Burst")) {
   double radius=scale*.9*Math.min(1,t*6)*Math.min(1,(1-t)*6);
   // Concentric feathered bands avoid a hard, opaque disc against the terrain.
   for(int ring=0;ring<3;ring++) for(int i=0;i<32;i++) {
    double a=i*Math.PI/16,b=(i+1)*Math.PI/16;
    double inner=radius*ring/3,outer=radius*(ring+1)/3;
    double edge=1-(ring+.5)/3;
    quad(out,m,Math.cos(a)*inner,.026,Math.sin(a)*inner,
      Math.cos(a)*outer,.026,Math.sin(a)*outer,
      Math.cos(b)*outer,.026,Math.sin(b)*outer,
      Math.cos(b)*inner,.026,Math.sin(b)*inner,argb(0x100D17,fade*.8*edge*edge));
   }
   for(int i=0;i<10;i++) {
    double a=i*Math.PI/5+random.nextDouble()*.3,x=Math.cos(a)*radius*.75,z=Math.sin(a)*radius*.75;
    for(int j=0;j<4;j++) {
     double angle=a+(random.nextDouble()-.5)*.8;
     double nx=x+Math.cos(angle)*scale*.25,nz=z+Math.sin(angle)*scale*.25;
     groundLine(out,m,x,z,nx,nz,scale*(.07-j*.014),argb(0x110E18,fade));
     groundLine(out,m,x,z,nx,nz,scale*.006,argb(tint,fade*.5));
     x=nx;z=nz;
    }
   }
   if(style.equals("Chain Burial")) {
    double descend=2.15*smooth((t-.24)/.62);
    // Three continuous vertical chains: tangent-aligned oval links interlock.
    for(int strand=0;strand<3;strand++) for(int i=0;i<18;i++) {
     double y=(.075+i*.11-descend)*scale;
     if(y<.08*scale)continue;
     double angle=strand*Math.PI*2/3+.25;
     double wrap=smooth(t/.22),r=(.75-.4*wrap)*scale;
     m.push();
     m.translate(Math.cos(angle)*r,y,Math.sin(angle)*r);
     m.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Y.rotation((float)(-angle+(i%2)*Math.PI/2)));
     for(int j=0;j<10;j++) {
      double a=j*Math.PI/5,b=(j+1)*Math.PI/5;
      double x=Math.cos(a)*.070*scale,z=Math.cos(b)*.070*scale;
      double v=Math.sin(a)*.070*scale,w=Math.sin(b)*.070*scale;
      double nx=Math.cos(a)*.043*scale,nz=Math.cos(b)*.043*scale;
      double nv=Math.sin(a)*.052*scale,nw=Math.sin(b)*.052*scale;
      int metal=argb(j<5?0xACB8CA:0x465166,fade*wrap);
      double d=.007*scale;
      quad(out,m,x,v,-d,z,w,-d,nz,nw,-d,nx,nv,-d,metal);
      quad(out,m,x,v,d,nx,nv,d,nz,nw,d,z,w,d,metal);
      quad(out,m,x,v,-d,x,v,d,z,w,d,z,w,-d,metal);
      quad(out,m,nx,nv,-d,nz,nw,-d,nz,nw,d,nx,nv,d,metal);
     }
     m.pop();
    }
   }
  } else {
   int count=pl.xvisuals.rendering.Quality.factor()<.5?16:28;
   for(int i=0;i<count;i++) {
    double start=random.nextDouble()*.08,life=Math.clamp((t-start)/(1-start),0,1);

    double angle=random.nextDouble()*Math.PI*2,speed=.4+random.nextDouble()*.8;
    double x=Math.cos(angle)*life*speed*scale,z=Math.sin(angle)*life*speed*scale;
    double y=(random.nextDouble()*1.6+life*1.3-life*life*.9)*scale;
    double size=(.035+random.nextDouble()*.035)*Math.sin(Math.PI*life)*scale;
    if(life<=0 || life>=1)continue;
    int rgb=switch(i%4){case 0->0xFFD887;case 1->0xFF98DF;case 2->0xE8DCFF;default->tint;};
    m.push();m.translate(x,y,z);
    m.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Y.rotation((float)(angle+life*2)));
    m.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Z.rotation((float)(life*1.4+i*.7)));
    for(int face=0;face<4;face++) {
      double aa=face*Math.PI/2,bb=(face+1)*Math.PI/2,r=size*1.8;
      double ax=Math.cos(aa)*r,az=Math.sin(aa)*r,bx=Math.cos(bb)*r,bz=Math.sin(bb)*r;
      int shade=argb(pl.xvisuals.util.Colors.mix(rgb,0xff172336,face*.12),fade*(1-life));
      quad(out,m,0,size*4,0,ax,0,az,bx,0,bz,0,size*4,0,shade);
      quad(out,m,0,-size*3,0,bx,0,bz,ax,0,az,0,-size*3,0,shade);
    }
    m.pop();
   }
  }
  BUFFERS.draw();
 }
 private static double smooth(double t){t=Math.clamp(t,0,1);return t*t*(3-2*t);}
 private static int argb(int rgb,double a){return ((int)(255*Math.clamp(a,0,1))<<24)|(rgb&0xffffff);}
 private static void groundLine(VertexConsumer out,MatrixStack m,double x,double z,double u,double v,double w,int color){
  double len=Math.hypot(u-x,v-z),nx=-(v-z)/len*w/2,nz=(u-x)/len*w/2;
  quad(out,m,x+nx,.03,z+nz,u+nx,.03,v+nz,u-nx,.03,v-nz,x-nx,.03,z-nz,color);
 }
 private static void cube(VertexConsumer o,MatrixStack m,double x,double y,double z,double w,double h,double d,int c){
  double X=x+w,Y=y+h,Z=z+d;
  quad(o,m,x,y,z,X,y,z,X,Y,z,x,Y,z,c);quad(o,m,x,y,Z,x,Y,Z,X,Y,Z,X,y,Z,c);
  quad(o,m,x,y,z,x,Y,z,x,Y,Z,x,y,Z,c);quad(o,m,X,y,z,X,y,Z,X,Y,Z,X,Y,z,c);
  quad(o,m,x,Y,z,X,Y,z,X,Y,Z,x,Y,Z,c);quad(o,m,x,y,z,x,y,Z,X,y,Z,X,y,z,c);
 }
 private static void quad(VertexConsumer out,MatrixStack m,double x,double y,double z,double a,double b,double c,double d,double e,double f,double g,double h,double i,int color){
  var matrix=m.peek().getPositionMatrix();
  out.vertex(matrix,(float)x,(float)y,(float)z).texture(0,0).color(color);out.vertex(matrix,(float)a,(float)b,(float)c).texture(1,0).color(color);
  out.vertex(matrix,(float)d,(float)e,(float)f).texture(1,1).color(color);out.vertex(matrix,(float)g,(float)h,(float)i).texture(0,1).color(color);
 }
 private KillAnimationGeometry(){}
}
