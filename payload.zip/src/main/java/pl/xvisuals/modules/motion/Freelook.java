package pl.xvisuals.modules.motion;

import pl.xvisuals.XVisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.*;

/** Camera-only state. Entity position/angles and outgoing movement packets are never rewritten. */
public final class Freelook {
  private static boolean requested, engaged, lastDown, screenOpen;
  private static Perspective original;
  private static Object world;
  private static String key = "";
  private static double yaw, pitch, targetYaw, targetPitch, blend;
  private static Vec3d offset = Vec3d.ZERO, targetOffset = Vec3d.ZERO;
  private static long previous;

  public static boolean active() {
    return engaged;
  }

  public static boolean requested() {
    return requested;
  }

  public static boolean capturesMovement() {
    var settings = XVisuals.config().module("freelook");
    return engaged && requested && settings.flag("cameraOnly") && settings.number("radius") > 0;
  }

  public static float yaw() {
    return (float) yaw;
  }

  public static float pitch() {
    return (float) pitch;
  }

  public static Vec3d offset() {
    return offset;
  }

  public static double distance() {
    double base = original != null && !original.isFirstPerson() ? 4 : 0;
    return base + (XVisuals.config().module("freelook").number("distance") - base) * blend;
  }

  public static void tick(MinecraftClient c) {
    var s = XVisuals.config().module("freelook");
    if (!key.equals(s.text("key"))) {
      key = s.text("key");
      try {
        XVisuals.FREELOOK.setBoundKey(InputUtil.fromTranslationKey(key));
        KeyBinding.updateKeysByCode();
      } catch (IllegalArgumentException ignored) {
      }
    }
    if (c.world != world) {
      reset(c);
      world = c.world;
    }
    if (c.player == null || !s.enabled) {
      reset(c);
      return;
    }
    // Screens release gameplay bindings. Keep the orbit, including its movement
    // offset, until gameplay resumes instead of treating that as a key release.
    if (c.currentScreen != null || pl.xvisuals.gui.world.WorldStudio.active()) { screenOpen = true; return; }
    boolean down = XVisuals.FREELOOK.isPressed();
    if (screenOpen) {
      screenOpen = false;
      down = physicalDown(c);
      XVisuals.FREELOOK.setPressed(down);
      lastDown = down; // A key pressed in a menu is not a new toggle in gameplay.
    }
    if (s.text("mode").equals("Hold")) requested = down;
    else if (down && !lastDown) requested = !requested;
    lastDown = down;
    if (!requested && engaged) {
      reset(c);
      lastDown = down; // A held toggle key must not reactivate on the next tick.
      return;
    }
    if (requested && !engaged) {
      engaged = true;
      original = c.options.getPerspective();
      c.options.setPerspective(Perspective.THIRD_PERSON_BACK);
      yaw = targetYaw = c.gameRenderer.getCamera().getYaw();
      pitch = targetPitch = c.gameRenderer.getCamera().getPitch();
      blend = 0;
      previous = System.nanoTime();
    }
  }

  public static boolean mouse(double dx, double dy) {
    if (!engaged) return false;
    if (MinecraftClient.getInstance().currentScreen != null) return true;
    if (requested) {
      double s = XVisuals.config().module("freelook").number("sensitivity") * .15;
      targetYaw += dx * s;
      targetPitch = Math.max(-89.9, Math.min(89.9, targetPitch + dy * s));
    }
    return true;
  }

  public static void frame() {
    if (!engaged) return;
    var c = MinecraftClient.getInstance();
    if (c.player == null) {
      reset(c);
      return;
    }
    var s = XVisuals.config().module("freelook");
    long now = System.nanoTime();
    double dt = Math.min(.05, (now - previous) / 1e9);
    previous = now;
    if (c.currentScreen != null) return;
    double speed = s.number("smoothing");
    if (capturesMovement() && c.currentScreen == null) {
      double
          forward =
              (c.options.forwardKey.isPressed() ? 1 : 0) - (c.options.backKey.isPressed() ? 1 : 0),
          side = (c.options.rightKey.isPressed() ? 1 : 0) - (c.options.leftKey.isPressed() ? 1 : 0),
          up = (c.options.jumpKey.isPressed() ? 1 : 0) - (c.options.sneakKey.isPressed() ? 1 : 0);
      double angle = Math.toRadians(yaw);
      Vec3d move =
          new Vec3d(
              -Math.sin(angle) * forward - Math.cos(angle) * side,
              up,
              Math.cos(angle) * forward - Math.sin(angle) * side);
      if (move.lengthSquared() > 0)
        targetOffset = targetOffset.add(move.normalize().multiply(s.number("moveSpeed") * dt));
      if (targetOffset.length() > s.number("radius"))
        targetOffset = targetOffset.normalize().multiply(s.number("radius"));
    } else targetOffset = Vec3d.ZERO;
    yaw = Easing.damp(yaw, targetYaw, speed, dt);
    pitch = Easing.damp(pitch, targetPitch, speed, dt);
    blend = Easing.damp(blend, 1, speed, dt);
    offset = offset.lerp(targetOffset, 1 - Math.exp(-speed * dt));
  }

  private static boolean physicalDown(MinecraftClient c) {
    if (!c.isWindowFocused()) return false;
    try {
      var bound = InputUtil.fromTranslationKey(key);
      long window = c.getWindow().getHandle();
      if (bound.getCategory() == InputUtil.Type.MOUSE)
        return org.lwjgl.glfw.GLFW.glfwGetMouseButton(window, bound.getCode()) == org.lwjgl.glfw.GLFW.GLFW_PRESS;
      if (bound.getCategory() == InputUtil.Type.KEYSYM && bound.getCode() >= 32 && bound.getCode() <= org.lwjgl.glfw.GLFW.GLFW_KEY_LAST)
        return org.lwjgl.glfw.GLFW.glfwGetKey(window, bound.getCode()) == org.lwjgl.glfw.GLFW.GLFW_PRESS;
    } catch (IllegalArgumentException ignored) { }
    return false;
  }

  public static void reset(MinecraftClient c) {
    if (engaged && original != null) c.options.setPerspective(original);
    engaged = requested = lastDown = screenOpen = false;
    blend = 0;
    offset = targetOffset = Vec3d.ZERO;
    previous = 0;
    original = null;
  }

  private Freelook() {}
}
