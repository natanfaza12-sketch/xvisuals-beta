package pl.xvisuals.modules.motion;

/** Reusable, allocation-free clipping of a terrain rectangle into an animated texture cell. */
final class LandingClip {
  private double[] points = new double[24], scratch = new double[24];
  int count;
  double u(int i) { return points[i * 2]; }
  double v(int i) { return points[i * 2 + 1]; }

  void rectangle(double x0, double z0, double x1, double z1, double radius, double angle) {
    double co = Math.cos(angle), si = Math.sin(angle);
    point(0, x0, z0, radius, co, si); point(1, x1, z0, radius, co, si);
    point(2, x1, z1, radius, co, si); point(3, x0, z1, radius, co, si);
    count = 4;
    for (int axis = 0; axis < 2; axis++) { clip(axis, 0, true); clip(axis, 1, false); }
  }

  private void point(int i, double x, double z, double radius, double co, double si) {
    points[i * 2] = .5 + (x * co + z * si) / (2 * radius);
    points[i * 2 + 1] = .5 + (-x * si + z * co) / (2 * radius);
  }

  private void clip(int axis, double edge, boolean lower) {
    if (count == 0) return;
    int written = 0, previous = count - 1;
    for (int current = 0; current < count; current++) {
      double a = points[previous * 2 + axis], b = points[current * 2 + axis];
      boolean inA = lower ? a >= edge : a <= edge, inB = lower ? b >= edge : b <= edge;
      if (inA != inB) {
        double t = (edge - a) / (b - a);
        for (int k = 0; k < 2; k++) scratch[written * 2 + k] = points[previous * 2 + k] + t * (points[current * 2 + k] - points[previous * 2 + k]);
        scratch[written * 2 + axis] = edge;
        written++;
      }
      if (inB) { scratch[written * 2] = points[current * 2]; scratch[written * 2 + 1] = points[current * 2 + 1]; written++; }
      previous = current;
    }
    double[] swap = points; points = scratch; scratch = swap; count = written;
  }
}
