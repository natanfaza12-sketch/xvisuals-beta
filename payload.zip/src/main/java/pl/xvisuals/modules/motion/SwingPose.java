package pl.xvisuals.modules.motion;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
/** Shared cosmetic pose for held items and the GUI gallery. */
public final class SwingPose {
 public static boolean apply(MatrixStack matrices,String preset,int sign,double progress,double pulseValue,double arcValue,double strengthValue,double distanceValue,double followValue){
    if (preset.equals("Vanilla")) {
      float t = (float) progress,
          root = (float) Math.sqrt(t),
          a = (float) Math.sin(t * t * Math.PI),
          b = (float) Math.sin(root * Math.PI),
          strength = (float) strengthValue,
          distance = (float) distanceValue;
      matrices.translate(
          sign * -.4 * b * distance,
          .2 * Math.sin(root * Math.PI * 2) * distance,
          -.2 * Math.sin(t * Math.PI) * distance);
      matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(sign * (45 - a * 20) * strength));
      matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(sign * b * -20 * strength));
      matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(b * -80 * strength));
      matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(sign * -45 * strength));
      return true;
    }
    double pulse = pulseValue * strengthValue, phase = progress;
    double arc = arcValue * strengthValue;
    double follow=followValue;
    double distance = distanceValue,
        weight = preset.equals("Cinematic") ? 1.25 : 1;
    switch(preset){
      case "Thrust" -> {matrices.translate(sign*(.06*pulse+.05*arc*follow)*distance,.04*pulse*distance,(-.55*pulse+.18*arc*follow)*distance);matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float)(-22*pulse)));return true;}
      case "Crosscut" -> {matrices.translate(sign*-.42*pulse*distance,.12*arc*distance,-.12*pulse*distance);matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((float)(sign*-65*pulse)));matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float)(sign*-38*arc)));return true;}
      case "Heavy Chop" -> {matrices.translate(0,.19*arc*distance,-.22*pulse*distance);matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float)(-100*pulse+25*arc)));return true;}
      case "Recoil" -> {matrices.translate(sign*.04*arc*distance,.06*pulse*distance,(.22*pulse-.12*arc*follow)*distance);matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float)(-32*pulse+12*arc*follow)));return true;}
      case "Sweep" -> {matrices.translate(sign*(-.32*pulse+.16*arc)*distance,.08*arc*distance,-.15*pulse*distance);matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((float)(sign*(-48*pulse+18*arc*follow))));matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float)(sign*42*arc)));return true;}
      case "Flourish" -> {matrices.translate(sign*.2*arc*distance,.12*pulse*distance,-.12*pulse*distance);matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float)(sign*135*arc)));matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((float)(sign*35*pulse)));return true;}
    }
    matrices.translate(
        sign * (-.24 * pulse + .08 * arc) * distance,
        -.10 * pulse * distance,
        -.17 * pulse * distance);
    matrices.multiply(
        RotationAxis.POSITIVE_Y.rotationDegrees((float) (sign * (-24 * pulse + arc * 9) * weight)));
    matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float) (-66 * pulse * weight)));
    matrices.multiply(
        RotationAxis.POSITIVE_Z.rotationDegrees((float) (sign * (-21 * pulse + 13 * arc))));
    return true;
 }
 private SwingPose(){}
}
