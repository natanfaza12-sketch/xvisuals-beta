package pl.xvisuals.modules.motion;

/** Two spaced poses followed by a real quiet interval, even during continuous sprinting. */
public final class AfterimageBurst {
  private double nextBurst, until, last = Double.NEGATIVE_INFINITY;
  private int remaining;
  public boolean sample(double now, boolean moving, boolean separated, double spacing, double interval, boolean budget) {
    if (!moving) { remaining = 0; return false; }
    if (now >= nextBurst) {
      remaining = 2; until = now + .36; nextBurst = now + interval;
    }
    if (remaining == 0 || now > until || !separated || !budget || now - last < spacing) return false;
    remaining--; last = now; return true;
  }
}
