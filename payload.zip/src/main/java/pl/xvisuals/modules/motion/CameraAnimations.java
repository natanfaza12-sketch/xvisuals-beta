package pl.xvisuals.modules.motion;

import pl.xvisuals.XVisuals;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;

public final class CameraAnimations {
  private static final CameraMotionState SPRING=new CameraMotionState();
  private static Object world,player;
  private static boolean grounded,seeded;
  private static double lastVy;
  private static long previous;
  private static int direction=1;
  public static void init(){ClientTickEvents.END_CLIENT_TICK.register(c->tick());}
  private static boolean active(){return XVisuals.ready()&&XVisuals.config().on("cameraanimations");}
  public static void tick(){
    var c=MinecraftClient.getInstance();
    if(world!=c.world||player!=c.player||!active()){clear();world=c.world;player=c.player;}
    if(c.player==null||!active())return;
    boolean ground=c.player.isOnGround();double vy=c.player.getVelocity().y;
    if(!seeded){grounded=ground;lastVy=vy;seeded=true;return;}
    if(grounded&&!ground&&vy>.2){
      SPRING.jump(value("jumpDip",0),value("jumpTilt",0),value("jumpFov",0));direction=-direction;
    }
    if(!grounded&&ground){double impact=Math.min(1.5,Math.max(0,-lastVy-.1)*1.6);SPRING.land(impact,value("landBounce",0),value("jumpTilt",0));}
    grounded=ground;lastVy=vy;
  }
  public static void frame(){
    if(!active()){clear();return;}
    long now=System.nanoTime();double dt=previous==0?0:(now-previous)/1e9;previous=now;
    if(!MinecraftClient.getInstance().isPaused())SPRING.advance(dt,value("spring",1));
  }
  public static double value(String key,double fallback){return AnimationControls.number("cameraanimations",key,fallback);}
  public static boolean steady(){return XVisuals.ready()&&XVisuals.config().on("lens")&&XVisuals.config().module("lens").flag("steady");}
  public static void apply(MatrixStack matrices){
    var c=MinecraftClient.getInstance();
    if(!active()||steady()||!c.options.getPerspective().isFirstPerson())return;
    double dip=SPRING.position();
    matrices.translate(0,dip*.12,0);
    matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float)(SPRING.tilt()*6*direction)));
    matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float)(SPRING.tilt()*3)));
  }
  public static float fov(){return active()?(float)SPRING.fov():0;}
  private static void clear(){SPRING.clear();seeded=false;previous=0;lastVy=0;}
  private CameraAnimations(){}
}
