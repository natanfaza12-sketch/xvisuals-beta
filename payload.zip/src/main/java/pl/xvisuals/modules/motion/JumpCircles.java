package pl.xvisuals.modules.motion;

import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import pl.xvisuals.config.VisualConfig.ModuleState;
import pl.xvisuals.mixins.RenderLayerAccessor;
import pl.xvisuals.rendering.Quality;
import java.awt.Color;
import java.util.*;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/** Bounded, depth-tested landing decals and volumetric meshes. Terrain is sampled once on spawn. */
public final class JumpCircles {
  private static final Map<UUID, Track> TRACKS = new HashMap<>();
  private static final List<Circle> CIRCLES = new ArrayList<>();
  private static Object world;
  private static int spawnBudget;
  private static double time;
  private static long lastClock;
  private static final LandingClip CLIP = new LandingClip();
  private static final BufferAllocator ALLOCATOR=new BufferAllocator(524288);
  private static final VertexConsumerProvider.Immediate BUFFERS=VertexConsumerProvider.immediate(ALLOCATOR);
  private static final Map<String,RenderLayer> LAYERS=new HashMap<>();
  private static final RenderPipeline PIPE=pipeline(false),GLOW=pipeline(true);
  public static int renderedQuads;
  public static long lastDrawNanos;
  private static RenderPipeline pipeline(boolean glow){return RenderPipeline.builder()
    .withLocation(Identifier.of("xvisuals","pipeline/jump_art"+(glow?"_glow":"")))
    .withVertexShader(Identifier.of("xvisuals","core/player_sprite"))
    .withFragmentShader(Identifier.of("xvisuals","core/player_sprite"))
    .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER).withSampler("Sampler0")
    .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS)
    .withBlend(glow?new BlendFunction(com.mojang.blaze3d.platform.SourceFactor.SRC_ALPHA,com.mojang.blaze3d.platform.DestFactor.ONE):BlendFunction.TRANSLUCENT)
    .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withDepthWrite(false).withCull(false).build();}
  private static RenderLayer layer(String style,boolean glow){return LAYERS.computeIfAbsent(style+(glow?"_glow":""),k->RenderLayerAccessor.visuals$of("xvisuals_jump_art_"+k,RenderSetup.builder(glow?GLOW:PIPE).texture("Sampler0",LandingDesigns.texture(style)).translucent().expectedBufferSize(524288).build()));}

  public static void init() {
    WorldRenderEvents.END_MAIN.register(context -> render(context.matrices()));
    net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING.register(c -> ALLOCATOR.close());
  }

  private static double clock(MinecraftClient client) {
    long now = System.nanoTime();
    if (lastClock != 0 && !client.isPaused()) time += Math.min(.1, (now - lastClock) / 1e9);
    lastClock = now;
    return time;
  }

  public static void tick(MinecraftClient client) {
    double now = clock(client);
    if (world != client.world || !XVisuals.visualModule("jumpcircles").enabled) {
      TRACKS.clear();
      CIRCLES.clear();
      world = client.world;
    }
    if (client.world == null || client.player == null || !XVisuals.visualModule("jumpcircles").enabled) return;
    ModuleState s = XVisuals.visualModule("jumpcircles");
    CIRCLES.removeIf(c -> now - c.born >= c.duration ||
        (c.local ? !s.flag("local") : !s.flag("others")));
    spawnBudget = 3;
    Set<UUID> seen = new HashSet<>();
    var players = new ArrayList<>(client.world.getPlayers());
    players.sort(Comparator.comparingInt(p -> p == client.player ? 0 : 1));
    for (var player : players) {
      boolean local = player == client.player;
      if (!(local ? s.flag("local") : s.flag("others")) ||
          player.getEntityPos().squaredDistanceTo(client.player.getEntityPos()) > 2304) continue;
      seen.add(player.getUuid());
      Vec3d pos = player.getEntityPos();
      Track old = TRACKS.get(player.getUuid());
      boolean grounded = player.isOnGround();
      boolean excluded = player.isSpectator() || !player.isAlive() || player.hasVehicle() ||
          player.isTouchingWater() || player.isInLava() || player.isClimbing() ||
          player.getAbilities().flying || player.isGliding();
      int air = grounded ? 0 : old == null ? 1 : old.airTicks + 1;
      if (old != null && !old.excluded && pos.squaredDistanceTo(old.position) < 9) {
        if (old.jumped && JumpCircleMath.landed(old.grounded, grounded, old.airTicks, excluded))
          spawn(client, player, pos, now, local, s);
      }
      boolean jumped = old != null && !excluded && !old.excluded && !grounded
          && (old.grounded ? JumpCircleMath.tookOff(pos.y - old.position.y) : old.jumped);
      TRACKS.put(player.getUuid(), new Track(pos, grounded, air, excluded, jumped));
    }
    TRACKS.keySet().retainAll(seen);
  }

  private static void spawn(MinecraftClient client, AbstractClientPlayerEntity player, Vec3d pos,
      double now, boolean local, ModuleState s) {
    if (spawnBudget-- <= 0) return;
    int limit = Math.max(6, (int) (12 * Math.min(1, Quality.factor())));
    while (CIRCLES.size() >= limit) CIRCLES.removeFirst();
    double extent = s.number("size") * 1.5 + .15;
    List<Surface> surfaces = new ArrayList<>();
    // Align geometry with actual collision-shape edges. Interpolating heights across
    // a stair/snow boundary buried the high half and discarded neighbouring quads.
    for (int z=(int)Math.floor(pos.z-extent); z<=Math.floor(pos.z+extent); z++)
      for (int x=(int)Math.floor(pos.x-extent); x<=Math.floor(pos.x+extent); x++) {
        var xs=new TreeSet<Double>(); var zs=new TreeSet<Double>();
        xs.add(0d); xs.add(1d); zs.add(0d); zs.add(1d);
        for (int y=(int)Math.floor(pos.y-1.5); y<=Math.floor(pos.y+.75); y++) {
          var bp=new net.minecraft.util.math.BlockPos(x,y,z);
          var state=client.world.getBlockState(bp);
          var shape=state.getCollisionShape(client.world,bp,net.minecraft.block.ShapeContext.of(player));
          for (var box:shape.getBoundingBoxes()) {
            xs.add(Math.clamp(box.minX,0,1)); xs.add(Math.clamp(box.maxX,0,1));
            zs.add(Math.clamp(box.minZ,0,1)); zs.add(Math.clamp(box.maxZ,0,1));
          }
        }
        var xx=xs.toArray(Double[]::new); var zz=zs.toArray(Double[]::new);
        for(int iz=0;iz<zz.length-1;iz++)for(int ix=0;ix<xx.length-1;ix++) {
          double wx=x+(xx[ix]+xx[ix+1])*.5,wz=z+(zz[iz]+zz[iz+1])*.5;
          var hit=client.world.raycast(new RaycastContext(new Vec3d(wx,pos.y+.75,wz),new Vec3d(wx,pos.y-1.5,wz),RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,player));
          if(hit.getType()!=HitResult.Type.BLOCK)continue;
          surfaces.add(new Surface(x+xx[ix]-pos.x,z+zz[iz]-pos.z,x+xx[ix+1]-pos.x,z+zz[iz+1]-pos.z,visibleSurface(client,hit.getPos())-pos.y));
        }
      }
    CIRCLES.add(new Circle(pos, now, s.number("duration") / s.number("speed"), extent, surfaces, local));
  }

  private static double visibleSurface(MinecraftClient client, Vec3d collision) {
    // Snow layers render one eighth of a block above their collision surface.
    // A single layer has no collision at all, so inspect just above the hit.
    var at=net.minecraft.util.math.BlockPos.ofFloored(collision.add(0,.001,0));
    var state=client.world.getBlockState(at);
    return state.isOf(net.minecraft.block.Blocks.SNOW)
        ? at.getY()+state.get(net.minecraft.block.SnowBlock.LAYERS)/8.0 : collision.y;
  }

  private static void render(MatrixStack matrices) {
    renderedQuads=0;lastDrawNanos=0;
    var client=MinecraftClient.getInstance();double now=clock(client);
    if(client.world==null||CIRCLES.isEmpty()||!XVisuals.visualModule("jumpcircles").enabled)return;
    long started=System.nanoTime();var s=XVisuals.visualModule("jumpcircles");
    Vec3d camera=client.gameRenderer.getCamera().getCameraPos();
    CIRCLES.sort(Comparator.comparingDouble((Circle c)->-c.position.squaredDistanceTo(camera)));
    String style=s.text("style");
    for(Circle c:CIRCLES){
      if(c.position.squaredDistanceTo(camera)>2304)continue;
      double t=JumpCircleMath.progress(now-c.born,c.duration,1),alpha=s.number("opacity")*LandingDesigns.opacity(t);
      if(alpha<.004)continue;
      matrices.push();matrices.translate(c.position.subtract(camera));
      double radius=Math.min(s.number("size"),(c.extent-.15)/1.5)*LandingDesigns.radius(t);
      int layers=Math.clamp(s.integer("layers"),1,3);
      // Upper translucent layers are drawn first; the ground artwork stays crisp.
      for(int l=layers-1;l>=0;l--){
        drawArt(BUFFERS.getBuffer(layer(style,false)),matrices,c,s,style,t,now,radius,l,alpha,false);
      }
      if(s.number("glow")>.01)drawArt(BUFFERS.getBuffer(layer(style,true)),matrices,c,s,style,t,now,radius,0,alpha*s.number("glow")*.65,true);
      matrices.pop();
    }
    BUFFERS.draw();lastDrawNanos=System.nanoTime()-started;
  }
  private static void drawArt(VertexConsumer out,MatrixStack matrices,Circle c,ModuleState settings,String style,double t,double now,double radius,int layer,double alpha,boolean glow){
    int frame=LandingDesigns.frame(t);
    double r=radius*LandingDesigns.layerScale(layer),angle=LandingDesigns.rotation(style,layer,t),co=Math.cos(angle),si=Math.sin(angle);
    double lift=.032+LandingDesigns.lift(layer,t,settings.number("depth"))+(glow?.002:0);
    alpha*=LandingDesigns.layerOpacity(layer);
    var matrix=matrices.peek().getPositionMatrix();
    for(Surface surface:c.surfaces){
      CLIP.rectangle(surface.x0,surface.z0,surface.x1,surface.z1,r,angle);
      for(int triangle=1;triangle<CLIP.count-1;triangle++) {
        for(int corner=0;corner<4;corner++) {
          int index=corner==0?0:corner==1?triangle:triangle+1;
          double u=CLIP.u(index),v=CLIP.v(index),px=(u*2-1)*r,pz=(v*2-1)*r;
          out.vertex(matrix,(float)(px*co-pz*si),(float)(surface.height+lift),(float)(px*si+pz*co))
              .texture((float)((frame%6+u)/6),(float)((frame/6+v)/4)).color(tint(settings,u,now,alpha));
        }
        renderedQuads++;
      }
    }
  }
  public static int tint(ModuleState s,double fraction,double now,double alpha){
    int rgb=s.flag("designColors")?0xFFFFFFFF:s.flag("gradient")?pl.xvisuals.util.Colors.mix(s.color("color"),s.color("secondary"),fraction):s.color("color");
    if(s.flag("rainbow"))rgb=Color.HSBtoRGB((float)((fraction*.35+now*.12)%1),.65f,1);
    return ((int)(Math.clamp(alpha,0,1)*255)<<24)|(rgb&0xFFFFFF);
  }

  public static int count() { return CIRCLES.size(); }
  private record Track(Vec3d position, boolean grounded, int airTicks, boolean excluded, boolean jumped) {}
  private record Surface(double x0,double z0,double x1,double z1,double height) {}
  private record Circle(Vec3d position, double born, double duration, double extent, List<Surface> surfaces, boolean local) {}
  private JumpCircles() {}
}

