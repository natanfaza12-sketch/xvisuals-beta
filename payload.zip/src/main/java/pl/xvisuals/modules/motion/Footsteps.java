package pl.xvisuals.modules.motion;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import pl.xvisuals.config.VisualConfig.ModuleState;
import pl.xvisuals.mixins.RenderLayerAccessor;
import pl.xvisuals.rendering.Quality;
import pl.xvisuals.util.Colors;
import java.util.*;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.RaycastContext;
import net.minecraft.block.BlockState;
/** Animated authored decals. Ground is sampled only when a footprint is created. */
public final class Footsteps {
 private record Print(Vec3d[] corners,Vec3d center,BlockPos[] supports,BlockState[] states,String style,double born,double duration,boolean left,boolean local){}
 private static final Map<UUID,FootstepTracker> TRACKS=new HashMap<>();
 private static final List<Print> PRINTS=new ArrayList<>(128);
 private static final BufferAllocator ALLOCATOR=new BufferAllocator(65536);
 private static final VertexConsumerProvider.Immediate BUFFERS=VertexConsumerProvider.immediate(ALLOCATOR);
 private static final Map<String,RenderLayer> LAYERS=new HashMap<>();
 private static final RenderPipeline PIPE=RenderPipeline.builder().withLocation(Identifier.of("xvisuals","pipeline/footstep_art"))
  .withVertexShader(Identifier.of("xvisuals","core/player_sprite")).withFragmentShader(Identifier.of("xvisuals","core/player_sprite"))
  .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER).withSampler("Sampler0")
  .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS).withBlend(BlendFunction.TRANSLUCENT)
  .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withDepthWrite(false).withCull(false).build();
 private static Object world;private static double time;private static long lastClock;private static int budget;
 public static int renderedQuads;public static long lastDrawNanos;
 public static int count(){return PRINTS.size();}
 public static void init(){WorldRenderEvents.END_MAIN.register(c->render(c.matrices()));net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING.register(c->ALLOCATOR.close());}
 private static double clock(MinecraftClient c){long now=System.nanoTime();if(lastClock!=0&&!c.isPaused())time+=Math.min(.1,(now-lastClock)/1e9);lastClock=now;return time;}
 public static int tint(ModuleState s,double alpha){return Colors.alpha(s.flag("designColors")?0xffffffff:s.color("color"),alpha*s.number("opacity"));}
 public static void tick(MinecraftClient c){
  double now=clock(c);var s=XVisuals.visualModule("footsteps");
  if(world!=c.world||!s.enabled){TRACKS.clear();PRINTS.clear();world=c.world;}
  if(c.world==null||c.player==null||!s.enabled)return;
  PRINTS.removeIf(p->now-p.born>=p.duration||(p.local?!s.flag("local"):!s.flag("others"))||!supported(c,p));
  int limit=Math.max(8,(int)(s.integer("limit")*Math.min(1,Quality.factor())));while(PRINTS.size()>limit)PRINTS.removeFirst();
  budget=8;Set<UUID> seen=new HashSet<>();
  track(c,c.player,now,s,seen);
  if(s.flag("others"))for(var player:c.world.getPlayers())if(player!=c.player)track(c,player,now,s,seen);
  TRACKS.keySet().retainAll(seen);
 }
 private static void track(MinecraftClient c,AbstractClientPlayerEntity p,double now,ModuleState s,Set<UUID> seen){
  boolean local=p==c.player;if(!(local?s.flag("local"):s.flag("others"))||p.squaredDistanceTo(c.player)>1024)return;
  seen.add(p.getUuid());var tracker=TRACKS.computeIfAbsent(p.getUuid(),id->new FootstepTracker());Vec3d pos=p.getEntityPos();
  boolean excluded=p.isSpectator()||!p.isAlive()||p.hasVehicle()||p.isTouchingWater()||p.isInLava()||p.isClimbing()||p.isGliding()||p.getAbilities().flying;
  // Remote interpolation does not reliably preserve the server's onGround bit.
  // Confirm support geometrically as well, without counting airborne flight.
  boolean grounded=p.isOnGround();
  if(!grounded&&!excluded&&Math.abs(p.getVelocity().y)<.08){double floor=surface(c,p,pos.x,pos.y,pos.z);grounded=Double.isFinite(floor)&&Math.abs(floor-pos.y)<=.14;}
  if(tracker.update(pos.x,pos.y,pos.z,grounded,excluded,s.number("spacing"),p.bodyYaw))spawn(c,p,pos,tracker.dx,tracker.dz,tracker.left(),local,now,s);
 }
 private static boolean supported(MinecraftClient c,Print p){for(int i=0;i<p.supports.length;i++)if(!c.world.getBlockState(p.supports[i]).equals(p.states[i]))return false;return true;}
 private static double surface(MinecraftClient c,AbstractClientPlayerEntity p,double x,double y,double z){
  var hit=c.world.raycast(new RaycastContext(new Vec3d(x,y+.6,z),new Vec3d(x,y-.65,z),RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,p));
  if(hit.getType()!=HitResult.Type.BLOCK)return Double.NaN;
  Vec3d point=hit.getPos();var at=BlockPos.ofFloored(point.add(0,.001,0));var state=c.world.getBlockState(at);
  if(!c.world.getFluidState(at).isEmpty())return Double.NaN;
  return state.isOf(net.minecraft.block.Blocks.SNOW)?at.getY()+state.get(net.minecraft.block.SnowBlock.LAYERS)/8.:point.y;
 }
 private static void spawn(MinecraftClient c,AbstractClientPlayerEntity p,Vec3d pos,double dx,double dz,boolean left,boolean local,double now,ModuleState s){
  if(budget--<=0)return;
  double lateral=left?-.14:.14,rx=-dz,rz=dx,cx=pos.x+rx*lateral,cz=pos.z+rz*lateral,half=s.number("size")*.5*(FootstepDesigns.isImported(s.text("style"))?FootstepDesigns.imported(s.text("style")).size():1);
  double centerY=surface(c,p,cx,pos.y,cz);if(!Double.isFinite(centerY)||Math.abs(centerY-pos.y)>.3)return;
  Vec3d[] corners=new Vec3d[4];
  boolean fits=false;
  // A single corner over a stair edge used to discard the entire step. Fit the
  // mark to its supported tread instead of silently dropping it.
  for(int attempt=0;attempt<4&&!fits;attempt++,half*=.65){
   fits=true;
   for(int k=0;k<4;k++){
    double side=k<2?-1:1,forward=k==1||k==2?1:-1;
    double x=cx+rx*half*side+dx*half*forward,z=cz+rz*half*side+dz*half*forward;
    double y=surface(c,p,x,pos.y,z);if(!Double.isFinite(y)||Math.abs(y-centerY)>.06){fits=false;break;}
    corners[k]=new Vec3d(x,y+.018,z);
   }
  }
  if(!fits)return;
  BlockPos[] supports=new BlockPos[5];BlockState[] states=new BlockState[5];
  supports[0]=BlockPos.ofFloored(cx,centerY-.01,cz);
  for(int k=0;k<4;k++)supports[k+1]=BlockPos.ofFloored(corners[k].add(0,-.028,0));
  for(int k=0;k<5;k++)states[k]=c.world.getBlockState(supports[k]);
  int limit=Math.max(8,(int)(s.integer("limit")*Math.min(1,Quality.factor())));while(PRINTS.size()>=limit)PRINTS.removeFirst();
  PRINTS.add(new Print(corners,new Vec3d(cx,centerY,cz),supports,states,s.text("style"),now,s.number("duration"),left,local));
 }
 private static void render(MatrixStack matrices){
  renderedQuads=0;lastDrawNanos=0;var c=MinecraftClient.getInstance();double now=clock(c);var s=XVisuals.visualModule("footsteps");
  if(c.world==null||!s.enabled||PRINTS.isEmpty())return;
  long started=System.nanoTime();var eye=c.gameRenderer.getCamera().getCameraPos();var matrix=matrices.peek().getPositionMatrix();
  PRINTS.sort(Comparator.comparingDouble((Print p)->-p.center.squaredDistanceTo(eye)));
  for(var p:PRINTS){double age=now-p.born,alpha=FootstepDesigns.opacity(age/p.duration);if(alpha<.005||p.center.squaredDistanceTo(eye)>1600)continue;
   boolean imported=FootstepDesigns.isImported(p.style);var layer=LAYERS.computeIfAbsent(p.style+(imported?(p.left?"_left":"_right"):""),key->RenderLayerAccessor.visuals$of("xvisuals_footsteps_"+FootstepDesigns.index(p.style),RenderSetup.builder(PIPE).texture("Sampler0",FootstepDesigns.texture(p.style,p.left)).translucent().expectedBufferSize(65536).build()));
   var out=BUFFERS.getBuffer(layer);int frame=FootstepDesigns.frame(age,s.number("speed")),color=tint(s,alpha);
   for(int k=0;k<4;k++){double u=k<2?0:1;if(p.left&&!imported)u=1-u;double v=k==1||k==2?0:1;var point=p.corners[k].subtract(eye);
    out.vertex(matrix,(float)point.x,(float)point.y,(float)point.z).texture((float)(imported?u:(frame%6+u)/6),(float)(imported?v:(frame/6+v)/4)).color(color);
   }renderedQuads++;
  }BUFFERS.draw();lastDrawNanos=System.nanoTime()-started;
 }
 private Footsteps(){}
}
