package pl.xvisuals.modules.motion;
import java.util.List;
import net.minecraft.util.Identifier;
/** Original authored sprite sheets and shared animation timing for landing effects. */
public final class LandingDesigns {
 public static final List<String> ALL=List.of("Reactor","Supernova","Crimson Vortex","Neon Circuit","Arcane Bloom","Scarlet Singularity","Frost Shatter","Solar Eclipse","Thunder Crown","Sakura Spiral","Emerald Orbit","Void Fracture","Astral Shuriken","Seraph Wings","Hex Grid","Crimson Sigil","Sakura Crest","Void Maze");
 public static final int CELL=192,WIDTH=CELL*6,HEIGHT=CELL*4;
 private static final Identifier[] TEXTURES=ALL.stream().map(s->Identifier.of("xvisuals","textures/jump_circles/"+asset(s)+".png")).toArray(Identifier[]::new);
 public static String asset(String s){return s.toLowerCase(java.util.Locale.ROOT).replace(' ','_');}
 public static String migrate(String s){String plain=s.replace(" [2D]", "").replace(" [3D]", "");return ALL.contains(plain)?plain:"Reactor";}
 public static int index(String s){return Math.max(0,ALL.indexOf(migrate(s)));}
 public static Identifier texture(String s){return TEXTURES[index(s)];}
 public static int frame(double t){return (int)(Math.pow(Math.clamp(Double.isFinite(t)?t:0,0,1),.75)*23.999);}
 public static double rotation(String style,int layer,double t){return (layer%2==0?1:-1)*t*(.5+index(style)%5*.24)+layer*.35;}
 public static double radius(double t){return .22+.78*(1-Math.pow(1-Math.clamp(t,0,1),4));}
 public static double opacity(double t){return t<=0||t>=1?0:Math.min(1,t*25)*Math.min(1,(1-t)*3.8);}
 public static double layerScale(int layer){return Math.pow(.88,layer);}
 public static double layerOpacity(int layer){return layer==0?1:layer==1?.38:.22;}
 public static double lift(int layer,double t,double depth){return layer*depth*Math.sin(Math.PI*Math.clamp(t,0,1));}
 private LandingDesigns(){}
}
