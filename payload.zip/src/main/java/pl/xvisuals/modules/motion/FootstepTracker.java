package pl.xvisuals.modules.motion;
/** Distance-based cadence: idle, airborne motion and teleports never create footsteps. */
public final class FootstepTracker {
 private double x,y,z,distance;private boolean initialized,grounded,left;
 public double dx,dz;
 public boolean left(){return left;}
 /** Distance drives cadence; body facing drives toes and the left/right offset.
  * Using velocity for orientation makes backward steps flip and strafing steps face sideways. */
 public boolean update(double nx,double ny,double nz,boolean onGround,boolean excluded,double spacing,double bodyYaw){
  boolean emit=update(nx,ny,nz,onGround,excluded,spacing);
  if(emit&&Double.isFinite(bodyYaw)){
   double angle=Math.toRadians(bodyYaw%360);
   dx=-Math.sin(angle);dz=Math.cos(angle);
  }
  return emit;
 }
 public boolean update(double nx,double ny,double nz,boolean onGround,boolean excluded,double spacing){
  double mx=nx-x,mz=nz-z,dy=ny-y;double moved=Math.hypot(mx,mz);
  boolean valid=initialized&&grounded&&onGround&&!excluded&&Double.isFinite(moved)&&moved<2&&Math.abs(dy)<.76;
  x=nx;y=ny;z=nz;initialized=true;grounded=onGround&&!excluded;
  if(!valid){distance=0;return false;}
  if(moved<.002)return false;
  dx=mx/moved;dz=mz/moved;distance+=moved;
  if(distance<Math.max(.2,spacing))return false;
  distance%=Math.max(.2,spacing);left=!left;return true;
 }
}
