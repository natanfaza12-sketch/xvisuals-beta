package pl.xvisuals.modules.motion;

/** Keeps a mining swing on vanilla's clock through its final recovery frame. */
public final class SwingGate {
 private boolean mining;
 public boolean update(boolean breaking,boolean attackHeld,boolean blockTarget,boolean swinging) {
  boolean requested=breaking || attackHeld && blockTarget;
  mining=requested || mining && swinging;
  return mining;
 }
 public void reset(){mining=false;}
 public static boolean accepted(boolean wasSwinging,int beforeTicks,boolean swinging,int afterTicks) {
  return swinging && afterTicks==-1 && (!wasSwinging || beforeTicks>=0);
 }
}
