package pl.xvisuals.modules.motion;

public final class Easing {
  public static double apply(String curve, double t) {
    t = Math.max(0, Math.min(1, t));
    return switch (curve) {
      case "Linear" -> t;
      case "Sine" -> .5 - .5 * Math.cos(Math.PI * t);
      case "Cubic" -> t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
      case "Quintic" -> t * t * t * (t * (t * 6 - 15) + 10);
      case "Ease Out" -> 1 - Math.pow(1 - t, 3);
      default -> t * t * (3 - 2 * t);
    };
  }

  public static double bezier(double t, double a, double b) {
    double u = 1 - t;
    return 3 * u * u * t * a + 3 * u * t * t * b + t * t * t;
  }

  public static double damp(double value, double target, double speed, double dt) {
    return value + (target - value) * (1 - Math.exp(-speed * Math.max(0, Math.min(.1, dt))));
  }

  private Easing() {}
}
