package pl.xvisuals.modules.motion;

import pl.xvisuals.XVisuals;
import pl.xvisuals.config.VisualConfig.ModuleState;
import pl.xvisuals.rendering.SpiritMaterial;
import java.util.*;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.*;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.*;
import net.minecraft.client.render.entity.model.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerSkinType;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.*;

/** Detached render-only player snapshots. Never creates entities or sends packets. */
public final class GhostEffects {
  private static final List<Ghost> GHOSTS = new ArrayList<>();
  private static final Set<UUID> DEAD = new HashSet<>();
  private static final Map<UUID, Long> DEATH_TIMES = new HashMap<>();
  private static Object world;
  private static final pl.xvisuals.util.EffectClock CLOCK=new pl.xvisuals.util.EffectClock();
  private static double animationTime() {
    var c=MinecraftClient.getInstance();
    return CLOCK.sample(System.nanoTime(),c.world==null || c.isPaused());
  }
  private static final BufferAllocator ALLOCATOR = new BufferAllocator(262144);
  private static final VertexConsumerProvider.Immediate BUFFERS =
      VertexConsumerProvider.immediate(ALLOCATOR);
  private static final ModelPart SHARD = createShard();

  private static ModelPart createShard() {
    var data = new ModelData();
    data.getRoot()
        .addChild(
            "shard",
            ModelPartBuilder.create().uv(20, 20).cuboid(-.6f, -.6f, -.6f, 1.2f, 1.2f, 1.2f),
            ModelTransform.NONE);
    return TexturedModelData.of(data, 64, 64).createModel();
  }

  public static void init() {
    WorldRenderEvents.END_MAIN.register(context -> render(context.matrices()));
    net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING
        .register(c -> ALLOCATOR.close());
  }

  public static void tick(MinecraftClient c) {
    double now=animationTime();
    if (world != c.world) {
      GHOSTS.clear();
      DEAD.clear();
      DEATH_TIMES.clear();
      world = c.world;
      SwingMotion.clear();
      SwingAfterimages.clear();
    }
    if (c.world == null) return;
    boolean deathEnabled=XVisuals.visualModule("deathghost").enabled || XVisuals.visualModule("killanimations").enabled;
    if (!deathEnabled) { DEAD.clear(); DEATH_TIMES.clear(); }
    if (!deathEnabled && !XVisuals.visualModule("totemghost").enabled) {
      GHOSTS.clear(); return;
    }
    if (deathEnabled) for (var p : c.world.getPlayers())
      if (p.deathTime > 0) {
        if (DEAD.add(p.getUuid())) death(p);
      } else DEAD.remove(p.getUuid());
    DEATH_TIMES.values().removeIf(time -> System.nanoTime() - time > 30_000_000_000L);
    DEAD.removeIf(id -> c.world.getPlayerByUuid(id) == null);
    GHOSTS.removeIf(
        g -> now - g.born > g.settings.number("duration") / g.settings.number("animation") || !XVisuals.visualModule(g.id).enabled);
  }

  public static void status(AbstractClientPlayerEntity player, byte status) {
    if (status == 35) {
      var settings = XVisuals.visualModule("totemghost");
      if (player != MinecraftClient.getInstance().player || settings.flag("local"))
        spawn(player, false, player.getEntityPos());
    }
    else if (status == 3 && (XVisuals.visualModule("deathghost").enabled || XVisuals.visualModule("killanimations").enabled) && DEAD.add(player.getUuid())) death(player);
  }

  private static void death(AbstractClientPlayerEntity player) {
    long now = System.nanoTime();
    Long previous = DEATH_TIMES.put(player.getUuid(), now);
    if (previous == null || now - previous > 1_000_000_000L) {
      GHOSTS.removeIf(g -> g.seed == player.getUuid().hashCode());
      spawn(player, XVisuals.visualModule("killanimations").enabled
          ? "killanimations" : "deathghost", player.getEntityPos());
    }
  }

  public static void preview(boolean death) {
    var c = MinecraftClient.getInstance();
    if (c.player != null) {
      GHOSTS.clear();
      spawn(c.player, death, previewPosition(c));
    }
  }

  public static int count() {
    return GHOSTS.size();
  }

  public static long count(String module) {
    return GHOSTS.stream().filter(g -> g.id.equals(module)).count();
  }

  private static void spawn(AbstractClientPlayerEntity player, boolean death, Vec3d position) {
    spawn(player, death ? "deathghost" : "totemghost", position);
  }

  public static void previewKill() {
    var c=MinecraftClient.getInstance();
    if(c.player!=null) {
      GHOSTS.clear();
      spawn(c.player,"killanimations",previewPosition(c));
    }
  }

  private static Vec3d previewPosition(MinecraftClient c) {
    Vec3d look=c.player.getRotationVec(1);
    return c.player.getEntityPos().add(new Vec3d(look.x,0,look.z).normalize().multiply(3));
  }

  private static void spawn(AbstractClientPlayerEntity player, String id, Vec3d position) {
    var s = XVisuals.visualModule(id);
    if (!s.enabled) return;
    var c = MinecraftClient.getInstance();
    if (c.player == null || c.player.getEntityPos().squaredDistanceTo(position) > 4096) return;
    while (GHOSTS.stream().filter(g -> g.id.equals(id)).count() >= s.integer("limit")) {
      for (int i = 0; i < GHOSTS.size(); i++)
        if (GHOSTS.get(i).id.equals(id)) {
          GHOSTS.remove(i);
          break;
        }
    }
    while (GHOSTS.size() >= 12) GHOSTS.removeFirst();
    boolean slim = player.getSkin().model() == PlayerSkinType.SLIM;
    var model =
        new PlayerEntityModel(
            TexturedModelData.of(
                    PlayerEntityModel.getTexturedModelData(Dilation.NONE, slim), 64, 64)
                .createModel(),
            slim);
    var renderer = c.getEntityRenderDispatcher().getPlayerRenderer(player);
    var state = renderer.createRenderState();
    renderer.updateRenderState(player, state, 1);
    state.deathTime = 0;
    model.setAngles(state);
    GHOSTS.add(
        new Ghost(
            id,
            s,
            model,
            player.getSkin().body().texturePath(),
            position,
            state.bodyYaw,
            player.getUuid().hashCode()));
  }

  private static void render(MatrixStack matrices) {
    if (GHOSTS.isEmpty()) return;
    var c = MinecraftClient.getInstance();
    var camera = c.gameRenderer.getCamera().getCameraPos();
    double now = animationTime();
    GHOSTS.sort(Comparator.comparingDouble((Ghost g) -> -g.position.squaredDistanceTo(camera)));
    for (Ghost g : GHOSTS) {
      if (!XVisuals.visualModule(g.id).enabled) continue;
      if (g.position.squaredDistanceTo(camera) > 4096) continue;
      ModuleState s = g.settings;
      double age = now - g.born,
          t = Math.clamp(age * s.number("animation") / s.number("duration"), 0, 1),
          a = age * s.number("animation");
      double fade = Math.pow(1 - smooth((t-.55)/.45), s.number("fade")) * smooth(t/.06);
      if (fade < .005) continue;
      String style = s.text("style");
      boolean afterglow=style.equals("Afterglow");
      boolean kill = g.id.equals("killanimations"), burial = kill && !style.equals("Prismatic Burst") && !afterglow;
      boolean clean = style.equals("Clean Ascension");
      boolean soul = style.equals("Soul") || clean,
          ash = style.equals("Ash"),
          collapse = style.equals("Collapse"),
          glitch = style.equals("Glitch"),
          shatter = style.equals("Freeze / Shatter");
      double dissolve =
          Math.clamp(
              Math.pow(Math.max(0, t - .08) / .92, 1.65)
                  * s.number("dissolveSpeed")
                  * s.number("dissolve"),
              0,
              1);
      int rgb = afterglow && (s.color("color") & 0xffffff)==0xffffff ? 0xD994FF : clean ? 0xF1F8FF : s.color("color") & 0xffffff;
      int color = ((int) (255 * s.number("opacity") * fade) << 24) | rgb;
      var out =
          SpiritMaterial.wrap(
              BUFFERS.getBuffer(SpiritMaterial.layer(g.texture)),
              dissolve,
              s.number("glow") * pl.xvisuals.rendering.Quality.glow(),
              s.number("skin"));
      matrices.push();
      matrices.translate(g.position.subtract(camera));
      if(kill && !afterglow) KillAnimationGeometry.draw(matrices,style,t,s.number("scale"),s.number("opacity"),rgb,g.seed);

      double vertical =
          soul
              ? a * s.number("rise")
              : ash ? -t * t * s.number("fall") : .07 * Math.sin(a * 2) * Math.sin(t * Math.PI);
      if(afterglow) vertical=.08*smooth(t/.5);
      matrices.translate(0, burial ? -2.15 * s.number("scale") * smooth((t-.24)/.62) : vertical, 0);
      matrices.multiply(
          RotationAxis.POSITIVE_Y.rotationDegrees(
              (float) (180 - g.yaw + (burial || afterglow ? 0 : a * s.number("rotation")))));
      float scale = (float) s.number("scale");
      matrices.scale(-scale, -scale, scale);
      matrices.translate(0, -1.501, 0);
      for (int i = 0; i < g.bones.length; i++) {
        ModelPart part = g.bones[i];
        part.setTransform(g.pose[i]);
        double limb = Math.clamp((t - .25 - i * .055) * 1.7, 0, 1) * s.number("dissolveSpeed");

        if (soul) {
          part.roll += (float) (Math.sin(a * 1.3 + i) * .055 * t);
          if (i == 2 || i == 3) part.roll += (i == 2 ? -1 : 1) * t * .22f;
        } else if (collapse) {
          part.originY += limb * 12 * s.number("fall");
          part.roll += (float) ((i % 2 == 0 ? 1 : -1) * limb * 1.8);
          part.pitch += limb * .8f;
        } else if (glitch) {
          double jitter = Math.sin(Math.floor(a * 12) + i * 19);
          part.originX += jitter * limb * 3;
          part.yaw += jitter * limb * .4f;
        } else if (shatter) {
          part.originX += (i % 2 == 0 ? -1 : 1) * limb * 6;
          part.originY += limb * limb * 12 * s.number("gravity");
          part.roll += (i % 2 == 0 ? -1 : 1) * limb;
        } else if (!kill) {
          part.pitch += (float) (Math.sin(a * 2 + i) * .10 * t);
          part.originY += ash ? limb * 6 : 0;
        }
        double partDissolve=afterglow ? smooth((t-(i==0?.06:i<4?.18:.30))/.55) : clean ? smooth((t-(i>=4?.12:i>=2?.22:.34))/.56)
            : kill ? smooth((t-(burial?.72:.10))/(burial?.22:.40)) : dissolve;
        var surface=(clean||kill) ? SpiritMaterial.wrap(BUFFERS.getBuffer((afterglow?SpiritMaterial.afterglowLayer(g.texture):SpiritMaterial.layer(g.texture))),
            partDissolve,s.number("glow")*pl.xvisuals.rendering.Quality.glow(),clean?0:1) : out;
        part.render(matrices, surface, 0xf000f0, 0, color);
      }
      int count =
          (int)
              (s.integer("fragments")
                  * s.number("density")
                  * Math.min(1, pl.xvisuals.rendering.Quality.factor()));
      // Bespoke kill effects supply their own particles; avoid a second debris cloud.
      if(kill) count=0;
      for (int i = 0; i < Math.min(count,g.fragments.length); i++) {
        Fragment f = g.fragments[i];
        double start = .12 + f.seed * .5, ft = (t - start) / (1 - start);
        if (ft <= 0) continue;
        double elapsed = (t - start) * s.number("duration");
        double spread = kill && !burial ? 2.6 : clean ? .3 : shatter ? 1.8 : ash ? .25 : .65;
        matrices.push();
        matrices.translate(
            f.x + f.vx * elapsed * spread,
            f.y
                + (soul
                    ? -elapsed * s.number("rise")
                    : elapsed * elapsed * .16 * s.number("gravity"))
                + elapsed * s.number("fall") * (ash ? .6 : .12),
            f.z + f.vz * elapsed * spread);
        matrices.multiply(RotationAxis.POSITIVE_X.rotation((float) (elapsed * (i % 5 + 1))));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotation((float) (elapsed * (i % 3 - 1))));
        float fs = (float) ((shatter ? 1.5 : .65) * (1 - ft));
        matrices.scale(fs, fs, fs);
        int fc = ((int) (255 * s.number("opacity") * (1 - ft) * fade) << 24) | rgb;
        SHARD.render(
            matrices,
            SpiritMaterial.wrap(
                BUFFERS.getBuffer(SpiritMaterial.layer(g.texture)),
                0,
                s.number("glow") * pl.xvisuals.rendering.Quality.glow(),
                clean ? 0 : s.number("skin")),
            0xf000f0,
            0,
            fc);
        matrices.pop();
      }
      matrices.pop();
      if(afterglow){BUFFERS.draw();matrices.push();matrices.translate(g.position.subtract(camera));AfterglowGeometry.draw(matrices,t,s.number("scale"),s.number("opacity"),rgb,g.seed,s.number("glow"),s.integer("fragments"),s.number("density"));matrices.pop();}
    }
    BUFFERS.draw();
  }

  private static double smooth(double t) { t=Math.clamp(t,0,1); return t*t*(3-2*t); }

  private static final class Ghost {
    final String id;
    final int seed;
    final ModuleState settings;
    final Identifier texture;
    final Vec3d position;
    final float yaw;
    final double born = animationTime();
    final ModelPart[] bones;
    final ModelTransform[] pose = new ModelTransform[6];
    final Fragment[] fragments = new Fragment[64];

    Ghost(
        String id,
        ModuleState s,
        PlayerEntityModel m,
        Identifier texture,
        Vec3d pos,
        float yaw,
        int seed) {
      this.id = id;
      this.seed = seed;
      settings = s;
      this.texture = texture;
      position = pos;
      this.yaw = yaw;
      bones = new ModelPart[] {m.head, m.body, m.rightArm, m.leftArm, m.rightLeg, m.leftLeg};
      for (int i = 0; i < 6; i++) pose[i] = bones[i].getTransform();
      Random random = new Random(seed ^ Double.doubleToLongBits(born));
      for (int i = 0; i < 64; i++)
        fragments[i] =
            new Fragment(
                (random.nextDouble() - .5) * .55,
                random.nextDouble() * 1.65 - .35,
                (random.nextDouble() - .5) * .3,
                (random.nextDouble() - .5) * .55,
                (random.nextDouble() - .5) * .55,
                random.nextDouble());
    }
  }

  private record Fragment(double x, double y, double z, double vx, double vz, double seed) {}

  private GhostEffects() {}
}
