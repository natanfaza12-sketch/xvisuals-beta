package pl.xvisuals.modules.motion;

import pl.xvisuals.XVisuals;
import pl.xvisuals.config.VisualConfig;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Hand;

/** Camera-space translation only; no player pose, interaction or server changes. */
public final class Viewmodel {
  public static double offset(VisualConfig.ModuleState settings, boolean main, String axis) {
    return settings.number((main || settings.flag("linked") ? "main" : "off") + axis);
  }

  public static void apply(MatrixStack matrices, Hand hand) {
    var settings = XVisuals.config().module("viewmodel");
    boolean main = hand == Hand.MAIN_HAND;
    float scale=(float)settings.number((main||settings.flag("linked")?"main":"off")+"Scale");
    // Camera X is right, Y is up, and negative Z points forward into the scene.
    matrices.translate(offset(settings, main, "X"), offset(settings, main, "Y"), -offset(settings, main, "Z"));
    matrices.scale(scale,scale,scale);
    var player=net.minecraft.client.MinecraftClient.getInstance().player;
    int sign=player==null||((hand==Hand.MAIN_HAND?player.getMainArm():player.getMainArm().getOpposite())==net.minecraft.util.Arm.RIGHT)?1:-1;
    matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Z.rotationDegrees((float)(sign*settings.number((main||settings.flag("linked")?"main":"off")+"Tilt"))));
  }

  private Viewmodel() {}
}
