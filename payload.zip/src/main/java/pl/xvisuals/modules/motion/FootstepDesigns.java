package pl.xvisuals.modules.motion;
import java.util.List;
import net.minecraft.util.Identifier;
public final class FootstepDesigns {
 public static final List<String> ORIGINAL=List.of("Frostprint","Emberstep","Sakura Steps","Astral Dust","Toxic Tracks","Rose Chrome","Ghost Paws");
 public static final String[] IDS={"frostprint","emberstep","sakura_steps","astral_dust","toxic_tracks","rose_chrome","ghost_paws"};
 public record Imported(String name,String file,boolean pair,float size){}
 public static final List<Imported> IMPORTED=List.of(
 new Imported("Sneakers","sneakers",true,1),new Imported("Boots","boots",true,1.05f),new Imported("Bare Feet","bare_feet",true,1),new Imported("Paws","paws",false,.8f),new Imported("Bunny","bunny",false,.9f),new Imported("Dino","dino",true,1.3f),new Imported("Bird","bird",false,.75f),new Imported("Hearts","hearts",false,.95f),new Imported("Stars","stars",false,.95f),new Imported("Flames","flames",true,1.05f),new Imported("Frost","frost",true,1),new Imported("Flowers","flowers",true,1),new Imported("Leaves","leaves",true,1),new Imported("Rainbow","rainbow",true,1),new Imported("Ghost","ghost",true,1),new Imported("Neon","neon",true,1),new Imported("Slime","slime",true,1),new Imported("Sparkle","sparkle",true,1));
 public static final List<String> ALL=java.util.stream.Stream.concat(ORIGINAL.stream(),IMPORTED.stream().map(Imported::name)).toList();
 private static final java.util.Map<String,Imported> BY_NAME;
 static {var designs=new java.util.HashMap<String,Imported>();for(var design:IMPORTED)designs.put(design.name(),design);BY_NAME=java.util.Collections.unmodifiableMap(designs);}
 public static Imported imported(String name){return BY_NAME.get(name);}
 public static boolean isImported(String name){return imported(name)!=null;}
 public static Identifier texture(String style,boolean left){var d=imported(style);return d==null?TEXTURES[index(style)]:Identifier.of("xvisuals","textures/imported/footsteps/"+d.file+(!left&&d.pair?"_right":"")+".png");}
 private static final Identifier[] TEXTURES=java.util.Arrays.stream(IDS).map(s->Identifier.of("xvisuals","textures/footsteps/"+s+".png")).toArray(Identifier[]::new);
 public static int index(String style){return Math.max(0,ALL.indexOf(style));}
 public static Identifier texture(String style){return texture(style,true);}
 public static int frame(double age,double speed){if(!Double.isFinite(age)||!Double.isFinite(speed))return 0;return Math.floorMod((int)Math.floor((age%120)*20*speed+1e-7),24);}
 public static double opacity(double progress){if(!Double.isFinite(progress)||progress<=0||progress>=1)return 0;return Math.min(1,progress*25)*Math.min(1,(1-progress)*3);}
 private FootstepDesigns(){}
}
