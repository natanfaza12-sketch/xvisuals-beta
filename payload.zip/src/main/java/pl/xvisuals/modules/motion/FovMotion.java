package pl.xvisuals.modules.motion;

import pl.xvisuals.XVisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffects;

public final class FovMotion {
  private static double current = 70, from = 70, target = 70, transition, dynamic;
  private static long previous;
  private static boolean enabled;

  public static float resolve(float vanilla, boolean changing) {
    var c = MinecraftClient.getInstance();
    var s = XVisuals.config().module("customfov");
    if (!s.enabled || c.player == null) {
      enabled = false;
      previous = 0;
      dynamic = 0;
      return vanilla;
    }
    if (!changing) return vanilla;
    long now = System.nanoTime();
    double dt = previous == 0 ? 0 : Math.min(.1, (now - previous) / 1e9);
    previous = now;
    double desired =
        FovTarget.choose(
            s,
            c.player.isSprinting(),
            c.player.hasStatusEffect(StatusEffects.SPEED),
            c.player.isUsingItem());
    if (!enabled) {
      current = from = target = vanilla;
      enabled = true;
    }
    if (Math.abs(desired - target) > .05) {
      from = current;
      target = desired;
      transition = 0;
    }
    transition = Math.min(1, transition + dt * s.number("transitionSpeed"));
    current =
        s.flag("smooth")
            ? from + (target - from) * Easing.apply(s.text("easing"), transition)
            : target;
    double dynamicTarget = s.flag("disableDynamic") ? 0 : vanilla - c.options.getFov().getValue();
    dynamic =
        s.flag("smooth")
            ? Easing.damp(dynamic, dynamicTarget, s.number("transitionSpeed") * 3, dt)
            : dynamicTarget;
    return (float) Math.clamp(current + dynamic, 30, 150);
  }

  private FovMotion() {}
}
