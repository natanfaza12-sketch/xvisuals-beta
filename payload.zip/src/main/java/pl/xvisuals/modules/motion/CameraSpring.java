package pl.xvisuals.modules.motion;

/** Frame-rate independent bounded spring, shared by take-off and landing camera effects. */
public final class CameraSpring {
  private double position,velocity,fov;
  public void impulse(double force,double kick){velocity+=force;fov=Math.min(30,fov+kick);}
  public void advance(double seconds,double stiffness){
    double remaining=Math.clamp(seconds,0,.1);
    while(remaining>0){double dt=Math.min(remaining,1./240);remaining-=dt;
      velocity+=(-90*Math.clamp(stiffness,.2,3)*position-11*velocity)*dt;
      position+=velocity*dt;
      fov=Math.max(0,fov*Math.exp(-6*dt)-dt*.5);
    }
  }
  public double position(){return position;}
  public double fov(){return fov;}
  public void clear(){position=velocity=fov=0;}
}
