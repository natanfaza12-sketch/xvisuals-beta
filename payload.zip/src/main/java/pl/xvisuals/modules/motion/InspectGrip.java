package pl.xvisuals.modules.motion;

import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.swords.CustomSwords;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerModelPart;
import net.minecraft.entity.player.PlayerSkinType;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Arm;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/** Place the fist at the hilt, not at the empty-hand animation's shoulder pivot. */
public final class InspectGrip {
  public static boolean custom(ItemStack item){
    var s=XVisuals.config().module("customswords");
    var id=Registries.ITEM.getId(item.getItem());
    return s.enabled&&id.getNamespace().equals("minecraft")&&CustomSwords.matches(id.getPath(),s.text("replace"));
  }
  public static Vector3f position(boolean custom, boolean right){
    float sign=right?1:-1;
    // Item display transforms are in sixteenths; baked geometry is centred on (8,8,8).
    Matrix4f model=new Matrix4f().translation(.56f*sign,-.52f,-.72f);
    if(custom)model.translate(sign/16f,-1/16f,-1/16f).rotateY((float)-Math.PI/2).rotateZ((float)Math.toRadians(15)).scale(.52f);
    else model.translate(sign*1.13f/16,3.2f/16,1.13f/16).rotateY((float)-Math.PI/2).rotateZ((float)Math.toRadians(25)).scale(.68f);
    return model.transformPosition(new Vector3f(custom?0:-.25f,-.25f,0));
  }
  public static void render(AbstractClientPlayerEntity player,ItemStack item,Arm arm,MatrixStack matrices,OrderedRenderCommandQueue queue,int light){
    render(player,item,arm,arm,matrices,queue,light,0);
  }
  public static void renderSupport(AbstractClientPlayerEntity player,ItemStack item,Arm swordArm,MatrixStack matrices,OrderedRenderCommandQueue queue,int light,double amount){
    render(player,item,swordArm.getOpposite(),swordArm,matrices,queue,light,amount);
  }
  private static void render(AbstractClientPlayerEntity player,ItemStack item,Arm arm,Arm swordArm,MatrixStack matrices,OrderedRenderCommandQueue queue,int light,double support){
    var settings=XVisuals.config().module("customswords");
    var id=Registries.ITEM.getId(item.getItem());
    boolean custom=settings.enabled&&id.getNamespace().equals("minecraft")&&CustomSwords.matches(id.getPath(),settings.text("replace"));
    boolean right=arm==Arm.RIGHT;
    var renderer=MinecraftClient.getInstance().getEntityRenderDispatcher().getPlayerRenderer(player);
    var part=right?renderer.getModel().rightArm:renderer.getModel().leftArm;
    var origin=part.getDefaultTransform();
    boolean slim=player.getSkin().model()==PlayerSkinType.SLIM;
    var grip=position(custom,swordArm==Arm.RIGHT);
    if(arm!=swordArm){
      // Second fist braces below the primary grip; approach and release are continuous.
      grip.y-=.13f;
      grip.x+=(float)((right?1:-1)*.65*(1-support));
      grip.y-=(float)(.55*(1-support));
    }
    matrices.translate(grip.x,grip.y,grip.z);
    // Keep the shoulders on their respective sides even while the sword turns point-down.
    if(SwordInspect.plunging()){
      SwordInspect.undoRotation(matrices,swordArm);
      matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(right?58:-58));
      matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-62));
    }else matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90));
    float size=custom?.52f:.60f;
    matrices.scale(size,size,size);
    float fistX=(right?-1:1)*(slim?.5f:1f);
    matrices.translate(-fistX/16,-8f/16,0);
    // PlayerEntityRenderer resets the shoulder and adds +/-0.1 roll: undo both at the grip.
    matrices.multiply(RotationAxis.POSITIVE_Z.rotation(right?-.1f:.1f));
    matrices.translate(-origin.x()/16,-origin.y()/16,-origin.z()/16);
    var texture=player.getSkin().body().texturePath();
    if(right)renderer.renderRightArm(matrices,queue,light,texture,player.isModelPartVisible(PlayerModelPart.RIGHT_SLEEVE));
    else renderer.renderLeftArm(matrices,queue,light,texture,player.isModelPartVisible(PlayerModelPart.LEFT_SLEEVE));
  }
  private InspectGrip(){}
}
