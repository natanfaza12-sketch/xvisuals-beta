package pl.xvisuals.modules.motion;

import pl.xvisuals.config.VisualConfig.ModuleState;

/** Explicit priority for mutually overlapping lens states. */
public final class FovTarget {
  public static double choose(
      ModuleState settings, boolean sprinting, boolean speedEffect, boolean usingItem) {
    return Math.clamp(
        settings.number(
            usingItem ? "use" : speedEffect ? "speed" : sprinting ? "sprint" : "static"),
        30,
        150);
  }

  private FovTarget() {}
}
