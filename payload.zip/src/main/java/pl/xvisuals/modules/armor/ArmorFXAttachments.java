package pl.xvisuals.modules.armor;
import pl.xvisuals.XVisuals;
import pl.xvisuals.mixins.ArmorFXModelPartAccessor;
import pl.xvisuals.util.Colors;
import net.minecraft.client.model.*;
import net.minecraft.client.render.*;
import net.minecraft.client.render.command.RenderCommandQueue;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.equipment.EquipmentAsset;
import net.minecraft.registry.RegistryKey;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.EquipmentSlot;
import java.util.*;
public final class ArmorFXAttachments {
 private static final Map<Model<?>,Decoration> CACHE=new IdentityHashMap<>();
 private static final Set<Long> SEEN=new HashSet<>();
 private static int budget=192;
 public static void beginFrame(){budget=192;SEEN.clear();}
 public static void reload(){CACHE.clear();beginFrame();}
 public static void submit(RenderCommandQueue q,Model<?> model,BipedEntityRenderState state,MatrixStack matrices,int light,ItemStack stack,RegistryKey<EquipmentAsset> asset){
  if(state instanceof ArmorFXFirstPerson.State)return;
  var s=XVisuals.config().module("armorfx");if(ArmorFXCompatibility.basic())return;
  int lod=ArmorFXPolicy.lod(state.squaredDistanceToCamera,s.flag("lod"));
  var equip=stack.get(DataComponentTypes.EQUIPPABLE);if(equip==null)return;
  long key=((long)ArmorFXRenderer.entityId(state)<<8)|equip.slot().ordinal();if(!SEEN.add(key))return; // layered leather must not duplicate cosmetics
  if(lod>=2||s.text("quality").equals("Low"))return;
  int type=equip.slot()==EquipmentSlot.HEAD?switch(s.text("attachment")){case "Crown"->1;case "Horns"->2;default->0;}:0;
  boolean damage=s.flag("durabilityEnabled")&&s.flag("durabilitySparks")&&ArmorFXPolicy.wear(stack.getDamage(),stack.getMaxDamage())>.9;
  int count=s.flag("auraEnabled")?Math.min(8,s.integer("auraAmount")):damage?1:0;
  if(s.flag("combatCrit")&&ArmorFXRenderer.combatPulse(state)>.03f)count=Math.max(count,2);
  if(s.text("quality").equals("Medium")||lod==1)count=Math.min(count,2);
  else if(s.text("quality").equals("High"))count=Math.min(count,4);
  count=Math.min(count,budget);budget-=count;
  boolean debug=false;if(count==0&&type==0&&!debug)return;
  Decoration decoration=CACHE.get(model);if(decoration==null){if(CACHE.size()>=32)return;decoration=new Decoration(model);CACHE.put(model,decoration);}
  double time=ArmorFXResources.time();
  if(type!=0||debug)q.submitModel(decoration,new Pose(state,time,0,type,debug,false),matrices,RenderLayers.entityCutoutNoCull(ArmorFXResources.id("textures/armorfx/white.png")),light,OverlayTexture.DEFAULT_UV,s.color("attachmentColor"),null,0,null);
  if(count>0)q.submitModel(decoration,new Pose(state,time,count,0,false,true),matrices,RenderLayers.entityTranslucentEmissiveNoOutline(ArmorFXResources.id("textures/armorfx/mote.png")),light,OverlayTexture.DEFAULT_UV,Colors.alpha(s.color("auraColor"),s.number("auraOpacity")*(s.text("auraType").equals("Smoke")?.35:1)),null,0,null);
 }
 private record Pose(BipedEntityRenderState player,double time,int motes,int attachment,boolean debug,boolean aura){}
 private record Binding(ModelPart source,ModelPart target){}
 private record Mote(ModelPart part,ModelPart.Cuboid bounds,int index){}
 /** Copies the entire native hierarchy, then adds children to actual armor cuboid owners.
  * Evaluated at queue consumption so interpolated limb transforms are exactly vanilla's current state. */
 private static final class Decoration extends Model<Pose> {
  final Model<BipedEntityRenderState> source;
  final List<Binding> bindings=new ArrayList<>();final List<Mote> motes=new ArrayList<>();
  final List<ModelPart> crowns=new ArrayList<>(),horns=new ArrayList<>(),origins=new ArrayList<>();
  @SuppressWarnings("unchecked") Decoration(Model<?> source){super(new ModelPart(List.of(),new HashMap<>()),RenderLayers::entityCutoutNoCull);this.source=(Model<BipedEntityRenderState>)source;build(source.getRootPart(),root,"root");}
  void build(ModelPart from,ModelPart into,String name){
   bindings.add(new Binding(from,into));var access=(ArmorFXModelPartAccessor)(Object)from;
   var children=((ArmorFXModelPartAccessor)(Object)into).armorfx$children();
   for(var entry:access.armorfx$children().entrySet()){var p=new ModelPart(List.of(),new HashMap<>());children.put(entry.getKey(),p);build(entry.getValue(),p,entry.getKey());}
   if(access.armorfx$cuboids().isEmpty())return;
   var bounds=access.armorfx$cuboids().getFirst();
   for(int i=0;i<8;i++){var p=box(-.5f,-.5f,-.5f,1,1,1);children.put("armorfx_mote_"+i,p);motes.add(new Mote(p,bounds,motes.size()));}
   ModelPart axis=box(-.1f,-.1f,-.1f,.2f,2,.2f);children.put("armorfx_origin",axis);origins.add(axis);
   if(!name.equals("head"))return;
   float y=bounds.minY-1.1f,x=bounds.minX-.3f,z=bounds.minZ-.3f,w=bounds.maxX-bounds.minX+.6f,d=bounds.maxZ-bounds.minZ+.6f;
   add(children,crowns,"crown_front",box(x,y,z,w,.65f,.55f));add(children,crowns,"crown_back",box(x,y,z+d-.55f,w,.65f,.55f));
   add(children,crowns,"crown_left",box(x,y,z,.55f,.65f,d));add(children,crowns,"crown_right",box(x+w-.55f,y,z,.55f,.65f,d));
   for(int i=0;i<5;i++){float height=i==2?2.2f:i%2==0?1.6f:1.1f;add(children,crowns,"crown_tip_"+i,box(x+.3f+i*(w-1.3f)/4,y-height,z,.7f,height,.55f));}
   for(int side=-1;side<=1;side+=2)for(int segment=0;segment<4;segment++){float size=1.6f-segment*.32f;var p=box(-size/2,-1.4f,-size/2,size,1.6f,size);p.originX=side*(w*.36f+segment*.25f);p.originY=y-segment*1.15f;p.originZ=0;p.roll=side*.24f;add(children,horns,"horn_"+side+"_"+segment,p);}
  }
  @Override public void setAngles(Pose pose){
   source.setAngles(pose.player);for(var b:bindings){b.target.setTransform(b.source.getTransform());b.target.visible=b.source.visible;}
   var s=XVisuals.config().module("armorfx");int total=motes.size(),step=pose.motes==0?total+1:Math.max(1,total/pose.motes),shown=0;
   int style=switch(s.text("auraType")){case "Energy"->0;case "Smoke"->1;case "Frost"->3;case "Embers"->4;case "Void particles"->5;default->2;};
   for(var m:motes){var p=m.part;p.visible=pose.aura&&shown<pose.motes&&m.index%step==0;if(!p.visible)continue;shown++;
    double phase=(pose.time*s.number("auraSpeed")*.3+m.index*.618+(pose.player instanceof net.minecraft.client.render.entity.state.PlayerEntityRenderState player?player.id:0)*.013)%1;if(phase<0)phase+=1;
    var b=m.bounds;float a=(float)(m.index*2.39996+pose.time*.17),radius=(b.maxX-b.minX)*.5f+.65f;
    p.originX=(b.minX+b.maxX)*.5f+(float)Math.cos(a)*radius;p.originZ=(b.minZ+b.maxZ)*.5f+(float)Math.sin(a)*((b.maxZ-b.minZ)*.5f+.65f);
    p.originY=(float)(b.maxY-(b.maxY-b.minY)*phase-(style==3?-1:1)*phase*2);
    float size=(float)(s.number("auraSize")*16*Math.sin(Math.PI*phase));if(style==1)size*=1.8f;
    p.xScale=p.zScale=size;p.yScale=style==0?size*2.5f:style==2?size*.5f:size;
    p.pitch=p.yaw=(float)(pose.time*.3+m.index);p.roll=style==3?(float)Math.PI/4:0;
   }
   for(var p:crowns)p.visible=pose.attachment==1;for(var p:horns)p.visible=pose.attachment==2;for(var p:origins)p.visible=pose.debug;
  }
 }
 private static void add(Map<String,ModelPart> map,List<ModelPart> list,String key,ModelPart p){map.put("armorfx_"+key,p);list.add(p);}
 private static ModelPart box(float x,float y,float z,float w,float h,float d){return new ModelPart(List.of(new ModelPart.Cuboid(0,0,x,y,z,w,h,d,0,0,0,false,4,2,EnumSet.allOf(net.minecraft.util.math.Direction.class))),Map.of());}
 private ArmorFXAttachments(){}
}


