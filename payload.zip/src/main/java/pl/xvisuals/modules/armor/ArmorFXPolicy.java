package pl.xvisuals.modules.armor;

import java.util.Locale;

/** Pure decisions shared by submission, first person, and regression tests. */
public final class ArmorFXPolicy {
 public static boolean target(String mode, boolean self, boolean friend) {
  return switch(mode){case "Everyone"->true;case "Friends"->friend;case "Others"->!self;default->self;};
 }
 public static boolean friend(String list,String name,String uuid) {
  for(String entry:list.split(",")){String e=entry.trim();if(!e.isEmpty()&&(e.equalsIgnoreCase(name)||e.equalsIgnoreCase(uuid)))return true;}return false;
 }
 public static String material(String asset) {
  if(!asset.startsWith("minecraft:"))return "otherArmor";
  return switch(asset.substring(10).toLowerCase(Locale.ROOT)){case "leather"->"leather";case "chainmail"->"chainmail";case "iron"->"iron";case "gold"->"gold";case "diamond"->"diamond";case "netherite"->"netherite";case "turtle_scute"->"turtle";default->"otherArmor";};
 }
 public static int lod(double squared,boolean enabled){return !enabled?0:squared>1024?2:squared>256?1:0;}
 public static float wear(int damage,int maximum){return maximum<=0?0:Math.clamp((float)damage/maximum,0,1);}
 public static float pulse(double seconds,double duration){if(seconds<0||seconds>=duration||duration<=0)return 0;double x=seconds/duration;return (float)(Math.sin(Math.PI*x)*Math.pow(1-x,.6));}
 private ArmorFXPolicy(){}
}
