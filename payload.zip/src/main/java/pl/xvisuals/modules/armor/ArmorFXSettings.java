package pl.xvisuals.modules.armor;

import pl.xvisuals.modules.*;
import java.util.*;
import static pl.xvisuals.modules.Setting.*;

/** One schema for config validation and the existing Studio colour/settings controls. */
public final class ArmorFXSettings {
 public static final List<String> PRESETS=List.of("Obsidian Angel","Vanilla+","Obsidian","Chrome","Frost","Inferno","Void","Angel","Cyber","Solaris","Deepsea","Crimson","Jade","Starlight");
 public static ModuleSpec spec(){return new ModuleSpec("armorfx","ArmorFX","Player",
  "Materials, native trim lighting and animated details on the actual equipped armor models.","A",false,List.of(
  choice("section","Settings section","General","General","Material","Overlay","Trim FX","Emissive","Glint","Durability FX","Combat FX","Aura","Attachments","Advanced"),
  choice("applyTo","Apply to","Self","Self","Everyone","Friends","Others"),text("friends","Friends (names or UUIDs, comma separated)",""),
  flag("armorStands","Armour stands",true),flag("firstPerson","First-person armored arms",true),number("distance","Render distance",64,8,128,8),
  choice("preset","Self material","Obsidian Angel",PRESETS.toArray(String[]::new)),choice("otherPreset","Other player material","Vanilla+",PRESETS.toArray(String[]::new)),
  flag("allArmor","All armor materials",true),flag("leather","Leather",true),flag("chainmail","Chainmail",true),flag("iron","Iron",true),flag("gold","Gold",true),flag("diamond","Diamond",true),flag("netherite","Netherite",true),flag("turtle","Turtle helmet",true),flag("otherArmor","Other compatible equipment",false),
  flag("preserveDye","Preserve leather dye",true),
  flag("shoulderFit","Fit overlapping shoulder armor",true),
  flag("materialEnabled","Material layer",true),flag("materialCustom","Custom material colours",false),
  color("materialColor","Base colour","#FFFFFF"),color("materialSecondary","Secondary colour","#FFFFFF"),
  choice("materialMode","Material colour mode","Static","Static","Gradient","Rainbow","Pulse"),
  number("materialIntensity","Material intensity",.7,0,1,.05),number("reflectivity","Reflectivity",.45,0,1,.05),
  flag("overlayEnabled","Texture overlay",false),text("overlayOuter","Outer texture resource","xvisuals:textures/armorfx/outer.png"),text("overlayInner","Leggings texture resource","xvisuals:textures/armorfx/inner.png"),
  color("overlayColor","Overlay tint","#FFFFFF"),number("overlayOpacity","Overlay opacity",.4,0,1,.05),flag("overlayAnimation","Animate overlay UVs",false),number("overlaySpeed","UV movement speed",.1,0,1,.05),
  choice("overlayBlend","Overlay blend","Alpha","Alpha","Additive"),
  flag("trimEnabled","Trim FX",true),flag("trimPreserve","Preserve vanilla trim",true),color("trimColor","Trim colour","#FFFFFF"),
  flag("trimGlow","Emissive trim",true),number("trimIntensity","Trim glow intensity",.65,0,2,.05),flag("trimPulse","Trim pulse",false),number("trimPulseSpeed","Trim pulse speed",.35,.05,3,.05),
  flag("trimFlow","Flow through trim",true),number("trimFlowSpeed","Trim flow speed",.08,0,2,.02),flag("trimRainbow","Rainbow trim",false),number("trimRainbowSpeed","Trim rainbow speed",.2,.05,2,.05),
  flag("emissiveEnabled","Emissive details",true),color("emissiveColor","Emissive colour","#FFFFFF"),number("emissiveIntensity","Emissive intensity",.45,0,2,.05),number("emissiveOpacity","Emissive opacity",.55,0,1,.05),flag("emissivePulse","Pulse",true),number("emissivePulseSpeed","Pulse speed",.3,.05,3,.05),
  flag("animatedEnabled","Animated material details",true),number("animationSpeed","Detail animation speed",.35,0,3,.05),
  choice("glintMode","Armor enchant glint","Slow Luxury Shimmer","Vanilla","Disabled","Custom Color","White Shimmer","RGB","Flowing","Pulse","Lightning-inspired","Slow Luxury Shimmer"),
  number("glintOpacity","Glint opacity",.25,0,1,.05),number("glintSpeed","Glint speed",.25,0,3,.05),number("glintScale","Glint scale",1,.25,4,.05),number("glintIntensity","Glint intensity",.65,0,2,.05),color("glintColor","Primary glint colour","#FFFFFF"),color("glintSecondary","Secondary glint colour","#FFFFFF"),
  flag("durabilityEnabled","Durability FX",false),flag("durabilityCracks","Wear and cracks",true),flag("durabilitySparks","Low durability sparks",true),flag("durabilityGlow","Low durability glow",true),number("durabilityIntensity","Wear intensity",.5,0,1,.05),
  flag("combatHit","Confirmed hit pulse",true),flag("combatKill","Confirmed kill pulse",false),flag("combatCrit","Critical spark",true),number("combatIntensity","Combat intensity",.3,0,1,.05),number("combatDuration","Pulse duration (seconds)",.32,.25,.8,.01),
  flag("auraEnabled","Armor aura",false),choice("auraType","Aura type","Sparks","Energy","Smoke","Sparks","Frost","Embers","Void particles"),number("auraAmount","Maximum motes per piece",3,1,8,1),number("auraSpeed","Aura speed",.35,.1,2,.05),number("auraSize","Mote size",.025,.01,.10,.005),number("auraOpacity","Aura opacity",.35,0,1,.05),color("auraColor","Aura colour","#FFFFFF"),
  choice("attachment","Helmet attachment","None","None","Crown","Horns"),color("attachmentColor","Attachment colour","#FFFFFF"),
  choice("quality","Quality","High","Low","Medium","High","Ultra"),flag("lod","Distance LOD",true),flag("compatibility","Compatibility mode",false)
  ));}
 public static List<Setting> visible(ModuleSpec spec,String section,boolean debug){
  return spec.settings().stream().filter(s->s.key().equals("section")||switch(section){
   case "Material"->s.key().startsWith("material")||Set.of("preset","otherPreset","reflectivity","preserveDye").contains(s.key());
   case "Overlay"->s.key().startsWith("overlay");case "Trim FX"->s.key().startsWith("trim");
   case "Emissive"->s.key().startsWith("emissive")||s.key().equals("animatedEnabled")||s.key().equals("animationSpeed");
   case "Glint"->s.key().startsWith("glint");case "Durability FX"->s.key().startsWith("durability");case "Combat FX"->s.key().startsWith("combat");case "Aura"->s.key().startsWith("aura");
   case "Attachments"->s.key().startsWith("attachment");
   case "Advanced"->Set.of("quality","lod","compatibility").contains(s.key());
   default->Set.of("armorStands","applyTo","friends","firstPerson","distance","preset","otherPreset","shoulderFit","allArmor","leather","chainmail","iron","gold","diamond","netherite","turtle","otherArmor").contains(s.key());
  }).toList();
 }
 private ArmorFXSettings(){}
}



