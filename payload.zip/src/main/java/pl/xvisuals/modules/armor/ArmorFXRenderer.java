package pl.xvisuals.modules.armor;

import pl.xvisuals.XVisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.Model;
import net.minecraft.client.render.*;
import net.minecraft.client.render.command.*;
import net.minecraft.client.render.entity.equipment.EquipmentModel;
import net.minecraft.client.render.entity.state.*;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.item.equipment.EquipmentAsset;

/** Only called at vanilla's actual equipment submissions, after slot/model selection. */
public final class ArmorFXRenderer {
 public static long baseSubmissions,trimSubmissions,glintSubmissions;
 public static boolean eligible(Object state,EquipmentModel.LayerType type,RegistryKey<EquipmentAsset> asset){
  if(pl.xvisuals.modules.glass.GlassMode.player(state))return false;
  if(!XVisuals.ready()||!(state instanceof BipedEntityRenderState p))return false;
  boolean stand=p instanceof ArmorStandEntityRenderState;
  if(!stand&&(!(p instanceof PlayerEntityRenderState player)||player.invisible||player.spectator))return false;
  if(type!=EquipmentModel.LayerType.HUMANOID&&type!=EquipmentModel.LayerType.HUMANOID_LEGGINGS)return false;
  var s=XVisuals.config().module("armorfx");var c=MinecraftClient.getInstance();
  if(!s.enabled||c.player==null||p.squaredDistanceToCamera>s.number("distance")*s.number("distance"))return false;
  int id=entityId(p);boolean self=!stand&&id==c.player.getId();var entity=stand||c.world==null?null:c.world.getEntityById(id);
  boolean friend=s.text("applyTo").equals("Friends")&&entity!=null&&ArmorFXPolicy.friend(s.text("friends"),entity.getName().getString(),entity.getUuidAsString());
  if(stand?!s.flag("armorStands"):!ArmorFXPolicy.target(s.text("applyTo"),self,friend))return false;
  String material=ArmorFXPolicy.material(asset.getValue().toString());
  // Unknown assets are opt-in even when 'all armor' is selected.
  return material.equals("otherArmor")?s.flag("otherArmor"):s.flag("allArmor")||s.flag(material);
 }
 @SuppressWarnings({"rawtypes","unchecked"})
 public static boolean submit(int pass,RenderCommandQueue queue,Model model,Object state,MatrixStack matrices,
   RenderLayer original,int light,int overlay,int color,Sprite sprite,int outline,ModelCommandRenderer.CrumblingOverlayCommand crumble,
   ItemStack stack,EquipmentModel.LayerType type,RegistryKey<EquipmentAsset> asset){
  if(!eligible(state,type,asset))return false;
  var s=XVisuals.config().module("armorfx");var p=(BipedEntityRenderState)state;
  if(s.flag("shoulderFit")&&!ArmorFXCompatibility.basic())model=ArmorFXFit.model(model);
  if(ArmorFXCompatibility.basic()){
   // Only vanilla pipelines in compatibility mode. Trims and glint are left entirely to vanilla/Iris.
   if(pass!=0)return false;
   int tint=color;
   if(s.flag("materialEnabled")&&s.flag("materialCustom"))tint=pl.xvisuals.util.Colors.mix(color,s.color("materialColor"),s.number("materialIntensity")*.5);
   queue.submitModel(model,state,matrices,original,light,overlay,tint,sprite,outline,crumble);
   var texture=ArmorFXResources.overlay(type==EquipmentModel.LayerType.HUMANOID_LEGGINGS);
   if(s.flag("overlayEnabled")&&texture!=null)queue.submitModel(model,state,matrices,RenderLayers.entityTranslucent(texture),light,overlay,pl.xvisuals.util.Colors.alpha(s.color("overlayColor"),s.number("overlayOpacity")),null,outline,crumble);
   baseSubmissions++;return true;
  }
  if(pass==1){if(s.text("glintMode").equals("Vanilla")){queue.submitModel(model,state,matrices,original,light,overlay,color,sprite,outline,crumble);return true;}if(s.text("glintMode").equals("Disabled"))return true;}
  if(pass==2&&(!s.flag("trimEnabled"))){queue.submitModel(model,state,matrices,original,light,overlay,color,sprite,outline,crumble);return true;}
  // Glint's original texture is intentionally replaced with the armor alpha mask, never with a full-screen pattern.
  RenderLayer source=pass==1?LAST_BASE.get():original;
  if(source==null)return false;
  RenderLayer layer=ArmorFXResources.layer(source,type==EquipmentModel.LayerType.HUMANOID_LEGGINGS,pass);if(layer==null)return false;
  if(pass==0)LAST_BASE.set(original);
  int preset=Math.max(0,ArmorFXSettings.PRESETS.indexOf(s.text(p instanceof ArmorStandEntityRenderState||entityId(p)==MinecraftClient.getInstance().player.getId()?"preset":"otherPreset")));
  int lod=ArmorFXPolicy.lod(p.squaredDistanceToCamera,s.flag("lod"));
  int wear=Math.round(ArmorFXPolicy.wear(stack.getDamage(),stack.getMaxDamage())*255);
  int pulse=Math.round(combatPulse(p)*127);
  int bits=preset|(lod<<4)|(s.flag("preserveDye")?64:0)|((overlay&15)<<7)|(((overlay>>>16)&15)<<11);
  int packed=wear|(pulse<<8)|(bits<<16);
  if(pass==2&&s.flag("trimPreserve"))queue.submitModel(model,state,matrices,original,light,overlay,color,sprite,outline,crumble);
  queue.submitModel(model,state,matrices,layer,light,packed,color,sprite,outline,crumble);
  if(pass==0){baseSubmissions++;ArmorFXAttachments.submit(queue,model,p,matrices,light,stack,asset);}else if(pass==1)glintSubmissions++;else trimSubmissions++;
  return true;
 }
 // Scope is strictly one EquipmentRenderer.render call; cleared at entry and exit by the mixin.
 private static final ThreadLocal<RenderLayer> LAST_BASE=new ThreadLocal<>();
 public static int entityId(BipedEntityRenderState state){
  return state instanceof PlayerEntityRenderState p?p.id:java.util.Objects.hash(state.x,state.y,state.z);
 }
 public static float combatPulse(BipedEntityRenderState state){return state instanceof PlayerEntityRenderState p?ArmorFXCombat.pulse(p.id):0;}
 public static void clear(){LAST_BASE.remove();}
 private ArmorFXRenderer(){}
}


