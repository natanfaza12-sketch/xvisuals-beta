package pl.xvisuals.modules.armor;

/** Allocation-free convex surface subtraction. Positions and UVs share the same intersection weight. */
final class ArmorFXSurfaceClip {
 interface Sink { void polygon(float[] vertices,int count); }
 final float[] input=new float[80];
 private final float[] a=new float[80],b=new float[80],outside=new float[80];
 void subtract(float minX,float minY,float minZ,float maxX,float maxY,float maxZ,Sink sink){
  System.arraycopy(input,0,a,0,20);float[] remaining=a,next=b;int count=4;
  for(int plane=0;plane<6&&count>=3;plane++){
   int axis=plane/2;float bound=switch(plane){case 0->minX;case 1->maxX;case 2->minY;case 3->maxY;case 4->minZ;default->maxZ;};
   int inCount=0,outCount=0;
   for(int i=0;i<count;i++){
    int p=i*5,q=((i+1)%count)*5;float dp=(remaining[p+axis]-bound)*(plane%2==0?1:-1),dq=(remaining[q+axis]-bound)*(plane%2==0?1:-1);
    boolean inside=dp>=0;
    if(inside){System.arraycopy(remaining,p,next,inCount++*5,5);}else{System.arraycopy(remaining,p,outside,outCount++*5,5);}
    if(inside!=(dq>=0)){
     float t=dp/(dp-dq);
     for(int k=0;k<5;k++){float v=remaining[p+k]+t*(remaining[q+k]-remaining[p+k]);next[inCount*5+k]=v;outside[outCount*5+k]=v;}
     inCount++;outCount++;
    }
   }
   if(outCount>=3)sink.polygon(outside,outCount);
   count=inCount;float[] swap=remaining;remaining=next;next=swap;
  }
 }
}
