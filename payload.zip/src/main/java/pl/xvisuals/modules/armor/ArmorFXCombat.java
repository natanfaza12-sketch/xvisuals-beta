package pl.xvisuals.modules.armor;

import pl.xvisuals.XVisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.s2c.play.EntityDamageS2CPacket;
import java.util.*;

/** Authoritative damage + death packets, never attack clicks or predicted health. Bounded per-world history. */
public final class ArmorFXCombat {
 private record Damage(long at,boolean local){}
 private static final Map<Integer,Damage> DAMAGE=new HashMap<>();
 private static final Map<Integer,Long> PULSES=new HashMap<>(),CRITS=new HashMap<>();
 private static Object world;
 private static int attackedId=Integer.MIN_VALUE;private static long attackedAt;
 public static void attacked(net.minecraft.entity.Entity entity){attackedId=entity.getId();attackedAt=System.nanoTime();}
 private static boolean ourSwing(int target,long now){return target==attackedId&&now-attackedAt<500_000_000L;}
 public static void tick(MinecraftClient c){
  if(world!=c.world||!XVisuals.config().on("armorfx")){world=c.world;DAMAGE.clear();PULSES.clear();CRITS.clear();attackedId=Integer.MIN_VALUE;}
  long now=System.nanoTime();DAMAGE.values().removeIf(d->now-d.at>3_000_000_000L);PULSES.values().removeIf(t->now-t>1_000_000_000L);CRITS.values().removeIf(t->now-t>250_000_000L);
 }
 public static void damage(EntityDamageS2CPacket p){
  var c=MinecraftClient.getInstance();if(c.player==null||c.world==null||!XVisuals.config().on("armorfx"))return;
  long now=System.nanoTime();boolean local=p.sourceCauseId()==c.player.getId();
  if(DAMAGE.size()>=128)DAMAGE.clear();DAMAGE.put(p.entityId(),new Damage(now,local));
  var s=XVisuals.config().module("armorfx");
  if(local&&s.flag("combatHit"))pulse(p.entityId(),now);
  if(local&&ourSwing(p.entityId(),now)&&s.flag("combatCrit")&&now-CRITS.getOrDefault(p.entityId(),Long.MIN_VALUE/2)<250_000_000L)pulse(c.player.getId(),now);
 }
 public static void critical(int target){
  var c=MinecraftClient.getInstance();if(c.player==null||!XVisuals.config().on("armorfx"))return;
  long now=System.nanoTime();if(CRITS.size()>=128)CRITS.clear();CRITS.put(target,now);Damage d=DAMAGE.get(target);
  if(d!=null&&d.local&&ourSwing(target,now)&&now-d.at<250_000_000L&&XVisuals.config().module("armorfx").flag("combatCrit"))pulse(c.player.getId(),now);
 }
 public static void death(int target){
  var c=MinecraftClient.getInstance();Damage d=DAMAGE.remove(target);if(c.player==null||d==null||!d.local||System.nanoTime()-d.at>2_000_000_000L)return;
  if(XVisuals.config().module("armorfx").flag("combatKill"))pulse(c.player.getId(),System.nanoTime());
 }
 private static void pulse(int id,long now){if(PULSES.size()>=128)PULSES.clear();PULSES.put(id,now);}
 public static float pulse(int id){Long start=PULSES.get(id);if(start==null)return 0;var s=XVisuals.config().module("armorfx");return ArmorFXPolicy.pulse((System.nanoTime()-start)/1e9,s.number("combatDuration"))*(float)s.number("combatIntensity");}
 private ArmorFXCombat(){}
}
