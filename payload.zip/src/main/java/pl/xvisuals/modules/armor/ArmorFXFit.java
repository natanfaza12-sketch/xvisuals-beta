package pl.xvisuals.modules.armor;

import pl.xvisuals.mixins.ArmorFXModelPartAccessor;
import net.minecraft.client.model.*;
import net.minecraft.client.render.*;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.*;
import java.util.*;

/** Clips shoulder surfaces against the actual transformed chest cuboid. No guessed limb origins,
 * arm separation, model inflation or changes to the player's pose, skin or held-item transforms.
 * A shared fitted model is submitted for base, native trim, FX and glint so their geometry stays identical.
 */
public final class ArmorFXFit {
 private static final Map<Model<?>,Fitted> CACHE=new IdentityHashMap<>();
 public static void reload(){CACHE.clear();}
 public static Model<?> model(Model<?> source){
  if(!(source instanceof BipedEntityModel<?> b)||cubes(b.body).isEmpty()||cubes(b.rightArm).isEmpty())return source;
  Fitted found=CACHE.get(source);if(found!=null)return found;if(CACHE.size()>=32)return source;
  found=new Fitted(b);CACHE.put(source,found);return found;
 }
 private static List<ModelPart.Cuboid> cubes(ModelPart p){return ((ArmorFXModelPartAccessor)(Object)p).armorfx$cuboids();}
 private record Part(ModelPart source,ModelPart copy){}
 private static final class Fitted extends Model<BipedEntityRenderState> {
  final BipedEntityModel<BipedEntityRenderState> source;final List<Part> parts=new ArrayList<>();
  final MatrixStack transforms=new MatrixStack();final Matrix4f inverseBody=new Matrix4f();
  final Matrix4f rightToBody=new Matrix4f(),leftToBody=new Matrix4f(),bodyToRight=new Matrix4f(),bodyToLeft=new Matrix4f();
  final Vector3f minimum=new Vector3f(Float.POSITIVE_INFINITY),maximum=new Vector3f(Float.NEGATIVE_INFINITY);
  @SuppressWarnings("unchecked") Fitted(BipedEntityModel<?> source){super(new ModelPart(List.of(),new HashMap<>()),RenderLayers::armorCutoutNoCull);this.source=(BipedEntityModel<BipedEntityRenderState>)source;
   for(var cube:cubes(source.body))for(var face:cube.sides)for(var v:face.vertices()){
    minimum.min(new Vector3f(v.worldX(),v.worldY(),v.worldZ()));maximum.max(new Vector3f(v.worldX(),v.worldY(),v.worldZ()));
   }
   copy(source.getRootPart(),root);
  }
  void copy(ModelPart original,ModelPart destination){
   parts.add(new Part(original,destination));var children=((ArmorFXModelPartAccessor)(Object)destination).armorfx$children();
   for(var entry:((ArmorFXModelPartAccessor)(Object)original).armorfx$children().entrySet()){
    ModelPart from=entry.getValue();List<ModelPart.Cuboid> geometry=cubes(from);
    if(from==source.rightArm||from==source.leftArm){boolean right=from==source.rightArm;geometry=geometry.stream().map(c->(ModelPart.Cuboid)new Shoulder(c,this,right)).toList();}
    ModelPart to=new ModelPart(geometry,new HashMap<>());children.put(entry.getKey(),to);copy(from,to);
   }
  }
  @Override public void setAngles(BipedEntityRenderState state){
   source.setAngles(state);
   for(var pair:parts){ModelPart a=pair.source,b=pair.copy;b.originX=a.originX;b.originY=a.originY;b.originZ=a.originZ;b.pitch=a.pitch;b.yaw=a.yaw;b.roll=a.roll;b.xScale=a.xScale;b.yScale=a.yScale;b.zScale=a.zScale;b.visible=a.visible;b.hidden=a.hidden;}
   transforms.loadIdentity();source.body.applyTransform(transforms);inverseBody.set(transforms.peek().getPositionMatrix()).invert();
   transforms.loadIdentity();source.rightArm.applyTransform(transforms);rightToBody.set(inverseBody).mul(transforms.peek().getPositionMatrix());bodyToRight.set(rightToBody).invert();
   transforms.loadIdentity();source.leftArm.applyTransform(transforms);leftToBody.set(inverseBody).mul(transforms.peek().getPositionMatrix());bodyToLeft.set(leftToBody).invert();
  }
 }
 private static final class Shoulder extends ModelPart.Cuboid {
  final ModelPart.Cuboid original;final Fitted owner;final boolean right;
  final ArmorFXSurfaceClip clip=new ArmorFXSurfaceClip();
  final Vector3f projected=new Vector3f(),reference=new Vector3f();
  final Matrix4f toOutput=new Matrix4f();
  VertexConsumer output;int packedLight,packedOverlay,packedColor;
  final ArmorFXSurfaceClip.Sink sink=this::emit;
  void vertex(float[] v,int i){
   int o=i*5;toOutput.transformPosition(v[o],v[o+1],v[o+2],projected);
   output.vertex(projected.x,projected.y,projected.z,packedColor,v[o+3],v[o+4],packedOverlay,packedLight,reference.x,reference.y,reference.z);
  }
  void emit(float[] v,int n){
   if(n==4){for(int i=0;i<4;i++)vertex(v,i);}
   else for(int i=1;i<n-1;i++){vertex(v,0);vertex(v,i);vertex(v,i+1);vertex(v,i+1);}
  }
  Shoulder(ModelPart.Cuboid original,Fitted owner,boolean right){super(0,0,original.minX,original.minY,original.minZ,original.maxX-original.minX,original.maxY-original.minY,original.maxZ-original.minZ,0,0,0,false,64,32,Set.of());this.original=original;this.owner=owner;this.right=right;}
  @Override public void renderCuboid(MatrixStack.Entry matrix,VertexConsumer out,int light,int overlay,int color){
   Matrix4f toBody=right?owner.rightToBody:owner.leftToBody,toArm=right?owner.bodyToRight:owner.bodyToLeft;
   output=out;packedLight=light;packedOverlay=overlay;packedColor=color;
   toOutput.set(matrix.getPositionMatrix()).mul(toArm);
   try {
    for(var face:original.sides){
     matrix.transformNormal(face.direction(),reference);
     var vertices=face.vertices();
     for(int i=0;i<4;i++){
      var v=vertices[i];toBody.transformPosition(v.worldX(),v.worldY(),v.worldZ(),projected);int o=i*5;
      clip.input[o]=projected.x;clip.input[o+1]=projected.y;clip.input[o+2]=projected.z;clip.input[o+3]=v.u();clip.input[o+4]=v.v();
     }
     // Remove only surfaces inside the chest, including nearly coplanar seams.
     // Exterior vertices stay on the original armor plane; no snapping or stretched corners.
     var lo=owner.minimum;var hi=owner.maximum;float e=.0001f;
     if(owner.source.body.visible&&!owner.source.body.hidden)
      clip.subtract(lo.x-e,lo.y-e,lo.z-e,hi.x+e,hi.y+e,hi.z+e,sink);
     else emit(clip.input,4);
    }
   } finally {output=null;}
  }
 }
 private ArmorFXFit(){}
}

