package pl.xvisuals.modules.armor;
import pl.xvisuals.XVisuals;
import pl.xvisuals.mixins.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.*;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.equipment.*;
import net.minecraft.client.render.entity.model.*;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.EquipmentSlot;
import java.util.*;

/** Native chest equipment geometry with the already-posed first-person skin arm transform.
 * Own models avoid mutating third-person armor or retaining a shared mutable pose in the command queue.
 */
public final class ArmorFXFirstPerson {
 public static final class State extends PlayerEntityRenderState {final ModelTransform pose;State(ModelTransform pose){this.pose=pose;}}
 private static final class ArmModel extends Model<State> {
  final ModelPart arm;
  ArmModel(ModelPart arm){super(new ModelPart(List.of(),Map.of("arm",arm)),RenderLayers::armorCutoutNoCull);this.arm=arm;}
  @Override public void setAngles(State state){arm.setTransform(state.pose);arm.visible=true;}
 }
 private final EquipmentRenderer renderer;
 private final ArmModel right,left;
 public ArmorFXFirstPerson(EntityRendererFactory.Context context,boolean slim){
  renderer=context.getEquipmentRenderer();var layers=slim?ArmorFXModelLayersAccessor.armorfx$slim():EntityModelLayers.PLAYER_EQUIPMENT;
  var chest=new PlayerEntityModel(context.getPart(layers.chest()),slim);
  right=new ArmModel(copy(chest.rightArm));left=new ArmModel(copy(chest.leftArm));
 }
 private static ModelPart copy(ModelPart source){
  var access=(ArmorFXModelPartAccessor)(Object)source;Map<String,ModelPart> children=new HashMap<>();access.armorfx$children().forEach((key,part)->children.put(key,copy(part)));
  var part=new ModelPart(access.armorfx$cuboids(),children);part.setDefaultTransform(source.getDefaultTransform());part.resetTransform();return part;
 }
 public void render(MatrixStack matrices,OrderedRenderCommandQueue queue,int light,ModelPart nativeArm,boolean isRight){
  var c=MinecraftClient.getInstance();if(c.player==null||c.player.isInvisible()||!XVisuals.config().on("armorfx"))return;
  var s=XVisuals.config().module("armorfx");if(!s.flag("firstPerson"))return;
  var stack=c.player.getEquippedStack(EquipmentSlot.CHEST);var equippable=stack.get(DataComponentTypes.EQUIPPABLE);
  if(equippable==null||equippable.slot()!=EquipmentSlot.CHEST||equippable.assetId().isEmpty())return;
  var state=new State(nativeArm.getTransform());state.id=c.player.getId();state.equippedChestStack=stack;
  if(!ArmorFXRenderer.eligible(state,EquipmentModel.LayerType.HUMANOID,equippable.assetId().get()))return;
  renderer.render(EquipmentModel.LayerType.HUMANOID,equippable.assetId().get(),isRight?right:left,state,stack,matrices,queue,light,0);
 }
}
