package pl.xvisuals.modules.armor;
import pl.xvisuals.XVisuals;
/** Optional Iris integration without linking the client to an Iris version. Unknown APIs fail conservatively. */
public final class ArmorFXCompatibility {
 private static boolean shaders;
 private static long checked;
 public static void tick(){long now=System.nanoTime();if(now-checked<1_000_000_000L)return;checked=now;
  if(!net.fabricmc.loader.api.FabricLoader.getInstance().isModLoaded("iris")){shaders=false;return;}
  try{var api=Class.forName("net.irisshaders.iris.api.v0.IrisApi");Object instance=api.getMethod("getInstance").invoke(null);shaders=(boolean)api.getMethod("isShaderPackInUse").invoke(instance);}catch(ReflectiveOperationException|LinkageError ex){shaders=true;}
 }
 public static boolean basic(){return shaders||XVisuals.config().module("armorfx").flag("compatibility");}
 private ArmorFXCompatibility(){}
}
