package pl.xvisuals.modules.armor;

import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import pl.xvisuals.mixins.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.client.texture.*;
import net.minecraft.util.Identifier;
import java.util.*;

/** Render-thread-owned resources. No cached trim sprites, GPU state mutation or render-time file reads. */
public final class ArmorFXResources {
 private static final Identifier DATA=id("dynamic/armorfx_settings");
 private static final Map<Key,RenderLayer> LAYERS=new HashMap<>();
 private static final RenderPipeline[] PIPELINES=new RenderPipeline[3];
 private static final String[] FLAGS={"materialEnabled","materialCustom","emissiveEnabled","emissivePulse","animatedEnabled","overlayEnabled","overlayAnimation","trimEnabled","trimPreserve","trimGlow","trimPulse","trimFlow","trimRainbow","durabilityEnabled","durabilityCracks","durabilityGlow"};
 private static final String[] NUMBERS={"materialIntensity","reflectivity","emissiveIntensity","emissiveOpacity","emissivePulseSpeed","animationSpeed","overlayOpacity","overlaySpeed","trimIntensity","trimPulseSpeed","trimFlowSpeed","trimRainbowSpeed","durabilityIntensity","glintOpacity","glintSpeed","glintScale","glintIntensity"};
 private static final String[] COLORS={"materialColor","materialSecondary","emissiveColor","overlayColor","trimColor","glintColor","glintSecondary"};
 private static final List<String> COLOR_MODES=List.of("Static","Gradient","Rainbow","Pulse"),GLINT_MODES=List.of("Vanilla","Disabled","Custom Color","White Shimmer","RGB","Flowing","Pulse","Lightning-inspired","Slow Luxury Shimmer");
 private static NativeImageBackedTexture data;
 private static long lastUpdate=-1,frame,clockStamp=System.nanoTime();
 private static double clockTime;
 private static Identifier outer=id("textures/armorfx/outer.png"),inner=id("textures/armorfx/inner.png");
 private static String requestedOuter="",requestedInner="";
 private static boolean validOuter,validInner;
 private record Key(Identifier texture,Identifier overlay,int pass){}
 public static void init(){
  net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents.END_MAIN.register(context->{frame++;ArmorFXAttachments.beginFrame();});
  net.fabricmc.fabric.api.resource.v1.ResourceLoader.get(net.minecraft.resource.ResourceType.CLIENT_RESOURCES)
   .registerReloader(id("armorfx"),(net.minecraft.resource.SynchronousResourceReloader)manager->reload());
 }
 public static Identifier id(String path){return Identifier.of("xvisuals",path);}
 public static void tick(MinecraftClient c){
  if(!XVisuals.ready())return;
  var s=XVisuals.config().module("armorfx");
  if(!requestedOuter.equals(s.text("overlayOuter"))){requestedOuter=s.text("overlayOuter");outer=Identifier.tryParse(requestedOuter);validOuter=outer!=null&&c.getResourceManager().getResource(outer).isPresent();LAYERS.clear();}
  if(!requestedInner.equals(s.text("overlayInner"))){requestedInner=s.text("overlayInner");inner=Identifier.tryParse(requestedInner);validInner=inner!=null&&c.getResourceManager().getResource(inner).isPresent();LAYERS.clear();}
  ArmorFXCombat.tick(c);
  ArmorFXCompatibility.tick();
 }
 public static void reload(){
  LAYERS.clear();requestedOuter=requestedInner="";validOuter=validInner=false;lastUpdate=-1;
  if(data!=null){MinecraftClient.getInstance().getTextureManager().destroyTexture(DATA);data=null;}
  ArmorFXAttachments.reload();
  ArmorFXFit.reload();
 }
 public static Identifier texture(RenderLayer layer){
  var textures=((RenderSetupAccessor)(Object)((RenderLayerAccessor)(Object)layer).visuals$setup()).visuals$textures();
  Object spec=textures.get("Sampler0");return spec instanceof TextureSpecAccessor access?access.visuals$location():null;
 }
 public static Identifier overlay(boolean leggings){return leggings?validInner?inner:null:validOuter?outer:null;}
 public static RenderLayer layer(RenderLayer nativeLayer,boolean leggings,int pass){
  Identifier nativeTexture=texture(nativeLayer);if(nativeTexture==null)return null;
  update();Identifier overlay=leggings&&validInner?inner:!leggings&&validOuter?outer:id("textures/armorfx/empty.png");
  Key key=new Key(nativeTexture,overlay,pass);RenderLayer cached=LAYERS.get(key);if(cached!=null)return cached;
  if(LAYERS.size()>=256)return null;
  // Match vanilla armor's projection-aware depth layering on EVERY pass. Changing only polygon bias
  // lets native trims and intersecting limb surfaces disagree about which surface is in front.
  var setup=RenderSetup.builder(pipeline(pass)).useLightmap().layeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING)
   .texture("Sampler0",nativeTexture).texture("ArmorData",DATA).expectedBufferSize(4096);
  if(pass==0)setup.crumbling().outlineMode(RenderSetup.OutlineMode.AFFECTS_OUTLINE);
  if(pass==0)setup.useOverlay().texture("ArmorOverlay",overlay);else setup.translucent();
  RenderLayer result=RenderLayerAccessor.visuals$of("armorfx_"+pass,setup.build());
  LAYERS.put(key,result);return result;
 }
 private static RenderPipeline pipeline(int pass){
  if(PIPELINES[pass]!=null)return PIPELINES[pass];
  var builder=RenderPipeline.builder().withLocation(id("pipeline/armorfx_"+pass))
   .withVertexShader(id("core/armorfx")).withFragmentShader(id("core/armorfx"))
   .withShaderDefine("ARMOR_PASS",pass)
   .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER)
   .withUniform("Lighting",UniformType.UNIFORM_BUFFER).withUniform("Fog",UniformType.UNIFORM_BUFFER)
   .withSampler("Sampler0").withSampler("Sampler2").withSampler("ArmorData")
   .withVertexFormat(VertexFormats.POSITION_COLOR_TEXTURE_OVERLAY_LIGHT_NORMAL,VertexFormat.DrawMode.QUADS)
   .withDepthTestFunction(pass==0?DepthTestFunction.LEQUAL_DEPTH_TEST:DepthTestFunction.EQUAL_DEPTH_TEST).withDepthWrite(pass==0).withCull(false);
  if(pass!=0)builder.withBlend(BlendFunction.TRANSLUCENT);
  if(pass==0)builder.withSampler("Sampler1").withSampler("ArmorOverlay");
  return PIPELINES[pass]=builder.build();
 }
 public static double time(){var s=XVisuals.config().module("armorfx");long now=System.nanoTime();
  boolean freeze=MinecraftClient.getInstance().isPaused();
  if(!freeze)clockTime+=Math.min(.1,(now-clockStamp)/1e9);clockStamp=now;return clockTime;
 }
 private static void number(int index,double value){data.getImage().setColorArgb(index,0,Float.floatToRawIntBits((float)value));}
 private static void color(int index,int value){data.getImage().setColorArgb(index,0,value);}
 private static void update(){
  if(data!=null&&frame==lastUpdate)return;lastUpdate=frame;
  if(data==null){data=new NativeImageBackedTexture(()->"ArmorFX parameters",new NativeImage(96,1,false));MinecraftClient.getInstance().getTextureManager().registerTexture(DATA,data);}
  var s=XVisuals.config().module("armorfx");boolean basic=s.flag("compatibility");
  number(0,time());
  for(int i=0;i<FLAGS.length;i++)number(i+1,s.flag(FLAGS[i])?1:0);
  for(int i=0;i<NUMBERS.length;i++)number(i+20,s.number(NUMBERS[i]));
  for(int i=0;i<COLORS.length;i++)color(i+40,s.color(COLORS[i]));
  number(50,COLOR_MODES.indexOf(s.text("materialMode")));
  number(51,GLINT_MODES.indexOf(s.text("glintMode")));
  number(52,s.text("overlayBlend").equals("Additive")?1:0);number(53,0);
  number(54,basic||s.text("quality").equals("Low")?0:s.text("quality").equals("Medium")?1:s.text("quality").equals("High")?2:3);
  if(basic){number(3,0);number(5,0);number(7,0);number(12,0);number(18,0);}
  data.upload();
 }
 private ArmorFXResources(){}
}
