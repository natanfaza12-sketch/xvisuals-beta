package pl.xvisuals.modules.entity;

import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.*;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import pl.xvisuals.mixins.RenderLayerAccessor;
import pl.xvisuals.rendering.Quality;
import pl.xvisuals.util.Colors;
import java.util.*;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.client.render.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/** Depth-tested crystal auras, nearest-first with quality and target limits. */
public final class CrystalAnimations {
  private static final BufferAllocator ALLOCATOR = new BufferAllocator(262144);
  private static final VertexConsumerProvider.Immediate BUFFERS = VertexConsumerProvider.immediate(ALLOCATOR);
  private static final RenderLayer LAYER = RenderLayerAccessor.visuals$of("xvisuals_crystal_animations",
      RenderSetup.builder(RenderPipeline.builder()
          .withLocation(Identifier.of("xvisuals", "pipeline/crystal_animations"))
          .withVertexShader(Identifier.of("xvisuals", "core/jump_circle"))
          .withFragmentShader(Identifier.of("xvisuals", "core/jump_circle"))
          .withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
          .withUniform("Projection", UniformType.UNIFORM_BUFFER)
          .withVertexFormat(VertexFormats.POSITION_COLOR, VertexFormat.DrawMode.QUADS)
          .withBlend(new BlendFunction(SourceFactor.SRC_ALPHA, DestFactor.ONE))
          .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withDepthWrite(false).withCull(false).build())
          .expectedBufferSize(262144).build());
  private static final List<EndCrystalEntity> TARGETS = new ArrayList<>();
  private static final double[] A = new double[3], B = new double[3];
  private static Object world;
  private static double time, previousTime;
  public static int drawnCrystals, drawnSegments;

  public static void init() {
    ClientTickEvents.END_CLIENT_TICK.register(CrystalAnimations::tick);
    WorldRenderEvents.END_MAIN.register(context -> render(context.matrices()));
    ClientLifecycleEvents.CLIENT_STOPPING.register(c -> ALLOCATOR.close());
  }
  private static void tick(MinecraftClient c) {
    TARGETS.clear();
    if (world != c.world) { world = c.world; time = previousTime = 0; }
    var s = XVisuals.config().module("crystals");
    if (c.world == null || c.player == null || !s.enabled || s.text("animation").equals("Off")) return;
    previousTime = time;
    if (!c.isPaused()) time += .05 * s.number("animationSpeed");
    double range = s.number("distance");
    for (var entity : c.world.getEntities()) {
      if (entity instanceof EndCrystalEntity crystal && !crystal.isRemoved()
          && c.player.squaredDistanceTo(crystal) <= range*range) TARGETS.add(crystal);
    }
    TARGETS.sort(Comparator.comparingDouble(c.player::squaredDistanceTo));
    int cap = Math.min(s.integer("animationCount"), Math.max(1, (int)(16*Math.min(1,Quality.factor()))));
    if (TARGETS.size() > cap) TARGETS.subList(cap, TARGETS.size()).clear();
  }
  private static void render(MatrixStack matrices) {
    drawnCrystals = drawnSegments = 0;
    var c = MinecraftClient.getInstance();
    if (c.world == null || c.player == null || c.world != world || TARGETS.isEmpty()
        || !XVisuals.config().on("crystals")) return;
    var s = XVisuals.config().module("crystals");
    float partial = c.getRenderTickCounter().getTickProgress(false);
    double t = c.isPaused() ? time : previousTime + (time-previousTime)*partial;
    int style = Math.max(0, Arrays.asList(CrystalAnimationShape.STYLES).indexOf(s.text("animation")));
    int segments = Math.max(24, (int)(64*Math.min(1,Quality.factor())));
    double size = s.number("animationSize"), glow = s.number("bloom") * Quality.glow();
    Vec3d camera = c.gameRenderer.getCamera().getCameraPos();
    var out = BUFFERS.getBuffer(LAYER);
    for (var p : TARGETS) {
      if (p.isRemoved() || p.isInvisible()) continue;
      Vec3d pos = p.getLerpedPos(partial).add(0, 1.2 + .12*Math.sin((p.age+partial)*.2), 0);
      double distance = pos.distanceTo(camera), range = s.number("distance");
      if (distance > range) continue;
      double alpha = s.number("opacity") * Math.min(1, (range-distance)/4);
      if (alpha <= .01) continue;
      matrices.push(); matrices.translate(pos.subtract(camera));
      Matrix4f matrix = matrices.peek().getPositionMatrix();
      Vec3d localCamera = camera.subtract(pos);
      double phase = t + (p.getId() & 15) * .13;
      for (int strand=0; strand<CrystalAnimationShape.strands(style); strand++) {
        int color = Colors.mix(s.color("color"), s.color("secondary"), strand/(double)Math.max(1,CrystalAnimationShape.strands(style)-1));
        double fade = CrystalAnimationShape.fade(style,strand,phase);
        CrystalAnimationShape.point(style,strand,0,phase,A);
        for (int i=1;i<=segments;i++) {
          CrystalAnimationShape.point(style,strand,i/(double)segments,phase,B);
          double taper=CrystalAnimationShape.taper(style,(i-.5)/segments);
          if (glow > .01) ribbon(out,matrix,localCamera,size,.06*taper,Colors.alpha(color,alpha*fade*glow*.2));
          ribbon(out,matrix,localCamera,size,.014*taper,Colors.alpha(color,alpha*fade));
          System.arraycopy(B,0,A,0,3); drawnSegments++;
        }
      }
      matrices.pop(); drawnCrystals++;
    }
    BUFFERS.draw();
  }
  private static void ribbon(VertexConsumer out, Matrix4f matrix, Vec3d camera, double size, double width, int color) {
    double ax=A[0]*size, ay=A[1]*size, az=A[2]*size, bx=B[0]*size, by=B[1]*size, bz=B[2]*size;
    double dx=bx-ax, dy=by-ay, dz=bz-az, cx=camera.x-(ax+bx)*.5, cy=camera.y-(ay+by)*.5, cz=camera.z-(az+bz)*.5;
    double sx=dy*cz-dz*cy, sy=dz*cx-dx*cz, sz=dx*cy-dy*cx;
    double length=Math.sqrt(sx*sx+sy*sy+sz*sz);
    if (length < 1e-8) return;
    double scale=width*size/length; sx*=scale; sy*=scale; sz*=scale;
    out.vertex(matrix,(float)(ax-sx),(float)(ay-sy),(float)(az-sz)).color(color);
    out.vertex(matrix,(float)(ax+sx),(float)(ay+sy),(float)(az+sz)).color(color);
    out.vertex(matrix,(float)(bx+sx),(float)(by+sy),(float)(bz+sz)).color(color);
    out.vertex(matrix,(float)(bx-sx),(float)(by-sy),(float)(bz-sz)).color(color);
  }
  private CrystalAnimations() {}
}
