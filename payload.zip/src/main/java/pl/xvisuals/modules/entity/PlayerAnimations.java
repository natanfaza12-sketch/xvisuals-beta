package pl.xvisuals.modules.entity;
import pl.xvisuals.XVisuals;
import pl.xvisuals.util.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.texture.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public final class PlayerAnimations {
 private static final Identifier WHITE=Identifier.of("xvisuals","textures/crafted/ribbon.png");
 private static boolean texture;
 public static void init(){}
 public static void render(MatrixStack matrices,OrderedRenderCommandQueue queue,PlayerEntityRenderState state){
   if(state instanceof pl.xvisuals.gui.screens.WearablePreview)return;
   var c=MinecraftClient.getInstance();var s=XVisuals.visualModule("enemyanimations");
   if(!s.enabled||c.player==null||state.invisible||state.spectator)return;
   boolean self=state.id==c.player.getId();String scope=s.text("scope");
   if(self&&scope.equals("Other players")||!self&&scope.equals("My player")||state.squaredDistanceToCamera>s.number("distance")*s.number("distance"))return;
   int style=PlayerAnimationShapes.index(s.text("style")),primary=s.color("color"),secondary=s.color("secondary");
   double time=(c.world==null?0:c.world.getTime()+c.getRenderTickCounter().getTickProgress(false))/20*s.number("speed");
   if(XVisuals.config().module("performance").text("animation").equals("Off"))time=0;
   final double phase=time,opacity=s.number("opacity"),size=s.number("size");
   matrices.push();
   queue.submitCustom(matrices,RenderLayers.entityTranslucentEmissive(WHITE),(entry,out)->{
     double[] a=new double[3],b=new double[3];
     for(int strand=0;strand<PlayerAnimationShapes.strands(style);strand++)for(int i=0;i<32;i++){
       double u=i/32.;PlayerAnimationShapes.point(style,strand,u,phase,a);PlayerAnimationShapes.point(style,strand,(i+1)/32.,phase,b);
       int tint=Colors.alpha(Colors.mix(primary,secondary,.5+.5*Math.sin(u*3+phase)),opacity);
       double width=PlayerAnimationShapes.width(style,u);
       // Crossed strips provide visible thickness from both front and side views.
       for(int axis=0;axis<2;axis++)for(int winding=0;winding<2;winding++)for(int corner=0;corner<4;corner++){
         int n=winding==0?corner:3-corner;double[] p=n==1||n==2?b:a;double offset=n<2?-width:width;
         float x=(float)(p[0]*size+(axis==0?offset:0)),y=(float)(1.5-p[1]*size),z=(float)(p[2]*size+(axis==1?offset:0));
         out.vertex(entry.getPositionMatrix(),x,y,z).color(tint).texture(n<2?0:1,(float)(n==1||n==2?(i+1)/32.:u)).overlay(OverlayTexture.DEFAULT_UV).light(LightmapTextureManager.MAX_LIGHT_COORDINATE).normal(entry,0,0,1);
       }
     }
   });matrices.pop();
 }
 private PlayerAnimations(){}
}
