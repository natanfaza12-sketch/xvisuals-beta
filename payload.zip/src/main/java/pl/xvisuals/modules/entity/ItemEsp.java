package pl.xvisuals.modules.entity;

import pl.xvisuals.XVisuals;
import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.rendering.Projection;
import pl.xvisuals.util.Colors;
import java.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.ItemEntity;

/** Compact screen-space markers; nearby labels win when drops are crowded. */
public final class ItemEsp {
  private static final Projection.Point POINT = new Projection.Point();
  private static final List<EntityVisuals.Target> ITEMS = new ArrayList<>();
  private static final List<OverlayLayout.Rect> LABELS = new ArrayList<>();
  public static void render(DrawContext g, Projection projection) {
    ITEMS.clear(); LABELS.clear();
    var config = XVisuals.config();
    var options = config.module("items");
    for (var t : EntityVisuals.TARGETS) if (t.entity instanceof ItemEntity) ITEMS.add(t);
    // Preserve the distance order cached by EntityVisuals.
    for (var t : ITEMS) {
      var item = (ItemEntity)t.entity;
      var s = t.settings();
      if (!s.enabled || item.isRemoved() || item.getStack().isEmpty()
          || s.text("depth").equals("Visible Only") && !t.visible) continue;
      var pos = item.getLerpedPos(projection.tick);
      if (!projection.project(pos.x, pos.y + .22, pos.z, POINT) || !POINT.visible || POINT.depth < .5) continue;
      float x=(float)POINT.x, y=(float)POINT.y;
      double alpha=s.number("opacity")*(s.flag("fade") ? OverlayLayout.fade(t.distance,s.number("distance")) : 1);
      int color=Colors.alpha(s.color("color"),alpha);
      switch(options.text("style")) {
        case "Dot" -> Glass.dot(g,x,y+5,2,color,0);
        case "Underline" -> Glass.line(g,x-4,y+5,x+4,y+5,1,color);
        default -> {
          for(int side : new int[]{-1,1}) {
            Glass.line(g,x+side*5,y-2,x+side*5,y+4,1,color);
            Glass.line(g,x+side*5,y+4,x+side*2,y+4,1,color);
          }
        }
      }
      if (!options.flag("labels") || !config.on("nametags") || LABELS.size() >= 24) continue;
      var tags=config.module("nametags");
      if(t.distance>tags.number("distance") || tags.flag("depth") && !t.visible) continue;
      String suffix=options.flag("count") && item.getStack().getCount()>1 ? " ×"+item.getStack().getCount() : "";
      if(options.flag("showDistance")) suffix+=" · "+(int)t.distance+"m";
      String name=item.getStack().getName().getString();
      int available=Math.max(24,140-Glass.textWidth(suffix));
      if(Glass.textWidth(name)>available) name=MinecraftClient.getInstance().textRenderer
          .trimToWidth(Glass.label(name),available-Glass.textWidth("…")).getString()+"…";
      String label=name+suffix;
      float scale=(float)Math.clamp(options.number("labelScale"),.4,.85);
      float width=(Glass.textWidth(label)+10)*scale, height=14*scale;
      var rect=OverlayLayout.label(x,y-4,width,height,projection.width);
      if(rect.y()<2 || rect.y()+height>projection.height-2) continue;
      boolean overlaps=false;
      for(var prior:LABELS) if(prior.overlaps(rect)) {overlaps=true;break;}
      if(overlaps) continue;
      LABELS.add(rect);
      g.getMatrices().pushMatrix();
      g.getMatrices().translate(rect.x(),rect.y()); g.getMatrices().scale(scale,scale);
      Glass.rounded(g,0,0,width/scale,14,3,Colors.alpha(0x10141D,alpha*.60));
      Glass.text(g,label,5,3,Colors.alpha(0xF0F0F5,alpha));
      g.getMatrices().popMatrix();
    }
  }
  private ItemEsp() {}
}
