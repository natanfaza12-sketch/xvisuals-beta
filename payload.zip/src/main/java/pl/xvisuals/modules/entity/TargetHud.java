package pl.xvisuals.modules.entity;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import pl.xvisuals.XVisuals;
import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.gui.themes.Theme;

/** Target HUD (widget przeciagany w edytorze HUD). Style: Zenith i Round, wzorowane na Soup Visuals (SOUP-1.0, Padej_). */
public final class TargetHud {
  private static LivingEntity target;
  private static long lastSeen;
  private static float shown = 1f;
  private static float fade;

  public static void attacked(Entity entity) {
    if (entity instanceof LivingEntity living && XVisuals.ready() && XVisuals.config().on("targethud")) {
      target = living;
      lastSeen = System.currentTimeMillis();
    }
  }

  public static boolean round() { return XVisuals.config().module("targethud").text("style").equals("Round"); }
  public static int width() { return round() ? 128 : 104; }
  public static int height() { return round() ? 48 : 38; }

  /** Wywolywane co klatke: aktualizuje cel i animacje. */
  public static void render(DrawContext g) {
    if (!XVisuals.ready() || !XVisuals.config().on("targethud")) { fade = 0; return; }
    var s = XVisuals.config().module("targethud");
    MinecraftClient c = MinecraftClient.getInstance();
    if (c.player == null || c.world == null) return;
    long now = System.currentTimeMillis();
    if (c.targetedEntity instanceof LivingEntity looking) { target = looking; lastSeen = now; }
    LivingEntity t = target;
    boolean valid = t != null && t.isAlive() && !t.isRemoved() && now - lastSeen < s.number("hold") * 1000
        && (!s.flag("onlyPlayers") || t instanceof AbstractClientPlayerEntity);
    fade += ((valid ? 1f : 0f) - fade) * .2f;
  }

  public static void draw(DrawContext g, boolean editor) {
    var s = XVisuals.config().module("targethud");
    MinecraftClient c = MinecraftClient.getInstance();
    LivingEntity t = target;
    boolean real = fade >= .02f && t != null;
    if (!real && !editor) return;
    float f = real ? fade : 1f;
    float health = 20f, max = 20f;
    String name = "Player";
    if (real) { max = Math.max(1f, t.getMaxHealth()); health = Math.max(0f, t.getHealth()); name = t.getName().getString(); }
    shown += (health / max - shown) * .15f;
    float frac = Math.clamp(shown, 0f, 1f);
    int a = Math.round(255 * f);
    int accent = Theme.accent() & 0xFFFFFF;
    int bar = s.text("barColor").equals("Health") ? java.awt.Color.HSBtoRGB(.33f * frac, .75f, 1f) & 0xFFFFFF : accent;
    boolean rnd = round();
    int w = width(), h = height();
    var tr = c.textRenderer;
    Glass.rounded(g, 0, 0, w, h, rnd ? 10 : 6, (Math.round(a * .78f) << 24) | 0x0A0D14);
    int face = rnd ? 40 : 25;
    int fx = rnd ? 4 : 5, fy = rnd ? 4 : 6;
    if (real && t instanceof AbstractClientPlayerEntity p) PlayerSkinDrawer.draw(g, p.getSkin(), fx, fy, face);
    else Glass.rounded(g, fx, fy, face, face, rnd ? 8 : 5, (Math.round(a * .6f) << 24) | accent);
    if (real && t.hurtTime > 0) Glass.rounded(g, fx, fy, face, face, rnd ? 8 : 5, (Math.round(a * .35f) << 24) | 0xFF2020);
    int tx = rnd ? 48 : 34;
    int white = (a << 24) | 0xFFFFFF, grey = (Math.round(a * .75f) << 24) | 0xC8CCD8;
    int bw = rnd ? 68 : 61, bh = rnd ? 9 : 2;
    int textW = w - tx - 6;
    g.drawText(tr, tr.trimToWidth(name, textW), tx, rnd ? 9 : 8, white, true);
    String hp = rnd ? "HP: " + Math.round(health) : String.format("%.1f HP", health);
    if (s.flag("distance") && real) hp += "  " + String.format("%.1fm", c.player.distanceTo(t));
    g.drawText(tr, tr.trimToWidth(hp, textW), tx, rnd ? 22 : 17, grey, false);
    int by = rnd ? 34 : 28;
    Glass.rounded(g, tx, by, bw, bh, bh / 2f, (Math.round(a * .35f) << 24));
    Glass.rounded(g, tx, by, Math.max(bh, bw * frac), bh, bh / 2f, (a << 24) | bar);
  }

  private TargetHud() {}
}
