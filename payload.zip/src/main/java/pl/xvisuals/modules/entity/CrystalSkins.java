package pl.xvisuals.modules.entity;
/** Original surface palettes. Custom preserves existing saved colours and flow. */
public final class CrystalSkins {
 public record Skin(String name,int primary,int secondary) {}
 public static final Skin[] ALL={
  new Skin("Custom",0xFFB46CFF,0xFF64E9FF),
  new Skin("Aurora Glass",0xFF295478,0xFF78FFD1),
  new Skin("Crimson Circuit",0xFF470E29,0xFFFF557B),
  new Skin("Frost Prism",0xFF478FC0,0xFFDEF9FF),
  new Skin("Obsidian Gold",0xFF211D35,0xFFFFD279),
  new Skin("Rose Quartz",0xFF914A96,0xFFFFC9EA),
  new Skin("Solar Core",0xFFDB421E,0xFFFFE098),
  new Skin("Deep Cosmos",0xFF251958,0xFF84A5FF),
  new Skin("Prismatic",0xFF65EBDC,0xFFE497FF)};
 public static final String[] NAMES=java.util.Arrays.stream(ALL).map(Skin::name).toArray(String[]::new);
 public static int index(String name){for(int i=0;i<ALL.length;i++)if(ALL[i].name().equals(name))return i;return 0;}
 private CrystalSkins(){}
}
