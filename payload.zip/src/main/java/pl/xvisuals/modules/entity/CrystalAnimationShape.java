package pl.xvisuals.modules.entity;

/** Bounded local-space curves centred on an end crystal, independent of frame rate. */
public final class CrystalAnimationShape {
  public static final String[] STYLES = {"Off", "Orbit Rings", "Double Helix", "Pulse Waves", "Rune Cage",
      "Comet Trails", "Lotus", "Lightning Lattice", "Starburst"};
  public static int strands(int style) { return switch(style) { case 1 -> 3; case 2 -> 2; case 3 -> 4; case 4 -> 8; case 5 -> 5; case 6 -> 8; case 7 -> 6; case 8 -> 12; default -> 0; }; }
  public static double fade(int style,int strand,double t) {
    return style==3 ? Math.pow(Math.sin(Math.PI*((t*.45+strand*.25)%1)),2) : 1;
  }
  public static double taper(int style,double u) { return style>=5 ? .12+.88*Math.sin(Math.PI*u) : 1; }
  public static void point(int style,int strand,double u,double t,double[] p) {
    double a=u*Math.PI*2,x=0,y=0,z=0;
    switch(style) {
      case 1 -> { a+=t; double tilt=strand*Math.PI/3+t*.15; x=Math.cos(a)*1.1; y=Math.sin(a)*Math.sin(tilt)*1.1; z=Math.sin(a)*Math.cos(tilt)*1.1; }
      case 2 -> { a=u*Math.PI*4+t*1.7+strand*Math.PI; double r=.8+.15*Math.sin(u*Math.PI); x=Math.cos(a)*r; y=(u-.5)*2.4; z=Math.sin(a)*r; }
      case 3 -> { double f=(t*.45+strand*.25)%1,r=.35+f*1.45; x=Math.cos(a)*r; y=(f-.5)*.7; z=Math.sin(a)*r; }
      case 4 -> {
        if(strand<2) { double k=u*6,f=k-Math.floor(k),b=Math.floor(k)*Math.PI/3+t*.4;
          x=Math.cos(b)*(1-f)+Math.cos(b+Math.PI/3)*f; z=Math.sin(b)*(1-f)+Math.sin(b+Math.PI/3)*f; y=strand==0?-.85:.85;
        } else { a=(strand-2)*Math.PI/3+t*.4; x=Math.cos(a); z=Math.sin(a); y=(u-.5)*1.7; }
      }
      case 5 -> { a=t*2.2+strand*Math.PI*2/5-u*1.7; double tilt=strand*.8; x=Math.cos(a)*1.25; y=Math.sin(a)*Math.sin(tilt)*1.25; z=Math.sin(a)*Math.cos(tilt)*1.25; }
      case 6 -> { double r=Math.sin(u*Math.PI)*1.4,b=strand*Math.PI/4+t*.3; x=Math.cos(b)*r; z=Math.sin(b)*r; y=-.55+Math.sin(u*Math.PI*2)*(.5+.15*Math.sin(t)); }
      case 7 -> { a=strand*Math.PI/3+t*.25; double k=u*12,f=k-Math.floor(k);
        double jag=(Math.sin(Math.floor(k)*17+strand+t*4)*(1-f)+Math.sin((Math.floor(k)+1)*17+strand+t*4)*f)*.18;
        x=Math.cos(a)*(.9+jag); z=Math.sin(a)*(.9+jag); y=(u-.5)*2;
      }
      case 8 -> { double b=strand*Math.PI*2/12+t*.45,r=.4+u*(.8+.25*Math.sin(t*2+strand)); x=Math.cos(b)*r; z=Math.sin(b)*r; y=Math.sin(strand*2.4+t)*u*.65; }
    }
    p[0]=x;p[1]=y;p[2]=z;
  }
  private CrystalAnimationShape() {}
}
