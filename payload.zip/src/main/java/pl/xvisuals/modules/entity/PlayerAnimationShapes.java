package pl.xvisuals.modules.entity;
/** Shared 3D paths for worn animations and gallery playback. Coordinates are player-local blocks. */
public final class PlayerAnimationShapes {
 public static final String[] ORIGINAL={"Contour","Shoulder Flares","Orbit Blades","Footwork","Prism Guard","Ribbon Wrap","Backdraft","Crescent Guard"};
 public static final String[] STYLES=ORIGINAL.clone();
 public static int index(String name){return Math.max(0,java.util.Arrays.asList(STYLES).indexOf(name));}
 public static int strands(int style){return switch(style){case 0->4;case 1->6;case 2->4;case 3->3;case 4->6;case 5->2;case 6->8;default->2;};}
 public static void point(int style,int strand,double u,double time,double[] p){
   double a=u*Math.PI*2,x=0,y=0,z=0;
   switch(style){
    case 0->{double side=strand%2==0?-1:1;x=side*(.34+.045*Math.sin(u*Math.PI));y=.30+u*1.1;z=(strand<2?-.21:.21)+.025*Math.sin(time*1.1+u*4);}
    case 1->{double side=strand<3?-1:1,f=strand%3;x=side*(.34+u*(.50-f*.11));y=1.35+Math.sin(u*Math.PI)*.18-u*.18;z=.08+u*.16+.025*Math.sin(time*1.4+f);}
    case 2->{a=strand*Math.PI/2+time*.6+(u-.5)*.35;double r=.57+Math.sin(u*Math.PI)*.10;x=Math.cos(a)*r;y=.7+(u-.5)*.43;z=Math.sin(a)*r;}
    case 3->{a=time*.75+strand*Math.PI*2/3+u*Math.PI*.48;x=Math.cos(a)*.48;y=.045+Math.sin(u*Math.PI)*.035;z=Math.sin(a)*.48;}
    case 4->{a=strand*Math.PI/3+time*.25;double d=1-Math.abs(u*2-1);x=Math.cos(a)*(.53+d*.10);y=.42+u*.56;z=Math.sin(a)*(.53+d*.10);}
    case 5->{a=time*.7+u*Math.PI*1.6+strand*Math.PI;x=Math.cos(a)*.49;y=.40+u*.7;z=Math.sin(a)*.49;}
    case 6->{double side=strand%2==0?-1:1,f=strand/2;x=side*(.15+u*(.65-f*.12));y=1.25-u*(.45+f*.13)+.035*Math.sin(time*1.2+u*4+f);z=.25+u*.24;}
    default->{a=-1.1+u*2.2;double side=strand==0?-1:1;x=side*(.37+Math.cos(a)*.30);y=.8+Math.sin(a)*.45;z=.04+.10*Math.sin(time*.65);}
   }
   p[0]=x;p[1]=y;p[2]=z;
 }
 public static double width(int style,double u){return (.25+.75*Math.sin(Math.PI*u))*(style==2||style==4?.022:.012);}
 private PlayerAnimationShapes(){}
}
