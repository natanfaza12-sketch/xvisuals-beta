package pl.xvisuals.modules.entity;

/** Bounded HUD layout rules shared by the renderer and regression tests. */
public final class OverlayLayout {
  public record Rect(float x, float y, float width, float height) {
    public boolean overlaps(Rect other) {
      return x < other.x + other.width + 3 && x + width + 3 > other.x
          && y < other.y + other.height + 3 && y + height + 3 > other.y;
    }
  }
  public static boolean usable(double x, double y, double w, double h, int screenW, int screenH) {
    return Double.isFinite(x + y + w + h) && w >= 2 && h >= 4 && w < screenW * .9
        && h < screenH * 1.6 && x < screenW && x + w > 0 && y < screenH && y + h > 0;
  }
  public static double fade(double distance, double range) {
    double t = Math.clamp((distance / Math.max(1, range) - .7) / .3, 0, 1);
    return 1 - t * t * (3 - 2 * t);
  }
  public static float labelScale(double requested, double distance) {
    return (float)(Math.clamp(requested, .55, 1.1) * (1 - .16 * Math.clamp(distance / 96, 0, 1)));
  }
  public static float health(double value, double max) {
    return Double.isFinite(value) && Double.isFinite(max) && max > 0 ? (float)Math.clamp(value / max, 0, 1) : 0;
  }
  public static Rect label(float center, float top, float width, float height, int screenWidth) {
    return new Rect(Math.clamp(center - width / 2, 3, Math.max(3, screenWidth - width - 3)),
        top - height - 6, width, height);
  }
  private OverlayLayout() {}
}
