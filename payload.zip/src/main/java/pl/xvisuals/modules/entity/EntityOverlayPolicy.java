package pl.xvisuals.modules.entity;

import pl.xvisuals.config.VisualConfig.ModuleState;
import java.util.Comparator;
import java.util.List;

/** Selection and label ownership shared by the entity overlay integration. */
public final class EntityOverlayPolicy {
  public static <T> void retainNearest(List<T> targets, Comparator<? super T> distance, int cap) {
    targets.sort(distance);
    int limit = Math.max(0, cap);
    if (targets.size() > limit) targets.subList(limit, targets.size()).clear();
  }

  public static boolean replacesLabel(ModuleState category, ModuleState tags, boolean item,
      double distance, boolean visible, boolean hudHidden) {
    return !hudHidden && category.enabled && tags.enabled
        && (!item || category.flag("labels"))
        && distance <= tags.number("distance")
        && (visible || !tags.flag("depth") && !category.text("depth").equals("Visible Only"));
  }

  private EntityOverlayPolicy() {}
}
