package pl.xvisuals.modules.entity;
import pl.xvisuals.XVisuals;
import pl.xvisuals.mixins.RenderLayerAccessor;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.texture.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.*;
import net.minecraft.block.*;
import java.util.*;

/** Native crystal material and depth-tested, face-attached anchor energy. */
public final class MaterialShaders {
 private static final Identifier PALETTE=Identifier.of("xvisuals","dynamic/material_palette");
 private static NativeImageBackedTexture palette;
 private static final BufferAllocator ALLOCATOR=new BufferAllocator(65536);
 private static final VertexConsumerProvider.Immediate BUFFERS=VertexConsumerProvider.immediate(ALLOCATOR);
 private static final Set<BlockPos> anchors=new HashSet<>();
 private static Object world;private static int cursor;private static BlockPos center;
 private static final RenderLayer CRYSTAL=layer(false),ANCHOR=layer(true);
 private static RenderLayer layer(boolean anchor){
  var builder=RenderPipeline.builder().withLocation(Identifier.of("xvisuals","pipeline/material_"+anchor))
   .withVertexShader(Identifier.of("xvisuals","core/material"))
   .withFragmentShader(Identifier.of("xvisuals","core/material"))
   .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER)
   .withSampler("Sampler0").withSampler("Palette").withSampler("Artwork")
   .withVertexFormat(VertexFormats.POSITION_COLOR_TEXTURE_OVERLAY_LIGHT_NORMAL,VertexFormat.DrawMode.QUADS)
   .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withDepthWrite(!anchor).withCull(false);
  if(anchor)builder.withBlend(BlendFunction.TRANSLUCENT);
  return RenderLayerAccessor.visuals$of("material_"+anchor,RenderSetup.builder(builder.build())
   .texture("Sampler0",Identifier.ofVanilla("textures/entity/end_crystal/end_crystal.png"))
   .texture("Artwork",Identifier.of("xvisuals","textures/crafted/"+(anchor?"anchors":"crystals")+".png")).texture("Palette",PALETTE).expectedBufferSize(65536).build());
 }
 public static RenderLayer crystal(RenderLayer original){
  if(!XVisuals.ready()||!XVisuals.config().on("crystals"))return original;
  updatePalette();return CRYSTAL;
 }
 private static long paletteFrame=Long.MIN_VALUE;
 private static void updatePalette(){
  var c=MinecraftClient.getInstance();long frame=net.minecraft.util.Util.getMeasuringTimeMs()/16;
  if(frame==paletteFrame)return;paletteFrame=frame;
  if(palette==null){palette=new NativeImageBackedTexture(()->"Material colours",new NativeImage(4,2,false));c.getTextureManager().registerTexture(PALETTE,palette);}
  double time=c.world==null?0:(c.world.getTime()+c.getRenderTickCounter().getTickProgress(false))/20d;
  for(int row=0;row<2;row++){
   var m=XVisuals.config().module(row==0?"crystals":"anchorshader");var img=palette.getImage();
   int skin=row==0?CrystalSkins.index(m.text("skin")):0;
   boolean preset=skin>0&&!m.flag("customColors");
   img.setColorArgb(0,row,preset?CrystalSkins.ALL[skin].primary():m.color("color"));
   img.setColorArgb(1,row,preset?CrystalSkins.ALL[skin].secondary():m.color("secondary"));
   // Quantised phase wraps at a full cycle, so long sessions cannot lose shader precision.
   int phase=row==0&&(!m.flag("animated")||XVisuals.config().module("performance").text("animation").equals("Off"))?0:(int)(time*m.number("speed")*.2%1*65535);
   img.setColorArgb(2,row,0xFF000000|((phase>>8)&255)<<16|(phase&255)<<8);
   if(row==1){
    int style=Math.max(0,java.util.List.of("Void Well","Solar Forge","Glacial Prism","Crimson Eclipse","Aurora Glass","Chrono Circuit").indexOf(m.text("style")));
    img.setColorArgb(3,row,0xFF000000|(style<<16)|((m.flag("customColors")?255:0)<<8)|(int)(Math.clamp(m.number("brightness"),.3,2)/2*255));
   }else img.setColorArgb(3,row,0xFF000000|(skin<<16));
  }
  palette.upload();
 }
 public static void init(){
  net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.END_CLIENT_TICK.register(c->{
   if(world!=c.world){world=c.world;anchors.clear();cursor=0;center=null;}
   if(c.world==null||c.player==null||!XVisuals.config().on("anchorshader")){anchors.clear();center=null;cursor=0;return;}
   BlockPos next=c.player.getBlockPos();
   if(center==null||center.getSquaredDistance(next)>64){anchors.clear();cursor=0;center=next;}
   anchors.removeIf(p->!c.world.isChunkLoaded(p.getX()>>4,p.getZ()>>4)||p.getSquaredDistance(next)>32*32||!c.world.getBlockState(p).isOf(Blocks.RESPAWN_ANCHOR));
   var pos=new BlockPos.Mutable();
   // Nearby placements are visible on the next tick instead of waiting for the full scan.
   for(int dx=-4;dx<=4;dx++)for(int dy=-4;dy<=4;dy++)for(int dz=-4;dz<=4;dz++){
    pos.set(next.getX()+dx,next.getY()+dy,next.getZ()+dz);
    if(c.world.isChunkLoaded(pos.getX()>>4,pos.getZ()>>4)&&c.world.getBlockState(pos).isOf(Blocks.RESPAWN_ANCHOR))anchors.add(pos.toImmutable());
   }
   for(int i=0;i<2048;i++){int n=cursor++%(33*33*33);pos.set(center.getX()+n%33-16,center.getY()+n/1089-16,center.getZ()+n/33%33-16);
    if(c.world.isChunkLoaded(pos.getX()>>4,pos.getZ()>>4)&&c.world.getBlockState(pos).isOf(Blocks.RESPAWN_ANCHOR))anchors.add(pos.toImmutable());}
  });
  net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents.END_MAIN.register(ctx->{
   var c=MinecraftClient.getInstance();if(c.world==null||!XVisuals.config().on("anchorshader")||anchors.isEmpty())return;
   updatePalette();var out=BUFFERS.getBuffer(ANCHOR);var matrices=ctx.matrices();var camera=c.gameRenderer.getCamera().getCameraPos();
   for(var p:anchors.stream().sorted(java.util.Comparator.comparingDouble(p->p.getSquaredDistance(c.player.getBlockPos()))).limit(128).toList()){var state=c.world.getBlockState(p);if(!state.isOf(Blocks.RESPAWN_ANCHOR))continue;int charge=state.get(RespawnAnchorBlock.CHARGES);
    matrices.push();matrices.translate(p.getX()-camera.x,p.getY()-camera.y,p.getZ()-camera.z);
    for(var side:Direction.values()){
     if(c.world.getBlockState(p.offset(side)).isOpaqueFullCube())continue;
     var normal=side.getDoubleVector();var u=side.getAxis()==Direction.Axis.Y?new Vec3d(1,0,0):new Vec3d(-normal.z,0,normal.x);var v=normal.crossProduct(u);
     var face=new Vec3d(.5,.5,.5).add(normal.multiply(.502));
     for(int k=0;k<4;k++){double a=k==0||k==3?-.5:.5,b=k<2?-.5:.5;var q=face.add(u.multiply(a)).add(v.multiply(b));
      out.vertex(matrices.peek().getPositionMatrix(),(float)q.x,(float)q.y,(float)q.z).color(255,255,255,255).texture((float)(a+.5),(float)(b+.5))
       .overlay(charge,1).light(15728880).normal(matrices.peek(),(float)normal.x,(float)normal.y,(float)normal.z);}
    }matrices.pop();
   }BUFFERS.draw();
  });
  net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING.register(c->ALLOCATOR.close());
 }
 private MaterialShaders(){}
}
