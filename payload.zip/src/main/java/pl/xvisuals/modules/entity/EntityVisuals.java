package pl.xvisuals.modules.entity;

import pl.xvisuals.XVisuals;
import pl.xvisuals.config.VisualConfig;
import pl.xvisuals.rendering.*;
import pl.xvisuals.util.Colors;
import java.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.*;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.RaycastContext;

public final class EntityVisuals {
  public static final List<Target> TARGETS = new ArrayList<>();
  private static final Map<Entity, Target> INDEX = new IdentityHashMap<>();
  private static Object world;
  private static int ticks;
  private static final Set<Entity> ALIVE = Collections.newSetFromMap(new IdentityHashMap<>());
  private static final String[] CATEGORIES = {"items",
      "projectiles", "crystals", "hostile"};

  public static final class Target {
    public Entity entity;
    public String module, label;
    public double distance;
    public boolean visible, occlusionChecked;
    public int color;

    Target(Entity entity, String module) {
      this.entity = entity;
      this.module = module;
    }

    public VisualConfig.ModuleState settings() {
      return XVisuals.config().module(module);
    }
  }

  public static void tick(MinecraftClient c) {
    if (c.world != world) {
      world = c.world;
      INDEX.clear();
      TARGETS.clear();
    }
    if (c.world == null || c.player == null) { INDEX.clear(); TARGETS.clear(); ALIVE.clear(); return; }
    ticks++;
    TARGETS.clear();
    ALIVE.clear();
    boolean enabled = false;
    for (String id : CATEGORIES) enabled |= XVisuals.config().on(id);
    if (!enabled) { INDEX.clear(); return; }
    int cap = Quality.entityCap();
    for (Entity e : c.world.getEntities()) {
      if (e instanceof PlayerEntity) continue;
      if (e == c.player || e.isRemoved()) continue;
      String id = category(e);
      if (id == null || !XVisuals.config().on(id)) continue;
      var s = XVisuals.config().module(id);
      double distanceSquared = c.player.squaredDistanceTo(e);
      double limit = s.number("distance");
      if (distanceSquared > limit * limit) continue;
      double distance = Math.sqrt(distanceSquared);
      Target t = INDEX.computeIfAbsent(e, k -> new Target(e, id));
      t.module = id;
      t.distance = distance;
      TARGETS.add(t);
    }
    // World iteration order is unrelated to distance. Apply the budget only after
    // selecting nearby targets, and reserve raycasts and label work for that set.
    EntityOverlayPolicy.retainNearest(TARGETS, Comparator.comparingDouble(t -> t.distance), cap);
    for (Target t : TARGETS) {
      Entity e = t.entity;
      var s = t.settings();
      var names = XVisuals.config().module("nametags");
      boolean needsOcclusion = s.text("depth").equals("Visible Only") || names.enabled && names.flag("depth");
      if (!needsOcclusion) { t.visible = true; t.occlusionChecked=false; }
      else if (ticks % 4 == 0 || !t.occlusionChecked) {
        t.visible = visible(c, e.getEntityPos().add(0, e.getHeight() * .55, 0));
        t.occlusionChecked=true;
      }
      t.color = color(t);
      if (ticks % 10 == 0 || t.label == null) t.label = label(c, t);
      ALIVE.add(e);
    }
    INDEX.keySet().retainAll(ALIVE);
    ALIVE.clear();
  }

  public static boolean visible(MinecraftClient c, Vec3d point) {
    return c.world
            .raycast(
                new RaycastContext(
                    c.gameRenderer.getCamera().getCameraPos(),
                    point,
                    RaycastContext.ShapeType.COLLIDER,
                    RaycastContext.FluidHandling.NONE,
                    c.player))
            .getType()
        == HitResult.Type.MISS;
  }

  public static Target target(Entity e) {
    return INDEX.get(e);
  }

  public static boolean shouldGlow(Entity e) {
    var c = MinecraftClient.getInstance();
    if (c.world == null || e.getEntityWorld() != c.world) return false;
    if (e == c.player)
      return XVisuals.visualModule("playerfx").enabled
          && XVisuals.visualModule("playerfx").flag("outline");
    Target t = INDEX.get(e);
    if (t == null) return false;
    if (e instanceof ItemEntity) return false;
    var s = t.settings();
    if (!s.enabled || s.text("depth").equals("Visible Only") && !t.visible) return false;
    return switch (s.text("style")) {
      case "Glow Outline",
              "Neon Outline",
              "Filled Glow",
              "Soft Aura",
              "Soft Outline",
              "Pulse",
              "Chromatic",
              "Gradient" ->
          true;
      default -> false;
    };
  }

  public static int glowColor(Entity e) {
    Target t = INDEX.get(e);
    return t == null ? XVisuals.visualModule("playerfx").color("color") : t.color;
  }

  public static int color(Target t) {
    var s = t.settings();
    double time = System.nanoTime() / 1e9;
    return switch (s.text("style")) {
      case "Chromatic" -> Colors.rainbow(time * .08 * s.number("speed") + t.entity.getId() * .017);
      case "Pulse" ->
          Colors.mix(
              0xFF252132, s.color("color"), .6 + .4 * Math.sin(time * s.number("pulse") * 3));
      case "Gradient" ->
          Colors.mix(
              s.color("color"),
              s.color("secondary"),
              s.text("gradient").equals("Animated")
                  ? .5 + .5 * Math.sin(time * s.number("speed"))
                  : t.distance / Math.max(1, s.number("distance")));
      default -> s.color("color");
    };
  }

  private static String category(Entity e) {
    if (e instanceof ItemEntity) return "items";

    if (e instanceof ProjectileEntity) return "projectiles";
    if (e.getType()==EntityType.END_CRYSTAL) return null;
    if (e instanceof Monster) return "hostile";
    return null;
  }

  private static String label(MinecraftClient c, Target t) {
    var m = XVisuals.config().module("nametags");
    StringBuilder b = new StringBuilder(t.entity.getDisplayName().getString());
    if (m.flag("health") && t.entity instanceof LivingEntity l)
      b.append("  ").append(String.format(Locale.ROOT, "%.0f", l.getHealth())).append(" hp");
    if (m.flag("showDistance")) b.append("  ").append((int) t.distance).append("m");
    if (m.flag("ping") && t.entity instanceof PlayerEntity && c.getNetworkHandler() != null) {
      var entry = c.getNetworkHandler().getPlayerListEntry(t.entity.getUuid());
      if (entry != null) b.append("  ").append(entry.getLatency()).append("ms");
    }
    return b.toString();
  }

  private EntityVisuals() {}
}

