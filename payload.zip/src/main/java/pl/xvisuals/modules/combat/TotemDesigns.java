package pl.xvisuals.modules.combat;
import pl.xvisuals.XVisuals;
import java.util.Set;
public final class TotemDesigns {
 public static final String[] IMPORTED=new String[0];
 public static final Set<String> ANIMATED=Set.of("astral_oracle","ember_phoenix","tidal_guardian");
 public static String path(String name,double seconds,double speed,boolean animated){
  String id=name.toLowerCase(java.util.Locale.ROOT).replace(' ','_');
  if(!ANIMATED.contains(id))return id;
  int frame=animated&&Double.isFinite(seconds)&&Double.isFinite(speed)?Math.floorMod((long)Math.floor(seconds*8*speed),16):0;
  return id+"/"+frame;
 }
 public static String path(String name){
  var s=XVisuals.config().module("totemtexture");
  return path(name,net.minecraft.util.Util.getMeasuringTimeMs()/1000.,s.number("modelSpeed"),s.flag("animatedModels")&&!XVisuals.config().module("performance").text("animation").equals("Off"));
 }
 private TotemDesigns(){}
}
