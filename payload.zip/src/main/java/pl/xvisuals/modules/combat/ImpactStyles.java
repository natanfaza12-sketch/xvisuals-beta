package pl.xvisuals.modules.combat;
import java.util.List;
import net.minecraft.util.Identifier;
/** Shared asset-backed impact choreography. No procedural glyph or stroke effects. */
public final class ImpactStyles {
 public static final List<String> HITS=List.of("Ember Bloom","Glacier Break","Sakura Snap","Violet Rift","Golden Comet","Tidal Crash","Ruby Shatter","Spectral Wings","Storm Burst","Roseflare","Prism Pop","Moonfall");
 public static final List<String> CRITS=HITS;
 private static final Identifier[] TEXTURES=HITS.stream().map(s->Identifier.of("xvisuals","textures/hit_effects/"+asset(s)+".png")).toArray(Identifier[]::new);
 public record Point(double x,double y,double z){}
 public static int hit(String s){return Math.max(0,HITS.indexOf(s));}
 public static int crit(String s){return Math.max(0,CRITS.indexOf(s));}
 public static String asset(String s){return s.toLowerCase(java.util.Locale.ROOT).replace(' ','_');}
 public static Identifier texture(String s){return TEXTURES[hit(s)];}
 public static int frame(double t){return (int)Math.floor(Math.pow(Math.clamp(Double.isFinite(t)?t:0,0,1),.62)*23.999);}
 public static double opacity(double t){return t<=0||t>=1?0:Math.min(1,t*40)*Math.min(1,(1-t)*3.5);}
 public static double rotation(int style,double t){return switch(style){case 2,7,9->Math.sin(t*4)*.3;case 3,4,10->t*.65;case 5,11->-t*.3;default->t*.12;};}
 public static Point particle(int style,int i,int count,double t){
  t=Math.clamp(t,0,1);if(i==0)return new Point(0,t*.05,0);double a=i*2.399963+style*.31,r=(1-Math.pow(1-t,2))*(.22+i*.06);
  double x=Math.cos(a)*r,y=Math.sin(a)*r,z=Math.sin(a*1.7)*r*.45;
  switch(style){
   case 0->y+=t*.24;
   case 1->y-=t*t*.3;
   case 2->{x+=Math.sin(t*5+a)*t*.12;y-=t*.15;}
   case 3->{x*=1-t*.5;z+=t*.15;}
   case 4->{x+=t*.25;y+=t*.2;}
   case 5->{x*=1.25;y-=t*t*.2;}
   case 6->{x*=.8;y-=t*t*.4;}
   case 7->{x+=Math.sin(t*7+a)*.08*t;y+=t*.32;}
   case 8->{y*=1.4;z*=.5;}
   case 9->{x+=Math.sin(t*3+a)*t*.1;y+=Math.sin(t*Math.PI)*.12;}
   case 10->{z*=1.8;y+=t*.12;}
   case 11->{x-=t*.12;y-=t*.22;}
  }
  return new Point(x,y,z);
 }
 public static Point criticalParticle(int style,int i,int count,double t){var p=particle(style,i,count,t);return new Point(p.x()*1.4,p.y()*1.3,p.z()*1.4);}
 private ImpactStyles(){}
}
