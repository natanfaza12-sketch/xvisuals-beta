package pl.xvisuals.modules.combat;

import pl.xvisuals.XVisuals;
import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.util.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public final class AttackIndicator {
  private AttackIndicator() {}
  public static boolean enabled() {return XVisuals.ready() && XVisuals.config().on("attackindicator");}
  public static void render(DrawContext g,float tickDelta) {
    var c=MinecraftClient.getInstance();
    boolean editing=c.currentScreen instanceof pl.xvisuals.gui.screens.StudioScreen studio && studio.editingAttackIndicator()
        || pl.xvisuals.gui.world.WorldStudio.active() && pl.xvisuals.gui.world.WorldStudio.screen().editingAttackIndicator();
    if(editing){preview(g);return;}
    if(c.currentScreen!=null || c.getOverlay()!=null || pl.xvisuals.gui.world.WorldStudio.active()) return;
    if(!enabled() || c.player==null || c.world==null || c.options.hudHidden || c.player.isSpectator()
        || !c.options.getPerspective().isFirstPerson()) return;
    var s=XVisuals.config().module("attackindicator");
    float charge=Math.clamp(c.player.getAttackCooldownProgress(tickDelta),0,1);
    if(s.flag("hideReady") && charge>=1) return;
    paint(g,charge);
  }
  public static void preview(DrawContext g){paint(g,(float)(.15+.85*(System.nanoTime()/1e9%2.4)/2.4));}
  private static void paint(DrawContext g,float charge){
    var s=XVisuals.config().module("attackindicator");
    boolean hotbar=s.text("position").equals("Hotbar");
    float x=g.getScaledWindowWidth()/2f+(hotbar?104:0)+(float)s.number("offsetX");
    float y=(hotbar?g.getScaledWindowHeight()-20:g.getScaledWindowHeight()/2f+22)+(float)s.number("offsetY");
    g.getMatrices().pushMatrix();g.getMatrices().translate(x,y);
    g.getMatrices().rotate((float)Math.toRadians(s.number("rotation")));
    float size=(float)s.number("scale");
    g.getMatrices().scale(s.flag("flipX")?-size:size,s.flag("flipY")?-size:size);
    draw(g,s.text("style"),charge,Colors.alpha(s.color(charge>=1?"readyColor":"color"),s.number("opacity")),
        Colors.alpha(s.color("background"),s.number("opacity")*.65),s.flag("reverseFill"));
    g.getMatrices().popMatrix();
  }
  public static void draw(DrawContext g,String style,float charge,int ink,int empty) {
    draw(g,style,charge,ink,empty,false);
  }
  public static void draw(DrawContext g,String style,float charge,int ink,int empty,boolean reverse) {
    charge=Float.isFinite(charge)?Math.clamp(charge,0,1):0;
    int faint=Colors.alpha(ink,(ink>>>24)/255.0*.22);
    switch(style) {
      case "Hairline" -> {
        track(g,new double[][]{{-14,0},{14,0}},1.4,charge,ink,empty,reverse);
        box(g,-15,-2,1,4,.5f,faint);box(g,14,-2,1,4,.5f,faint);
      }
      case "Split Bar" -> {
        for(int side:new int[]{-1,1})track(g,new double[][]{{side*2,0},{side*15,0}},2,charge,ink,empty,reverse);
      }
      case "Segments" -> {
        for(int i=0;i<7;i++){
          float fill=Math.clamp(charge*7-(reverse?6-i:i),0,1);
          box(g,-13.5f+i*4,-2,3,4,.75f,empty);
          if(fill>0)box(g,-13.5f+i*4+(reverse?3*(1-fill):0),-2,3*fill,4,.75f,ink);
        }
      }
      case "Arc" -> arc(g,10,35,290,1.5,charge,ink,empty,reverse);
      case "Twin Arcs" -> {
        arc(g,10,-65,130,1.5,charge,ink,empty,reverse);
        arc(g,10,115,130,1.5,charge,ink,empty,reverse);
      }
      case "Diamond" -> track(g,new double[][]{{0,-10},{9,0},{0,10},{-9,0},{0,-10}},1.4,charge,ink,empty,reverse);
      case "Brackets" -> {
        for(int side:new int[]{-1,1})track(g,new double[][]{{side*5,7},{side*10,7},{side*10,-7},{side*5,-7}},1.5,charge,ink,empty,reverse);
      }
      case "Chevron" -> {
        for(int i=0;i<3;i++){
          float fill=Math.clamp(charge*3-(reverse?2-i:i),0,1);
          track(g,new double[][]{{-10+i*8,-5},{-5+i*8,0},{-10+i*8,5}},1.8,fill,ink,empty,reverse);
        }
      }
      case "Battery" -> {
        box(g,-12,-6,22,12,3,empty);
        pl.xvisuals.rendering.shaders.SdfRenderer.rect(g,-12,-6,22,12,3,faint,22);
        box(g,10,-2,2,4,1,ink);
        for(int i=0;i<5;i++) {
          float x=-9+i*3.5f,fill=Math.clamp(charge*5-(reverse?4-i:i),0,1);
          box(g,x,-3,2.5f,6,.8f,faint);
          if(fill>0)box(g,x,3-6*fill,2.5f,6*fill,.8f,ink);
        }
      }
      case "Ring" -> {
        for(int i=0;i<96;i++) {
          double angle=(reverse?-1:1)*i*Math.PI*2/96-Math.PI/2;
          float fill=Math.clamp(charge*96-i,0,1);
          Glass.dot(g,Math.cos(angle)*8,Math.sin(angle)*8,1.7,fill>0?ink:faint,0);
        }
        if(charge>0){double angle=(reverse?-1:1)*charge*Math.PI*2-Math.PI/2;
          Glass.dot(g,Math.cos(angle)*8,Math.sin(angle)*8,2.4,ink,0);}
      }
      case "Lightning bolt", "Sword" -> {
        // Half-pixel silhouette sampling keeps diagonals clean at larger HUD scales.
        for(int py=0;py<40;py++)for(int px=0;px<28;px++) {
          double x=(px+.5)/2.,y=(py+.5)/2.;
          if(!AttackIndicatorShape.contains(style,x,y))continue;
          box(g,px*.5f-7,py*.5f-10,.5f,.5f,0,faint);
          float fill=Math.clamp(charge*40-(reverse?py:39-py),0,1);
          if(fill>0)box(g,px*.5f-7,py*.5f-10+(reverse?0:(1-fill)*.5f),.5f,fill*.5f,0,ink);
        }
      }
      default -> {
        box(g,-14,-3.5f,28,7,3.5f,empty);
        pl.xvisuals.rendering.shaders.SdfRenderer.rect(g,-14,-3.5f,28,7,3.5f,faint,22);
        box(g,-12,-1.5f,24,3,1.5f,faint);
        if(charge>0)box(g,reverse?12-24*charge:-12,-1.5f,24*charge,3,1.5f,ink);
      }
    }
  }
  private static void arc(DrawContext g,double radius,double start,double sweep,double thickness,float charge,int ink,int empty,boolean reverse){
    double[][] points=new double[65][2];
    for(int i=0;i<points.length;i++){double a=Math.toRadians(start+sweep*i/64.);points[i][0]=Math.cos(a)*radius;points[i][1]=Math.sin(a)*radius;}
    track(g,points,thickness,charge,ink,empty,reverse);
  }
  private static void track(DrawContext g,double[][] points,double thickness,float charge,int ink,int empty,boolean reverse){
    double total=0;
    for(int i=1;i<points.length;i++)total+=Math.hypot(points[i][0]-points[i-1][0],points[i][1]-points[i-1][1]);
    double remaining=total*charge;
    for(int i=1;i<points.length;i++){
      int a=reverse?points.length-i:i-1,b=reverse?points.length-i-1:i;
      double x=points[a][0],y=points[a][1],dx=points[b][0]-x,dy=points[b][1]-y,length=Math.hypot(dx,dy);
      Glass.line(g,x,y,x+dx,y+dy,thickness,empty);
      double fill=length==0?0:Math.clamp(remaining/length,0,1);
      if(fill>0)Glass.line(g,x,y,x+dx*fill,y+dy*fill,thickness,ink);
      remaining-=length;
    }
  }
  private static void box(DrawContext g,float x,float y,float w,float h,float r,int color) {
    Glass.rounded(g,x,y,w,h,r,color);
  }
}
