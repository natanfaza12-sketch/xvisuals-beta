package pl.xvisuals.modules.combat;

import java.util.Locale;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

/** Local-only equipment; copying never transfers or changes the player's inventory. */
public final class FakePlayerEquipment {
  private FakePlayerEquipment() {}

  public static ItemStack stack(String choice, EquipmentSlot slot, ItemStack own, int totems) {
    if ("Copy mine".equals(choice)) return own.copy();
    if ("Auto totem".equals(choice))
      return totems > 0 ? new ItemStack(Items.TOTEM_OF_UNDYING) : ItemStack.EMPTY;
    if (choice == null || choice.isBlank() || "None".equals(choice)) return ItemStack.EMPTY;
    String id = switch (choice) {
      case "Elytra" -> "elytra";
      case "Turtle" -> "turtle_helmet";
      case "Totem" -> "totem_of_undying";
      default -> {
        String material = choice.toLowerCase(Locale.ROOT).replace(' ', '_');
        if (material.equals("gold")) material = "golden";
        yield material + switch (slot) {
          case HEAD -> "_helmet"; case CHEST -> "_chestplate";
          case LEGS -> "_leggings"; case FEET -> "_boots"; default -> "";
        };
      }
    };
    var identifier = Identifier.tryParse("minecraft:" + id);
    if (identifier == null || !Registries.ITEM.containsId(identifier)) return ItemStack.EMPTY;
    return new ItemStack(Registries.ITEM.get(identifier));
  }
}
