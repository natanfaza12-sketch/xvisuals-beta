package pl.xvisuals.modules.combat;
import java.util.List;
import pl.xvisuals.util.Colors;
public final class VanillaTotemEyes {
 public static List<Integer> colors(String mode,int a,int b,double time){
   double phase=Double.isFinite(time)?time*.2:0;
   return switch(mode){
     case "Gradient" -> List.of(a,b);
     case "Animated gradient" -> List.of(Colors.mix(a,b,.5+.5*Math.sin(phase*Math.PI*2)),Colors.mix(a,b,.5-.5*Math.sin(phase*Math.PI*2)));
     case "Rainbow" -> List.of(Colors.rainbow(phase),Colors.rainbow(phase+.12));
     default -> List.of(a,a);
   };
 }
 private VanillaTotemEyes(){}
}
