package pl.xvisuals.modules.combat;

/** A recent attack's observed health loss, never an estimate based on weapon or animation. */
final class ObservedDamage {
  private final double baseline;
  private double amount;

  ObservedDamage(double health, double absorption) {
    baseline = total(health, absorption);
  }

  double observe(double health, double absorption) {
    double current = total(health, absorption);
    if (Double.isFinite(baseline) && Double.isFinite(current))
      amount = Math.max(amount, Math.max(0, baseline - current));
    return amount;
  }

  private static double total(double health, double absorption) {
    return Double.isFinite(health) && Double.isFinite(absorption)
        ? Math.max(0, health) + Math.max(0, absorption)
        : Double.NaN;
  }
}
