package pl.xvisuals.modules.combat;

public final class AttackIndicatorShape {
  private AttackIndicatorShape() {}
  public static boolean filled(String style,int x,int y) {
    return contains(style,x+.5,y+.5);
  }
  public static boolean contains(String style,double x,double y) {
    if(style.equals("Sword")) return y<3 ? Math.abs(x-6)<=y : y<13 ? x>=4&&x<=8
        : y<15 ? x>=1&&x<=11 : y<19 ? x>=5&&x<=7 : x>=4&&x<=8;
    int[] vx={8,1,6,4,13,8}, vy={0,11,11,20,8,8};
    double px=x,py=y;boolean inside=false;
    for(int i=0,j=5;i<6;j=i++) if((vy[i]>py)!=(vy[j]>py)
        && px<(double)(vx[j]-vx[i])*(py-vy[i])/(vy[j]-vy[i])+vx[i]) inside=!inside;
    return inside;
  }
}
