package pl.xvisuals.modules.combat;

/** Bounded, stratified burst shapes and continuous particle envelopes. */
public final class TotemBurstMotion {
  private TotemBurstMotion() {}

  public record Sample(double x, double height, double z, double vx, double vy, double vz) {}

  public static Sample sample(String pattern, int index, int count, double spread, double jitter) {
    double t = (index + .5) / Math.max(1, count);
    double angle = index * 2.399963229728653 + (jitter - .5) * .22;
    double radius = .42, y = .12 + .73 * t, outward = .8, up = .55 + .45 * jitter, tangent = 0;
    switch (pattern) {
      case "Bloom" -> {
        double latitude = Math.acos(1 - 2 * t);
        radius = .35 + .3 * Math.sin(latitude);
        y = .48 + .32 * Math.cos(latitude);
        outward = 1.1 * Math.sin(latitude);
        up = .25 + .8 * Math.cos(latitude);
      }
      case "Helix" -> {
        angle = t * Math.PI * 5 + (index % 2) * Math.PI;
        radius = .55;
        y = .08 + .78 * t;
        outward = .22;
        tangent = .8;
        up = .65;
      }
      case "Halo" -> {
        angle = t * Math.PI * 2;
        radius = .65;
        y = .55 + .035 * (jitter - .5);
        outward = 1.15;
        up = .18;
      }
      case "Fountain" -> {
        radius = .3 + .15 * jitter;
        y = .12 + .12 * t;
        outward = .35 + .35 * jitter;
        up = 1.25 + .6 * t;
      }
      case "Nova" -> {
        // Six radial spokes with stratified lengths form a sharp starburst.
        angle = (index % 6) * Math.PI / 3;
        radius = .15 + .5 * t;
        y = .45 + .12 * Math.sin(t * Math.PI * 2);
        outward = .35 + .85 * t;
        up = .1;
      }
      case "Vortex" -> {
        angle = t * Math.PI * 8;
        radius = .15 + .5 * t;
        y = .1 + .8 * t;
        outward = -.3;
        tangent = 1.05;
        up = .3 + .6 * (1 - t);
      }
      case "Wings" -> {
        // Paired fans rise and spread to either side of the player.
        double feather = (index / 2 + .5) / Math.max(1, (count + 1) / 2);
        angle = (index % 2 == 0 ? 0 : Math.PI) + (jitter - .5) * .15;
        radius = .18 + .47 * feather;
        y = .2 + .65 * Math.sin(feather * Math.PI * .8);
        outward = .4 + .7 * feather;
        up = .3 + .9 * Math.sin(feather * Math.PI);
      }
      default -> {}
    }
    double s = Double.isFinite(spread) ? Math.clamp(spread, .3, 2) : 1;
    double c = Math.cos(angle), n = Math.sin(angle);
    return new Sample(
        c * radius * s,
        y,
        n * radius * s,
        (c * outward - n * tangent) * s,
        up,
        (n * outward + c * tangent) * s);
  }

  public static float opacity(float progress, float strength, boolean twinkle, float phase) {
    float p = Math.clamp(progress, 0, 1);
    float enter = smooth(p / .07f), leave = 1 - smooth((p - .28f) / .72f);
    float shimmer = twinkle ? .84f + .16f * (float) Math.sin(p * Math.PI * 6 + phase) : 1;
    return Math.clamp(strength, 0, 1) * enter * leave * shimmer;
  }

  public static float size(float progress) {
    float p = Math.clamp(progress, 0, 1);
    return (.65f + .35f * smooth(p / .12f)) * (1 - .7f * smooth((p - .35f) / .65f));
  }

  private static float smooth(float v) {
    float t = Math.clamp(v, 0, 1);
    return t * t * (3 - 2 * t);
  }
}
