package pl.xvisuals.modules.combat;

import pl.xvisuals.XVisuals;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.minecraft.client.particle.*;
import net.minecraft.client.world.ClientWorld;

/** Neutral sprites keep every GUI colour accurate, including blue/green hearts. */
public final class TotemBurstParticle extends BillboardParticle
    implements TotemVisuals.TunableParticle {
  private final float opacity;
  private final boolean twinkle, bright;
  private final float phase;

  private TotemBurstParticle(
      ClientWorld world, double x, double y, double z, SpriteProvider sprites) {
    super(
        world,
        x,
        y,
        z,
        sprites.getSprite(
            switch (XVisuals.config().module("totemparticles").text("style")) {
              case "Hearts" -> 1;
              case "Dust" -> 2;
              case "Classic" -> 3;
              default -> 0;
            },
            3));
    scale = .11f;
    velocityMultiplier = .965f;
    collidesWithWorld = true;
    var settings = XVisuals.config().module("totemparticles");
    opacity = (float) Math.clamp(settings.number("opacity"), 0, 1);
    twinkle = settings.flag("twinkle");
    bright = settings.flag("bright");
    phase = random.nextFloat() * (float) Math.PI * 2;
    alpha = 0;
  }

  public static void init() {
    ParticleFactoryRegistry.getInstance()
        .register(
            TotemParticleType.BURST,
            sprites ->
                (effect, world, x, y, z, vx, vy, vz, random) ->
                    new TotemBurstParticle(world, x, y, z, sprites));
  }

  @Override
  public void visuals$tune(int color, float gravity, int lifetime) {
    setColor((color >> 16 & 255) / 255f, (color >> 8 & 255) / 255f, (color & 255) / 255f);
    gravityStrength = gravity;
    maxAge = lifetime;
  }

  @Override
  public void tick() {
    super.tick();
    if (!XVisuals.config().on("totemparticles")) markDead();
    alpha = TotemBurstMotion.opacity((float) age / Math.max(1, maxAge), opacity, twinkle, phase);
  }

  @Override
  public void render(
      BillboardParticleSubmittable batch,
      net.minecraft.client.render.Camera camera,
      float tickProgress) {
    float progress = (age + tickProgress) / Math.max(1, maxAge);
    float previousAlpha = alpha;
    alpha = TotemBurstMotion.opacity(progress, opacity, twinkle, phase);
    try {
      super.render(batch, camera, tickProgress);
    } finally {
      alpha = previousAlpha;
    }
  }

  @Override
  public float getSize(float tickProgress) {
    return scale * TotemBurstMotion.size((age + tickProgress) / Math.max(1, maxAge));
  }

  @Override
  protected RenderType getRenderType() {
    return RenderType.PARTICLE_ATLAS_TRANSLUCENT;
  }

  @Override
  protected int getBrightness(float tickProgress) {
    return bright ? 0xF000F0 : super.getBrightness(tickProgress);
  }
}
