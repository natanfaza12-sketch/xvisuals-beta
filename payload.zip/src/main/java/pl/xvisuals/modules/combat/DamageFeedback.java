package pl.xvisuals.modules.combat;

import pl.xvisuals.XVisuals;
import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.util.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** One restrained HUD pulse; no screen tint, shake, or extra particle pass. */
public final class DamageFeedback {
  private static final HealthLoss HEALTH = new HealthLoss();
  private static Object player;
  private static int tick, born = -1000, color;
  private static int hurt, hurtBorn = -1000;
  private static double amount;

  public static void tick(MinecraftClient c) {
    if (player != c.player || !XVisuals.visualModule("damagefeedback").enabled) {
      HEALTH.reset();
      born = hurtBorn = -1000;
      amount = 0;
      hurt = 0;
      player = c.player;
    }
    if (c.player == null || !XVisuals.visualModule("damagefeedback").enabled || c.isPaused()) return;
    tick++;
    var loss = HEALTH.update(c.player.getHealth(), c.player.getAbsorptionAmount());
    if (c.player.hurtTime > hurt) hurtBorn = tick;
    hurt = c.player.hurtTime;
    if (loss.absorptionOnly() && tick - hurtBorn > 4) return;
    if (loss.amount() <= .01) return;
    amount = tick - born <= 3 ? amount + loss.amount() : loss.amount();
    born = tick;
    var settings = XVisuals.visualModule("damagefeedback");
    color = settings.color(loss.absorptionOnly() ? "absorptionColor" : "color");
  }

  public static void render(DrawContext g, float partial) {
    var c = MinecraftClient.getInstance();
    if (c.player == null
        || c.options.hudHidden
        || c.currentScreen != null
        || !XVisuals.visualModule("damagefeedback").enabled) return;
    var s = XVisuals.visualModule("damagefeedback");
    double age = tick + partial - born, t = age / (s.number("duration") * 20);
    if (t < 0 || t >= 1) return;
    double fade = Math.min(1, age / 1.5) * (1 - t) * (1 - t) * s.number("opacity");
    double r = s.number("radius") + 8 * (1 - Math.pow(1 - t, 3));
    double cx = g.getScaledWindowWidth() * .5, cy = g.getScaledWindowHeight() * .5;
    int tint = Colors.alpha(color, fade);
    for (int side = 0; side < 4; side++) {
      double a = side * Math.PI * .5 + Math.PI * .25;
      double px = cx + Math.cos(a) * r, py = cy + Math.sin(a) * r;
      double sx = Math.signum(Math.cos(a)), sy = Math.signum(Math.sin(a));
      Glass.glowLine(g, px, py, px - sx * 6, py, 1.3, tint, 0);
      Glass.glowLine(g, px, py, px, py - sy * 6, 1.3, tint, 0);
    }
    if (s.flag("amount")) {
      String value = "−" + String.format(java.util.Locale.ROOT, "%.1f", amount);
      Glass.scaled(
          g, value, (float) (cx - Glass.textWidth(value) * .38), (float) (cy + r + 8), .76f, tint);
    }
  }

  public static double lastAmount() {
    return amount;
  }

  private DamageFeedback() {}
}
