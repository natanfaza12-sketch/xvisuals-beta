package pl.xvisuals.modules.combat;

import com.mojang.authlib.GameProfile;
import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.motion.GhostEffects;
import pl.xvisuals.rendering.particles.ParticleEngine;
import java.util.UUID;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/** One local practice target. This class never accesses a network handler or server world. */
public final class FakePlayer {
  private static ClientWorld world;
  private static OtherClientPlayerEntity bot;
  private static boolean enabled;
  private static int remainingTotems, cooldown, deadTicks;
  private static int nextId = -1;
  private static double verticalSpeed;
  private static String notice = "Enable to spawn a practice target.";

  private FakePlayer() {}

  public static OtherClientPlayerEntity target() {
    return bot;
  }

  public static int remainingTotems() {
    return remainingTotems;
  }

  public static void tick(MinecraftClient client) {
    boolean on = XVisuals.config().on("fakeplayer");
    if (world != client.world || !on) {
      remove();
      world = client.world;
      enabled = false;
    }
    if (!on || client.world == null || client.player == null) return;
    if (!enabled) {
      enabled = true;
      spawn();
    }
    if (client.isPaused() || bot == null) return;
    if (cooldown > 0) cooldown--;
    if (!bot.isAlive() || bot.isRemoved()) {
      deadTicks++;
      if (deadTicks >= 20 && world.getEntityById(bot.getId()) == bot)
        world.removeEntity(bot.getId(), Entity.RemovalReason.KILLED);
      var settings = XVisuals.config().module("fakeplayer");
      int delay = Math.max(22, (int) (settings.number("respawnDelay") * 20));
      if (settings.flag("autoRespawn") && deadTicks >= delay) spawn();
      return;
    }
    updateEquipment();
    verticalSpeed = Math.max(-1.5, verticalSpeed - .08);
    bot.move(MovementType.SELF, new Vec3d(0, verticalSpeed, 0));
    if (bot.isOnGround()) verticalSpeed = 0;
    bot.setVelocity(0, verticalSpeed, 0);
    // Face the local player without steering or interacting with real entities.
    Vec3d delta = client.player.getEntityPos().subtract(bot.getEntityPos());
    float yaw = (float) Math.toDegrees(Math.atan2(-delta.x, delta.z));
    bot.setYaw(yaw);
    bot.setHeadYaw(yaw);
    bot.bodyYaw = yaw;
  }

  public static void spawn() {
    var client = MinecraftClient.getInstance();
    if (client.world == null || client.player == null) {
      notice = "Join a world first.";
      return;
    }
    if (!XVisuals.config().on("fakeplayer")) {
      notice = "Enable Fake Player first.";
      return;
    }
    remove();
    world = client.world;
    var settings = XVisuals.config().module("fakeplayer");
    Vec3d forward = client.player.getRotationVec(1).multiply(1, 0, 1).normalize();
    if (forward.lengthSquared() < .1) forward = new Vec3d(0, 0, 1);
    Vec3d position = null;
    for (double distance : new double[] {2.5, 2, 3, 1.5}) {
      Vec3d center = client.player.getEntityPos().add(forward.multiply(distance));
      var hit =
          world.raycast(
              new RaycastContext(
                  center.add(0, 2, 0),
                  center.add(0, -6, 0),
                  RaycastContext.ShapeType.COLLIDER,
                  RaycastContext.FluidHandling.NONE,
                  client.player));
      if (hit.getType() != HitResult.Type.BLOCK || hit.getPos().y > center.y + 1.5) continue;
      Vec3d feet = hit.getPos().add(0, .02, 0);
      Box bounds =
          new Box(feet.x - .3, feet.y, feet.z - .3, feet.x + .3, feet.y + 1.8, feet.z + .3);
      if (world.isSpaceEmpty(client.player, bounds)) {
        position = feet;
        break;
      }
    }
    if (position == null) {
      notice = "Find clear ground in front of you, then Spawn.";
      return;
    }
    String name = settings.text("name").strip();
    if (name.isEmpty()) name = "Practice Bot";
    if (name.length() > 16) name = name.substring(0, 16);
    SkinTextures skin = settings.flag("copySkin") ? client.player.getSkin() : null;
    bot =
        new OtherClientPlayerEntity(world, new GameProfile(UUID.randomUUID(), name)) {
          @Override
          public SkinTextures getSkin() {
            return skin == null ? super.getSkin() : skin;
          }

          @Override
          public boolean isPushable() {
            return false;
          }

          @Override
          public void pushAwayFrom(Entity entity) {}
        };
    int id;
    do {
      id = nextId;
      nextId = nextId == Integer.MIN_VALUE ? -1 : nextId - 1;
    } while (world.getEntityById(id) != null);
    bot.setId(id);
    bot.noClip = false;
    bot.refreshPositionAndAngles(position, client.player.getYaw() + 180, 0);
    float health = (float) Math.clamp(settings.number("health"), 1, 200);
    bot.getAttributeInstance(EntityAttributes.MAX_HEALTH).setBaseValue(health);
    bot.setHealth(health);
    bot.setOnGround(true);
    remainingTotems = Math.clamp(settings.integer("totems"), 0, 64);
    updateEquipment();
    cooldown = deadTicks = 0;
    verticalSpeed = 0;
    world.addEntity(bot);
    enabled = true;
    notice = "Practice target ready.";
  }

  public static void reset() {
    spawn();
  }

  /** True also for a dead bot, preventing any attack packet for this local entity. */
  public static boolean attack(Entity entity) {
    if (entity != bot || bot == null) return false;
    var client = MinecraftClient.getInstance();
    if (client.player == null || client.player.isSpectator() || !bot.isAlive() || cooldown > 0)
      return true;
    HitEffects.attacked(bot);
    ParticleEngine.attacked(bot);
    boolean critical =
        !client.player.isOnGround()
            && client.player.getVelocity().y < 0
            && client.player.fallDistance > 0
            && !client.player.isClimbing()
            && !client.player.isTouchingWater()
            && !client.player.hasVehicle()
            && !client.player.isSprinting()
            && !client.player.getAbilities().flying
            && !client.player.hasStatusEffect(net.minecraft.entity.effect.StatusEffects.BLINDNESS)
            && client.player.getAttackCooldownProgress(.5f) > .9f;
    client.player.resetTicksSinceLastAttack();
    if (critical) {
      HitEffects.critical(bot);
    }
    bot.animateDamage(client.player.getYaw());
    bot.hurtTime = bot.maxHurtTime = 10;
    cooldown = 10;
    float damage =
        (float) Math.clamp(XVisuals.config().module("fakeplayer").number("damage"), .5, 200);
    if (critical) damage *= 1.5f;
    if (bot.getHealth() > damage) bot.setHealth(bot.getHealth() - damage);
    else if (remainingTotems > 0) pop();
    else kill();
    return true;
  }

  public static void pop() {
    if (bot == null || !bot.isAlive()) return;
    if (remainingTotems <= 0) {
      notice = "No totems remaining. Reset to refill.";
      return;
    }
    remainingTotems--;
    bot.setHealth(bot.getMaxHealth());
    MinecraftClient.getInstance()
        .particleManager
        .addEmitter(bot, ParticleTypes.TOTEM_OF_UNDYING, 20);
    GhostEffects.status(bot, (byte) 35);
    updateEquipment();
    notice = "Totem popped.";
  }

  public static void kill() {
    if (bot == null || !bot.isAlive()) return;
    ParticleEngine.attacked(bot);
    bot.setHealth(0);
    bot.deathTime = 1;
    GhostEffects.status(bot, (byte) 3);
    deadTicks = 0;
    notice = "Target defeated.";
  }

  public static void jump() {
    if (bot != null && bot.isAlive() && bot.isOnGround()) {
      verticalSpeed = .5;
      bot.setVelocity(0, verticalSpeed, 0);
      bot.setOnGround(false);
    }
  }

  public static String status() {
    if (MinecraftClient.getInstance().world == null) return "Join a world to practice.";
    if (bot == null) return notice;
    if (!bot.isAlive())
      return "Defeated — "
          + (XVisuals.config().module("fakeplayer").flag("autoRespawn")
              ? "respawning soon"
              : "press Reset");
    return String.format(
        java.util.Locale.ROOT,
        "%.0f / %.0f health · %d totems",
        bot.getHealth(),
        bot.getMaxHealth(),
        remainingTotems);
  }

  private static void updateEquipment() {
    var client = MinecraftClient.getInstance();
    if (bot == null || client.player == null) return;
    var settings = XVisuals.config().module("fakeplayer");
    for (var slot : new EquipmentSlot[] {EquipmentSlot.HEAD, EquipmentSlot.CHEST,
        EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND}) {
      String key = switch (slot) {
        case HEAD -> "helmet"; case CHEST -> "chestplate"; case LEGS -> "leggings";
        case FEET -> "boots"; case MAINHAND -> "mainHand"; default -> "offHand";
      };
      var stack = FakePlayerEquipment.stack(settings.text(key), slot,
          client.player.getEquippedStack(slot), remainingTotems);
      if (!ItemStack.areEqual(bot.getEquippedStack(slot), stack)) bot.equipStack(slot, stack);
    }
  }

  private static void remove() {
    if (bot != null && world != null && world.getEntityById(bot.getId()) == bot)
      world.removeEntity(bot.getId(), Entity.RemovalReason.DISCARDED);
    bot = null;
    cooldown = deadTicks = 0;
    verticalSpeed = 0;
  }
}
