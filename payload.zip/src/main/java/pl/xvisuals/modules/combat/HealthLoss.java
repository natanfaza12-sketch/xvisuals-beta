package pl.xvisuals.modules.combat;

/** Observed health/absorption only: never estimates damage from weapon or animation. */
public final class HealthLoss {
  private double health = Double.NaN, absorption;

  public record Loss(double amount, boolean absorptionOnly) {}

  public Loss update(double nextHealth, double nextAbsorption) {
    if (!Double.isFinite(nextHealth) || !Double.isFinite(nextAbsorption)) {
      reset();
      return new Loss(0, false);
    }
    nextHealth = Math.max(0, nextHealth);
    nextAbsorption = Math.max(0, nextAbsorption);
    double lost =
        Double.isNaN(health) ? 0 : Math.max(0, health + absorption - nextHealth - nextAbsorption);
    boolean absorbed = nextHealth >= health && nextAbsorption < absorption;
    health = nextHealth;
    absorption = nextAbsorption;
    return new Loss(lost, absorbed);
  }

  public void reset() {
    health = Double.NaN;
    absorption = 0;
  }
}
