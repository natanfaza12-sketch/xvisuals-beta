package pl.xvisuals.modules.combat;

import pl.xvisuals.XVisuals;
import net.minecraft.item.ItemDisplayContext;

/** Cosmetic render multipliers, independent of the optional totem skin replacement. */
public final class TotemSizing {
  private TotemSizing() {}

  public interface State {
    void visuals$totemContext(boolean totem, ItemDisplayContext context);
    boolean visuals$isTotem();
    float visuals$totemScale();
  }

  public static float scale(String key) {
    var settings = XVisuals.config().module("totemsize");
    return settings.enabled ? (key.equals("pop") ? clampPop(settings.number(key)) : clamp(settings.number(key))) : 1;
  }

  public static void orientPop(net.minecraft.client.util.math.MatrixStack matrices) {
    var skin=XVisuals.visualModule("totemtexture");
    if(skin.enabled && java.util.Set.of("Astral Oracle","Ember Phoenix","Tidal Guardian","Moonlit Kitsune","Moss Golem","Royal Capybara").contains(skin.text("style")))
      matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Y.rotationDegrees(180));
  }

  public static float clampPop(double value) {
    return Double.isFinite(value) ? (float)Math.clamp(value,.2,2.5) : 1;
  }

  public static float clamp(double value) {
    return Double.isFinite(value) ? (float) Math.clamp(value, .25, 2) : 1;
  }

  public static String setting(ItemDisplayContext context) {
    return switch (context) {
      case FIRST_PERSON_LEFT_HAND, FIRST_PERSON_RIGHT_HAND -> "hand";
      case THIRD_PERSON_LEFT_HAND, THIRD_PERSON_RIGHT_HAND -> "thirdPerson";
      default -> null;
    };
  }
}
