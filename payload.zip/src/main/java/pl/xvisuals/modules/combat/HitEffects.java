package pl.xvisuals.modules.combat;

import pl.xvisuals.XVisuals;
import pl.xvisuals.gui.components.Glass;
import pl.xvisuals.modules.entity.EntityVisuals;
import pl.xvisuals.rendering.Projection;
import pl.xvisuals.rendering.Quality;
import pl.xvisuals.rendering.particles.HitSpriteRenderer;
import pl.xvisuals.util.Colors;
import java.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Bounded client-only impact pool. No gameplay packets or damage modifications. */
public final class HitEffects {
  private static final int MAX = 48;
  private static final Impact[] IMPACTS = new Impact[MAX];
  private static final Map<Integer, Pending> PENDING = new HashMap<>();
  private static final ArrayDeque<DamageNumber> NUMBERS = new ArrayDeque<>();
  private static final Projection.Point A = new Projection.Point();
  private static Object world;
  private static int tick, next;
  private static int markerBorn = -100, markerTarget;
  private static boolean markerCritical;

  private static final class Pending {
    LivingEntity entity;
    int born, hurt;
    boolean hearts, critical;
    final ObservedDamage damage;
    DamageNumber number;
    int confirmed = -1;

    Pending(LivingEntity entity) {
      this.entity = entity;
      born = tick;
      hurt = entity.hurtTime;
      damage = new ObservedDamage(entity.getHealth(), entity.getAbsorptionAmount());
    }
  }

  private static final class Impact {
    Vec3d origin;
    double size, life, rotation;
    int born, color, style, index, count;
    double yaw;
    boolean critical;
  }

  private static final class DamageNumber {
    final Vec3d origin;
    final int born;
    double amount;
    String label;
    boolean critical, visible;

    DamageNumber(LivingEntity entity) {
      origin = entity.getEntityPos().add(0, entity.getHeight() * .85, 0);
      born = tick;
    }

    void update(double value) {
      if (value == amount) return;
      amount = value;
      label = String.format(Locale.ROOT, "%.1f", amount).replaceAll("\\.0$", "");
    }
  }

  static {
    for (int i = 0; i < MAX; i++) IMPACTS[i] = new Impact();
  }

  private static boolean eligible(Entity entity) {
    var s = XVisuals.visualModule("hitfx");
    return s.enabled
        && s.number("opacity") > 0
        && entity instanceof LivingEntity living
        && living.isAlive()
        && (entity instanceof PlayerEntity ? s.flag("players") : s.flag("mobs"));
  }

  public static void attacked(Entity entity) {
    var c = MinecraftClient.getInstance();
    if (c.player == null || c.player.isSpectator() || !eligible(entity)) return;
    if (PENDING.size() >= 16) PENDING.clear();
    var old = PENDING.get(entity.getId());
    if (old == null || (tick - old.born > 2 && old.confirmed >= 0) || tick - old.born > 20) {
      Pending pending=new Pending((LivingEntity)entity);
      PENDING.put(entity.getId(),pending);
      // Cosmetic response is immediate. Damage totals and markers still await server evidence.
      burst(entity);
      pending.hearts=true;
    }
  }

  /** Called only from Minecraft's received critical animation, filtered to our recent target. */
  public static boolean replaceCriticalParticles(Entity entity) {
    if (entity == null) return false;
    var s = XVisuals.visualModule("hitfx");
    Pending pending = PENDING.get(entity.getId());
    return s.enabled && s.flag("critical") && s.flag("replaceCrit") && s.number("opacity") > 0
        && pending != null && tick - pending.born <= 20;
  }

  /** Received critical animation for a recently attacked target. */
  public static void critical(Entity entity) {
    if (entity == null || !XVisuals.visualModule("hitfx").enabled) return;
    Pending p = PENDING.get(entity.getId());
    if (p == null || tick - p.born > 20 || p.critical) return;
    p.critical = true;
    confirm(p);
    if (p.number != null) p.number.critical = true;
    var s = XVisuals.visualModule("hitfx");
    if (!s.flag("critical")) return;
    spawn(entity, ImpactStyles.crit(s.text("critStyle")), true);

  }

  public static void tick(MinecraftClient c) {
    if (world != c.world || !XVisuals.visualModule("hitfx").enabled
        || XVisuals.visualModule("hitfx").number("opacity") <= 0) {
      clear();
      world = c.world;
    }
    if (c.world == null
        || c.player == null
        || !XVisuals.visualModule("hitfx").enabled
        || XVisuals.visualModule("hitfx").number("opacity") <= 0
        || c.isPaused()) return;
    tick++;
    PENDING
        .values()
        .removeIf(p -> tick - p.born > 20 || (p.confirmed >= 0 && tick - p.confirmed > 6));
    for (Pending p : PENDING.values()) {
      // Wait for a new hurt animation; swinging at an invulnerable target produces nothing.
      double damage = p.damage.observe(p.entity.getHealth(), p.entity.getAbsorptionAmount());
      if (p.entity.hurtTime > p.hurt || damage > 0) confirm(p);
      if (damage > 0 && XVisuals.visualModule("hitfx").flag("damageNumbers")) {
        if (p.number == null) {
          while (NUMBERS.size() >= 24) NUMBERS.removeFirst();
          p.number = new DamageNumber(p.entity);
          NUMBERS.add(p.number);
        }
        p.number.update(damage);
        p.number.critical = p.critical;
      }
      p.hurt = p.entity.hurtTime;
    }
    NUMBERS.removeIf(n -> tick - n.born >= 24);
    for (DamageNumber n : NUMBERS) n.visible = EntityVisuals.visible(c, n.origin);
    for (Impact h : IMPACTS)
      if (h.origin != null) {
        if (tick - h.born >= h.life) {
          h.origin = null;
          continue;
        }
      }
  }

  private static void confirm(Pending p) {
    if (p.confirmed < 0) {
      if (!p.hearts) burst(p.entity);
      p.hearts = true;
      p.confirmed = tick;
      markerBorn = tick;
      markerTarget = p.entity.getId();
      markerCritical = p.critical;
    } else if (p.critical && markerTarget == p.entity.getId()) markerCritical = true;
  }

  private static Vec3d local(Vec3d origin, ImpactStyles.Point p, double yaw, double scale) {
    double c=Math.cos(yaw), s=Math.sin(yaw);
    return origin.add((p.x()*c-p.z()*s)*scale,p.y()*scale,(p.x()*s+p.z()*c)*scale);
  }

  private static Vec3d position(Impact h, double age) {
    return local(h.origin, h.critical ? ImpactStyles.criticalParticle(h.style,h.index,h.count,age/h.life) : ImpactStyles.particle(h.style,h.index,h.count,age/h.life),h.yaw,1);
  }

  private static void burst(Entity entity) {
    var s = XVisuals.visualModule("hitfx");
    if (s.flag("hearts")) spawn(entity, ImpactStyles.hit(s.text("style")), false);
  }

  private static void spawn(Entity entity, int style, boolean critical) {
    var s = XVisuals.visualModule("hitfx");
    int count = Math.clamp((int)Math.ceil(s.integer("count") * Math.min(1,Quality.factor()) / 3.), 1, 3);
    var c = MinecraftClient.getInstance();
    Vec3d origin = entity.getEntityPos().add(0, entity.getHeight()*.55, 0);
    // Start on the visible contact surface; the target body must not swallow the burst.
    Vec3d towardCamera = c.gameRenderer.getCamera().getCameraPos().subtract(origin).normalize();
    origin = origin.add(towardCamera.multiply(entity.getWidth()*.75 + .08));
    for (int i=0;i<count;i++) {
      Impact h = IMPACTS[next];
      next = (next + 1) % MAX;
      h.origin=origin; h.critical=critical; h.style=style; h.index=i; h.count=count;
      h.yaw=Math.toRadians(c.player.getYaw());
      h.size=s.number("size")*(critical ? 1.3 : 1)*(i==0?.85:.28+.04*(i%3));
      h.life=Math.max(2,s.number("duration")*20); h.born=tick;
      int color=s.color(critical ? "criticalColor" : "color");
      h.color=!s.flag("customColors") ? 0xFFFFFFFF : s.flag("gradient") ? Colors.mix(color,s.color("secondary"),(double)i/count) : color;

      h.rotation=i==0?0:Math.PI*2*i/count;
    }
  }
  public static void renderWorld(net.minecraft.client.util.math.MatrixStack matrices) {
    HitSpriteRenderer.begin();
    var c=MinecraftClient.getInstance();var settings=XVisuals.visualModule("hitfx");
    if(c.world==null||c.player==null||!settings.enabled||settings.number("opacity")<=0)return;
    double now=tick+c.getRenderTickCounter().getTickProgress(false);
    for(Impact h:IMPACTS){
      if(h.origin==null)continue;
      double t=(now-h.born)/h.life;if(t<0||t>=1)continue;
      double alpha=ImpactStyles.opacity(t)*settings.number("opacity");
      double size=Math.min(1.25,h.size*1.8*(h.critical?Math.min(1.4,settings.number("intensity")):1))*(.8+.2*Math.sin(Math.PI*t));
      var pos=position(h,now-h.born);double spin=h.rotation+ImpactStyles.rotation(h.style,t)*(h.index==0?1:3);
      HitSpriteRenderer.add(pos,size,spin,ImpactStyles.frame(t),Colors.alpha(h.color,alpha),h.style,false);
      if(h.index==0 && t<.55)HitSpriteRenderer.add(pos,size*1.12,spin,ImpactStyles.frame(t),Colors.alpha(h.color,alpha*(1-t/.55)*Math.min(.3,settings.number("glow")*.2)),h.style,true);
    }
    HitSpriteRenderer.draw(matrices);
  }
  public static void render(DrawContext g, Projection projection) {
    var settings=XVisuals.visualModule("hitfx");
    if(!settings.enabled || MinecraftClient.getInstance().options.hudHidden)return;
    double now=tick+projection.tick,opacity=settings.number("opacity"),glow=settings.number("glow")*Quality.glow();
    if(opacity<=0)return;
    renderNumbers(g, projection, now, opacity);
    if (settings.flag("hitMarker")) {
      double age = now - markerBorn;
      if (age >= 0 && age < 9) {
        double fade = Math.pow(1 - age / 9, 2) * opacity;
        double cx = projection.width / 2.0, cy = projection.height / 2.0;
        double inner = 4 + age * .22, outer = inner + (markerCritical ? 5 : 3.5);
        int color = Colors.alpha(settings.color(markerCritical ? "criticalColor" : "color"), fade);
        for (int x = -1; x <= 1; x += 2)
          for (int y = -1; y <= 1; y += 2)
            Glass.glowLine(
                g,
                cx + x * inner,
                cy + y * inner,
                cx + x * outer,
                cy + y * outer,
                markerCritical ? 1.7 : 1.2,
                color,
                glow * fade);
      }
    }
  }

  private static void renderNumbers(
      DrawContext g, Projection projection, double now, double opacity) {
    var settings = XVisuals.visualModule("hitfx");
    if (!settings.flag("damageNumbers")) return;
    for (DamageNumber n : NUMBERS) {
      if (!n.visible || n.label == null) continue;
      double t = Math.clamp((now - n.born) / 24, 0, 1);
      Vec3d p = n.origin.add(0, .15 + .55 * (1 - Math.pow(1 - t, 2)), 0);
      if (!projection.project(p.x, p.y, p.z, A) || !A.visible || A.depth < .5 || A.depth > 40)
        continue;
      float scale =
          (float)
              (Math.clamp(projection.height / (A.depth * 100), .65, 1.5)
                  * settings.number("numberScale")
                  * (1 + .15 * Math.sin(Math.min(1, t * 4) * Math.PI)));
      double fade = pl.xvisuals.util.EffectEnvelope.fade(t,.08,.35) * opacity;
      String label = n.label + (n.critical ? "!" : "");
      float x = (float) A.x - Glass.textWidth(label) * scale / 2;
      int color = settings.color(n.critical ? "criticalColor" : "color");
      Glass.scaled(
          g, label, x + scale, (float) A.y + scale, scale, Colors.alpha(0xFF10101A, fade * .8));
      Glass.scaled(g, label, x, (float) A.y, scale, Colors.alpha(color, fade));
    }
  }

  public static int count() {
    int n = 0;
    for (Impact h : IMPACTS) if (h.origin != null) n++;
    return n;
  }

  public static void clear() {
    PENDING.clear();
    NUMBERS.clear();
    markerBorn = -100;
    for (Impact h : IMPACTS) h.origin = null;
  }

  private HitEffects() {}
}
