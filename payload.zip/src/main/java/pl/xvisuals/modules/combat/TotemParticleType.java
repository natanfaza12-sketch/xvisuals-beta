package pl.xvisuals.modules.combat;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.particle.SimpleParticleType;
import net.minecraft.registry.*;
import net.minecraft.util.Identifier;

public final class TotemParticleType implements ModInitializer {
  public static final SimpleParticleType BURST = FabricParticleTypes.simple();
  public static final SimpleParticleType ANCHOR = FabricParticleTypes.simple();
  @Override public void onInitialize() {
    Registry.register(Registries.PARTICLE_TYPE, Identifier.of("xvisuals", "totem_burst"), BURST);
    Registry.register(Registries.PARTICLE_TYPE, Identifier.of("xvisuals", "anchor_spark"), ANCHOR);
  }
}
