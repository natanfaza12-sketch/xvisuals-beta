package pl.xvisuals.modules.combat;

import pl.xvisuals.XVisuals;
import pl.xvisuals.util.Colors;
import java.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.BillboardParticle;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.CustomModelDataComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.particle.*;
import net.minecraft.util.Identifier;

/** Cosmetic only: the source inventory stack and server state are never modified. */
public final class TotemVisuals {
  public interface TunableParticle {
    void visuals$tune(int color, float gravity, int lifetime);
  }

  private static final Random RANDOM = new Random();
  private static java.lang.ref.WeakReference<Object> world = new java.lang.ref.WeakReference<>(null);
  private static long window;
  private static int emitted;
  public static int lastBurst;

  /** Returns true only when the vanilla emitter should be replaced. */
  public static boolean burst(Entity entity) {
    var c = MinecraftClient.getInstance();
    // Larp deliberately mutes custom totem particles. Its own pop effect must be
    // notified independently of whether this method replaces the vanilla emitter.
    if (entity != null && entity == c.player) pl.xvisuals.modules.larp.LarpEffects.burst();
    var s = XVisuals.visualModule("totemparticles");
    if (!s.enabled
        || c.world == null
        || !(entity instanceof PlayerEntity)
        || !s.flag(entity == c.player ? "local" : "others")) return false;
    lastBurst = 0;
    if (s.number("opacity") <= 0) return true;
    if (c.player == null || entity.squaredDistanceTo(c.player) > 4096) return true;
    // Limit dense multiplayer fights to 320 new particles per second.
    long now = System.nanoTime();
    if (world.get() != c.world || now - window > 1_000_000_000L) {
      world = new java.lang.ref.WeakReference<>(c.world);
      window = now;
      emitted = 0;
    }
    int amount = Math.min(Math.clamp(s.integer("amount"), 0, 160), 320 - emitted);
    boolean firstPerson = entity == c.player && c.options.getPerspective().isFirstPerson();
    for (int i = 0; i < amount; i++) {
      var shape =
          TotemBurstMotion.sample(
              s.text("pattern"), i, amount, s.number("spread"), RANDOM.nextDouble());
      double speed = s.number("speed") * (.085 + RANDOM.nextDouble() * .025);
      double colorPhase = (double) i / Math.max(1, amount);
      int color =
          s.flag("rainbow")
              ? Colors.rainbow(colorPhase)
              : Colors.mix(s.color("color"), s.color("secondary"), colorPhase);
      // Keep local sparks beneath the eye line and outside the immediate camera volume.
      double x = shape.x(), z = shape.z();
      if (firstPerson) {
        double radius = Math.hypot(x, z);
        if (radius < .7) {
          x *= .7 / radius;
          z *= .7 / radius;
        }
      }
      var p =
          c.particleManager.addParticle(
              TotemParticleType.BURST,
              entity.getX() + x,
              entity.getY() + .12 + shape.height() * entity.getHeight() * (firstPerson ? .65 : 1),
              entity.getZ() + z,
              0,
              0,
              0);
      if (p == null) continue;
      p.setVelocity(
          shape.vx() * speed, shape.vy() * speed * (firstPerson ? .75 : 1), shape.vz() * speed);
      p.scale((float) s.number("size"));
      ((TunableParticle) p)
          .visuals$tune(
              color,
              (float) s.number("gravity"),
              Math.max(4, (int) (s.number("duration") * 20 * (.75 + RANDOM.nextDouble() * .5))));
      if (p instanceof BillboardParticle b)
        b.setColor((color >> 16 & 255) / 255f, (color >> 8 & 255) / 255f, (color & 255) / 255f);
      emitted++;
      lastBurst++;
    }
    return true;
  }

  public static void preview() {
    var c = MinecraftClient.getInstance();
    if (c.player != null) burst(c.player);
  }

  public static ItemStack appearance(ItemStack original) {
    var s = XVisuals.visualModule("totemtexture");
    if (!s.enabled || !original.isOf(Items.TOTEM_OF_UNDYING)) return original;
    String style = s.text("style").toLowerCase(java.util.Locale.ROOT).replace(' ', '_');
    ItemStack copy = original.copy();
    copy.set(DataComponentTypes.ITEM_MODEL, Identifier.of("xvisuals", "totem/" + TotemDesigns.path(s.text("style"))));
    // Imported designs already contain their authored colours and use their own tint/accent controls.
    var data =
        original.getOrDefault(
            DataComponentTypes.CUSTOM_MODEL_DATA, CustomModelDataComponent.DEFAULT);
    List<Integer> colors=s.flag("customTint")?List.of(s.color("color"),s.color("secondary")):List.of(0xFFFFFF,0xFFFFFF);
    if(style.equals("custom_vanilla")) {
      var client=MinecraftClient.getInstance();
      double time=client.world==null?0:client.world.getTime()/20.0;
      if(XVisuals.config().module("performance").text("animation").equals("Off"))time=0;
      colors=VanillaTotemEyes.colors(s.text("eyeMode"),s.color("eyeColor"),s.color("eyeSecondary"),time*s.number("eyeSpeed"));
    }
    if(data.colors().size()>colors.size()) {
      var preserved=new ArrayList<Integer>(colors);preserved.addAll(data.colors().subList(colors.size(),data.colors().size()));colors=preserved;
    }
    copy.set(
        DataComponentTypes.CUSTOM_MODEL_DATA,
        new CustomModelDataComponent(
            data.floats(),
            data.flags(),
            data.strings(),
            colors));
    return copy;
  }
}
