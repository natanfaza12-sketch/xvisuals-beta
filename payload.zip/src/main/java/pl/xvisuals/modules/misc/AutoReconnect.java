package pl.xvisuals.modules.misc;

import pl.xvisuals.XVisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;

/** In-memory target and disconnect-screen-only retries using vanilla authentication/connection. */
public final class AutoReconnect {
  private static final ReconnectSchedule SCHEDULE=new ReconnectSchedule();
  private static ServerInfo server;
  private static ServerAddress address;
  private static Screen parent,disconnectScreen;
  private static boolean launching;

  public static boolean enabled() {
    return XVisuals.ready() && XVisuals.visualModule("autoreconnect").enabled;
  }
  public static boolean available() { return enabled() && server!=null && address!=null; }
  public static boolean showCountdown() {
    return enabled() && XVisuals.visualModule("autoreconnect").flag("countdown");
  }
  public static void capture(Screen returnTo,ServerAddress destination,ServerInfo info) {
    if(launching)return;
    cancel();
    if(info==null || info.isRealm()) {server=null;address=null;parent=null;return;}
    server=new ServerInfo(info.name,info.address,info.getServerType());
    server.copyWithSettingsFrom(info);
    address=destination;parent=returnTo;SCHEDULE.reset();
  }
  public static void joined() {
    var info=MinecraftClient.getInstance().getCurrentServerEntry();
    if(info==null || info.isRealm()) {cancel();server=null;address=null;parent=null;return;}
    // Re-synchronise transfers and direct-join flows, without storing session cookies.
    server=new ServerInfo(info.name,info.address,info.getServerType());server.copyWithSettingsFrom(info);
    address=ServerAddress.parse(info.address);SCHEDULE.reset();disconnectScreen=null;
  }
  public static boolean enter(Screen screen) {
    if(!available())return false;
    if(disconnectScreen!=screen) {
      disconnectScreen=screen;
      var s=XVisuals.visualModule("autoreconnect");
      SCHEDULE.disconnected(now(),s.number("delay"),s.flag("indefinite"));
    }
    return true;
  }
  public static void tick(Screen screen) {
    if(!available()) {cancel();return;}
    if(disconnectScreen==screen && MinecraftClient.getInstance().currentScreen==screen
        && SCHEDULE.waiting() && SCHEDULE.secondsRemaining(now())==0) reconnect(screen,false);
  }
  public static void reconnect(Screen screen,boolean manual) {
    var client=MinecraftClient.getInstance();
    if(launching || !available() || client.currentScreen!=screen || disconnectScreen!=screen)return;
    if(!SCHEDULE.take(now(),manual))return;
    launching=true;
    try {
      Screen returnTo=parent!=null?parent:new MultiplayerScreen(new TitleScreen());
      ConnectScreen.connect(returnTo,client,address,server,false,null);
    } finally {launching=false;}
  }
  public static void cancel() {SCHEDULE.cancel();}
  public static void left(Screen screen) {
    if(disconnectScreen==screen) {if(!launching)cancel();disconnectScreen=null;}
  }
  public static void screenChanged(Screen next) {
    if(launching)return;
    if(next instanceof TitleScreen || next instanceof MultiplayerScreen
        || next!=null && next==parent) cancel();
  }
  public static boolean waiting() {return SCHEDULE.waiting();}
  public static long secondsRemaining() {return SCHEDULE.secondsRemaining(now());}
  private static long now() {return System.nanoTime()/1_000_000L;}
  private AutoReconnect() {}
}
