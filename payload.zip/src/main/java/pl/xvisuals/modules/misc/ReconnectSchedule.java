package pl.xvisuals.modules.misc;

/** Monotonic one-shot timer; no threads and no connections from this state machine. */
public final class ReconnectSchedule {
  private long deadline;
  private int attempts;
  private boolean cancelled=true,waiting;
  public void reset() { attempts=0;cancelled=false;waiting=false; }
  public void cancel() { cancelled=true;waiting=false; }
  public void disconnected(long now,double seconds,boolean indefinitely) {
    waiting=!cancelled && (indefinitely || attempts==0);
    deadline=now+delayMillis(seconds);
  }
  public boolean take(long now,boolean manual) {
    if(!manual && (!waiting || cancelled || now<deadline))return false;
    waiting=false;cancelled=false;attempts++;
    return true;
  }
  public boolean waiting() { return waiting; }
  public long secondsRemaining(long now) { return waiting?Math.max(0,(deadline-now+999)/1000):0; }
  public static long delayMillis(double seconds) {
    return Math.round(Math.clamp(Double.isFinite(seconds)?seconds:5,1,120)*1000);
  }
}
