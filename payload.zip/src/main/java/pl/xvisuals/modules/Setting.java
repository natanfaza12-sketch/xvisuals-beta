package pl.xvisuals.modules;

import java.util.List;

public record Setting(
    String key,
    String label,
    Kind kind,
    Object initial,
    double min,
    double max,
    double step,
    List<String> choices) {
  public enum Kind {
    BOOLEAN,
    NUMBER,
    CHOICE,
    COLOR,
    TEXT,
    KEY
  }

  public static Setting flag(String key, String label, boolean value) {
    return new Setting(key, label, Kind.BOOLEAN, value, 0, 1, 1, List.of());
  }

  public static Setting number(
      String key, String label, double value, double min, double max, double step) {
    return new Setting(key, label, Kind.NUMBER, value, min, max, step, List.of());
  }

  public static Setting choice(String key, String label, String initial, String... choices) {
    return new Setting(key, label, Kind.CHOICE, initial, 0, 0, 0, List.of(choices));
  }

  public static Setting color(String key, String label, String color) {
    String monochrome = java.util.Set.of("secondary", "end", "outlineColor", "shadow", "background", "tailColor",
        "criticalColor", "absorptionColor", "lyricColor").contains(key) ? "#000000" : "#FFFFFF";
    return new Setting(key, label, Kind.COLOR, monochrome, 0, 0, 0, List.of());
  }

  public static Setting key(String key, String label, String value) {
    return new Setting(key, label, Kind.KEY, value, 0, 0, 0, List.of());
  }

  public static Setting text(String key, String label, String text) {
    return new Setting(key, label, Kind.TEXT, text, 0, 0, 0, List.of());
  }
}
