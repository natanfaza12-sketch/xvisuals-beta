package pl.xvisuals.modules.larp;
import java.util.List;
public final class LarpDesigns {
 public static final List<String> ALL=List.of("Money Rain","Cash Cyclone","Royal Orbit");
 public record Pose(double x,double y,double z,double spin,double alpha){}
 public static Pose note(String style,int i,double time,double radius){
  double seed=i*2.39996323,phase=fract(i*.618033+time*.23),r=radius*(.35+.65*fract(i*.754877));
  double angle=seed,x,y,z;
  if(style.equals("Cash Cyclone")){angle+=time*1.4+phase*3;r*=.35+phase*.65;y=.15+phase*3.1;}
  else if(style.equals("Royal Orbit")){angle+=time*.55;r=radius*(.55+.18*Math.sin(seed));y=1.45+.9*Math.sin(seed*.5+time*.7);}
  else {y=.1+(1-phase)*3.4;}
  x=Math.cos(angle)*r+.1*Math.sin(time*2+seed);z=Math.sin(angle)*r+.1*Math.cos(time+seed);
  return new Pose(x,y,z,time*1.5+seed,Math.min(1,Math.min(phase,1-phase)*12));
 }
 private static double fract(double n){return n-Math.floor(n);}
 private LarpDesigns(){}
}
