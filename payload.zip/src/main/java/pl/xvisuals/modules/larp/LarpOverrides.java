package pl.xvisuals.modules.larp;

import pl.xvisuals.config.VisualConfig;
import java.util.*;

/** Render-time priority only. Never edits the profile or needs a restoration snapshot. */
public final class LarpOverrides {
  private static final Set<String> MUTED = Set.of("particles", "playerfx", "playertrails", "angelwings", "afterimage", "playerafterimage", "jumpcircles", "totemghost", "deathghost", "hitfx", "damagefeedback", "fireflies");
  private static final Map<String, VisualConfig.ModuleState> CACHE = new HashMap<>();
  private record Input(Map<String,Object> values, boolean cape, boolean totem, boolean burst) {}
  private static final Map<String, Input> INPUTS = new HashMap<>();
  public static VisualConfig.ModuleState settings(VisualConfig config, String id) {
    var original = config.module(id);
    if (!config.on("larp")) return original;
    var larp = config.module("larp");
    boolean cape = id.equals("capes") && larp.flag("cape");
    boolean totem = id.equals("totemtexture") && larp.flag("totem");
    boolean burst = id.equals("totemparticles") && larp.flag("bursts");
    if (!MUTED.contains(id) && !cape && !totem && !burst) return original;
    var result = CACHE.computeIfAbsent(id, key -> new VisualConfig.ModuleState());
    Input previous = INPUTS.get(id);
    if (previous != null && previous.cape == cape && previous.totem == totem
        && previous.burst == burst && previous.values.equals(original.values)) return result;
    INPUTS.put(id, new Input(new LinkedHashMap<>(original.values), cape, totem, burst));
    result.values.clear(); result.values.putAll(original.values);
    result.enabled = cape || totem;
    if (cape) { result.values.put("silky", false); result.values.put("style", "Money"); result.values.put("palette", "Theme"); result.values.put("others", false); result.values.put("speed", 1d); result.values.put("motion", 1d); result.values.put("bright", true); }
    if (totem) { result.values.put("style", "Money"); result.values.put("customTint", false); }
    if (burst) {
      result.values.put("color", "#61E894"); result.values.put("secondary", "#FFD76A");
      result.values.put("rainbow", false); result.values.put("local", true);
    }
    return result;
  }
  private LarpOverrides() {}
}
