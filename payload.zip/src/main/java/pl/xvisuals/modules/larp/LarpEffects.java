package pl.xvisuals.modules.larp;
import pl.xvisuals.XVisuals;
import pl.xvisuals.rendering.Quality;
import pl.xvisuals.mixins.RenderLayerAccessor;
import pl.xvisuals.util.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.render.*;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import java.util.*;
/** Bounded folding banknote meshes and solid spinning coins, using baked pixel artwork. */
public final class LarpEffects {
 private record Sprite(Vec3d position,double spin,boolean coin,double alpha){}
 private static final List<Sprite> SPRITES=new ArrayList<>(144);
 private static final BufferAllocator ALLOCATOR=new BufferAllocator(131072);
 private static final VertexConsumerProvider.Immediate BUFFER=VertexConsumerProvider.immediate(ALLOCATOR);
 private static final RenderPipeline PIPE=RenderPipeline.builder().withLocation(Identifier.of("xvisuals","pipeline/larp_art"))
  .withVertexShader(Identifier.of("xvisuals","core/player_sprite")).withFragmentShader(Identifier.of("xvisuals","core/player_sprite"))
  .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER).withSampler("Sampler0")
  .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS).withBlend(BlendFunction.TRANSLUCENT)
  .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withDepthWrite(false).withCull(false).build();
 private static RenderLayer layer(String name){return RenderLayerAccessor.visuals$of("larp_"+name,RenderSetup.builder(PIPE).texture("Sampler0",texture(name)).translucent().expectedBufferSize(65536).build());}
 public static Identifier texture(String name){return Identifier.of("xvisuals","textures/larp/"+name+".png");}
 private static final RenderLayer NOTES=layer("banknote"),COINS=layer("coin");
 private static Object world;private static long burstTick=-100;private static Vec3d burstOrigin=Vec3d.ZERO;
 public static int rendered;public static long lastDrawNanos;
 public static void init(){WorldRenderEvents.END_MAIN.register(c->render(c.matrices()));net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING.register(c->ALLOCATOR.close());}
 public static void burst(){var c=MinecraftClient.getInstance();if(c.world!=null&&c.player!=null&&XVisuals.config().on("larp")&&XVisuals.config().module("larp").flag("bursts")){world=c.world;burstTick=c.world.getTime();burstOrigin=c.player.getLerpedPos(1).add(0,1,0);}}
 public static void render(MatrixStack matrices){
  long start=System.nanoTime();rendered=0;SPRITES.clear();var c=MinecraftClient.getInstance();var config=XVisuals.config();
  if(!config.on("larp")||c.player==null||c.world==null||c.player.isSpectator()){burstTick=-100;return;}
  if(world!=c.world){world=c.world;burstTick=-100;}
  var s=config.module("larp");float partial=c.getRenderTickCounter().getTickProgress(false);double now=(c.world.getTime()+partial)/20.,time=now*s.number("speed");Vec3d center=c.player.getLerpedPos(partial);
  int count=Math.min(96,Math.max(8,(int)(s.integer("amount")*Math.min(1,Quality.factor()))));
  for(int i=0;i<count;i++){var p=LarpDesigns.note(s.text("style"),i,time,s.number("radius"));queue(center.add(p.x(),p.y(),p.z()),p.spin(),false,p.alpha());}
  if(s.flag("coins"))for(int i=0;i<12;i++){double a=time*.8+i*Math.PI/6;queue(center.add(Math.cos(a)*s.number("radius")*.48,1+.3*Math.sin(a*2),Math.sin(a)*s.number("radius")*.48),time*2+i,true,1);}
  double age=(c.world.getTime()+partial-burstTick)/20.;
  if(s.flag("bursts")&&age>=0&&age<1.6)for(int i=0;i<24;i++){double a=i*2.39996;queue(burstOrigin.add(Math.cos(a)*age*2.4,2.7*age-2.3*age*age,Math.sin(a)*age*2.4),time*3+i,i%3==0,Math.min(1,(1.6-age)*2));}
  var eye=c.gameRenderer.getCamera().getCameraPos();SPRITES.sort(Comparator.comparingDouble((Sprite p)->p.position.squaredDistanceTo(eye)).reversed());
  double size=s.number("size");
  for(boolean coins:new boolean[]{false,true}){var out=BUFFER.getBuffer(coins?COINS:NOTES);
   for(var p:SPRITES){if(p.coin!=coins||p.position.squaredDistanceTo(eye)<.20)continue;
    var q=new Quaternionf().rotateY((float)p.spin).rotateX((float)(Math.sin(p.spin*.7)*.6)).rotateZ((float)(Math.cos(p.spin)*.28));
    Vec3d centerEye=p.position.subtract(eye);int color=Colors.alpha(0xffffffff,p.alpha);
    if(coins)coin(out,matrices,centerEye,q,size,color);else note(out,matrices,centerEye,q,size,p.spin,color);rendered++;
   }BUFFER.draw();
  }lastDrawNanos=System.nanoTime()-start;
 }
 private static void queue(Vec3d p,double spin,boolean coin,double alpha){if(alpha>.005)SPRITES.add(new Sprite(p,spin,coin,alpha));}
 private static void note(VertexConsumer out,MatrixStack m,Vec3d p,Quaternionf q,double size,double spin,int color){
  for(int i=0;i<4;i++){float x0=i/4f-.5f,x1=(i+1)/4f-.5f;float z0=(float)(Math.sin(x0*4+spin)*.045*size),z1=(float)(Math.sin(x1*4+spin)*.045*size);
   point(out,m,p,q,x0*.58*size,.145*size,z0,i/4f,0,color);point(out,m,p,q,x0*.58*size,-.145*size,z0,i/4f,1,color);
   point(out,m,p,q,x1*.58*size,-.145*size,z1,(i+1)/4f,1,color);point(out,m,p,q,x1*.58*size,.145*size,z1,(i+1)/4f,0,color);
  }
 }
 private static void coin(VertexConsumer out,MatrixStack m,Vec3d p,Quaternionf q,double size,int color){
  double r=.155*size,d=.025*size;
  for(int side:new int[]{-1,1}){point(out,m,p,q,-r,r,side*d,0,0,color);point(out,m,p,q,-r,-r,side*d,0,1,color);point(out,m,p,q,r,-r,side*d,1,1,color);point(out,m,p,q,r,r,side*d,1,0,color);}
  for(int i=0;i<16;i++){double a=i*Math.PI/8,b=(i+1)*Math.PI/8;double x=Math.cos(a)*r,y=Math.sin(a)*r,xx=Math.cos(b)*r,yy=Math.sin(b)*r;
   point(out,m,p,q,x,y,-d,.25f,.25f,color);point(out,m,p,q,xx,yy,-d,.3f,.25f,color);point(out,m,p,q,xx,yy,d,.3f,.3f,color);point(out,m,p,q,x,y,d,.25f,.3f,color);
  }
 }
 private static void point(VertexConsumer out,MatrixStack m,Vec3d p,Quaternionf q,double x,double y,double z,float u,float v,int color){var a=new Vector3f((float)x,(float)y,(float)z).rotate(q);out.vertex(m.peek().getPositionMatrix(),(float)p.x+a.x,(float)p.y+a.y,(float)p.z+a.z).texture(u,v).color(color);}
 private LarpEffects(){}
}
