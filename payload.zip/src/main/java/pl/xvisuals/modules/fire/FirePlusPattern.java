package pl.xvisuals.modules.fire;

/** Pure, deterministic flame field shared by block and native entity fire textures. */
public final class FirePlusPattern {
 public static int pixel(double u,double v,double time,int style,int low,int high,double intensity){
  double h=1-v,t=time,x=u*6.2831853;
  double bend=Math.sin(x*2-t*1.6-h*5)*.17+Math.sin(x*5+t*2.3-h*9)*.09;
  double tongues=.5+.5*Math.sin(x*3+bend*4-t*1.7-h*4);
  double height=.40+.38*tongues+.13*Math.sin(x*7+t*2.1);
  if(style==1)height=.48+.30*Math.sin(x*2+t*.9+h*2)+.13*Math.sin(x*5-t*1.3);
  if(style==2)height=.50+.30*Math.sin(x*4-t*2.6+h*4)+.12*Math.sin(x*9+t*3);
  double field=(height-h)*8;
  double alpha=Math.max(0,Math.min(1,field));
  // Detached, rising cinders stay inside the same depth-tested flame geometry.
  double cy=fract(t*.29+Math.floor(u*11)*.618),cx=fract(Math.sin(Math.floor(u*11)*19.3)*451.7);
  if(h>.5&&Math.abs(fract(u*11)-cx)<.10&&Math.abs(h-cy)<.018)alpha=Math.max(alpha,.85);
  double heat=Math.max(0,Math.min(1,(1-h)*.63+Math.max(0,field)*.065+.17*Math.sin(x*4-t*2+h*9)+.08*Math.sin(x*7+t*2.7-h*12)));
  heat=Math.pow(heat,1.35);
  int r=channel(low,high,16,heat,intensity),g=channel(low,high,8,heat,intensity),b=channel(low,high,0,heat,intensity);
  return ((int)Math.round(alpha*255)<<24)|(r<<16)|(g<<8)|b;
 }
 /** Separate body-flame field: broad curved tongues, soft gaps and no detached square cinders. */
 public static int playerPixel(double u,double v,double time,int style,int low,int high,double intensity){
  double h=1-v,t=time*(style==1?.72:style==2?1.25:1),density=0,heat=0;
  for(int i=0;i<5;i++){
   double phase=i*2.399,top=.57+.17*Math.sin(t*1.25+phase)+.10*Math.cos(phase*2);
   double along=h/top;
   if(along>=1)continue;
   double center=.1+i*.2+(.035*Math.sin(t*1.7+phase-h*5)+.04*Math.sin(h*5-t*1.1+phase))*h;
   double width=(.095+.025*Math.sin(phase+1))*Math.pow(1-along,.65)+.008;
   double d=Math.abs(u-center)/width;
   double tongue=Math.max(0,Math.min(1,(1-d)*3))*Math.min(1,(1-along)*9);
   // Travelling warm folds break up the solid strip without strobing.
   double fold=.7+.3*Math.sin(h*13-t*3+phase);
   density=Math.max(density,tongue);
   heat=Math.max(heat,tongue*(.25+.6*(1-along))*fold);
  }
  double edge=Math.min(1,Math.min(u,1-u)*18);
  int a=(int)Math.round(255*density*Math.max(0,edge));
  return (a<<24)|(channel(low,high,16,heat,intensity)<<16)|(channel(low,high,8,heat,intensity)<<8)|channel(low,high,0,heat,intensity);
 }
 private static int channel(int a,int b,int shift,double f,double strength){return (int)Math.max(0,Math.min(255,(((a>>shift)&255)*(1-f)+((b>>shift)&255)*f)*strength));}
 private static double fract(double x){return x-Math.floor(x);}
 public static int average(int a,int b,int c,int d){
  int aa=a>>>24,ab=b>>>24,ac=c>>>24,ad=d>>>24,total=aa+ab+ac+ad;if(total==0)return 0;
  int result=((total+2)/4)<<24;for(int shift=0;shift<=16;shift+=8)result|=((((a>>shift)&255)*aa+((b>>shift)&255)*ab+((c>>shift)&255)*ac+((d>>shift)&255)*ad)/total)<<shift;return result;
 }
 private FirePlusPattern(){}
}

