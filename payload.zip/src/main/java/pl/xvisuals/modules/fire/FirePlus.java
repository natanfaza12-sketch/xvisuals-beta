package pl.xvisuals.modules.fire;

import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.*;
import pl.xvisuals.mixins.FirePlusImageAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.*;
import net.minecraft.util.Identifier;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.*;
import static pl.xvisuals.modules.Setting.*;

/** Changes only fire sprite rectangles, including their mip levels and padding. Native geometry is untouched. */
public final class FirePlus {
 private static Setting flameColor(String key,String label,String value){return new Setting(key,label,Setting.Kind.COLOR,value,0,0,0,List.of());}
 public static ModuleSpec spec(){return new ModuleSpec("fireplus","Fire+","World","Animated living flames, spectral soul fire and configurable player-burning visuals.","F",false,List.of(
  flag("fire","Fire blocks",true),flag("soul","Soul-fire blocks",true),flag("players","Custom player flames",true),
  flag("showSelf","Show flames on self",true),flag("showOthers","Show flames on other players",true),flag("showMobs","Show flames on mobs",true),flag("showOverlay","Show first-person fire",true),
  number("playerWidth","Player flame width",1,.25,2,.05),number("playerHeight","Player flame height",1,.15,1.5,.05),number("blockHeight","Fire-block flame height",1,.25,1,.05),number("soulHeight","Soul-fire flame height",1,.25,1,.05),
  choice("style","Flame motion","Dancing","Dancing","Wisps","Surge"),number("speed","Animation speed",1,.2,3,.1),number("brightness","Flame brightness",1,.5,1.5,.05),
  flameColor("fireEdge","Fire outer colour","#ED3918"),flameColor("fireCore","Fire core colour","#FFF2B5"),flameColor("soulEdge","Soul outer colour","#1556C9"),flameColor("soulCore","Soul core colour","#9AFFF0"),
  choice("playerPalette","Player flames","Fire","Fire","Soul","Custom"),flameColor("playerEdge","Player outer colour","#9E35EA"),flameColor("playerCore","Player core colour","#FFCCFC"),
  flag("firstPerson","Custom first-person flames",true),number("overlayHeight","First-person flame height",.55,.25,1,.05),number("overlayOpacity","First-person opacity",.7,.2,1,.05)
  ));}
 private static final Identifier PLAYER=Identifier.of("xvisuals","dynamic/fireplus_player");
 // LowOnFire uses fire_2 for inner/floor faces while keeping the vanilla side sprites.
 // Optional entries are skipped when a pack does not supply them.
 private static final Identifier[] IDS={Identifier.ofVanilla("block/fire_0"),Identifier.ofVanilla("block/fire_1"),Identifier.ofVanilla("block/soul_fire_0"),Identifier.ofVanilla("block/soul_fire_1"),Identifier.ofVanilla("block/fire_2"),Identifier.ofVanilla("block/soul_fire_2")};
 private static final Map<SpriteAtlasTexture,List<Slot>> CACHE=new IdentityHashMap<>();
 private static NativeImageBackedTexture playerTexture;private static Sprite playerSprite,playerSpriteAlt;private static long lastPlayer,clock=System.nanoTime();private static double time;
 public static boolean enabled(){return XVisuals.ready()&&XVisuals.config().on("fireplus");}
 public static boolean players(){return enabled()&&XVisuals.config().module("fireplus").flag("players");}
 public static boolean overlay(){return players()&&XVisuals.config().module("fireplus").flag("firstPerson");}
 public static boolean hideOverlay(){return enabled()&&(!XVisuals.config().module("fireplus").flag("showSelf")||!XVisuals.config().module("fireplus").flag("showOverlay"));}
 public static boolean hideEntity(net.minecraft.client.render.entity.state.EntityRenderState state){
  if(!enabled())return false;
  var s=XVisuals.config().module("fireplus");
  if(state instanceof net.minecraft.client.render.entity.state.PlayerEntityRenderState player){var local=MinecraftClient.getInstance().player;return !s.flag(local!=null&&player.id==local.getId()?"showSelf":"showOthers");}
  return !s.flag("showMobs");
 }
 public static float size(String key){return (float)XVisuals.config().module("fireplus").number(key);}
 public static Identifier playerTexture(){sprite();return PLAYER;}
 private static double time(){long now=System.nanoTime();if(!MinecraftClient.getInstance().isPaused())time+=Math.min(.1,(now-clock)/1e9);clock=now;return time;}
 public static void clear(SpriteAtlasTexture atlas){var slots=CACHE.remove(atlas);if(slots!=null)slots.forEach(Slot::close);}
 public static void init(){net.fabricmc.fabric.api.resource.v1.ResourceLoader.get(net.minecraft.resource.ResourceType.CLIENT_RESOURCES).registerReloader(Identifier.of("xvisuals","fireplus"),(net.minecraft.resource.SynchronousResourceReloader)r->{
  CACHE.values().forEach(list->list.forEach(Slot::close));CACHE.clear();
  if(playerTexture!=null){MinecraftClient.getInstance().getTextureManager().destroyTexture(PLAYER);playerTexture=null;}if(playerSprite!=null){playerSprite.close();playerSprite=null;}if(playerSpriteAlt!=null){playerSpriteAlt.close();playerSpriteAlt=null;}lastPlayer=0;
 });}
 public static void atlasTick(SpriteAtlasTexture atlas){
  if(!atlas.getId().equals(SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE))return;
  if(atlas.getGlTexture()==null||atlas.getGlTexture().isClosed())return;
  boolean on=enabled();if(!on&&!CACHE.containsKey(atlas))return;
  var slots=CACHE.get(atlas);
  if(slots==null){slots=new ArrayList<>();for(int i=0;i<IDS.length;i++){var sprite=atlas.getSprite(IDS[i]);if(sprite.getContents().getId().equals(IDS[i])&&sprite.getContents().getWidth()<=128&&sprite.getContents().getHeight()<=128)slots.add(new Slot(atlas,sprite,i));}CACHE.put(atlas,slots);}
  double t=time();var s=XVisuals.config().module("fireplus");
  for(var slot:slots){boolean active=on&&s.flag(slot.soul()?"soul":"fire");if(active){slot.draw(t*s.number("speed"));slot.write(atlas,false);slot.changed=true;}else if(slot.changed){slot.write(atlas,true);slot.changed=false;}}
 }
 public static Sprite sprite(boolean alternate){sprite();return alternate?playerSpriteAlt:playerSprite;}
 public static Sprite sprite(){
  if(playerTexture==null){playerTexture=new NativeImageBackedTexture(()->"Fire+ player flames",new NativeImage(128,64,false));MinecraftClient.getInstance().getTextureManager().registerTexture(PLAYER,playerTexture);playerSprite=new Standalone(0);playerSpriteAlt=new Standalone(64);}
  long now=System.nanoTime();if(now-lastPlayer>25_000_000L){lastPlayer=now;var s=XVisuals.config().module("fireplus");String palette=s.text("playerPalette");int low=s.color(palette.equals("Soul")?"soulEdge":palette.equals("Custom")?"playerEdge":"fireEdge"),high=s.color(palette.equals("Soul")?"soulCore":palette.equals("Custom")?"playerCore":"fireCore");double t=time()*s.number("speed");int style=switch(s.text("style")){case "Wisps"->1;case "Surge"->2;default->0;};for(int y=0;y<64;y++)for(int x=0;x<128;x++)playerTexture.getImage().setColorArgb(x,y,FirePlusPattern.playerPixel(((x%64)+.5)/64,(y+.5)/64,t+(x/64)*1.9,style,low,high,s.number("brightness")));playerTexture.upload();}return playerSprite;
 }
 private static final class Standalone extends Sprite {Standalone(int x){super(PLAYER,new SpriteContents(PLAYER,new SpriteDimensions(64,64),new NativeImage(64,64,false)),128,64,x,0,0);}}
 private static void fill(NativeImage image,int w,int h,int pad,double t,int low,int high,double height){var s=XVisuals.config().module("fireplus");int style=switch(s.text("style")){case "Wisps"->1;case "Surge"->2;default->0;};double strength=s.number("brightness");for(int y=0;y<image.getHeight();y++)for(int x=0;x<image.getWidth();x++){double u=(Math.max(0,Math.min(w-1,x-pad))+.5)/w,v=(Math.max(0,Math.min(h-1,y-pad))+.5)/h;image.setColorArgb(x,y,FirePlusPattern.pixel(u,1-(1-v)/height,t,style,low,high,strength));}}
 private static final class Slot {
  final int index,x,y;final NativeImage[] frames,original;final int[] widths,heights,pads;boolean changed;
  Slot(SpriteAtlasTexture atlas,Sprite sprite,int index){this.index=index;x=sprite.getX();y=sprite.getY();int w=sprite.getContents().getWidth(),h=sprite.getContents().getHeight(),pad=Math.round(sprite.getMinU()*atlas.getGlTexture().getWidth(0))-x;
   int levels=Math.min(atlas.getGlTexture().getMipLevels(),1+Integer.numberOfTrailingZeros(Integer.highestOneBit(Math.min(w,h))));frames=new NativeImage[levels];original=new NativeImage[levels];widths=new int[levels];heights=new int[levels];pads=new int[levels];
   NativeImage[] nativeLevels=((FirePlusImageAccessor)(Object)sprite.getContents()).fireplus$images();
   for(int m=0;m<levels;m++){int mw=Math.max(1,w>>m),mh=Math.max(1,h>>m),mp=pad>>m;widths[m]=mw;heights[m]=mh;pads[m]=mp;frames[m]=new NativeImage(mw+mp*2,mh+mp*2,false);original[m]=new NativeImage(mw+mp*2,mh+mp*2,false);var nativeImage=nativeLevels[Math.min(m,nativeLevels.length-1)];for(int py=0;py<original[m].getHeight();py++)for(int px=0;px<original[m].getWidth();px++)original[m].setColorArgb(px,py,nativeImage.getColorArgb(Math.min(nativeImage.getWidth()-1,Math.max(0,px-mp)),Math.min(nativeImage.getHeight()-1,Math.max(0,py-mp))));}
  }
  boolean soul(){return IDS[index].getPath().startsWith("block/soul_fire_");}
  void draw(double t){var s=XVisuals.config().module("fireplus");int low=s.color(soul()?"soulEdge":"fireEdge"),high=s.color(soul()?"soulCore":"fireCore");fill(frames[0],widths[0],heights[0],pads[0],t+(index%2)*1.73,low,high,s.number(soul()?"soulHeight":"blockHeight"));
   for(int m=1;m<frames.length;m++){var src=frames[m-1];var dst=frames[m];for(int py=0;py<dst.getHeight();py++)for(int px=0;px<dst.getWidth();px++){
    int sx=Math.max(0,Math.min(src.getWidth()-1,(px-pads[m])*2+pads[m-1])),sy=Math.max(0,Math.min(src.getHeight()-1,(py-pads[m])*2+pads[m-1])),nx=Math.min(src.getWidth()-1,sx+1),ny=Math.min(src.getHeight()-1,sy+1);
    dst.setColorArgb(px,py,FirePlusPattern.average(src.getColorArgb(sx,sy),src.getColorArgb(nx,sy),src.getColorArgb(sx,ny),src.getColorArgb(nx,ny)));
   }}
  }
  void write(SpriteAtlasTexture atlas,boolean restore){var encoder=RenderSystem.getDevice().createCommandEncoder();var images=restore?original:frames;for(int m=0;m<images.length;m++){var image=images[m];encoder.writeToTexture(atlas.getGlTexture(),image,m,0,x>>m,y>>m,image.getWidth(),image.getHeight(),0,0);}}
  void close(){for(var image:frames)image.close();for(var image:original)image.close();}
 }
 private FirePlus(){}
}

