package pl.xvisuals.modules.crosshair;

import pl.xvisuals.XVisuals;
import pl.xvisuals.config.VisualConfig.ModuleState;
import pl.xvisuals.util.Colors;
import net.minecraft.client.gui.DrawContext;

public final class CustomCrosshair {
  public static String design(ModuleState s) {
    return s.text("preset").equals("Custom") ? CrosshairDesign.normalize(s.text("pixels"))
        : CrosshairDesign.preset(s.text("preset"),s.integer("length"),s.integer("gap"),s.integer("thickness"),s.flag("dot"));
  }
  private static String key = "", cached;
  private static String outlineSource="", outlineMask="";
  public static long renderedFrames;
  public static void render(DrawContext g) {
    var s=XVisuals.config().module("crosshair");
    String next=s.text("preset")+":"+s.text("length")+":"+s.text("gap")+":"+s.text("thickness")+":"+s.flag("dot")+":"+s.text("pixels");
    if(!next.equals(key)) { key=next; cached=design(s); }
    draw(g,cached,g.getScaledWindowWidth()/2f,g.getScaledWindowHeight()/2f,s);
    renderedFrames++;
  }
  public static void draw(DrawContext g,String pixels,float x,float y,ModuleState s) {
    g.getMatrices().pushMatrix();
    g.getMatrices().translate(x,y);
    float scale=(float)s.number("scale");
    g.getMatrices().scale(scale,scale);
    g.getMatrices().rotate((float)Math.toRadians(s.number("rotation")));
    g.getMatrices().translate(-15.5f,-15.5f);
    double alpha=s.number("opacity");
    if(s.flag("outline")) {
      int color=Colors.alpha(s.color("outlineColor"),alpha);
      if(!pixels.equals(outlineSource)) {
        char[] mask="0".repeat(33*33).toCharArray();
        for(int py=0;py<31;py++) for(int px=0;px<31;px++) if(pixels.charAt(py*31+px)!='0')
          for(int dy=0;dy<3;dy++) for(int dx=0;dx<3;dx++) mask[(py+dy)*33+px+dx]='1';
        outlineSource=pixels; outlineMask=new String(mask);
      }
      for(int py=0;py<33;py++) for(int px=0;px<33;) {
        int end=px+1; char ink=outlineMask.charAt(py*33+px);
        while(end<33 && outlineMask.charAt(py*33+end)==ink) end++;
        if(ink=='1') g.fill(px-1,py-1,end-1,py,color);
        px=end;
      }
    }
    for(int py=0;py<31;py++) for(int px=0;px<31;) {
      char ink=pixels.charAt(py*31+px); int end=px+1;
      while(end<31 && pixels.charAt(py*31+end)==ink) end++;
      if(ink!='0') g.fill(px,py,end,py+1,Colors.alpha(s.color(ink=='2'?"secondary":"color"),alpha));
      px=end;
    }
    g.getMatrices().popMatrix();
  }
  private CustomCrosshair() {}
}
