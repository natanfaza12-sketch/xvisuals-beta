package pl.xvisuals.modules.crosshair;

/** Small, bounded pixel design shared by the editor and HUD renderer. */
public final class CrosshairDesign {
  public static final int SIZE = 31, CENTER = 15, CELLS = SIZE * SIZE;
  public static final String[] PRESETS = {"Classic", "Dot", "Halo", "Diamond", "Chevron", "Brackets", "Star", "Focus", "Custom"};
  public static String normalize(String value) {
    if (value == null || value.length() != CELLS) return "0".repeat(CELLS);
    StringBuilder result = new StringBuilder(CELLS);
    for (int i = 0; i < CELLS; i++) result.append(value.charAt(i) == '1' || value.charAt(i) == '2' ? value.charAt(i) : '0');
    return result.toString();
  }
  public static String preset(String name, int length, int gap, int thickness, boolean dot) {
    char[] pixels = "0".repeat(CELLS).toCharArray();
    length = Math.clamp(length, 1, 12); gap = Math.clamp(gap, 0, 10); thickness = Math.clamp(thickness, 1, 5);
    int radius = Math.min(14, gap + length), half = thickness / 2;
    for (int y = -15; y <= 15; y++) for (int x = -15; x <= 15; x++) {
      int ax = Math.abs(x), ay = Math.abs(y);
      boolean horizontal = y >= -half && y < thickness-half && ax > gap && ax <= radius;
      boolean vertical = x >= -half && x < thickness-half && ay > gap && ay <= radius;
      double distance = Math.hypot(x, y);
      boolean ink = switch (name) {
        case "Dot" -> distance <= Math.max(1, thickness);
        case "Halo" -> Math.abs(distance - radius) < thickness * .5 + .25;
        case "Diamond" -> Math.abs(ax + ay - radius) < thickness;
        case "Chevron" -> y >= -radius/2 && y <= radius/2 && Math.abs(ax - (y + radius/2)) < thickness;
        case "Brackets" -> ax >= radius-thickness && ax <= radius && ay <= radius || ay >= radius-thickness && ay <= radius && ax >= radius-3 && ax <= radius;
        case "Star" -> horizontal || vertical || ax > gap && ax <= radius*.7 && Math.abs(ax-ay) < thickness;
        case "Focus" -> horizontal || vertical || Math.abs(distance-radius*.65) < .6;
        default -> horizontal || vertical;
      };
      if (ink) pixels[(y+15)*SIZE+x+15] = '1';
      if (dot && distance <= Math.max(.5, thickness*.5)) pixels[(y+15)*SIZE+x+15] = '2';
    }
    return new String(pixels);
  }
  public static void stroke(char[] pixels, int x0, int y0, int x1, int y1, char ink, boolean mirrorX, boolean mirrorY) {
    int steps = Math.max(Math.abs(x1-x0), Math.abs(y1-y0));
    for (int i = 0; i <= steps; i++) {
      double t = steps == 0 ? 0 : i/(double)steps;
      int x = (int)Math.round(x0+(x1-x0)*t), y = (int)Math.round(y0+(y1-y0)*t);
      put(pixels,x,y,ink);
      if(mirrorX) put(pixels,30-x,y,ink);
      if(mirrorY) put(pixels,x,30-y,ink);
      if(mirrorX && mirrorY) put(pixels,30-x,30-y,ink);
    }
  }
  private static void put(char[] pixels, int x, int y, char ink) {
    if (x>=0 && y>=0 && x<SIZE && y<SIZE) pixels[y*SIZE+x]=ink;
  }
  private CrosshairDesign() {}
}
