package pl.xvisuals.modules.explosion;

import org.lwjgl.opengl.GL33;

/** Nonblocking GPU timestamps, enabled only in the opt-in development fixture. */
public final class ExplosionProfiler {
  private static final boolean ENABLED=Boolean.getBoolean("visuals.explosions");
  private static final int[][] START=new int[3][8],END=new int[3][8];
  private static final boolean[][] PENDING=new boolean[3][8];
  private static final int[] CURSOR=new int[3];
  public static final double[] gpuTotal=new double[3],gpuMax=new double[3];
  public static final int[] samples=new int[3];
  public static void begin(int channel) {
    if(!ENABLED)return;int i=CURSOR[channel];
    if(START[channel][i]==0) { START[channel][i]=GL33.glGenQueries();END[channel][i]=GL33.glGenQueries(); }
    if(PENDING[channel][i]) {
      if(GL33.glGetQueryObjecti(END[channel][i],GL33.GL_QUERY_RESULT_AVAILABLE)==0)return;
      double ms=(GL33.glGetQueryObjecti64(END[channel][i],GL33.GL_QUERY_RESULT)-GL33.glGetQueryObjecti64(START[channel][i],GL33.GL_QUERY_RESULT))/1e6;
      gpuTotal[channel]+=ms;gpuMax[channel]=Math.max(gpuMax[channel],ms);samples[channel]++;PENDING[channel][i]=false;
    }
    GL33.glQueryCounter(START[channel][i],GL33.GL_TIMESTAMP);
  }
  public static void end(int channel) {
    if(!ENABLED)return;int i=CURSOR[channel];if(PENDING[channel][i])return;
    GL33.glQueryCounter(END[channel][i],GL33.GL_TIMESTAMP);PENDING[channel][i]=true;CURSOR[channel]=(i+1)%8;
  }
  public static void reset() { java.util.Arrays.fill(gpuTotal,0);java.util.Arrays.fill(gpuMax,0);java.util.Arrays.fill(samples,0); }
  public static void close() {
    if(!ENABLED)return;
    for(int c=0;c<3;c++)for(int i=0;i<8;i++)if(START[c][i]!=0) {GL33.glDeleteQueries(START[c][i]);GL33.glDeleteQueries(END[c][i]);START[c][i]=END[c][i]=0;PENDING[c][i]=false;}
  }
  private ExplosionProfiler() {}
}
