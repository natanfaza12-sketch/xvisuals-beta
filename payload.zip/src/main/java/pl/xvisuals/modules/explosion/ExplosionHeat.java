package pl.xvisuals.modules.explosion;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;
import pl.xvisuals.mixins.*;
import pl.xvisuals.rendering.Projection;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.PostEffectProcessor;
import net.minecraft.client.render.DefaultFramebufferSet;
import net.minecraft.client.util.memory.ObjectAllocator;
import net.minecraft.util.Identifier;
import java.nio.*;

/** Reuses the existing post-effect architecture, with a strict four-region limit and no idle pass. */
public final class ExplosionHeat {
  private static final Identifier ID=Identifier.of("xvisuals","explosion_heat");
  private static final ByteBuffer DATA=ByteBuffer.allocateDirect(96).order(ByteOrder.nativeOrder());
  private static final Projection PROJECT=new Projection();
  private static final Projection.Point POINT=new Projection.Point();
  private static final float[] REGIONS=new float[16],DEPTHS=new float[4];
  private static final java.util.Map<PostEffectProcessor,Boolean> PREPARED=new java.util.WeakHashMap<>();
  public static int regions;
  public static double cpuMs;
  public static void render(ObjectAllocator pool) {
    var c=MinecraftClient.getInstance();var s=ExplosionFX.settings();cpuMs=0;
    if(ExplosionFloor.rendered || !s.enabled || !s.flag("heat") || c.world==null)return;
    long start=System.nanoTime();
    var effect=c.getShaderLoader().loadPostEffect(ID,DefaultFramebufferSet.MAIN_ONLY);
    if(effect==null)return;
    boolean warm=!PREPARED.containsKey(effect);
    upload(effect);
    if(regions==0&&!warm)return;
    ExplosionProfiler.begin(1);effect.render(c.getFramebuffer(),pool);ExplosionProfiler.end(1);
    cpuMs=(System.nanoTime()-start)/1e6;
  }
  /** The floor pass consumes these same uniforms, avoiding a second full-screen render/copy. */
  public static void upload(PostEffectProcessor effect) {
    regions=0;var c=MinecraftClient.getInstance();var s=ExplosionFX.settings();
    boolean enabled=s.enabled&&s.flag("heat")&&s.number("heatStrength")>0&&!s.text("quality").equals("Low");
    PROJECT.begin(c,c.getRenderTickCounter().getTickProgress(false));
    float fov=((GameRendererAccessor)c.gameRenderer).visuals$getFov(c.gameRenderer.getCamera(),PROJECT.tick,true);
    var projection=c.gameRenderer.getBasicProjectionMatrix(fov);
    double now=ExplosionFX.time(),strength=s.number("heatStrength");
    java.util.Arrays.fill(REGIONS,0);java.util.Arrays.fill(DEPTHS,0);
    for(var b:ExplosionFX.BLASTS) if(enabled && b.active && b.major && b.preset.rich()) {
      double age=now-b.born;
      if(age<.015||age>1.2||regions==4||!ExplosionVisibility.visible(b.pos))continue;
      if(!PROJECT.project(b.pos,POINT)||!POINT.visible||POINT.depth<3||POINT.depth>64)continue;
      double radius=Math.min(b.localSize*.7,1+age*8);
      int at=regions*4;
      REGIONS[at]=(float)(POINT.x/PROJECT.width);REGIONS[at+1]=(float)(1-POINT.y/PROJECT.height);
      REGIONS[at+2]=(float)Math.min(.5,projection.m11()*.5*radius/POINT.depth);
      REGIONS[at+3]=(float)(strength*Math.sin(Math.PI*age/1.2)*(b.water?.4:1));
      DEPTHS[regions]=(float)Math.max(.2,POINT.depth-radius);regions++;
    }
    DATA.clear();for(float v:REGIONS)DATA.putFloat(v);for(float v:DEPTHS)DATA.putFloat(v);
    DATA.putFloat(projection.m22()).putFloat(projection.m32()).putFloat((float)(now%1000)).putFloat((float)PROJECT.width/PROJECT.height).flip();
    boolean prepared=PREPARED.containsKey(effect);
    for(var pass:((PostProcessorAccessor)effect).visuals$passes()) {
      var map=((PostPassAccessor)pass).visuals$uniforms();var old=map.get("ExplosionHeat");
      if(old==null)continue;
      // Fixed-size GPU allocation belongs to the processor and is reused every frame.
      if(!prepared) {
        old.close();
        map.put("ExplosionHeat",RenderSystem.getDevice().createBuffer(()->"Explosion heat regions",
            GpuBuffer.USAGE_UNIFORM|GpuBuffer.USAGE_COPY_DST,DATA));
      } else RenderSystem.getDevice().createCommandEncoder().writeToBuffer(old.slice(),DATA);
      DATA.rewind();
    }
    PREPARED.put(effect,true);
  }
  private ExplosionHeat() {}
}
