package pl.xvisuals.modules.explosion;

import pl.xvisuals.XVisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.TntEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.block.*;
import net.minecraft.util.math.*;

/** Recent source evidence; packets have radius and origin, but no source type. */
public final class ExplosionSources {
  public enum Type { TNT, CRYSTAL, CREEPER, BED, ANCHOR, OTHER;
    public String key() { return name().toLowerCase(java.util.Locale.ROOT); }
  }
  private static final Hint[] HINTS=new Hint[128];
  private static int next;
  private static Object world;
  private static final class Hint { Vec3d pos; Type type; double time; boolean removed; }
  static { for(int i=0;i<HINTS.length;i++) HINTS[i]=new Hint(); }
  public static void clear() { for(var h:HINTS) h.pos=null; }
  public static void remember(Vec3d pos,Type type,boolean removed) {
    if(!XVisuals.visualModule("explosionfx").enabled || type==Type.OTHER) return;
    var h=HINTS[next++%HINTS.length]; h.pos=pos; h.type=type; h.time=ExplosionFX.time(); h.removed=removed;
  }
  public static Type entityType(Entity e) {
    return e instanceof TntEntity ? Type.TNT : e instanceof EndCrystalEntity ? Type.CRYSTAL
        : e instanceof CreeperEntity ? Type.CREEPER : Type.OTHER;
  }
  public static void removed(Entity e) { if(e!=null) remember(e.getEntityPos(),entityType(e),true); }
  public static void block(BlockPos pos,BlockState old,BlockState replacement) {
    if(old.getBlock()==replacement.getBlock()) return;
    if(replacement.getBlock() instanceof BedBlock) remember(Vec3d.ofCenter(pos),Type.BED,false);
    if(replacement.isOf(Blocks.RESPAWN_ANCHOR)) remember(Vec3d.ofCenter(pos),Type.ANCHOR,false);
    if(old.getBlock() instanceof BedBlock) remember(Vec3d.ofCenter(pos),Type.BED,true);
    if(old.isOf(Blocks.RESPAWN_ANCHOR)) remember(Vec3d.ofCenter(pos),Type.ANCHOR,true);
  }
  public static void tick(MinecraftClient c) {
    if(world!=c.world) { clear(); world=c.world; }
    if(c.world==null || c.player==null || !XVisuals.visualModule("explosionfx").enabled) { clear(); return; }
    int budget=64;
    for(var e:c.world.getEntities()) {
      Type type=entityType(e);
      if(type!=Type.OTHER && e.squaredDistanceTo(c.player)<65536 && budget-->0)
        remember(e.getEntityPos(),type,false);
    }
  }
  public static Type classify(Vec3d pos) {
    double best=Double.MAX_VALUE,now=ExplosionFX.time(); Type type=Type.OTHER;
    for(var h:HINTS) if(h.pos!=null && now-h.time<.65) {
      double distance=h.pos.squaredDistanceTo(pos);
      if(distance>6.25) continue;
      double score=distance+(h.removed?0:1.5)+(now-h.time)*2;
      if(score<best) { best=score; type=h.type; }
    }
    // Block updates can arrive after the explosion packet, or enter through a chunk delta.
    // Read the still-visible source block only when entity/history evidence was unavailable.
    var c=MinecraftClient.getInstance();
    if(type==Type.OTHER && c.world!=null) {
      var center=BlockPos.ofFloored(pos);
      for(int y=-1;y<=1;y++)for(int z=-1;z<=1;z++)for(int x=-1;x<=1;x++) {
        var state=c.world.getBlockState(center.add(x,y,z));
        if(state.isOf(Blocks.RESPAWN_ANCHOR))return Type.ANCHOR;
        if(state.getBlock() instanceof BedBlock)return Type.BED;
      }
    }
    return type;
  }
  private ExplosionSources() {}
}
