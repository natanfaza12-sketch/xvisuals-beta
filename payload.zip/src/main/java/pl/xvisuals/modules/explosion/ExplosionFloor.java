package pl.xvisuals.modules.explosion;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;
import pl.xvisuals.mixins.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.PostEffectProcessor;
import net.minecraft.client.render.DefaultFramebufferSet;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.memory.ObjectAllocator;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import java.nio.*;

/** Screen-space ground light: follows visible floor depth, with no terrain mesh or chunk loading. */
public final class ExplosionFloor {
  private static final Identifier ID=Identifier.of("xvisuals","explosion_floor");
  private static final ByteBuffer DATA=ByteBuffer.allocateDirect(256).order(ByteOrder.nativeOrder());
  private static final Matrix4f INVERSE=new Matrix4f();
  private static final ExplosionFX.Blast[] PICKED=new ExplosionFX.Blast[4];
  private static final java.util.Map<PostEffectProcessor,Boolean> PREPARED=new java.util.WeakHashMap<>();
  private static Object capturedWorld;
  private static Object warmedWorld;
  public static double cpuMs;
  public static boolean rendered;
  public static void clear() { capturedWorld=null;warmedWorld=null;java.util.Arrays.fill(PICKED,null); }

  public static void capture(MatrixStack matrices) {
    rendered=false;
    var c=MinecraftClient.getInstance();
    if(c.world==null || !ExplosionFX.settings().enabled)return;
    float fov=((GameRendererAccessor)c.gameRenderer).visuals$getFov(c.gameRenderer.getCamera(),c.getRenderTickCounter().getTickProgress(false),true);
    INVERSE.set(c.gameRenderer.getBasicProjectionMatrix(fov)).mul(matrices.peek().getPositionMatrix()).invert();
    capturedWorld=c.world;
  }

  public static void render(ObjectAllocator pool) {
    long start=System.nanoTime();cpuMs=0;
    var c=MinecraftClient.getInstance();var s=ExplosionFX.settings();
    if(!s.enabled||!s.flag("ground")||c.world==null||capturedWorld!=c.world)return;
    double now=ExplosionFX.time();int count=0;
    java.util.Arrays.fill(PICKED,null);
    // Merge nearby origins into one floor pass region; retain a strict four-region budget.
    for(var b:ExplosionFX.BLASTS)if(b.active&&b.ground&&now>=b.born&&now-b.born<b.duration) {
      boolean duplicate=false;
      for(int i=0;i<count;i++)if(PICKED[i].pos.squaredDistanceTo(b.pos)<64&&Math.abs(PICKED[i].born-b.born)<.25) {duplicate=true;break;}
      if(duplicate || !ExplosionVisibility.visible(b.pos))continue;
      if(count<4)PICKED[count++]=b;
      else {
        int weakest=0;for(int i=1;i<4;i++)if(PICKED[i].score<PICKED[weakest].score)weakest=i;
        if(b.score>PICKED[weakest].score)PICKED[weakest]=b;
      }
    }
    if(count==0 && warmedWorld==c.world)return;
    var camera=c.gameRenderer.getCamera().getCameraPos();
    DATA.clear();INVERSE.get(0,DATA);DATA.position(64);
    for(int i=0;i<4;i++) {
      var b=PICKED[i];
      if(b==null){for(int j=0;j<4;j++)DATA.putFloat(0);continue;}
      DATA.putFloat((float)(b.pos.x-camera.x)).putFloat((float)(b.floorY-camera.y)).putFloat((float)(b.pos.z-camera.z))
          .putFloat((float)(b.size*ExplosionMath.radius(now-b.born,b.duration)));
    }
    for(int i=0;i<4;i++) {
      var b=PICKED[i];
      if(b==null){for(int j=0;j<4;j++)DATA.putFloat(0);continue;}
      int color=s.text("colorMode").equals("Rainbow")?pl.xvisuals.util.Colors.rainbow(now*.18+b.seed*.01):pl.xvisuals.util.Colors.mix(b.color,b.secondary,.35);
      DATA.putFloat(((color>>16)&255)/255f).putFloat(((color>>8)&255)/255f).putFloat((color&255)/255f)
          .putFloat((float)(ExplosionMath.fade(now-b.born,b.duration)*Math.min(1.4,b.preset.energy())));
    }
    for(int i=0;i<4;i++) {
      var b=PICKED[i];
      DATA.putFloat(b==null?0:(float)(now-b.born)).putFloat(b==null?0:(float)b.seed)
          .putFloat((float)s.number("thickness")).putFloat((s.flag("primary")?1:0)+(s.flag("secondaryWave")?2:0));
    }
    DATA.flip();
    var effect=c.getShaderLoader().loadPostEffect(ID,DefaultFramebufferSet.MAIN_ONLY);
    if(effect==null)return;
    boolean prepared=PREPARED.containsKey(effect);
    for(var pass:((PostProcessorAccessor)effect).visuals$passes()) {
      var uniforms=((PostPassAccessor)pass).visuals$uniforms();var old=uniforms.get("ExplosionFloor");
      if(old==null)continue;
      if(!prepared) {
        old.close();uniforms.put("ExplosionFloor",RenderSystem.getDevice().createBuffer(()->"Explosion floor sweep",
            GpuBuffer.USAGE_UNIFORM|GpuBuffer.USAGE_COPY_DST,DATA));
      } else RenderSystem.getDevice().createCommandEncoder().writeToBuffer(old.slice(),DATA);
      DATA.rewind();
    }
    PREPARED.put(effect,true);
    ExplosionHeat.upload(effect);
    ExplosionProfiler.begin(2);effect.render(c.getFramebuffer(),pool);ExplosionProfiler.end(2);
    rendered=true;warmedWorld=c.world;cpuMs=(System.nanoTime()-start)/1e6;
  }
  private ExplosionFloor() {}
}

