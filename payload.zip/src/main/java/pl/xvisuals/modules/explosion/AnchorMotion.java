package pl.xvisuals.modules.explosion;

/** Deterministic spatial choreography, sampled over each effect's lifetime. */
public final class AnchorMotion {
  public record Point(double x,double y,double z) {}
  public static Point sample(String style,double progress,int index,int count) {
    double p=Math.clamp(progress,0,1),t=(index+.5)/Math.max(1,count),a=t*Math.PI*2;
    double r,y;
    switch(style) {
      case "Orbit Rings" -> { a+=p*Math.PI*3; r=.65+.15*Math.sin(p*Math.PI); y=.25+ .5*(index%2)+.15*Math.sin(a); }
      case "Soul Spiral" -> { a+=p*Math.PI*5; r=.7*(1-p)+.12; y=.2+p*1.8; }
      case "Rune Crown" -> { a=Math.floor(t*8)*Math.PI/4; r=.68; y=.45+Math.sin(p*Math.PI)*.85+(index%3)*.09; }
      case "Shockwave" -> { double wave=Math.max(0,p-(index%3)*.09); r=.25+wave*4.5; y=-.35+(index%3)*.35; }
      case "Soul Nova" -> { a=index*2.3999632297; double v=1-2*t; r=(.1+4*p)*Math.sqrt(1-v*v); y=v*4*p; }
      case "Rift Collapse" -> { a+=p*Math.PI*5; r=p<.3 ? 1.6*(1-p/.3)+.1 : .1+3*(p-.3)/.7; y=(t-.5)*2*Math.sin(p*Math.PI); }
      default -> { a=index*2.3999632297; double v=1-2*t; r=(.2+3*Math.sin(p*Math.PI*.5))*Math.sqrt(1-v*v); y=v*2.7*p; }
    }
    return new Point(Math.cos(a)*r,y,Math.sin(a)*r);
  }
  private AnchorMotion() {}
}
