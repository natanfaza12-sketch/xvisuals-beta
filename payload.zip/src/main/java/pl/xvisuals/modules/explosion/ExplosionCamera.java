package pl.xvisuals.modules.explosion;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

/** Analytic damped impulses: deterministic, continuous and additive, without per-frame random jitter. */
public final class ExplosionCamera {
  private static final Kick[] KICKS=new Kick[32];
  private static int next;
  public static double yaw,pitch,roll,fov,x,y,z;
  private static final class Kick { double born,amplitude,dx,dz,phase; boolean active; }
  static { for(int i=0;i<KICKS.length;i++)KICKS[i]=new Kick(); }
  public static void clear() { for(var k:KICKS)k.active=false; yaw=pitch=roll=fov=x=y=z=0; }
  public static void add(Vec3d origin,double power,double energy) {
    var c=MinecraftClient.getInstance();var s=ExplosionFX.settings();
    if(!(s.flag("shake")||s.flag("roll")||s.flag("fov")))return;
    var delta=c.gameRenderer.getCamera().getCameraPos().subtract(origin);double distance=delta.length();
    double amplitude=ExplosionMath.attenuation(distance,Math.min(64,s.number("distance")))*Math.min(1.8,power/4)*energy*s.number("cameraStrength");
    if(amplitude<.002)return;
    var k=KICKS[next++%KICKS.length]; k.active=true;k.amplitude=amplitude;
    k.born=ExplosionFX.time()+ExplosionMath.delay(distance,s.number("travelSpeed"),s.flag("distanceDelay"));
    k.dx=delta.x/Math.max(.01,distance);k.dz=delta.z/Math.max(.01,distance); k.phase=next*.81;
  }
  public static void frame() {
    yaw=pitch=roll=fov=x=y=z=0;var s=ExplosionFX.settings();
    if(!s.enabled) { clear();return; }
    double now=ExplosionFX.time();
    for(var k:KICKS) if(k.active) {
      double age=now-k.born;
      if(age>1.2) { k.active=false;continue; }
      if(age<0)continue;
      double pulse=ExplosionMath.impulse(age)*k.amplitude;
      if(s.flag("shake")) {
        yaw+=pulse*Math.sin(age*11+k.phase)*1.2; pitch+=pulse*1.6;
        x+=pulse*k.dx*.045;z+=pulse*k.dz*.045;y+=pulse*.016;
      }
      if(s.flag("roll"))roll+=pulse*Math.sin(k.phase)*1.5;
      if(s.flag("fov"))fov+=Math.abs(pulse)*2.4;
    }
    yaw=Math.clamp(yaw,-2.5,2.5);pitch=Math.clamp(pitch,-3,3);roll=Math.clamp(roll,-2,2);fov=Math.min(5,fov);
    x=Math.clamp(x,-.08,.08);y=Math.clamp(y,-.04,.04);z=Math.clamp(z,-.08,.08);
  }
  private ExplosionCamera() {}
}
