package pl.xvisuals.modules.explosion;

import pl.xvisuals.XVisuals;
import pl.xvisuals.util.Colors;
import net.minecraft.block.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.util.math.*;
import java.util.*;

/** Authoritative block-charge changes plus confirmed explosion packets; never changes gameplay. */
public final class AnchorEffects {
  private record Change(int charge,long tick) {}
  private static final Map<BlockPos,Change> CHANGES=new LinkedHashMap<>();
  private static final Map<BlockPos,Long> REMOVED=new LinkedHashMap<>();
  private static final List<Effect> ACTIVE=new ArrayList<>();
  private static Object world;
  public static int chargeEvents,explosionEvents;
  private static class Effect {
    final Vec3d pos; final String style; final int life,color,accent; final double size;
    int age;
    Effect(Vec3d p,boolean charge) {
      var m=XVisuals.config().module("anchorfx");pos=p;style=m.text(charge?"chargeStyle":"explodeStyle");
      life=charge?18:26;color=m.color("color");accent=m.color("secondary");size=m.number("size");
    }
  }
  private static boolean ready() {
    var c=MinecraftClient.getInstance();
    if(world!=c.world) { ACTIVE.clear();CHANGES.clear();REMOVED.clear();world=c.world; }
    return c.world!=null && c.player!=null && XVisuals.config().on("anchorfx");
  }
  public static void block(BlockPos pos,BlockState old,BlockState next) {
    if(!ready())return;
    var c=MinecraftClient.getInstance();long tick=c.world.getTime();
    if(old.isOf(Blocks.RESPAWN_ANCHOR) && old.get(RespawnAnchorBlock.CHARGES)>0 && !next.isOf(Blocks.RESPAWN_ANCHOR)) {
      REMOVED.put(pos.toImmutable(),tick);trim(REMOVED);
    }
    // Loading or placing an already charged anchor is not a charge animation.
    if(!old.isOf(Blocks.RESPAWN_ANCHOR)||!next.isOf(Blocks.RESPAWN_ANCHOR))return;
    int charge=next.get(RespawnAnchorBlock.CHARGES);
    if(charge<=old.get(RespawnAnchorBlock.CHARGES))return;
    Change previous=CHANGES.get(pos);
    if(previous!=null && previous.charge==charge && previous.tick==tick)return;
    CHANGES.put(pos.toImmutable(),new Change(charge,tick));trim(CHANGES);
    spawn(Vec3d.ofCenter(pos),true);
  }
  public static boolean replaces(Vec3d center) {
    if(!ready())return false;
    var c=MinecraftClient.getInstance();var m=XVisuals.config().module("anchorfx");
    if(!m.flag("explode") || c.player.squaredDistanceTo(center)>m.number("distance")*m.number("distance"))return false;
    long tick=c.world.getTime();
    for(var e:REMOVED.entrySet())if(tick-e.getValue()<=13 && Vec3d.ofCenter(e.getKey()).squaredDistanceTo(center)<1)return true;
    var state=c.world.getBlockState(BlockPos.ofFloored(center));
    return state.isOf(Blocks.RESPAWN_ANCHOR)&&state.get(RespawnAnchorBlock.CHARGES)>0;
  }
  public static void explosion(Vec3d center) {
    if(!ready())return;
    var c=MinecraftClient.getInstance();long tick=c.world.getTime();
    BlockPos source=null;
    for(var e:REMOVED.entrySet()) if(tick-e.getValue()<=13 && Vec3d.ofCenter(e.getKey()).squaredDistanceTo(center)<1) { source=e.getKey();break; }
    if(source==null) {
      BlockPos p=BlockPos.ofFloored(center);var state=c.world.getBlockState(p);
      if(state.isOf(Blocks.RESPAWN_ANCHOR)&&state.get(RespawnAnchorBlock.CHARGES)>0)source=p;
    }
    if(source==null)return;
    REMOVED.remove(source);spawn(center,false);
  }
  private static void spawn(Vec3d p,boolean charge) {
    var c=MinecraftClient.getInstance();var m=XVisuals.config().module("anchorfx");
    if(!m.flag(charge?"charge":"explode") || c.player.squaredDistanceTo(p)>m.number("distance")*m.number("distance"))return;
    if(ACTIVE.size()>=12)ACTIVE.removeFirst();
    ACTIVE.add(new Effect(p,charge));
    if(charge)chargeEvents++;else explosionEvents++;
  }
  public static void tick(MinecraftClient c) {
    if(!ready()) { ACTIVE.clear();CHANGES.clear();REMOVED.clear();return; }
    if(c.isPaused())return;
    long tick=c.world.getTime();REMOVED.entrySet().removeIf(e->tick-e.getValue()>13);
    CHANGES.entrySet().removeIf(e->tick-e.getValue().tick>20);
    int budget=192;
    for(var it=ACTIVE.iterator();it.hasNext();) {
      Effect e=it.next();double p=e.age/(double)e.life;
      int count=Math.max(6,(int)(20*XVisuals.config().module("anchorfx").number("intensity")));
      for(int i=0;i<count && budget>0;i++,budget--) {
        var q=AnchorMotion.sample(e.style,p,i,count);
        int color=Colors.mix(e.color,e.accent,(i%3)/2d);
        float size=(float)(.55*(1-p*.65)*Math.min(1.5,e.size));
        var particle=c.particleManager.addParticle(pl.xvisuals.modules.combat.TotemParticleType.ANCHOR,
            e.pos.x+q.x()*e.size,e.pos.y+q.y()*e.size,e.pos.z+q.z()*e.size,0,0,0);
        if(particle instanceof AnchorParticle spark)spark.tint(color,size);

      }
      if(++e.age>e.life)it.remove();
    }
  }
  private static void trim(Map<?,?> map) { if(map.size()>128)map.remove(map.keySet().iterator().next()); }
  private AnchorEffects() {}
}
