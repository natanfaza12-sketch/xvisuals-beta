package pl.xvisuals.modules.explosion;
import pl.xvisuals.XVisuals;
import pl.xvisuals.modules.combat.TotemParticleType;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.minecraft.client.particle.*;
import net.minecraft.client.world.ClientWorld;

/** Short-lived luminous motes retain their colour in dark anchor combat. */
public final class AnchorParticle extends BillboardParticle {
  private final SpriteProvider frames;
  private AnchorParticle(ClientWorld world,double x,double y,double z,SpriteProvider sprites) {
    super(world,x,y,z,sprites.getSprite(0,1));
    frames=sprites;maxAge=9;scale=.10f;collidesWithWorld=false;alpha=.9f;
  }
  public void tint(int color,float size) {
    setColor((color>>16&255)/255f,(color>>8&255)/255f,(color&255)/255f);scale=.17f*size;
  }
  public static void init() {
    ParticleFactoryRegistry.getInstance().register(TotemParticleType.ANCHOR,
        sprites->(effect,world,x,y,z,vx,vy,vz,random)->new AnchorParticle(world,x,y,z,sprites));
  }
  @Override public void tick() { super.tick();setSprite(frames.getSprite(age,maxAge));alpha=.9f*(1-age/(float)maxAge);if(!XVisuals.config().on("anchorfx"))markDead(); }
  @Override protected int getBrightness(float tickProgress) { return 0xF000F0; }
  @Override protected RenderType getRenderType() { return RenderType.PARTICLE_ATLAS_TRANSLUCENT; }
}
