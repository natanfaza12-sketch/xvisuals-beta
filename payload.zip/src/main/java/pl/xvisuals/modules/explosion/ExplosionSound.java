package pl.xvisuals.modules.explosion;

import java.util.ArrayList;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.Identifier;

/** One trimmed impact at the same birth time as the primary wave; never one per visual layer. */
final class ExplosionSound {
  private static final Identifier ID=Identifier.of("xvisuals","explosion.shockwave");
  private record Voice(PositionedSoundInstance sound,double ends) {}
  private static final ArrayList<Voice> VOICES=new ArrayList<>(4);
  private static double lastStart=Double.NEGATIVE_INFINITY;

  static void play(ExplosionFX.Blast blast) {
    tick();
    var s=ExplosionFX.settings();
    if(!s.enabled || !s.flag("sound") || s.number("soundVolume")<=0) return;
    double now=ExplosionFX.time();
    if(!ExplosionSoundTiming.admit(now,lastStart,VOICES.size()))return;
    var manager=MinecraftClient.getInstance().getSoundManager();
    if(manager.get(ID)==null)return;
    float pitch=ExplosionSoundTiming.pitch(blast.localDuration);
    // A conservative per-voice ceiling bounds overlapping chain reactions.
    float gain=(float)(s.number("soundVolume")*.45*Math.clamp(Math.sqrt(blast.power/4),.6,1));
    var sound=new PositionedSoundInstance(ID,SoundCategory.BLOCKS,gain,pitch,
        SoundInstance.createRandom(),false,0,SoundInstance.AttenuationType.LINEAR,
        blast.pos.x,blast.pos.y,blast.pos.z,false);
    manager.play(sound);
    VOICES.add(new Voice(sound,now+ExplosionSoundTiming.DURATION/pitch+.25));
    lastStart=now;
  }

  static void tick() {
    var c=MinecraftClient.getInstance();var s=ExplosionFX.settings();
    if(c.world==null || !s.enabled || !s.flag("sound") || s.number("soundVolume")<=0) {clear();return;}
    if(c.isPaused())return;
    double now=ExplosionFX.time();
    // Keep ownership during asynchronous decoding, when isPlaying can still be false.
    VOICES.removeIf(voice->{
      if(now<voice.ends())return false;
      c.getSoundManager().stop(voice.sound());return true;
    });
  }

  static void clear() {
    var manager=MinecraftClient.getInstance().getSoundManager();
    for(var voice:VOICES)manager.stop(voice.sound());
    VOICES.clear();lastStart=Double.NEGATIVE_INFINITY;
  }
  private ExplosionSound() {}
}
