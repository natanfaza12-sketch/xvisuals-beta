package pl.xvisuals.modules.explosion;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.RaycastContext;
/** Prevent screen-space effects from painting the visible side of an intervening wall. */
final class ExplosionVisibility {
 static boolean visible(Vec3d origin){
  var c=MinecraftClient.getInstance();
  if(c.world==null||c.player==null)return false;
  Vec3d eye=c.gameRenderer.getCamera().getCameraPos();
  var hit=c.world.raycast(new RaycastContext(eye,origin,RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,c.player));
  return hit.getType()==HitResult.Type.MISS || hit.getPos().squaredDistanceTo(origin)<.04;
 }
}
