package pl.xvisuals.modules.explosion;

final class ExplosionSoundTiming {
  static boolean replacesVanilla(pl.xvisuals.config.VisualConfig.ModuleState settings) {
    // No fallback boom at zero volume, during cooldown, or when the voice cap is full.
    return settings.enabled && settings.flag("sound");
  }
  static final double DURATION=3.591;
  static boolean admit(double now,double lastStart,int voices) {
    return voices<4 && now-lastStart>=.1-1e-9;
  }
  static float pitch(double waveDuration) {
    return (float)Math.clamp(Math.sqrt(1.15/Math.max(.01,waveDuration)),.75,1.5);
  }
  private ExplosionSoundTiming() {}
}
