package pl.xvisuals.modules.explosion;

import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.mixins.RenderLayerAccessor;
import pl.xvisuals.rendering.Quality;
import pl.xvisuals.util.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import static pl.xvisuals.modules.explosion.ExplosionFX.*;

/** Depth-tested soft meshes, batched into two passes. Camera-relative doubles preserve far-coordinate precision. */
public final class ExplosionRenderer {
  private static final BufferAllocator ALLOCATOR=new BufferAllocator(4*1024*1024);
  private static final VertexConsumerProvider.Immediate BUFFERS=VertexConsumerProvider.immediate(ALLOCATOR);
  private static final RenderLayer ENERGY=layer("energy",new BlendFunction(
      com.mojang.blaze3d.platform.SourceFactor.SRC_ALPHA,com.mojang.blaze3d.platform.DestFactor.ONE,
      com.mojang.blaze3d.platform.SourceFactor.ZERO,com.mojang.blaze3d.platform.DestFactor.ONE));
  private static final RenderLayer MATTER=layer("matter",BlendFunction.TRANSLUCENT);
  private static final double[][] SIN=new double[257][],COS=new double[257][];
  private static VertexConsumer out;
  private static Matrix4f matrix;
  private static Vec3d camera;
  private static double rightX,rightY,rightZ,upX,upY,upZ,eyeX,eyeY,eyeZ;
  private static int vertices;
  private static boolean pipelineWarm;
  private static final double[] SHELL_X=new double[1067],SHELL_Y=new double[1067],SHELL_Z=new double[1067],SHELL_A=new double[1067];
  private static final int VERTEX_LIMIT=100000;
  static { for(int n=24;n<=256;n+=4) { SIN[n]=new double[n+1];COS[n]=new double[n+1];
    for(int i=0;i<=n;i++) { SIN[n][i]=Math.sin(i*Math.PI*2/n);COS[n][i]=Math.cos(i*Math.PI*2/n); } } }
  private static RenderLayer layer(String name,BlendFunction blend) {
    var setup=RenderSetup.builder(RenderPipeline.builder()
        .withLocation(Identifier.of("xvisuals","pipeline/explosion_"+name))
        .withVertexShader(Identifier.of("xvisuals","core/player_sprite"))
        .withFragmentShader(Identifier.of("xvisuals","core/player_sprite"))
        .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER).withSampler("Sampler0")
        .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS)
        .withBlend(blend).withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withDepthWrite(false).withCull(false).build())
        .texture("Sampler0",pl.xvisuals.rendering.CraftedSprites.ATLAS).expectedBufferSize(2*1024*1024);
    // Additive energy is order independent; sorting thousands of quads wastes CPU every frame.
    if(name.equals("matter"))setup.translucent();
    return RenderLayerAccessor.visuals$of("explosion_"+name,setup.build());
  }
  public static void close() { ALLOCATOR.close(); ExplosionProfiler.close(); }
  public static void render(MatrixStack matrices){
    long started=System.nanoTime();var c=MinecraftClient.getInstance();var settings=settings();renderMs=0;
    if(!settings.enabled||c.world==null||c.player==null)return;
    camera=c.gameRenderer.getCamera().getCameraPos();matrix=matrices.peek().getPositionMatrix();vertices=0;
    double now=time();pl.xvisuals.rendering.CraftedSprites.begin();out=BUFFERS.getBuffer(MATTER);
    for(var b:BLASTS)if(b.active){
      double age=now-b.born;if(age<0||age>b.duration||b.pos.squaredDistanceTo(camera)>settings.number("distance")*settings.number("distance"))continue;
      double fade=ExplosionMath.fade(age,b.duration)/Math.sqrt(Math.max(1,count()*.3));
      double radius=Math.min(7,b.localSize)*ExplosionMath.radius(age,b.duration);int frame=Math.min(7,(int)(age/b.duration*8));
      int color=settings.text("colorMode").equals("Rainbow")?Colors.rainbow(now*.18):b.color;
      if(settings.flag("primary")){
        if(settings.flag("ground")&&b.ground)texturedGround(b,radius,frame,Colors.alpha(color,fade*.65));
        else sprite(b.pos,radius*2,7,frame,color,fade*.5);
      }
      if(settings.flag("pressure"))sprite(b.pos.add(0,.2,0),radius*1.5,7,frame,color,fade*.18);
      if(settings.flag("flash")&&age<.18)sprite(b.pos,1.2+age*7,23,frame,b.secondary,(1-age/.18)*.7);
      if(settings.flag("secondaryWave")&&age>b.delay)sprite(b.pos,Math.min(6,b.localSize)*ExplosionMath.radius(age-b.delay,b.duration)*2,7,frame,b.secondary,fade*.2);
      if(settings.flag("column")&&b.preset.column())for(int i=0;i<3;i++)sprite(b.pos.add(.15*Math.sin(b.seed+i),age*(1+i*.5),.15*Math.cos(b.seed+i)),.7+age,14,frame,color,fade*.22);
      if(settings.flag("heat"))sprite(b.pos.add(0,age*.6,0),1+age,14,frame,b.secondary,fade*settings.number("heatStrength")*.12);
      if(settings.flag("arcs")&&b.arcs)for(int i=0;i<4;i++){double a=i*Math.PI/2;sprite(b.pos.add(Math.cos(a)*radius*.7,.4,Math.sin(a)*radius*.7),.3,3,frame,b.secondary,fade*.5);}
      if(settings.flag("interference")&&count()>1)sprite(b.pos.add(0,radius*.3,0),.2,5,frame,b.secondary,fade*.3);
    }
    BUFFERS.draw();double delta=c.getRenderTickCounter().getTickProgress(false);int submitted=0;
    for(var p:FRAGMENTS)if(p.active&&submitted<400){
      if((p.kind==0||p.kind==3)&&!settings.flag("debris")||p.kind==1&&!settings.flag("sparks")||p.kind==2&&!settings.flag("smoke"))continue;
      double age=now-p.born,alpha=Math.pow(Math.max(0,1-age/p.life),1.5);var pos=new Vec3d(p.px+(p.x-p.px)*delta,p.py+(p.y-p.py)*delta,p.pz+(p.z-p.pz)*delta);
      if(pos.squaredDistanceTo(camera)>settings.number("distance")*settings.number("distance")||alpha<.01)continue;
      sprite(pos,p.size*(p.kind==2?2+age:2),p.kind==2?14:p.kind==1?3:18,(int)(age*8),p.color,alpha*(p.kind==2?.45:.9));submitted++;
    }
    pl.xvisuals.rendering.CraftedSprites.draw(matrices);peakVertices=Math.max(peakVertices,vertices+submitted*4);renderMs=(System.nanoTime()-started)/1e6;
  }
  private static void sprite(Vec3d p,double size,int mode,int frame,int color,double alpha){pl.xvisuals.rendering.CraftedSprites.add(p,size,size,0,mode,frame,Colors.alpha(color,alpha));}
  private static void texturedGround(Blast b,double radius,int frame,int tint){
    if(radius<.01)return;
    for(int z=0;z<8;z++)for(int x=0;x<8;x++){
      double[] xx=new double[4],zz=new double[4],yy=new double[4];boolean valid=true;
      for(int k=0;k<4;k++){xx[k]=((x+(k==1||k==2?1:0))/8d*2-1)*radius;zz[k]=((z+(k>=2?1:0))/8d*2-1)*radius;yy[k]=height(b,xx[k],zz[k]);if(!Double.isFinite(yy[k]))valid=false;}
      if(!valid)continue;
      for(int k=0;k<4;k++){float u=(float)((xx[k]/radius+1)*.5),v=(float)((zz[k]/radius+1)*.5);
        out.vertex(matrix,(float)(b.pos.x+xx[k]-camera.x),(float)(b.pos.y+yy[k]-camera.y),(float)(b.pos.z+zz[k]-camera.z)).texture((7+(.5f+u*63)/64)/24,(frame+(.5f+v*63)/64)/8).color(tint);vertices++;
      }
    }
  }
  private ExplosionRenderer(){}
}
