package pl.xvisuals.modules.explosion;

/** Immutable unit geometry reused by every explosion; shading each shared corner only once. */
final class ExplosionShell {
  record Mesh(int columns,int rows,double[] x,double[] y,double[] z) {}
  private static final Mesh[] DOMES=new Mesh[97],FLASHES=new Mesh[49];
  static {
    for(int n=24;n<=96;n+=4)DOMES[n]=create(n,10,true);
    for(int n=24;n<=48;n+=4)FLASHES[n]=create(n,8,false);
  }
  static void warm() {}
  static Mesh dome(int n) {return DOMES[n];}
  static Mesh flash(int n) {return FLASHES[n];}
  private static Mesh create(int n,int rows,boolean half) {
    int count=(n+1)*(rows+1);
    double[] x=new double[count],y=new double[count],z=new double[count];
    for(int row=0;row<=rows;row++) {
      double angle=Math.PI*row/rows*(half?.5:1),height=Math.cos(angle),radial=Math.sin(angle);
      for(int col=0;col<=n;col++) {
        int at=row*(n+1)+col;double longitude=col*Math.PI*2/n;
        x[at]=radial*Math.cos(longitude);y[at]=height;z[at]=radial*Math.sin(longitude);
      }
    }
    return new Mesh(n,rows,x,y,z);
  }
  private ExplosionShell() {}
}
