package pl.xvisuals.modules.explosion;

import pl.xvisuals.XVisuals;
import pl.xvisuals.config.VisualConfig.ModuleState;
import pl.xvisuals.rendering.Quality;
import pl.xvisuals.util.Colors;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.util.math.*;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.RaycastContext;
import java.util.Arrays;

/** Fixed origin/fragment pools. All geometry is client-only; no world writes or gameplay packets. */
public final class ExplosionFX {
  public static final int MAX_EVENTS=64, MAX_FRAGMENTS=1200, GRID=9;
  static final Blast[] BLASTS=new Blast[MAX_EVENTS];
  static final Fragment[] FRAGMENTS=new Fragment[MAX_FRAGMENTS];
  static final java.util.Random RANDOM=new java.util.Random(0xA1A71C);
  private static Object world;
  private static final ExplosionClock CLOCK=new ExplosionClock();
  private static int fragmentCursor, terrainBudget=192, spawnBudget=240;
  public static int received, rejected, peakEvents, peakFragments, peakVertices;
  public static final int[] sourceCounts=new int[ExplosionSources.Type.values().length];
  public static double renderMs, tickMs;
  public static final class Blast {
    boolean active,major,water,ground,arcs,magical;
    Vec3d pos=Vec3d.ZERO;
    double born,power,size,localSize,duration,localDuration,delay,seed,score,floorY,crowdWeight,frameGain;
    int color,secondary,groundCursor,segments;
    ExplosionSources.Type type;
    ExplosionMath.Preset preset;
    String style;
    final double[] heights=new double[GRID*GRID];
  }
  static final class Fragment {
    boolean active,split;
    int kind,color; // 0 debris, 1 sparks, 2 smoke, 3 crystal shards
    double x,y,z,px,py,pz,vx,vy,vz,born,life,size,seed;
  }
  static { for(int i=0;i<MAX_EVENTS;i++) BLASTS[i]=new Blast(); for(int i=0;i<MAX_FRAGMENTS;i++) FRAGMENTS[i]=new Fragment(); }
  public static ModuleState settings() { return XVisuals.visualModule("explosionfx"); }
  public static boolean replaceVanillaSound() { return ExplosionSoundTiming.replacesVanilla(settings()); }
  public static boolean replaceParticles(Vec3d origin) {
    var c=MinecraftClient.getInstance();var s=settings();
    return s.enabled && s.flag("replaceVanilla") && c.world!=null && c.player!=null
        && origin.squaredDistanceTo(c.gameRenderer.getCamera().getCameraPos())<=s.number("distance")*s.number("distance")
        && s.flag(ExplosionSources.classify(origin).key());
  }
  public static double time() {
    var c=MinecraftClient.getInstance();
    return CLOCK.sample(System.nanoTime(),c.world==null||c.isPaused());
  }
  public static void init() {
    WorldRenderEvents.END_MAIN.register(ctx->{ ExplosionRenderer.render(ctx.matrices()); });
    ClientLifecycleEvents.CLIENT_STOPPING.register(c->{ clear(); ExplosionRenderer.close(); });
  }
  public static void clear() {
    for(var b:BLASTS) b.active=false;
    for(var p:FRAGMENTS) p.active=false;
    ExplosionSources.clear(); ExplosionCamera.clear(); ExplosionSound.clear(); ExplosionFloor.clear();
    terrainBudget=192; spawnBudget=240;
  }
  public static int count() { int n=0; for(var b:BLASTS) if(b.active)n++; return n; }
  public static int fragments() { int n=0; for(var p:FRAGMENTS) if(p.active)n++; return n; }
  private static void syncWorld() {
    var c=MinecraftClient.getInstance(); if(world!=c.world) { clear(); world=c.world; }
  }
  /** Injected after vanilla's main-thread packet processing: no duplicates from integrated server explosions. */
  public static void packet(ExplosionS2CPacket packet) {
    syncWorld();
    var c=MinecraftClient.getInstance();
    if(c.world==null || c.player==null || !settings().enabled) return;
    int terrain=0xff817B71;
    for(var entry:packet.blockParticles().getEntries()) {
      if(entry.value().particle() instanceof BlockStateParticleEffect block) {
        terrain=0xff000000|block.getBlockState().getMapColor(c.world,BlockPos.ofFloored(packet.center())).color;
        break;
      }
    }
    spawn(packet.center(),packet.radius(),ExplosionSources.classify(packet.center()),terrain);
  }
  public static void spawn(Vec3d origin,double power,ExplosionSources.Type type,int terrainColor) {
    syncWorld(); var c=MinecraftClient.getInstance(); var s=settings();
    if(!s.enabled || c.world==null || c.player==null || !s.flag(type.key())) return;
    double distance=origin.distanceTo(c.gameRenderer.getCamera().getCameraPos());
    if(!Double.isFinite(power) || !Double.isFinite(origin.x+origin.y+origin.z) || distance>s.number("distance")) { rejected++; return; }
    received++;
    sourceCounts[type.ordinal()]++;
    Blast b=null;
    for(var candidate:BLASTS) if(!candidate.active) { b=candidate; break; }
    if(b==null) { b=BLASTS[0]; for(var candidate:BLASTS) if(candidate.born<b.born)b=candidate; }
    b.active=true; b.pos=origin; b.born=time(); b.power=Math.clamp(power,.5,16);
    b.type=type; b.style=s.text("preset"); b.preset=ExplosionMath.preset(b.style);
    b.magical=type==ExplosionSources.Type.CRYSTAL&&!s.text("style").equals("UNIVERSAL");
    b.localSize=Math.min(64,b.power*2.6*s.number("size")*b.preset.size());
    b.size=ExplosionMath.renderRadius(c.options.getViewDistance().getValue());
    b.localDuration=s.number("lifetime")/s.number("speed");
    b.duration=ExplosionMath.travelDuration(b.localDuration,b.size); b.delay=s.number("delay")/1000;
    b.segments=ExplosionMath.waveSegments(s.text("quality"),Quality.factor());
    b.seed=RANDOM.nextDouble()*100; b.score=b.power/(8+distance);
    b.water=!c.world.getFluidState(BlockPos.ofFloored(origin)).isEmpty();
    b.major=false; int majorCount=0; Blast weakest=null;
    for(var old:BLASTS) if(old!=b && old.active && old.major) { majorCount++; if(weakest==null||old.score<weakest.score)weakest=old; }
    int majorLimit=Math.max(2,(int)(s.integer("majorBudget")*Math.min(1,Quality.factor())));
    if(majorCount<majorLimit)b.major=true;
    else if(weakest!=null && b.score>weakest.score*1.1) { weakest.major=false; b.major=true; }
    b.arcs=b.preset.rich() && (b.magical || b.style.equals("Anime") || b.style.equals("NUCLEAR") || RANDOM.nextDouble()<.16);
    palette(b,s);
    b.groundCursor=0; Arrays.fill(b.heights,Double.NaN);
    var floor=c.world.raycast(new RaycastContext(origin.add(0,.3,0),origin.add(0,-48,0),
        RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.ANY,c.player));
    b.ground=floor.getType()==HitResult.Type.BLOCK;
    b.floorY=b.ground?floor.getPos().y+.035:origin.y;
    if(b.ground && terrainColor==0xff817B71) {
      var bp=BlockPos.ofFloored(floor.getPos().add(0,-.05,0));
      terrainColor=0xff000000|c.world.getBlockState(bp).getMapColor(c.world,bp).color;
    }
    sampleTerrain(b);
    double density=b.preset.fragments()*Math.min(1,Quality.factor())*(b.major?1:.1)*(distance>60?.4:1);
    int available=Math.min(spawnBudget,Math.max(0,s.integer("budget")-fragments()));
    int debris=s.flag("debris")?(int)(s.number("debrisAmount")*density):0;
    int sparks=s.flag("sparks")?(int)(s.number("sparkAmount")*density*(b.water?.25:1)):0;
    int smoke=s.flag("smoke")&&b.preset.rich()&&!b.water?(int)(10*density):0;
    int requested=debris+sparks+smoke;
    double scale=Math.min(1,available/(double)Math.max(1,requested));
    debris=(int)(debris*scale); sparks=(int)(sparks*scale); smoke=(int)(smoke*scale);
    for(int i=0;i<debris+sparks+smoke;i++) {
      int kind=i<debris?(b.magical?3:0):i<debris+sparks?1:2;
      Fragment p=allocate(); if(p==null)break;
      double angle=RANDOM.nextDouble()*Math.PI*2, speed=(2+RANDOM.nextDouble()*9)*Math.sqrt(b.power/4);
      p.x=origin.x+(RANDOM.nextDouble()-.5)*.5; p.y=origin.y+RANDOM.nextDouble()*.4; p.z=origin.z+(RANDOM.nextDouble()-.5)*.5;
      p.px=p.x; p.py=p.y; p.pz=p.z;
      p.vx=Math.cos(angle)*speed; p.vz=Math.sin(angle)*speed; p.vy=1+RANDOM.nextDouble()*speed*.85;
      if(kind==2) { p.vx*=.12; p.vz*=.12; p.vy*=.25; }
      if(b.water) { p.vx*=.4; p.vz*=.4; p.vy*=.4; }
      p.kind=kind; p.color=kind==0?terrainColor:kind==2?Colors.mix(b.color,0xff3b3640,.82):Colors.mix(b.color,b.secondary,RANDOM.nextDouble());
      p.born=b.born; p.life=kind==2?1.5+RANDOM.nextDouble():.55+RANDOM.nextDouble()*1.3;
      p.size=kind==0?.055+RANDOM.nextDouble()*.11:kind==3?.09+RANDOM.nextDouble()*.14:kind==1?.03+RANDOM.nextDouble()*.045:.25+RANDOM.nextDouble()*.35;
      p.seed=RANDOM.nextDouble()*100; p.split=false;
      spawnBudget--;
    }
    ExplosionCamera.add(origin,b.power,b.preset.energy());
    ExplosionSound.play(b);
    peakEvents=Math.max(peakEvents,count()); peakFragments=Math.max(peakFragments,fragments());
  }
  private static Fragment allocate() {
    for(int i=0;i<MAX_FRAGMENTS;i++) { var p=FRAGMENTS[fragmentCursor++%MAX_FRAGMENTS]; if(!p.active) { p.active=true; return p; } }
    return null;
  }
  static void palette(Blast b,ModuleState s) {
    int derived=switch(b.type) { case CRYSTAL->0xffDD72FF; case CREEPER->0xffB8D78B;
      case BED->0xffFF927F; case ANCHOR->0xffAB8CFF; default->0xffFFAE55; };
    if(s.text("style").equals("UNIVERSAL"))derived=0xffFFAE55;
    if(s.text("style").equals("PER-TYPE"))derived=s.color(b.type.key()+"Color");
    if(b.style.equals("Cyber"))derived=Colors.mix(derived,0xff68DFFF,.65);
    b.color=switch(s.text("colorMode")) { case "Static","Gradient"->s.color("color");
      case "Theme"->Colors.parse(XVisuals.config().accent); case "Per-type"->s.color(b.type.key()+"Color");
      case "Rainbow"->Colors.rainbow(b.born*.18+b.seed*.01); default->derived; };
    b.secondary=s.text("colorMode").equals("Gradient")?s.color("secondary"):
        s.text("colorMode").equals("Theme")?Colors.parse(XVisuals.config().secondary):b.color;
    if(b.water && s.text("colorMode").equals("Explosion")){b.color=Colors.mix(b.color,0xff83D8FF,.6);b.secondary=b.color;}
  }
  static void sampleTerrain(Blast b) {
    if(!b.major || !b.ground || !settings().flag("ground"))return;
    var c=MinecraftClient.getInstance(); double extent=b.localSize*1.08;
    while(b.groundCursor<GRID*GRID && terrainBudget>0) {
      int i=b.groundCursor++,x=i%GRID,z=i/GRID; terrainBudget--;
      double wx=b.pos.x+(x/(GRID-1d)*2-1)*extent, wz=b.pos.z+(z/(GRID-1d)*2-1)*extent;
      var hit=c.world.raycast(new RaycastContext(new Vec3d(wx,b.pos.y+2.5,wz),new Vec3d(wx,b.pos.y-5,wz),
          RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.ANY,c.player));
      b.heights[i]=hit.getType()==HitResult.Type.BLOCK?hit.getPos().y-b.pos.y:Double.NaN;
    }
  }
  static double height(Blast b,double x,double z) {
    double gx=Math.clamp((x/(b.localSize*1.08)+1)*.5*(GRID-1),0,GRID-1.00001);
    double gz=Math.clamp((z/(b.localSize*1.08)+1)*.5*(GRID-1),0,GRID-1.00001);
    int ix=(int)gx,iz=(int)gz; double a=b.heights[iz*GRID+ix],c=b.heights[iz*GRID+ix+1];
    double d=b.heights[(iz+1)*GRID+ix],e=b.heights[(iz+1)*GRID+ix+1];
    if(!Double.isFinite(a+c+d+e)||Math.max(Math.max(a,c),Math.max(d,e))-Math.min(Math.min(a,c),Math.min(d,e))>.8)return Double.NaN;
    return (a+(c-a)*(gx-ix))*(1-(gz-iz))+(d+(e-d)*(gx-ix))*(gz-iz)+.045;
  }
  public static void tick(MinecraftClient c) {
    long start=System.nanoTime(); syncWorld();
    if(!settings().enabled || c.world==null || c.player==null) { clear(); return; }
    ExplosionSound.tick();
    if(c.isPaused())return;
    double now=time(); terrainBudget=192; spawnBudget=240;
    ExplosionSources.tick(c);
    for(var b:BLASTS) if(b.active) {
      if(now-b.born>Math.max(2.6,b.duration+b.delay))b.active=false;
      else sampleTerrain(b);
    }
    int collisions=280,live=fragments(),limit=settings().integer("budget");
    for(var p:FRAGMENTS) if(p.active) {
      double age=now-p.born;
      if(age>p.life || live>limit) { p.active=false; live--; continue; }
      p.px=p.x; p.py=p.y; p.pz=p.z;
      double drag=p.kind==2?.94:.985, gravity=p.kind==2?-.65:p.kind==1?5:12;
      p.vx*=drag; p.vz*=drag; p.vy=p.vy*drag-gravity*.05;
      double nx=p.x+p.vx*.05,ny=p.y+p.vy*.05,nz=p.z+p.vz*.05;
      if(p.kind!=2 && collisions-->0) {
        var hit=c.world.raycast(new RaycastContext(new Vec3d(p.x,p.y,p.z),new Vec3d(nx,ny,nz),RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,c.player));
        if(hit.getType()==HitResult.Type.BLOCK) {
          var normal=((net.minecraft.util.hit.BlockHitResult)hit).getSide().getDoubleVector();
          double dot=p.vx*normal.x+p.vy*normal.y+p.vz*normal.z;
          p.vx=(p.vx-1.4*dot*normal.x)*.65; p.vy=(p.vy-1.4*dot*normal.y)*.65; p.vz=(p.vz-1.4*dot*normal.z)*.65;
          nx=hit.getPos().x+normal.x*.025; ny=hit.getPos().y+normal.y*.025; nz=hit.getPos().z+normal.z*.025;
        }
      }
      p.x=nx;p.y=ny;p.z=nz;
      if(p.kind==1 && !p.split && age>.24 && p.seed%9<1 && live<limit && spawnBudget>1) {
        p.split=true; var child=allocate();
        if(child!=null) {
          child.kind=1;child.split=true; child.x=child.px=p.x;child.y=child.py=p.y;child.z=child.pz=p.z;
          child.vx=p.vx*.7+.8;child.vy=p.vy*.6+1;child.vz=p.vz*.7-.8;
          child.born=now;child.life=.28;child.size=p.size*.6;child.color=p.color;child.seed=p.seed;spawnBudget--;live++;
        }
      }
    }
    tickMs=(System.nanoTime()-start)/1e6;
  }
  private ExplosionFX() {}
}

