package pl.xvisuals.modules.explosion;

/** Pure timing and budget rules; shared by meshes, camera impulses and tests. */
public final class ExplosionMath {
  public static double renderRadius(int chunks) { return Math.max(1,chunks)*16d; }
  public static double travelDuration(double base,double radius) {
    return base*Math.max(1,Math.sqrt(radius/32));
  }
  public static int waveSegments(String quality,double adaptive) {
    int base=switch(quality) {case "Low"->96;case "Medium"->128;case "Ultra"->256;default->192;};
    return Math.max(64,(int)(base*Math.sqrt(Math.clamp(adaptive,.2,1)))/4*4);
  }
  public static double unit(double x) { return Math.clamp(x,0,1); }
  public static double radius(double age, double duration) {
    double t=unit(age/duration); return 1-Math.pow(1-t,3.3);
  }
  public static double fade(double age, double duration) {
    double t=unit(age/duration); return Math.pow(1-t,1.65)*Math.min(1,Math.max(0,age)*100);
  }
  public static double impulse(double age) {
    return age<0 || age>1.2 ? 0 : Math.exp(-age*7)*Math.sin(age*25)*(1-Math.exp(-age*90));
  }
  public static double attenuation(double distance, double range) {
    return Math.pow(unit(1-distance/range),2);
  }
  public static double delay(double distance, double speed, boolean enabled) {
    return enabled ? Math.min(.65,Math.max(0,distance-6)/speed) : 0;
  }
  public static int segments(double distance, String quality, double adaptive) {
    int base=switch(quality) { case "Low"->48; case "Medium"->72; case "Ultra"->144; default->112; };
    return Math.max(24,(int)(base*Math.min(1,adaptive)/(distance>80?2:distance>40?1.5:1))/4*4);
  }
  public record Preset(double size, double energy, double fragments, boolean rich, boolean column) {}
  public static Preset preset(String name) {
    return switch(name) {
      case "Clean" -> new Preset(.8,.65,.12,false,false);
      case "Cyber" -> new Preset(1.05,.95,.65,true,false);
      case "Anime" -> new Preset(1.25,1.25,.85,true,true);
      case "NUCLEAR" -> new Preset(1.85,1.5,1.3,true,true);
      default -> new Preset(1,1,1,true,true);
    };
  }
  private ExplosionMath() {}
}
