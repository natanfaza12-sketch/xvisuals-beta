package pl.xvisuals.modules.explosion;

/** Smooth elapsed time independent of server world-time corrections and tick interpolation resets. */
final class ExplosionClock {
  private long previous=Long.MIN_VALUE;
  private double seconds;
  double sample(long nanos,boolean paused) {
    if(previous!=Long.MIN_VALUE && !paused)seconds+=Math.max(0,nanos-previous)/1e9;
    previous=nanos;
    return seconds;
  }
}
