package pl.xvisuals.modules.glass;
public interface GlassItemOwner {void visuals$glassOwner(int id);int visuals$glassOwner();}
