package pl.xvisuals.modules.glass;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import pl.xvisuals.XVisuals;
import pl.xvisuals.mixins.RenderLayerAccessor;
import pl.xvisuals.modules.armor.ArmorFXResources;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.*;
import net.minecraft.client.texture.*;
import net.minecraft.util.Identifier;
/** Depth-tested glass material: original textures supply silhouette alpha only. */
public final class GlassMaterial {
 private static final Identifier DATA=Identifier.of("xvisuals","dynamic/glass_material");
 private static NativeImageBackedTexture data;private static int lastHash;
 private static final java.util.Map<RenderLayer,RenderLayer> LAYERS=new java.util.LinkedHashMap<>(64,.75f,true){protected boolean removeEldestEntry(java.util.Map.Entry<RenderLayer,RenderLayer> e){return size()>256;}};
 private static final java.util.Map<RenderLayer,RenderLayer> ORIGINALS=new java.util.WeakHashMap<>();
 public static RenderLayer original(RenderLayer layer){return ORIGINALS.getOrDefault(layer,layer);}
 public static void reset(){LAYERS.clear();lastHash=0;if(data!=null){MinecraftClient.getInstance().getTextureManager().destroyTexture(DATA);data=null;}}
 public static long models,parts,items;
 private static final RenderPipeline PIPE=RenderPipeline.builder().withLocation(Identifier.of("xvisuals","pipeline/full_glass"))
 .withVertexShader(Identifier.of("xvisuals","core/full_glass")).withFragmentShader(Identifier.of("xvisuals","core/full_glass"))
 .withUniform("DynamicTransforms",UniformType.UNIFORM_BUFFER).withUniform("Projection",UniformType.UNIFORM_BUFFER).withUniform("Fog",UniformType.UNIFORM_BUFFER)
 .withSampler("Sampler0").withSampler("GlassData").withVertexFormat(VertexFormats.POSITION_COLOR_TEXTURE_OVERLAY_LIGHT_NORMAL,VertexFormat.DrawMode.QUADS)
 .withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withDepthWrite(true).withCull(true).build();
 public static RenderLayer layer(RenderLayer source){RenderLayer original=original(source);Identifier texture=ArmorFXResources.texture(original);if(texture==null)return original;update();return LAYERS.computeIfAbsent(original,key->{RenderLayer result=RenderLayerAccessor.visuals$of("full_glass",RenderSetup.builder(PIPE).texture("Sampler0",texture).texture("GlassData",DATA).translucent().expectedBufferSize(8192).build());ORIGINALS.put(result,key);return result;});}
 private static void update(){var s=XVisuals.config().module("glass");int hash=s.values.hashCode();if(data!=null&&hash==lastHash)return;
 if(data==null){data=new NativeImageBackedTexture(()->"Visual glass material",new NativeImage(2,1,false));MinecraftClient.getInstance().getTextureManager().registerTexture(DATA,data);}
 int tint=s.color("tint"),alpha=(int)(s.number("opacity")*255);data.getImage().setColorArgb(0,0,(tint&0xffffff)|(alpha<<24));int shine=(int)(s.number("shine")*255),edge=(int)(s.number("edge")*255);data.getImage().setColorArgb(1,0,0xff000000|(shine<<16)|(edge<<8));data.upload();lastHash=hash;
 }
 private GlassMaterial(){}
}
