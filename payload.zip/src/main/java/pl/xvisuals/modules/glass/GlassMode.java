package pl.xvisuals.modules.glass;
import pl.xvisuals.XVisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
public final class GlassMode {
 private static final ThreadLocal<Integer> OWNER=ThreadLocal.withInitial(()->-2);
 private static boolean wasEnabled;
 public static void tick(){boolean current=enabled();if(wasEnabled&&!current){OWNER.remove();GlassMaterial.reset();}wasEnabled=current;}
 public static void init(){net.fabricmc.fabric.api.resource.v1.ResourceLoader.get(net.minecraft.resource.ResourceType.CLIENT_RESOURCES).registerReloader(net.minecraft.util.Identifier.of("xvisuals","glass_material"),(net.minecraft.resource.SynchronousResourceReloader)r->GlassMaterial.reset());}
 public static boolean target(String scope,boolean self){return scope.equals("Everyone")||scope.equals(self?"You":"Others");}
 public static boolean enabled(){return XVisuals.ready()&&XVisuals.config().module("glass").enabled;}
 public static boolean applies(int owner){var c=MinecraftClient.getInstance();if(!enabled()||c.player==null)return false;var s=XVisuals.config().module("glass");if(owner < -1)return false;return owner==-1?s.text("scope").equals("Everyone")&&s.flag("worldItems"):target(s.text("scope"),owner==c.player.getId());}
 public static boolean player(Object state){return state instanceof PlayerEntityRenderState p&&!p.invisible&&!p.spectator&&applies(p.id);}
 public static int enter(int owner){int old=OWNER.get();OWNER.set(owner);return old;}
 public static void restore(int old){OWNER.set(old);}
 public static int owner(){return OWNER.get();}
 public static boolean active(){return OWNER.get()!=-2&&applies(OWNER.get());}
 public static boolean items(){return enabled();}
 private GlassMode(){}
}
