package pl.xvisuals.modules;

import java.util.List;

public record ModuleSpec(
    String id,
    String name,
    String category,
    String description,
    String glyph,
    boolean enabled,
    List<Setting> settings) {}
