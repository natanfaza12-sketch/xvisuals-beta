package pl.xvisuals.modules.cosmetics;

import pl.xvisuals.XVisuals;
import pl.xvisuals.config.VisualConfig.ModuleState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.*;
import net.minecraft.client.render.*;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.state.*;
import net.minecraft.client.texture.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

public final class AnimatedCosmetics {
  private static final Surface CAPE = new Surface("cape");
  private static final Surface CAPE_WINGS = new Surface("cape_wings");
  private static final ModelPart[] STRIPS = strips();

  public static boolean applies(String id, PlayerEntityRenderState state) {
    if(pl.xvisuals.modules.glass.GlassMode.player(state))return false;
    if(state instanceof pl.xvisuals.gui.screens.WearablePreview)return false;
    var c = MinecraftClient.getInstance();
    var m = XVisuals.visualModule(id);
    return m.enabled && !state.invisible && !state.spectator && c.player != null
        && (state.id == c.player.getId() || m.flag("others"));
  }

  public static double time() {
    var c = MinecraftClient.getInstance();
    return c.world == null ? 0 : (c.world.getTime() + c.getRenderTickCounter().getTickProgress(false)) / 20d;
  }

  public static ModuleState wingSettings(BipedEntityRenderState state) {
    if (state instanceof PlayerEntityRenderState player && applies("capes", player)) return XVisuals.visualModule("capes");
    var settings = XVisuals.visualModule("capes");
    if (state instanceof ArmorStandEntityRenderState && settings.enabled && settings.flag("armorStands")) return settings;
    return null;
  }

  public static Identifier wings(BipedEntityRenderState state) {
    ModuleState settings = wingSettings(state);
    if (settings == null) return null;
    // Cape cloth uses different UVs; regenerate its design for the elytra silhouette.
    return CAPE_WINGS.texture(settings, true);
  }

  public static void cape(MatrixStack matrices, OrderedRenderCommandQueue queue, int light,
                          PlayerEntityRenderState state, boolean armor) {
    ModuleState m = XVisuals.visualModule("capes");
    var layer = m.flag("silky") ? SilkSurface.layer(m) : RenderLayers.entityCutout(CAPE.texture(m, false));
    if (m.flag("bright")) light = LightmapTextureManager.MAX_LIGHT_COORDINATE;
    double t = time() * m.number("speed");
    matrices.push();
    // Follow the crouched torso: its back tilts away from the standing cloth plane.
    matrices.translate(0, state.isInSneakingPose ? .2 : 0, (armor ? .20 : .14) + (state.isInSneakingPose ? .12 : 0));
    if (state.isInSneakingPose) matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(28));
    // Vanilla's interpolated cape inertia supplies running, jumping and turning response.
    float lift = Math.max(6, Math.min(85, 6 + state.field_53537 / 2 + state.field_53536));
    if(m.flag("silky")) {
      SilkyCape.pose(matrices,state.id,time(),lift,Math.max(-25,Math.min(25,state.field_53538/2)),m.number("silkSmooth"));
      SilkyCape.draw(matrices,queue,layer,light,
          time()*m.number("silkFlow"),m.number("motion")*m.number("silkRipple"),m.number("silkSheen"));
      matrices.pop();return;
    }
    matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(lift));
    matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(Math.max(-25, Math.min(25, state.field_53538 / 2))));
    for (int i = 0; i < STRIPS.length; i++) {
      matrices.multiply(RotationAxis.POSITIVE_X.rotation(CosmeticPatterns.bend(t, i, m.number("motion"))));
      queue.submitModelPart(STRIPS[i], matrices, layer, light, OverlayTexture.DEFAULT_UV, null,
          false, false, -1, null, state.outlineColor);
      matrices.translate(0, .125, 0);
    }
    matrices.pop();
  }

  private static ModelPart[] strips() {
    var parts = new ModelPart[8];
    for (int i = 0; i < parts.length; i++) {
      // One-pixel thickness preserves vanilla cape panel offsets (1/12, 1).
      // A zero-depth cube samples the border and adjacent face instead.
      var data = new ModelData();
      data.getRoot().addChild("cloth", ModelPartBuilder.create().uv(0, i * 2)
          .cuboid(-5, 0, 0, 10, 2, 1), ModelTransform.NONE);
      parts[i] = TexturedModelData.of(data, 64, 32).createModel().getChild("cloth");
    }
    return parts;
  }

  /** Fixed GPU textures, updated at most 15 times/second, never allocated per frame. */
  private static final class Surface {
    final Identifier id;
    NativeImageBackedTexture texture;
    long frame = Long.MIN_VALUE;
    String style = "";
    int primary, accent;
    Surface(String name) { id = Identifier.of("xvisuals", "dynamic/" + name); }
    Identifier texture(ModuleState m, boolean wings) {
      long next = (long) Math.floor(time() * m.number("speed") * 15);
      String design = m.text("style");
      if(design.equals("Money"))next=0;
      boolean themed = !m.text("palette").equals("Custom");
      int p = CosmeticThemes.primary(design, m.color("color"), themed);
      int a = CosmeticThemes.accent(design, m.color("secondary"), themed);
      if (texture == null) {
        texture = new NativeImageBackedTexture(() -> "Animated cosmetic", new NativeImage(256, 128, false));
        MinecraftClient.getInstance().getTextureManager().registerTexture(id, texture);
      }
      if (next != frame || !style.equals(design) || p != primary || a != accent) {
        NativeImage image = texture.getImage();
        int width=image.getWidth(),height=image.getHeight();
        var artwork=WearableArtwork.frame(design,next/15d,p,a);
        for (int y = 0; y < height; y++) for (int x = 0; x < width; x++) {
          // Never evaluate expensive emblems in transparent/unused UV regions.
          if (wings ? !ElytraSilhouette.contains(x,y,width,height) : x >= 88 || y >= 68) {
            image.setColorArgb(x,y,0);
            continue;
          }
          int pixel = artwork.pixel(x*256d/width,y*128d/height,wings);
          image.setColorArgb(x, y, wings ? ElytraSilhouette.mask(pixel, x, y, width, height) : pixel);
        }
        texture.upload();
        frame = next; style = design; primary = p; accent = a;
      }
      return id;
    }
  }
  private AnimatedCosmetics() {}
}
