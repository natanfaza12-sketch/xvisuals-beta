package pl.xvisuals.modules.cosmetics;

import java.util.ArrayList;
import java.util.List;

/** Shoulder coverts, secondary vanes and individually fanned primary flight feathers. */
public final class AngelWingGeometry {
  public record Feather(float x, float y, float z, float length, float width, float angle, int row) {}
  public static final List<Feather> FEATHERS = create();
  public static final int SEGMENTS = 8;

  private static List<Feather> create() {
    var feathers = new ArrayList<Feather>();
    // Long primaries sweep outward; shorter inner feathers fill the shoulder without a solid slab.
    for(int i=0;i<13;i++){
      double t=i/12.;add(feathers,.48+.62*t,-.30-.43*t,.025,.94-.28*t,.098-.018*t,-.12-.95*t,0);
    }
    for(int i=0;i<12;i++){
      double t=i/11.;add(feathers,.055+.79*t,-.06-.49*t,.073,.63+.10*Math.sin(t*Math.PI),.107-.012*t,-.06-.48*t,1);
    }
    for(int i=0;i<14;i++){
      double t=i/13.;add(feathers,.025+1.07*t,-.08-.64*t,.122,.27+.08*Math.sin(t*Math.PI),.084,-.10-.91*t,2);
    }
    return List.copyOf(feathers);
  }

  private static void add(List<Feather> list, double x, double y, double z, double length,
                          double width, double angle, int row) {
    list.add(new Feather((float)x,(float)y,(float)z,(float)length,(float)width,(float)angle,row));
  }

  public static float width(Feather f, float t) {
    // Broad vane, gently rounded shoulders and a clean pointed tip.
    return (float)(f.width() * Math.pow(Math.sin(Math.PI*(.025+.975*Math.clamp(t,0,1))), .58));
  }
  private AngelWingGeometry() {}
}
