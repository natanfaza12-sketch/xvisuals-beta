package pl.xvisuals.modules.cosmetics;
import pl.xvisuals.XVisuals;
import pl.xvisuals.util.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.*;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.texture.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
public final class Halo {
  private static final Identifier WHITE=Identifier.of("xvisuals","textures/crafted/metal.png");
  private static boolean texture;
  public static void render(MatrixStack matrices,OrderedRenderCommandQueue queue,PlayerEntityRenderState state,ModelPart head){
    if(!AnimatedCosmetics.applies("halo",state))return;
    var s=XVisuals.visualModule("halo");
    double radius=s.number("radius"),thickness=s.number("thickness"),time=XVisuals.config().module("performance").text("animation").equals("Off")?0:AnimatedCosmetics.time()*s.number("speed");
    matrices.push();head.applyTransform(matrices);matrices.translate(0,-.5-s.number("offset"),0);
    queue.submitCustom(matrices,RenderLayers.entityTranslucentEmissive(WHITE),(entry,out)->{
      HaloDesigns.draw(s.text("style"),radius,thickness,time,(a,b,c,d,phase,shade)->{
        int color=s.flag("rainbow")?Colors.rainbow(phase+time):Colors.mix(s.color("color"),s.color("secondary"),.5+.5*Math.sin(phase*Math.PI*2-time));
        int tint=((int)(s.number("opacity")*255)<<24);
        for(int shift=0;shift<=16;shift+=8)tint|=(int)(((color>>shift)&255)*shade)<<shift;
        int corner=0;for(var p:new HaloDesigns.Point[]{a,b,c,d})out.vertex(entry.getPositionMatrix(),(float)p.x(),(float)p.y(),(float)p.z())
          .color(tint).texture((corner==1||corner==2)?1:0,corner++>=2?1:0).overlay(OverlayTexture.DEFAULT_UV).light(LightmapTextureManager.MAX_LIGHT_COORDINATE).normal(entry,0,-1,0);
      });
    });matrices.pop();
  }
  private Halo(){}
}
