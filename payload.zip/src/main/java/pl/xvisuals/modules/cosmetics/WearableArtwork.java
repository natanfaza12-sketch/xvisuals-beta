package pl.xvisuals.modules.cosmetics;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.util.Identifier;

/** Shared garment UVs and authored surface details for the live model and its gallery. */
public final class WearableArtwork {
 private static final java.util.Map<String,String> SURFACES=new java.util.HashMap<>();
 static {for(int i=0;i<CosmeticThemes.ALL.size();i++)SURFACES.put(CosmeticThemes.ALL.get(i),"crafted/garments/"+i);}
 private static final NativeImage[] ART=new NativeImage[3];
 private static final boolean[] LOADED=new boolean[3];
 /** One frame descriptor per texture update, instead of path/frame lookups per texel. */
 public static Frame frame(String style,double time,int primary,int accent){return new Frame(style,time,primary,accent);}
 public static final class Frame {
  private final pl.xvisuals.rendering.ArtworkTextures.Sampler image;
  private final boolean money;private final int frame,next,primary,accent;private final double blend;
  private Frame(String style,double time,int primary,int accent){
   money=style.equals("Money");image=pl.xvisuals.rendering.ArtworkTextures.sampler(money?"larp/cape":SURFACES.getOrDefault(style,"crafted/garments/0"));
   double phase=time*2.5;frame=Math.floorMod((int)Math.floor(phase),8);next=(frame+1)%8;blend=phase-Math.floor(phase);this.primary=primary;this.accent=accent;
  }
  public int pixel(double x,double y,boolean wing){
   double u=wing?wingU(x)*(money?1:.5):Math.clamp((x>=48?x-48+.5:x-4+.5)/40.,0,1),v=wing?wingV(y):Math.clamp((y-4+.5)/64.,0,1);
   return surface(u,v);
  }
  public int surface(double u,double v){
   if(money)return image.sample(u,v);
   u=Math.clamp(u,0,.9999);v=Math.clamp(v,0,.9999);
   int tex=image.sample((frame+u)/8,v),following=image.sample((next+u)/8,v);
   double l=((tex&255)*(1-blend)+(following&255)*blend)/255.;
   return l<.55?mix(0xff06080d,primary,l/.55):mix(primary,accent,(l-.55)/.45);
  }
 }
 public static double wingU(double x){
  double px=(x+.5)/4.;
  return Math.clamp(px>=36?(px-36)/10:px>=24&&px<34?(34-px)/10:px<24?1:0,0,1);
 }
 public static double wingV(double y){return Math.clamp(((y+.5)/4.-2)/20.,0,1);}
 public static int pixel(String style,double x,double y,boolean wing,double time,int primary,int accent){
  // Vanilla mirrors one wing texture onto both wings. Give each wing half
  // the composition so emblems meet at the spine instead of duplicating.
  // Money has an asymmetric symbol: retain the complete print on each wing.
  double u=wing?wingU(x)*(style.equals("Money")?1:.5):Math.clamp((x>=48?x-48+.5:x-4+.5)/40.,0,1),v=wing?wingV(y):Math.clamp((y-4+.5)/64.,0,1);
  return surface(style,u,v,time,primary,accent);
 }
 public static int surface(String style,double u,double v,double time,int primary,int accent){
  // All paths, including silk cloth, use the same original artwork.
  if(style.equals("Money"))return pl.xvisuals.rendering.ArtworkTextures.sample("larp/cape",u,v);
  double phase=time*2.5;int frame=Math.floorMod((int)Math.floor(phase),8);
  String artwork=SURFACES.getOrDefault(style,"crafted/garments/0");
  int tex=pl.xvisuals.rendering.ArtworkTextures.sample(artwork,(frame+Math.clamp(u,0,.9999))/8,Math.clamp(v,0,.9999));
  int next=pl.xvisuals.rendering.ArtworkTextures.sample(artwork,((frame+1)%8+Math.clamp(u,0,.9999))/8,Math.clamp(v,0,.9999));
  double blend=phase-Math.floor(phase),l=((tex&255)*(1-blend)+(next&255)*blend)/255.;
  return l<.55?mix(0xff06080d,primary,l/.55):mix(primary,accent,(l-.55)/.45);
 }
 public static double sheen(double u,double v,double time){
  double phase=v-u*.3-time*.085;phase-=Math.floor(phase);
  return Math.exp(-Math.pow(Math.min(phase,1-phase)*12,2));
 }
 private static NativeImage art(int index){
  if(!LOADED[index]){LOADED[index]=true;
   try(var in=MinecraftClient.getInstance().getResourceManager().open(Identifier.of("xvisuals",index==2?"textures/larp/cape.png":"textures/cosmetics/wings/"+(index==0?"seraph":"dragon")+".png"))){if(index==2)ART[index]=NativeImage.read(in);else try(var source=NativeImage.read(in)){ART[index]=new NativeImage(80,160,false);source.resizeSubRectTo(0,0,source.getWidth(),source.getHeight(),ART[index]);}}
   catch(java.io.IOException ignored){/* Resource packs may omit artwork: retain the selected design. */}
  }
  return ART[index];
 }
 private static int mix(int a,int b,double t){t=Math.clamp(t,0,1);return 0xff000000|((int)(((a>>16)&255)*(1-t)+((b>>16)&255)*t)<<16)|((int)(((a>>8)&255)*(1-t)+((b>>8)&255)*t)<<8)|(int)((a&255)*(1-t)+(b&255)*t);}
 private WearableArtwork(){}
}
