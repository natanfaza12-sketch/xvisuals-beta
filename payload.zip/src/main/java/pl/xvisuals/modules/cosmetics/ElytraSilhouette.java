package pl.xvisuals.modules.cosmetics;

/** Vanilla 1.21.11 elytra UV cutout, including the narrow edge faces.
 * The wing model is a cuboid: its transparent texels are part of its geometry.
 * Keep the unused/front-face UVs clear instead of painting an opaque rectangle.
 */
public final class ElytraSilhouette {
  private static final int[] START = {
      31, 32, 34, 34, 35, 35, 35, 35, 35, 35, 35,
      36, 36, 36, 36, 36, 37, 37, 37, 38, 38, 39
  };
  private static final int[] END = {
      40, 34, 42, 43, 44, 44, 44, 45, 45, 45, 45,
      46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46
  };

  public static boolean contains(int x, int y, int width, int height) {
    if (width <= 0 || height <= 0 || x < 0 || y < 0 || x >= width || y >= height) return false;
    int u = x * 64 / width, v = y * 32 / height;
    return v < START.length && ((u >= START[v] && u < END[v]) || (u == 22 && v >= 11));
  }

  public static int mask(int argb, int x, int y, int width, int height) {
    return contains(x, y, width, height) ? argb : 0;
  }

  private ElytraSilhouette() {}
}
