package pl.xvisuals.modules.cosmetics;
import net.minecraft.client.render.*;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import java.util.LinkedHashMap;

/** Bounded numeric pose history; one batched, continuous cloth mesh per visible cape. */
public final class SilkyCape {
  private static final int COLS=12,ROWS=24;
  private static final float[] GRID=new float[(COLS+1)*(ROWS+1)*7];
  private static final LinkedHashMap<Integer,Pose> POSES=new LinkedHashMap<>(32,.75f,true);
  private static final class Pose {double time,lift,roll;Pose(double t,double l,double r){time=t;lift=l;roll=r;}}
  public static void pose(MatrixStack matrices,int id,double t,double lift,double roll,double smoothing) {
    var p=POSES.get(id);
    if(p==null || t<p.time || t-p.time>1){p=new Pose(t,lift,roll);POSES.put(id,p);}
    double a=SilkyCapeMotion.smoothing(t-p.time,smoothing);
    p.lift+=(lift-p.lift)*a;p.roll+=(roll-p.roll)*a;p.time=t;
    while(POSES.size()>128)POSES.remove(POSES.keySet().iterator().next());
    matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float)p.lift));
    matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float)p.roll));
  }
  public static void draw(MatrixStack matrices,OrderedRenderCommandQueue queue,RenderLayer layer,int light,double t,double amount,double sheen) {
    queue.submitCustom(matrices,layer,(entry,out)->{
      // Render commands execute serially; this scratch grid is shared, never captured per player.
      for(int y=0;y<=ROWS;y++)for(int x=0;x<=COLS;x++) {
        double u=x/(double)COLS,v=y/(double)ROWS,z=SilkyCapeMotion.depth(u,v,t,amount);
        double dx=(SilkyCapeMotion.depth(u+.001,v,t,amount)-z)/.000625;
        double dy=(SilkyCapeMotion.depth(u,v+.001,t,amount)-z)/.001;
        double n=1/Math.sqrt(dx*dx+dy*dy+1);int i=(y*(COLS+1)+x)*7;
        GRID[i]=(float)((u-.5)*.625+SilkyCapeMotion.sway(v,t,amount));GRID[i+1]=(float)v;GRID[i+2]=(float)z;
        GRID[i+3]=(float)(-dx*n);GRID[i+4]=(float)(-dy*n);GRID[i+5]=(float)n;
        double highlight=Math.pow(Math.max(0,1-Math.abs(dx*.7+.18)),6);
        GRID[i+6]=(float)Math.clamp(.78+sheen*(highlight*.22-Math.abs(dx)*.05),.5,1);
      }
      for(int y=0;y<ROWS;y++)for(int x=0;x<COLS;x++) {
        vertex(out,entry,x,y,light);vertex(out,entry,x+1,y,light);
        vertex(out,entry,x+1,y+1,light);vertex(out,entry,x,y+1,light);
      }
    });
  }
  private static void vertex(VertexConsumer out,MatrixStack.Entry e,int x,int y,int light) {
    int i=(y*(COLS+1)+x)*7,shade=Math.round(GRID[i+6]*255);
    out.vertex(e.getPositionMatrix(),GRID[i],GRID[i+1],GRID[i+2]).color(shade,shade,shade,255)
      .texture(x/(float)COLS,y/(float)ROWS).overlay(OverlayTexture.DEFAULT_UV).light(light)
      .normal(e,GRID[i+3],GRID[i+4],GRID[i+5]);
  }
  public static void init() {
    net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.END_CLIENT_TICK.register(c->{
      var m=pl.xvisuals.XVisuals.visualModule("capes");
      if(c.world==null || !m.enabled || !m.flag("silky")){POSES.clear();SilkSurface.release(c);}
    });
    net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING.register(c->{POSES.clear();SilkSurface.release(c);});
  }
  private SilkyCape(){}
}
