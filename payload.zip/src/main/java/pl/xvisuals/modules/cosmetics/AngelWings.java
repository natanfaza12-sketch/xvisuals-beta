package pl.xvisuals.modules.cosmetics;

import java.util.*;
import pl.xvisuals.modules.cosmetics.AngelWingGeometry.Feather;
import pl.xvisuals.XVisuals;
import pl.xvisuals.util.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.texture.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

/** Cached curved feather vanes; two queued meshes per player, with no equipment requirement. */
public final class AngelWings {
  private static final Identifier TEXTURE = Identifier.of("xvisuals", "textures/crafted/angel_vane.png");
  private static final List<Feather> FEATHERS = AngelWingGeometry.FEATHERS;
  private static final Map<Integer, Fold> FOLDS = new HashMap<>();
  private static Object world;
  private static NativeImageBackedTexture texture;
  private static final class Fold { double value, glide, time; Fold(double value, double time) { this.value=value; this.time=time; } }

  public static void tick() {
    var c = MinecraftClient.getInstance();
    if (world != c.world || !XVisuals.visualModule("angelwings").enabled) {
      FOLDS.clear();
      world = null;
    }
  }

  public static void render(MatrixStack matrices, OrderedRenderCommandQueue queue, int light,
                            PlayerEntityRenderState state) {
    var c = MinecraftClient.getInstance();
    if (world != c.world) { FOLDS.clear(); world = c.world; }
    if (!AnimatedCosmetics.applies("angelwings", state)) { FOLDS.remove(state.id); return; }
    var m = XVisuals.visualModule("angelwings");
    double now = AnimatedCosmetics.time();
    double target = m.flag("fold") && state.isInSneakingPose ? 1 : 0;
    Fold f = FOLDS.computeIfAbsent(state.id, id -> new Fold(target, now));
    f.value = AngelWingPose.advance(f.value, target, now-f.time, m.number("foldSpeed"));
    f.glide = AngelWingPose.advance(f.glide, state.isGliding ? 1 : 0, now-f.time, .55);
    f.time = now;
    if (FOLDS.size() > 128) FOLDS.entrySet().removeIf(e -> now-e.getValue().time > 2);
    double closed = f.value, motion = m.number("motion"), length = m.number("length")*.78;
    double spread = m.number("spread"), shade = m.number("shade");
    int base = m.flag("customColors")?m.color("color"):0xfff4f0e7, highlight = m.flag("customColors")?m.color("highlight"):0xffffffff, shadow = m.flag("customColors")?m.color("shadow"):0xffaeb9cc;
    ensureTexture();
    var layer = RenderLayers.entityCutoutNoCull(TEXTURE);
    matrices.push();
    if (state.isInSneakingPose) { matrices.translate(0, .2, 0); matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(28)); }
    matrices.translate(0, .16, .19);
    for (int side = -1; side <= 1; side += 2) {
      matrices.push();
      matrices.translate(side * (.12 + closed*.08), 0, closed * .06);
      double flutter = Math.sin(now * 1.8) * (.025 + f.glide*.018) * motion * (1-closed);
      matrices.multiply(RotationAxis.POSITIVE_Y.rotation((float)(-side * (closed * 1.43 + (1-spread)*.55 + f.glide*.18*(1-closed) + flutter))));
      matrices.multiply(RotationAxis.POSITIVE_Z.rotation((float)(side * (closed * .48-f.glide*.08*(1-closed)))));
      matrices.scale((float)(side*length), (float)length, (float)length);
      // Capture immutable values: the ordered queue executes after the feature has returned.
      queue.submitCustom(matrices, layer, (entry, out) -> {
        for (Feather feather : FEATHERS) draw(out, entry, feather, now, closed, motion, base, highlight, shadow, shade, light);
      });
      matrices.pop();
    }
    matrices.pop();
  }

  private static void draw(VertexConsumer out, MatrixStack.Entry entry, Feather f, double time,
      double closed, double motion, int base, int highlight, int shadow, double shade, int light) {
    double angle=f.angle() + Math.sin(time*1.65+f.x()*1.2)*.009*motion*(1-closed);
    float sin=(float)Math.sin(angle), cos=(float)Math.cos(angle);
    for (int segment=0; segment<AngelWingGeometry.SEGMENTS; segment++) {
      float a=segment/(float)AngelWingGeometry.SEGMENTS, b=(segment+1)/(float)AngelWingGeometry.SEGMENTS;
      // Each side meets at a raised rachis, forming a curved three-dimensional ridge.
      for (int strip=0;strip<4;strip++) {
        float left=-1+strip*.5f,right=left+.5f;
        point(out,entry,f,a,left,sin,cos,base,highlight,shadow,shade,light);
        point(out,entry,f,a,right,sin,cos,base,highlight,shadow,shade,light);
        point(out,entry,f,b,right,sin,cos,base,highlight,shadow,shade,light);
        point(out,entry,f,b,left,sin,cos,base,highlight,shadow,shade,light);
      }
    }
  }

  private static void point(VertexConsumer out, MatrixStack.Entry entry, Feather f, float t, float edge,
      float sin, float cos, int base, int highlight, int shadow, double shade, int light) {
    float width=AngelWingGeometry.width(f,t);
    float across=edge*width*(edge<0?.78f:1), along=t*f.length();
    float x=f.x() + across*cos-along*sin, y=f.y()+across*sin+along*cos;
    float z=f.z() + .065f*t*t + .027f*(1-edge*edge)*(1-t);
    double darkness=(edge<0?.20:.07)*(1-t*.55)+f.row()*.025;
    int vane=Colors.mix(base,highlight,Math.pow(t,3)*.32*shade);
    int color=Colors.mix(Colors.mix(vane,shadow,darkness*shade),highlight,(1-Math.abs(edge))*.32*shade);
    out.vertex(entry.getPositionMatrix(),x,y,z).color(color).texture((edge+1)*.5f,t)
        .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(entry,-cos*edge*.18f,-sin*edge*.18f,.98f);
  }

  private static void ensureTexture() {}
  private AngelWings() {}
}
