package pl.xvisuals.modules.cosmetics;

/** Frame-rate independent fold easing, shared with the animation tests. */
public final class AngelWingPose {
  public static double advance(double current, double target, double elapsed, double speed) {
    return target + (current-target)*Math.exp(-Math.max(0, elapsed)*8*speed);
  }
  private AngelWingPose() {}
}
