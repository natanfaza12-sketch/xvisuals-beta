package pl.xvisuals.modules.cosmetics;
/** Shared torus meshes for equipped halos and their gallery cards. */
public final class HaloDesigns {
 public static final String[] STYLES={"Classic","Double Ring","Crescent","Segmented","Crown","Orbital"};
 public record Point(double x,double y,double z){}
 @FunctionalInterface public interface Quad {void add(Point a,Point b,Point c,Point d,double phase,double shade);}
 public static void draw(String style,double radius,double thickness,double time,Quad out){
  int rings=style.equals("Double Ring")||style.equals("Orbital")?2:1;
  for(int ring=0;ring<rings;ring++)for(int i=0;i<48;i++){
   if(style.equals("Segmented")&&i%6>=5)continue;
   if(style.equals("Crescent")&&i>=38)continue;
   for(int j=0;j<6;j++){
    Point[] p=new Point[4];
    for(int corner=0;corner<4;corner++){
     double u=(i+(corner==1||corner==2?1:0))/48.,a=u*Math.PI*2+(style.equals("Classic")?0:time*.45);
     double b=(j+(corner>=2?1:0))*Math.PI*2/6;
     double tube=thickness;
     if(style.equals("Crescent"))tube*=.12+.88*Math.pow(Math.sin(Math.PI*u/(38./48)),.65);
     double major=radius*(style.equals("Double Ring")?(ring==0?1:.73):1);
     double r=major+tube*Math.cos(b),y=tube*Math.sin(b);
     if(style.equals("Double Ring"))y+=(ring==0?-.035:.035);
     if(style.equals("Crown"))y-=radius*.40*Math.pow(.5+.5*Math.cos(u*Math.PI*16),4);
     double x=Math.cos(a)*r,z=Math.sin(a)*r;
     if(style.equals("Orbital")){double tilt=ring==0?.40:-.40;double yy=y*Math.cos(tilt)-z*Math.sin(tilt);z=y*Math.sin(tilt)+z*Math.cos(tilt);y=yy;}
     p[corner]=new Point(x,y,z);
    }
    double shade=.66+.34*(.5+.5*Math.cos((j+.5)*Math.PI/3));
    out.add(p[0],p[1],p[2],p[3],i/48.,shade);
   }
  }
 }
 private HaloDesigns(){}
}
