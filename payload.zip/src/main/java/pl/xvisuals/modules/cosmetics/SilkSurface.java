package pl.xvisuals.modules.cosmetics;
import pl.xvisuals.config.VisualConfig.ModuleState;
import pl.xvisuals.mixins.RenderLayerAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.*;
import net.minecraft.client.texture.*;
import net.minecraft.util.Identifier;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;

/** Full UV surface with linear filtering; plain finishes upload only when colours change. */
public final class SilkSurface {
 private static final Identifier ID=Identifier.of("xvisuals","dynamic/silk_surface");
 private static final RenderLayer LAYER=RenderLayerAccessor.visuals$of("silk_surface",RenderSetup.builder(RenderPipelines.ENTITY_CUTOUT_NO_CULL)
     .texture("Sampler0",ID,()->RenderSystem.getSamplerCache().get(FilterMode.LINEAR)).useLightmap().useOverlay().build());
 private static NativeImageBackedTexture texture;
 private static String lastFinish="",lastStyle="";private static int lastP,lastA;private static long lastFrame=-1;
 public static RenderLayer layer(ModuleState m) {
   String finish=m.text("silkFinish"),style=m.text("style");boolean themed=!m.text("palette").equals("Custom");
   int p=CosmeticThemes.primary(style,m.color("color"),themed),a=CosmeticThemes.accent(style,m.color("secondary"),themed);
   long frame=finish.equals("Original artwork")?(long)(AnimatedCosmetics.time()*m.number("speed")*15):0;
   if(texture==null){texture=new NativeImageBackedTexture(()->"Silk cape surface",new NativeImage(128,256,false));MinecraftClient.getInstance().getTextureManager().registerTexture(ID,texture);lastFrame=-1;}
   if(frame!=lastFrame || p!=lastP || a!=lastA || !finish.equals(lastFinish) || !style.equals(lastStyle)) {
     var image=texture.getImage();
     boolean original=finish.equals("Original artwork");
     var artwork=original?WearableArtwork.frame(style,frame/15d,p,a):null;
     var finishImage=original?null:pl.xvisuals.rendering.ArtworkTextures.sampler("crafted/silk_"+switch(finish){case "Ombre"->"ombre";case "Ribbon"->"ribbon";default->"plain";});
     for(int y=0;y<256;y++)for(int x=0;x<128;x++) {
       double u=(x+.5)/128,v=(y+.5)/256;
       int color=original?artwork.surface(u,v):pl.xvisuals.util.Colors.mix(p,a,(finishImage.sample(u,v)&255)/255.);
       image.setColorArgb(x,y,color);
     }
     texture.upload();lastFrame=frame;lastP=p;lastA=a;lastFinish=finish;lastStyle=style;
   }
   return LAYER;
 }
 public static int pixel(String finish,double u,double v,int primary,int accent) {
   int sample=pl.xvisuals.rendering.ArtworkTextures.sample("crafted/silk_"+switch(finish){case "Ombre"->"ombre";case "Ribbon"->"ribbon";default->"plain";},u,v);
   return pl.xvisuals.util.Colors.mix(primary,accent,(sample&255)/255.);
 }
 public static void release(MinecraftClient c){if(texture!=null){c.getTextureManager().destroyTexture(ID);texture=null;lastFrame=-1;}}
 private SilkSurface(){}
}
