package pl.xvisuals.modules.cosmetics;

/** Continuous cloth surface; the shoulder edge is pinned and waves grow toward the hem. */
public final class SilkyCapeMotion {
  public static double depth(double u,double v,double t,double amount) {
    double envelope=v*v;
    return envelope*amount*(.065*Math.sin(t*1.8-v*4.4+u*1.7)
        +.016*Math.sin(t*2.6-v*7-u*4)+.016*Math.sin(u*Math.PI*4+t*.7-v*2));
  }
  public static double sway(double v,double t,double amount) {return Math.sin(t*1.6-v*3.2)*v*v*.025*amount;}
  public static double smoothing(double dt,double smooth) {return 1-Math.exp(-Math.clamp(dt,0,.1)/( .018+Math.clamp(smooth,0,1)*.17));}
  private SilkyCapeMotion(){}
}
