package pl.xvisuals.modules.cosmetics;

/** Continuous procedural artwork, independent of the renderer and frame rate. */
public final class CosmeticPatterns {
  public static int pixel(String style, double u, double v, double t, int primary, int accent) {
    if (RefinedCapeArtwork.contains(style)) return RefinedCapeArtwork.pixel(style,u,v,t,primary,accent);
    if (CosmeticThemes.PREMIUM.contains(style)) return PremiumArtwork.pixel(style,u,v,t,primary,accent);
    if (!style.equals("Astral") && !style.equals("Inferno") && !style.equals("Aurora") && !style.equals("Storm"))
      return ThemeArtwork.pixel(style, u, v, t, primary, accent);
    double x = (u - .5) * 2, y = v;
    double wave = Math.sin(x * 9 + y * 12 - t * 2);
    double energy;
    switch (style) {
      case "Inferno" -> {
        double flame = Math.sin(x * 12 + Math.sin(y * 8 - t * 3) * 2);
        energy = Math.pow(Math.max(0, 1 - Math.abs(flame) * 2), 3) * (.25 + .75 * y);
      }
      case "Aurora" -> {
        double curtain = Math.sin(x * 5 + Math.sin(y * 5 - t) * 1.8 + t * .7);
        energy = Math.pow(.5 + .5 * curtain, 6) * (.55 + .45 * Math.sin(y * 8 + t));
      }
      case "Storm" -> {
        double bolt = x - .38 * Math.sin(y * 18 + Math.sin(t * 2)) - .12 * Math.sin(y * 43 - t);
        energy = Math.exp(-Math.abs(bolt) * 45) * (.65 + .35 * Math.sin(t * 5));
        energy += .2 * Math.pow(.5 + .5 * wave, 12);
      }
      default -> {
        double r = Math.sqrt(x * x + (y - .48) * (y - .48) * 3);
        double ring = Math.exp(-Math.pow((r - .37 - .025 * Math.sin(t)) * 55, 2));
        double stars = Math.pow(Math.max(0, Math.sin(u * 193 + v * 71) * Math.sin(v * 137 - u * 37)), 28);
        energy = ring * .8 + stars * (.6 + .4 * Math.sin(t * 2 + u * 20)) + .13 * (.5 + .5 * wave);
      }
    }
    // Let the artwork reach the cloth edge without adding a decorative border.
    double base = .13 + .09 * (.5 + .5 * wave);
    int dark = blend(0xff080b19, primary, base);
    return blend(dark, blend(primary, accent, .5 + .5 * Math.sin(v * 5 - t)), Math.min(1, energy));
  }

  public static float bend(double time, int segment, double motion) {
    return (float) (Math.sin(time * 2.8 - segment * .48) * .045 * motion * (segment + 1) / 8);
  }

  private static int blend(int a, int b, double f) {
    f = Math.max(0, Math.min(1, f));
    int r = (int) (((a >> 16) & 255) * (1-f) + ((b >> 16) & 255) * f);
    int g = (int) (((a >> 8) & 255) * (1-f) + ((b >> 8) & 255) * f);
    int bl = (int) ((a & 255) * (1-f) + (b & 255) * f);
    return 0xff000000 | r << 16 | g << 8 | bl;
  }
  private CosmeticPatterns() {}
}
