package pl.xvisuals.modules.cosmetics;
import java.util.List;
/** Shared by the picker, renderer, validation and development gallery. */
public final class CosmeticThemes {
  public static final List<String> ALL = List.of(
      "Astral", "Inferno", "Aurora", "Storm", "Hearts", "Broken Hearts", "Heartbeat",
      "Sacred Geometry", "Crystal Lattice", "Saturn", "Star Map", "Black Hole",
      "Circuit Board", "Reactor", "Digital Rain", "Sakura", "Phoenix", "Eclipse",
      "Premium - V Sovereign", "Premium - Celestial Seraph", "Premium - Void Lotus", "Premium - Obsidian Dragon",
      "Obsidian", "Silverline", "Carbon", "Crimson Trim", "Royal Navy", "Ivory Gold",
      "Midnight Fade", "Arctic Fade", "Copper Patina", "Redshift", "Topographic", "Damascus",
      "Black Ice", "Sunset Silk", "Emerald Crest", "Lunar Eclipse");
  public static final List<String> PREMIUM = ALL.subList(18,22);
  public static int primary(String style, int custom, boolean themed) {
    if (!themed) return custom;
    if(RefinedCapeArtwork.contains(style))return RefinedCapeArtwork.primary(style);
    return switch (style) {
      case "Premium - V Sovereign" -> 0xff73cfff;
      case "Premium - Celestial Seraph" -> 0xff66cbff;
      case "Premium - Void Lotus" -> 0xffa469ff;
      case "Premium - Obsidian Dragon" -> 0xffff492f;
      case "Hearts", "Broken Hearts", "Heartbeat" -> 0xffff3979;
      case "Sacred Geometry" -> 0xfff3bf55;
      case "Crystal Lattice" -> 0xff8178ff;
      case "Saturn" -> 0xffeba65e;
      case "Star Map" -> 0xff609eff;
      case "Black Hole" -> 0xffff8644;
      case "Circuit Board" -> 0xff16dbaa;
      case "Reactor" -> 0xff35caff;
      case "Digital Rain" -> 0xff36e96e;
      case "Sakura" -> 0xfffb84bf;
      case "Phoenix" -> 0xffff612a;
      case "Eclipse" -> 0xff9d69ff;
      default -> custom; // Existing designs retain their saved colors.
    };
  }
  public static int accent(String style, int custom, boolean themed) {
    if (!themed) return custom;
    if(RefinedCapeArtwork.contains(style))return RefinedCapeArtwork.accent(style);
    return switch (style) {
      case "Premium - V Sovereign" -> 0xffedf8ff;
      case "Premium - Celestial Seraph" -> 0xffefffff;
      case "Premium - Void Lotus" -> 0xffffa0dc;
      case "Premium - Obsidian Dragon" -> 0xffffce62;
      case "Hearts", "Broken Hearts", "Heartbeat" -> 0xffffcfdf;
      case "Sacred Geometry" -> 0xfffff0be;
      case "Crystal Lattice" -> 0xffc2f8ff;
      case "Saturn" -> 0xffffe2ae;
      case "Star Map" -> 0xffe0f0ff;
      case "Black Hole" -> 0xffffdf98;
      case "Circuit Board" -> 0xffbbfff0;
      case "Reactor" -> 0xffd4fbff;
      case "Digital Rain" -> 0xffdbffcf;
      case "Sakura" -> 0xffffe5f0;
      case "Phoenix" -> 0xffffe16b;
      case "Eclipse" -> 0xffffcd87;
      default -> custom;
    };
  }
  private CosmeticThemes() {}
}
