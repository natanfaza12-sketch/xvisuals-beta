package pl.xvisuals.modules.cosmetics;

import pl.xvisuals.util.Colors;

/** A broad metallic V and layered wing insignia, readable at cape texture resolution. */
final class SovereignArtwork {
  static int pixel(double u,double v,double t,int primary,int accent) {
    double x=Math.abs(u-.5)*2;
    double weave=.5+.5*Math.sin(u*190+v*110);
    int ink=Colors.mix(0xff050811,primary,.025+.018*weave+.04*v);
    // Subtle shoulder panels and a pointed lower panel create depth in the cloth.
    double panel=Math.abs(x-(.72-.24*v));
    ink=Colors.mix(ink,primary,Math.max(0,1-panel/.09)*.12);
    double hem=Math.abs(v-(.88+.065*(1-x)));
    ink=Colors.mix(ink,primary,line(hem,.008)*.65);
    ink=Colors.mix(ink,accent,line(Math.abs(v-(.92+.04*(1-x))),.004)*.32);
    ink=Colors.mix(ink,primary,line(Math.abs(x-.92),.008)*.5);
    // Three sharp, swept feathers flank the central mark.
    for(int i=0;i<3;i++) {
      double ax=.26+i*.055, ay=.47+i*.085;
      double bx=.86-i*.09, by=.21+i*.14;
      double d=segment(x,v,ax,ay,bx,by);
      double taper=Math.clamp((x-ax)/(bx-ax),0,1);
      ink=Colors.mix(ink,primary,line(d,.028*(1-taper)+.004)*(.45+.16*i));
      ink=Colors.mix(ink,accent,line(d,.006)*.45);
    }
    // The V stays solid; only its metal sheen travels across the surface.
    double d=segment(x,v,0,.69,.58,.24);
    ink=Colors.mix(ink,primary,Math.max(0,1-d/.13)*.23);
    ink=Colors.mix(ink,0xff02040a,line(d,.084));
    double sheen=Math.pow(Math.max(0,1-Math.abs(v-(.48+.38*Math.sin(t*.48)))/.14),2);
    int metal=Colors.mix(primary,accent,.32+.48*(1-v)+.2*sheen);
    ink=Colors.mix(ink,metal,line(d,.062));
    ink=Colors.mix(ink,accent,line(Math.abs(d-.048),.008)*(.6+.4*sheen));
    // Small suspended diamond and a quiet lower signature echo the logo.
    double diamond=x*.65+Math.abs(v-.15);
    ink=Colors.mix(ink,accent,line(diamond,.023)*.9);
    double signature=segment(x,v,0,.81,.13,.75);
    ink=Colors.mix(ink,primary,line(signature,.009)*.8);
    return ink;
  }
  private static double line(double d,double width) { return Math.clamp((width+.005-Math.abs(d))/.01,0,1); }
  private static double segment(double x,double y,double ax,double ay,double bx,double by) {
    double dx=bx-ax,dy=by-ay;
    double f=Math.clamp(((x-ax)*dx+(y-ay)*dy)/(dx*dx+dy*dy),0,1);
    return Math.hypot(x-ax-dx*f,y-ay-dy*f);
  }
  private SovereignArtwork() {}
}
