package pl.xvisuals.modules.cosmetics;
import pl.xvisuals.util.Colors;
public final class RefinedCapeArtwork {
  private static final java.util.List<String> NAMES=java.util.List.of("Obsidian","Silverline","Carbon","Crimson Trim","Royal Navy","Ivory Gold","Midnight Fade","Arctic Fade","Copper Patina","Redshift","Topographic","Damascus","Black Ice","Sunset Silk","Emerald Crest","Lunar Eclipse");
  private static final int[] PRIMARY={0x252936,0x667585,0x303238,0x8D2035,0x172F58,0xE7DDC4,0x373456,0x7BA6BE,0x437B70,0x702C43,0x35534E,0x555C70,0x263F54,0xB05A68,0x1C6452,0x29283F};
  private static final int[] ACCENT={0x747B8A,0xDEE5EB,0x8A8D94,0xD0A779,0xBDA36A,0xAA8548,0x9187B8,0xE8F7FD,0xC98D5E,0xEC986B,0xA2C7B1,0xC1CAD6,0x83BED3,0xE8AF83,0xC8AD6A,0xD3D2E6};
  public static boolean contains(String s){return NAMES.contains(s);}
  public static int primary(String s){return 0xFF000000|PRIMARY[NAMES.indexOf(s)];}
  public static int accent(String s){return 0xFF000000|ACCENT[NAMES.indexOf(s)];}
  public static int pixel(String s,double u,double v,double t,int p,int a){
    int id=NAMES.indexOf(s);double x=u-.5,y=v-.5;
    double weave=.025*Math.sin(u*240)*Math.sin(v*320);
    int base=Colors.mix(0xFF090D15,p,.24+.22*v+weave);
    double edge=Math.min(Math.min(u,1-u),Math.min(v,1-v));
    double ink=0;
    switch(id){
      case 0 -> ink=.12*Math.pow(.5+.5*Math.cos((u+v*.3)*12),8);
      case 1 -> ink=Math.abs(Math.abs(x)-.36)<.012||Math.abs(v-.9)<.009?.8:0;
      case 2 -> ink=((int)(u*18)+(int)(v*28))%2==0?.08:.015;
      case 3 -> {base=Colors.mix(0xFF090D15,p,.12);ink=edge>.045&&edge<.064?.9:0;}
      case 4 -> ink=(Math.abs(Math.abs(x)-.34)<.008||Math.abs(v-.86)<.007||Math.abs(y-.12+Math.abs(x)*.65)<.012&&Math.abs(x)<.22)?.8:0;
      case 5 -> {base=Colors.mix(p,0xFFFFFFFF,.08+weave);ink=edge>.06&&edge<.075?.85:0;}
      case 6 -> {base=Colors.mix(0xFF101524,p,v*v);ink=.16*Math.pow(.5+.5*Math.sin(u*5+v*3-t*.18),4);}
      case 7 -> {base=Colors.mix(0xFF23384A,p,v);ink=v*v*.65;}
      case 8 -> {base=Colors.mix(p,0xFF16312D,.3);ink=.45*Math.pow(.5+.5*Math.sin(u*15+Math.sin(v*11)*2),8);}
      case 9 -> {base=Colors.mix(0xFF100F1B,p,v);ink=Math.exp(-Math.pow((v-.74)*18,2))*.7;}
      case 10 -> ink=Math.pow(.5+.5*Math.sin(u*38+Math.sin(v*12)*3+Math.cos(u*9-v*8)*2),30)*.5;
      case 11 -> ink=Math.pow(.5+.5*Math.sin(u*55+Math.sin(v*19)*3+Math.sin(u*16+v*13)*2),8)*.38;
      case 12 -> ink=Math.max(0,1-Math.abs(x*2+Math.sin(v*8)*.32))*v*.45;
      case 13 -> {base=Colors.mix(p,0xFF302840,1-v);ink=v*.6+.05*Math.sin(u*6+v*4-t*.15);}
      case 14 -> {double diamond=Math.abs(x)*1.1+Math.abs(y+.02)*.65;ink=Math.abs(diamond-.19)<.009||edge>.055&&edge<.065?.8:0;}
      case 15 -> {double r=Math.hypot(x,(v-.42)*.68);ink=Math.exp(-Math.pow((r-.19)*160,2))*.8;}
    }
    double sheen=.92+.08*Math.sin(t*.35+v*2);
    return Colors.mix(base,a,Math.clamp(ink*sheen,0,1));
  }
  private RefinedCapeArtwork(){}
}
