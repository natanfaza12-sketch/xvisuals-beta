package pl.xvisuals.modules.cosmetics;
import pl.xvisuals.XVisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.*;
import java.nio.file.*;
public final class LocalAppearance {
  private static final Identifier TEXTURE=Identifier.of("xvisuals","local_skin");
  private static volatile String requested="",loaded="";
  private static volatile String status="Import a 64 x 64 PNG skin.";
  private static SkinTextures usernameSkin;
  private static String pending="";
  private static long changedAt;
  private static long generation;
  private static String selection(pl.xvisuals.config.VisualConfig.ModuleState m){
    return m.text("source").equals("Minecraft username")?"user:"+UsernameSkinLookup.clean(m.text("username")).toLowerCase(java.util.Locale.ROOT):m.text("image");
  }
  public static String status(){return status;}
  public static net.minecraft.text.Text protectText(net.minecraft.text.Text original){
    if(original==null||!XVisuals.ready()||!XVisuals.visualModule("namechanger").enabled)return original;
    var client=MinecraftClient.getInstance();
    String username=client.player==null?client.getSession().getUsername():client.player.getGameProfile().name();
    return displayName(original,username);
  }
  public static String displayName(String original){
    var m=XVisuals.visualModule("namechanger");
    String name=LocalNameText.clean(m.text("name"));
    return m.enabled&&!name.isEmpty()?name:original;
  }
  public static net.minecraft.text.Text displayName(net.minecraft.text.Text original,String username){
    return LocalNameText.replace(original,username,displayName(username));
  }
  public static void tick(){
    var m=XVisuals.visualModule("skinchanger");String path=selection(m);
    if(!m.enabled){if(!requested.isEmpty()||!pending.isEmpty())generation++;requested="";pending="";loaded="";usernameSkin=null;return;}
    if(!path.equals(pending)){pending=path;changedAt=System.nanoTime();generation++;requested="";loaded="";usernameSkin=null;status=path.startsWith("user:")?"Type a Minecraft username...":"Loading skin...";}
    if(path.equals(requested))return;
    if(path.startsWith("user:")&&System.nanoTime()-changedAt<600_000_000L)return;
    requested=path;
    long requestGeneration=generation;
    if(path.startsWith("user:")){
      String name=path.substring(5);
      if(!UsernameSkinLookup.valid(name)){status="Enter a Minecraft username (up to 16 characters).";return;}
      status="Loading skin for "+name+"...";
      var client=MinecraftClient.getInstance();
      java.util.concurrent.CompletableFuture.supplyAsync(()->{
        try{
          var id=UsernameSkinLookup.resolve(name);
          var result=client.getApiServices().sessionService().fetchProfile(id,true);
          if(result==null)throw new java.io.IOException("Minecraft profile unavailable.");
          return result.profile();
        }catch(Exception e){throw new java.util.concurrent.CompletionException(e);}
      }).thenCompose(profile->client.getSkinProvider().fetchSkinTextures(profile))
        .orTimeout(25,java.util.concurrent.TimeUnit.SECONDS).whenComplete((skin,error)->client.execute(()->{
          if(generation!=requestGeneration||!requested.equals(path))return;
          if(error!=null||skin==null||skin.isEmpty()){
            Throwable cause=error;
            while(cause!=null&&cause.getCause()!=null)cause=cause.getCause();
            if(cause!=null)org.slf4j.LoggerFactory.getLogger("xvisuals").warn("Username skin lookup failed: {}: {}",cause.getClass().getSimpleName(),cause.getMessage());
            status=cause instanceof java.io.IOException?"Skin unavailable: "+cause.getMessage():"Skin unavailable. Check connection; toggle off/on to retry.";
            return;
          }
          usernameSkin=skin.get();loaded=path;status="Skin applied: "+name+" (local only).";
        }));
      return;
    }
    if(path.isBlank()){loaded="";return;}
    java.util.concurrent.CompletableFuture.runAsync(()->{
      try{
        Path file=Path.of(path);SkinImageValidation.validate(file);
        NativeImage image;try(var in=Files.newInputStream(file)){image=NativeImage.read(in);}
        if(image.getWidth()!=64||image.getHeight()!=64){image.close();throw new java.io.IOException("Use a 64 x 64 PNG skin");}
        MinecraftClient.getInstance().execute(()->{
          if(generation!=requestGeneration||!requested.equals(path)){image.close();return;}
          MinecraftClient.getInstance().getTextureManager().registerTexture(TEXTURE,new NativeImageBackedTexture(()->"Local skin",image));
          loaded=path;status="Skin applied locally.";
        });
      }catch(Exception e){MinecraftClient.getInstance().execute(()->{if(generation==requestGeneration&&requested.equals(path)){status="Skin unavailable: "+e.getMessage();loaded="";}});}
    });
  }
  public static SkinTextures skin(SkinTextures original){
    var m=XVisuals.visualModule("skinchanger");
    if(!m.enabled||loaded.isEmpty()||!loaded.equals(selection(m)))return original;
    if(m.text("source").equals("Minecraft username"))return usernameSkin==null?original:new SkinTextures(usernameSkin.body(),original.cape(),original.elytra(),usernameSkin.model(),usernameSkin.secure());
    return new SkinTextures(new AssetInfo.TextureAssetInfo(TEXTURE,TEXTURE),original.cape(),original.elytra(),
        m.text("model").equals("Slim")?PlayerSkinType.SLIM:PlayerSkinType.WIDE,false);
  }
  private LocalAppearance(){}
}

