package pl.xvisuals.modules.cosmetics;

import com.google.gson.JsonParser;
import java.io.IOException;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.util.UUID;

public final class UsernameSkinLookup {
  public static String clean(String name) { return name.trim(); }
  public static boolean valid(String name) { return name.matches("[A-Za-z0-9_]{1,16}"); }
  public static UUID parseId(String id) {
    if(!id.matches("[a-fA-F0-9]{32}"))throw new IllegalArgumentException("Invalid Minecraft profile ID");
    return UUID.fromString(id.substring(0,8)+"-"+id.substring(8,12)+"-"+id.substring(12,16)+"-"+id.substring(16,20)+"-"+id.substring(20));
  }
  public static UUID resolve(String name) throws Exception {
    if(!valid(name))throw new IOException("Use a Minecraft username (letters, numbers or underscore, up to 16 characters).");
    try(var client=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build()) {
      var request=HttpRequest.newBuilder(URI.create("https://api.mojang.com/users/profiles/minecraft/"+name)).timeout(Duration.ofSeconds(10)).GET().build();
      var response=client.send(request,HttpResponse.BodyHandlers.ofInputStream());
      try(var body=response.body()) {
        if(response.statusCode()==404||response.statusCode()==204)throw new IOException("Minecraft username not found.");
        if(response.statusCode()==429)throw new IOException("Too many lookups. Try again shortly.");
        if(response.statusCode()!=200)throw new IOException("Minecraft profile service unavailable.");
        byte[] bytes=body.readNBytes(8193);
        if(bytes.length>8192)throw new IOException("Invalid Minecraft profile response.");
        return parseId(JsonParser.parseString(new String(bytes,java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject().get("id").getAsString());
      }
    }
  }
  private UsernameSkinLookup() {}
}
