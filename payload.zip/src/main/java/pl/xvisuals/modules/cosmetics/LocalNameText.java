package pl.xvisuals.modules.cosmetics;

import java.util.*;
import java.util.regex.Pattern;
import net.minecraft.text.*;

/** Replace the username in a local display without discarding rank or suffix styling. */
public final class LocalNameText {
  private record Run(int start,int end,String text,Style style) {}
  public static String clean(String value) {
    String name=value.replaceAll("[\\p{Cntrl}§]","").strip();
    return name.substring(0,name.offsetByCodePoints(0,Math.min(32,name.codePointCount(0,name.length()))));
  }
  public static Text replace(Text original,String username,String alias) {
    if(original==null||username.isEmpty()||alias.isEmpty()||username.equals(alias))return original;
    String plain=original.getString();
    var matches=Pattern.compile("(?<![A-Za-z0-9_])"+Pattern.quote(username)+"(?![A-Za-z0-9_])",Pattern.CASE_INSENSITIVE).matcher(plain);
    if(!matches.find())return original;
    List<Run> runs=new ArrayList<>();int[] offset={0};
    original.visit((style,text)->{int start=offset[0];offset[0]+=text.length();runs.add(new Run(start,offset[0],text,style));return Optional.empty();},Style.EMPTY);
    MutableText result=Text.empty().setStyle(original.getStyle());int position=0;
    do {
      append(result,runs,position,matches.start());
      Style style=runs.stream().filter(r->r.start<=matches.start()&&r.end>matches.start()).findFirst().map(Run::style).orElse(original.getStyle());
      result.append(Text.literal(alias).setStyle(style));position=matches.end();
    }while(matches.find());
    append(result,runs,position,plain.length());return result;
  }
  private static void append(MutableText target,List<Run> runs,int start,int end){
    for(var run:runs){int lo=Math.max(start,run.start),hi=Math.min(end,run.end);if(lo<hi)target.append(Text.literal(run.text.substring(lo-run.start,hi-run.start)).setStyle(run.style));}
  }
  private LocalNameText(){}
}
