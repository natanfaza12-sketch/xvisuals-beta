package pl.xvisuals.modules.cosmetics;

/** Recognizable animated emblems drawn directly into the cosmetic texture.
 * All movement is continuous in time; positions and paths are deterministic.
 */
final class ThemeArtwork {
  private static final double TAU = Math.PI * 2;
  private static final double[] STAR_X = {-.55,-.18,.33,.52,.08,-.42,-.12};
  private static final double[] STAR_Y = {-.92,-.6,-.8,-.13,.2,.03,.77};

  static int pixel(String style, double u, double v, double t, int p, int a) {
    double x = (u-.5)*2, y = (v-.5)*3.2;
    int ink = paint(0xff080c18, p, .045 + .035 * (1-v));
    switch (style) {
      case "Hearts", "Broken Hearts", "Heartbeat" -> {
        boolean broken = style.equals("Broken Hearts");
        double beat = beat(t), scale = .43 * (1 + .11 * beat);
        double gap = broken ? .025 + .14 * Math.pow(Math.sin(t * Math.PI / 4), 2) : 0;
        double localX = x + (x < 0 ? gap : -gap);
        double crack = .055 * Math.sin((y+.5)*23);
        double d = heart(localX / scale, -(y+.22) / scale);
        boolean half = !broken || (x < 0 ? localX < crack : localX > crack);
        if (half) {
          ink = paint(ink, p, .2 * Math.exp(-Math.abs(d)*4));
          ink = paint(ink, p, fill(d,.12) * (.78 + .22*beat));
          ink = paint(ink, a, stroke(d,.12) * .7);
          ink = paint(ink, a, Math.exp(-sq((localX+.2)/.075)-sq((y+.4)/.06)) * .65);
          if (broken) ink = paint(ink, a, stroke(localX-crack,.026) * fill(d,.12));
        }
        if (broken) {
          for (int i=0;i<3;i++) {
            double f = fract(t*.3+i*.31);
            double sx = (i-1)*(.14+f*.2), sy=.35+f*.9;
            double shard=Math.abs(x-sx)+Math.abs(y-sy)*.65-.055*(1-f);
            ink=paint(ink,p,fill(shard,.018)*(1-f));
          }
        } else if (style.equals("Hearts")) {
          for (int i=0;i<4;i++) {
            double f=fract(t*.16+i*.25);
            double hx=(i%2==0 ? -.66 : .66)+.05*Math.sin(t+i);
            double hy=1.4-f*2.8;
            ink=paint(ink,i%2==0?p:a,fill(heart((x-hx)/.105,-(y-hy)/.105),.2)*Math.sin(f*Math.PI)*.7);
          }
        } else {
          double trace=ecg((x+.8)/1.6), scan=fract(t*.6)*1.6-.8;
          double line=stroke(y-.85+trace*.32,.04) * (Math.abs(x)<.8?1:0);
          ink=paint(ink,p,line*(x<scan?.95:.45));
          ink=paint(ink,a,Math.exp(-sq((x-scan)/.065)-sq((y-.85+ecg((scan+.8)/1.6)*.32)/.06)));
        }
      }
      case "Sacred Geometry" -> {
        double r=Math.hypot(x,y), angle=Math.atan2(y,x);
        ink=paint(ink,p,stroke(r-.72,.018)*.7);
        for (int i=0;i<3;i++) {
          double rot=t*(i%2==0?.24:-.18)+i*Math.PI/3;
          double radius=.61-i*.13;
          for(int j=0;j<3;j++) {
            double aa=rot+j*TAU/3, bb=rot+(j+1)*TAU/3;
            ink=paint(ink,i==1?a:p,stroke(segment(x,y,Math.cos(aa)*radius,Math.sin(aa)*radius,
                Math.cos(bb)*radius,Math.sin(bb)*radius),.024));
          }
        }
        ink=paint(ink,a,stroke(r-.72,.038)*Math.pow(.5+.5*Math.cos(angle-t),18));
        ink=paint(ink,a,Math.exp(-r*r*160)*(.5+.5*Math.sin(t*2)));
      }
      case "Crystal Lattice" -> {
        for (int i=0;i<3;i++) {
          double cx=(i-1)*.38, cy=i==1?-.13:.27;
          cy+=Math.sin(t*1.2+i)*.075;
          double xx=x-cx, yy=y-cy, size=i==1?.85:.57;
          double diamond=Math.abs(xx)/.23+Math.abs(yy)/size-1;
          ink=paint(ink,p,fill(diamond,.04)*(.22+.35*(xx>0?1:0)));
          ink=paint(ink,a,stroke(diamond,.07)*.85);
          ink=paint(ink,p,stroke(xx,.018)*fill(diamond,.03));
          double facet=segment(xx,yy,-.23,0,0,size);
          ink=paint(ink,a,stroke(facet,.018)*.5);
          ink=paint(ink,a,stroke(yy-(fract(t*.25+i*.25)*2-1)*size,.045)*fill(diamond,.03)*.8);
        }
      }
      case "Saturn" -> {
        ink=stars(ink,x,y,t,a);
        double yy=y+.15, rot=.35+.08*Math.sin(t*.35);
        double rx=x*Math.cos(rot)+yy*Math.sin(rot), ry=-x*Math.sin(rot)+yy*Math.cos(rot);
        double ring=Math.hypot(rx,ry/.28), sphere=Math.hypot(x,yy);
        double ringInk=stroke(ring-.69,.055)+stroke(ring-.78,.015)*.7;
        if(ry<0) ink=paint(ink,a,ringInk*.7);
        if(sphere<.45) {
          ink=paint(ink,p,(.55+.3*Math.sin(yy*34+t*.45))*(1-.35*x/.45));
          ink=paint(ink,a,stroke(yy+.12+.012*Math.sin(x*10+t),.04)*.4);
        }
        if(ry>=0) ink=paint(ink,a,ringInk);
        double moonX=Math.cos(t*.55)*.76, moonY=Math.sin(t*.55)*.98;
        ink=paint(ink,a,fill(Math.hypot(x-moonX,y-moonY)-.045,.015));
      }
      case "Star Map" -> {
        ink=stars(ink,x,y,t,a);
        for(int i=0;i<STAR_X.length;i++) {
          double sx=STAR_X[i], sy=STAR_Y[i];
          double light=.55+.45*Math.sin(t*1.8+i);
          if(i>0) {
            ink=paint(ink,p,stroke(segment(x,y,STAR_X[i-1],STAR_Y[i-1],sx,sy),.014)*.7);
            double f=fract(t*.22-i*.14);
            ink=paint(ink,a,Math.exp(-sq((x-lerp(STAR_X[i-1],sx,f))/.035)-sq((y-lerp(STAR_Y[i-1],sy,f))/.035)));
          }
          ink=paint(ink,a,Math.exp(-sq((x-sx)/.034)-sq((y-sy)/.034))*light);
          ink=paint(ink,a,Math.max(stroke(x-sx,.01)*fill(Math.abs(y-sy)-.08,.01),
              stroke(y-sy,.01)*fill(Math.abs(x-sx)-.06,.01))*light);
        }
      }
      case "Black Hole", "Eclipse" -> {
        ink=stars(ink,x,y,t,a);
        double r=Math.hypot(x,y), angle=Math.atan2(y,x);
        boolean eclipse=style.equals("Eclipse");
        double radius=eclipse?.42:.32;
        double orbit=eclipse?r:Math.hypot(x,y/.36);
        double flow=.65+.35*Math.sin(angle*6-t*2.2);
        ink=paint(ink,p,Math.exp(-Math.abs(r-radius)*13)*.65);
        ink=paint(ink,a,stroke(r-radius,.035)*flow);
        if(!eclipse) {
          ink=paint(ink,p,stroke(orbit-.7,.075)*flow);
          ink=paint(ink,a,stroke(orbit-.7,.018));
        } else {
          double rays=.045+.04*Math.sin(angle*12+t)+.03*Math.sin(angle*19-t*1.4);
          ink=paint(ink,a,stroke(r-radius-rays,.018)*.55);
          ink=paint(ink,a,Math.exp(-sq((x-Math.cos(t*.4)*radius)/.09)-sq((y-Math.sin(t*.4)*radius)/.09)));
        }
        ink=paint(ink,0xff03050c,fill(r-radius+.025,.018));
      }
      case "Circuit Board" -> {
        for(int i=0;i<5;i++) {
          double lane=(i-2)*.29, elbow=(i%2==0?-.3:.3), end=lane+(i<2?.15:-.15);
          double d=Math.min(segment(x,y,lane,-1.2,lane,elbow-.16),
              Math.min(segment(x,y,lane,elbow-.16,end,elbow),segment(x,y,end,elbow,end,1.2)));
          ink=paint(ink,p,stroke(d,.022)*.5);
          double py=fract(t*.23+i*.19)*2.4-1.2;
          double px=py<elbow-.16?lane:py>elbow?end:lerp(lane,end,(py-elbow+.16)/.16);
          ink=paint(ink,a,Math.exp(-sq((x-px)/.04)-sq((y-py)/.085)));
          ink=paint(ink,a,stroke(Math.hypot(x-end,y-1.15)-.045,.013));
        }
        double chip=Math.max(Math.abs(x)-.24,Math.abs(y)-.24);
        ink=paint(ink,0xff061b20,fill(chip,.015));
        ink=paint(ink,a,stroke(chip,.02));
        ink=paint(ink,p,stroke(Math.max(Math.abs(x),Math.abs(y))-.12,.025)*(.6+.4*Math.sin(t*3)));
      }
      case "Reactor" -> {
        double r=Math.hypot(x,y), theta=Math.atan2(y,x);
        ink=paint(ink,p,Math.exp(-r*r*15)*(.65+.2*Math.sin(t*3)));
        ink=paint(ink,a,fill(r-.12,.03));
        for(int i=0;i<3;i++) {
          double radius=.29+i*.15, phase=theta+t*(i%2==0?1:-.6);
          ink=paint(ink,i%2==0?p:a,stroke(r-radius,.028)*(Math.cos(phase*3+i)>.0?1:.12));
        }
        double ticks=Math.abs(Math.sin(theta*16));
        ink=paint(ink,a,fill(Math.abs(r-.77)-.045,.012)*fill(ticks-.25,.08)*.75);
      }
      case "Digital Rain" -> {
        int col=(int)Math.floor((x+1)*5);
        double gx=fract((x+1)*5), gy=fract((y+1.6)*6), row=Math.floor((y+1.6)*6);
        double head=fract(t*(.17+(col%3)*.025)+col*.173)*20;
        double distance=(head-row+20)%20;
        // Small deterministic binary glyphs, with staggered moving column heads.
        boolean one=((int)row+col*3)%3==0;
        double glyph=one?stroke(gx-.5,.11)*fill(Math.abs(gy-.5)-.32,.06):
            stroke(Math.max(Math.abs(gx-.5)*1.3,Math.abs(gy-.5))-.32,.075);
        ink=paint(ink,distance<1?a:p,glyph*Math.max(0,1-distance/8));
      }
      case "Sakura" -> {
        ink=paint(ink,p,stroke(segment(x,y,-.74,1.3,-.28,.1),.035)*.6);
        ink=paint(ink,p,stroke(segment(x,y,-.28,.1,.57,-.9),.027)*.6);
        ink=paint(ink,p,stroke(segment(x,y,-.28,.1,-.55,-.6),.022)*.6);
        for(int i=0;i<5;i++) {
          double cx=i<3?-.48+i*.42:-.49+(i-3)*.54;
          double cy=i<3?-.57-i*.1:.3;
          double dx=x-cx, dy=y-cy, angle=Math.atan2(dy,dx)+.08*Math.sin(t+i);
          double radius=.13+.047*Math.cos(angle*5);
          ink=paint(ink,p,fill(Math.hypot(dx,dy)-radius,.018));
          ink=paint(ink,a,Math.exp(-(dx*dx+dy*dy)*800));
        }
        for(int i=0;i<4;i++) {
          double f=fract(t*.12+i*.25), px=.58*Math.sin(i*2.1+f*2.5), py=f*3.2-1.6;
          ink=paint(ink,a,fill(Math.hypot((x-px)*1.5,y-py)-.04,.012)*.85);
        }
      }
      case "Phoenix" -> {
        double flap=.13*Math.sin(t*2), ax=Math.abs(x);
        double body=Math.max(Math.abs(x)-.10,Math.abs(y+.02)-.42);
        ink=paint(ink,p,fill(body,.03));
        ink=paint(ink,a,fill(Math.hypot(x,y+.46)-.12,.02));
        for(int i=0;i<5;i++) {
          double tipX=.7-i*.075, tipY=-.65+i*.2+flap;
          double d=segment(ax,y,.07,-.18+i*.04,tipX,tipY);
          ink=paint(ink,p,stroke(d,.065)*(1-.08*i));
          ink=paint(ink,a,stroke(d,.016)*(.5+.5*Math.sin(t*2-i*.5)));
        }
        for(int i=0;i<3;i++) {
          double path=(i-1)*.13+Math.sin(y*5-t*3+i)*.035;
          ink=paint(ink,i==1?a:p,stroke(x-path,.045)*fill(Math.abs(y-.72)-.37,.04));
        }
      }
      default -> throw new IllegalArgumentException("Unknown emblem: " + style);
    }
    return ink;
  }

  private static int stars(int ink,double x,double y,double t,int color) {
    for(int i=0;i<9;i++) {
      double sx=Math.sin(i*13.7)*.82, sy=Math.cos(i*8.3)*1.35;
      ink=paint(ink,color,Math.exp(-sq((x-sx)/.018)-sq((y-sy)/.022))*(.5+.4*Math.sin(t*1.5+i)));
    }
    return ink;
  }
  static double beat(double t) {
    double f=fract(t*.6);
    return Math.exp(-sq((f-.15)/.055))+.65*Math.exp(-sq((f-.30)/.065));
  }
  private static double heart(double x,double y) {
    // Two rounded lobes meeting a pointed lower half. A deep notch remains
    // legible at Minecraft texture resolution, unlike a flattened implicit heart.
    double lobes=Math.hypot(Math.abs(x)-.46,y-.35)-.51;
    double tip=Math.max(y-.25,Math.max(-y-1.1,(Math.abs(x)-.711*(y+1.1))*.815));
    return Math.min(lobes,tip)*3;
  }
  private static double ecg(double x) {
    return .22*tri(x,.23,.07)-.3*tri(x,.41,.025)+1.2*tri(x,.46,.035)
        -.5*tri(x,.51,.035)+.28*tri(x,.67,.10);
  }
  private static double tri(double x,double center,double width) { return Math.max(0,1-Math.abs(x-center)/width); }
  private static double segment(double x,double y,double ax,double ay,double bx,double by) {
    double dx=bx-ax,dy=by-ay;
    double h=clamp(((x-ax)*dx+(y-ay)*dy)/(dx*dx+dy*dy));
    return Math.hypot(x-ax-h*dx,y-ay-h*dy);
  }
  private static double fill(double d,double width) { return clamp(.5-d/width); }
  private static double stroke(double d,double width) { return clamp(1-Math.abs(d)/width); }
  private static double fract(double x) { return x-Math.floor(x); }
  private static double sq(double x) { return x*x; }
  private static double lerp(double a,double b,double f) { return a+(b-a)*f; }
  private static double clamp(double x) { return Math.max(0,Math.min(1,x)); }
  private static int paint(int a,int b,double f) {
    f=clamp(f);
    int r=(int)(((a>>16)&255)*(1-f)+((b>>16)&255)*f);
    int g=(int)(((a>>8)&255)*(1-f)+((b>>8)&255)*f);
    int bl=(int)((a&255)*(1-f)+(b&255)*f);
    return 0xff000000|r<<16|g<<8|bl;
  }
  private ThemeArtwork() {}
}
