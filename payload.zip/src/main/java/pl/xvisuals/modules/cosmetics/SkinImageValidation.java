package pl.xvisuals.modules.cosmetics;
import java.nio.file.*;
import java.io.IOException;
import javax.imageio.ImageIO;
public final class SkinImageValidation {
  public static void validate(Path file) throws IOException {
    if(!Files.isRegularFile(file)||Files.size(file)>1024*1024)throw new IOException("Choose a PNG skin under 1 MB");
    try(var input=ImageIO.createImageInputStream(file.toFile())){
      if(input==null)throw new IOException("Cannot read skin");
      var readers=ImageIO.getImageReaders(input);
      if(!readers.hasNext())throw new IOException("Choose a PNG skin");
      var reader=readers.next();
      try {reader.setInput(input);
        if(!reader.getFormatName().equalsIgnoreCase("png")||reader.getWidth(0)!=64||reader.getHeight(0)!=64)
          throw new IOException("Use a 64 x 64 PNG skin");
      }finally{reader.dispose();}
    }
  }
  private SkinImageValidation(){}
}
