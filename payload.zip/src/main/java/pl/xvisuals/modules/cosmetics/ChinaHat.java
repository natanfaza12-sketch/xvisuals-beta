package pl.xvisuals.modules.cosmetics;

import pl.xvisuals.XVisuals;
import pl.xvisuals.config.VisualConfig.ModuleState;
import pl.xvisuals.util.Colors;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.*;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

/** Authored neon artwork wrapped on a head-attached, double-sided cone. */
public final class ChinaHat {
 public static final int SEGMENTS=64;
 public static long submissions;
 public static Identifier texture(String theme){return Identifier.of("xvisuals","textures/china_hat/"+switch(theme){case "Sunset"->"sunset";case "Rainbow"->"rainbow";case "Custom"->"custom";case "Black","White","Silver"->"clean";default->"aurora";}+".png");}
 public static void render(MatrixStack matrices,OrderedRenderCommandQueue queue,int light,PlayerEntityRenderState state,ModelPart head){
  if(!AnimatedCosmetics.applies("chinahat",state))return;
  var m=XVisuals.visualModule("chinahat");
  draw(matrices,queue,state,head,m,m.text("theme"),AnimatedCosmetics.time());
 }
 public static void draw(MatrixStack matrices,OrderedRenderCommandQueue queue,PlayerEntityRenderState state,ModelPart head,ModuleState m,String theme,double seconds){
  double radius=m.number("radius"),height=m.number("height");
  double rotation=m.flag("animated")?seconds*m.number("speed")*.18:0;
  boolean rim=m.flag("rim");double uvRadius=rim?.445:.375;
  int primary=tint(theme,m,true),secondary=tint(theme,m,false);
  float opacity=(float)m.number("opacity");
  matrices.push();head.applyTransform(matrices);matrices.translate(0,-.57-m.number("offset"),0);
  queue.submitCustom(matrices,RenderLayers.entityTranslucentEmissive(texture(theme)),(entry,out)->{
   for(int i=0;i<SEGMENTS;i++){
    double a=i*Math.PI*2/SEGMENTS,b=(i+1)*Math.PI*2/SEGMENTS;
    int ca=Colors.mix(primary,secondary,(Math.cos(a)+1)*.5),cb=Colors.mix(primary,secondary,(Math.cos(b)+1)*.5);
    // Reversed underside is slightly lower: the hat remains visible when viewed from beneath.
    face(out,entry,a,b,radius,height,rotation,uvRadius,ca,cb,opacity,false);
    face(out,entry,b,a,radius,height,rotation,uvRadius,cb,ca,opacity*.65f,true);
    if(rim){
     vertex(out,entry,a,radius,0,rotation,uvRadius,ca,opacity);
     vertex(out,entry,b,radius,0,rotation,uvRadius,cb,opacity);
     vertex(out,entry,b,radius,.018,rotation,uvRadius,cb,opacity);
     vertex(out,entry,a,radius,.018,rotation,uvRadius,ca,opacity);
    }
   }
  });submissions++;matrices.pop();
 }
 public static int tint(String theme,ModuleState m,boolean primary){return switch(theme){case "Black"->0xff30323a;case "Silver"->0xffa3adbc;case "White"->0xffffffff;case "Custom"->m.color(primary?"color":"secondary");default->0xffffffff;};}
 private static void face(VertexConsumer out,MatrixStack.Entry e,double a,double b,double r,double h,double rotation,double uv,int ca,int cb,float opacity,boolean under){
  double offset=under?.012:0;
  vertex(out,e,a,0,-h+offset,rotation,0,ca,opacity);
  vertex(out,e,b,0,-h+offset,rotation,0,cb,opacity);
  vertex(out,e,b,r,offset,rotation,uv,cb,opacity);
  vertex(out,e,a,r,offset,rotation,uv,ca,opacity);
 }
 private static void vertex(VertexConsumer out,MatrixStack.Entry e,double angle,double radius,double y,double rotation,double uvRadius,int color,float alpha){
  out.vertex(e.getPositionMatrix(),(float)(Math.cos(angle)*radius),(float)y,(float)(Math.sin(angle)*radius))
   .color(Colors.alpha(color,alpha)).texture((float)(.5+Math.cos(angle+rotation)*uvRadius),(float)(.5+Math.sin(angle+rotation)*uvRadius))
   .overlay(OverlayTexture.DEFAULT_UV).light(LightmapTextureManager.MAX_LIGHT_COORDINATE).normal(e,0,-1,0);
 }
 private ChinaHat(){}
}
