package pl.xvisuals.modules.cosmetics;
import pl.xvisuals.util.Colors;
/** Authored emblems with continuous motion, shared by cloth and the wing UV layout. */
final class PremiumArtwork {
 static int pixel(String style,double u,double v,double t,int primary,int accent){
  if(style.equals("Premium - V Sovereign")) return SovereignArtwork.pixel(u,v,t,primary,accent);
  double x=(u-.5)*2,y=(v-.5)*3.2,r=Math.hypot(x,y),angle=Math.atan2(y,x);
  double mist=.04+.045*Math.sin(x*4+y*3-t*.5)*Math.sin(y*3-x*2+t*.3);
  int ink=Colors.mix(0xff050811,primary,mist);
  // Small travelling motes, fading continuously rather than popping at the wrap.
  for(int i=0;i<7;i++){
   double phase=t*.22+i*.897,px=Math.sin(i*8.71)*.8,py=Math.sin(phase)*1.5;
   ink=paint(ink,accent,Math.exp(-((x-px)*(x-px)+(y-py)*(y-py))*1900)*(.3+.25*Math.cos(phase)));
  }
  switch(style){
   case "Premium - Celestial Seraph" -> {
    for(int side:new int[]{-1,1})for(int feather=0;feather<6;feather++){
     double tipX=side*(.35+feather*.085),tipY=-.65+feather*.19+Math.sin(t*.8)*.045;
     double d=segment(x,y,side*.08,.43+feather*.055,tipX,tipY);
     ink=paint(ink,primary,Math.exp(-d*24)*.19);
     ink=paint(ink,primary,stroke(d,.035));
     ink=paint(ink,accent,stroke(d,.012)*(.6+.4*Math.sin(t+feather*.6)));
    }
    ink=paint(ink,accent,stroke(Math.hypot(x,(y+.91)*2.7)-.26,.023));
    ink=paint(ink,accent,fill(Math.abs(x)*2+Math.abs(y+.18)-.18));
   }
   case "Premium - Void Lotus" -> {
    double yy=y+.1;
    for(int i=0;i<7;i++){
     double a=(i-3)*.39+Math.sin(t*.6)*.06;
     double px=x*Math.cos(a)+yy*Math.sin(a),py=-x*Math.sin(a)+yy*Math.cos(a);
     double petal=Math.abs(px)/(.13+.035*Math.cos(t*.6+i)) + Math.abs(py+.26)/.73-1;
     ink=paint(ink,primary,fill(petal*.12)*.23);
     ink=paint(ink,i%2==0?accent:primary,stroke(petal*.12,.012)*.9);
    }
    ink=paint(ink,accent,Math.exp(-(x*x+(y-.13)*(y-.13))*170)*(.6+.4*Math.sin(t*1.2)));
    ink=paint(ink,primary,stroke(Math.hypot(x,(y-.84)*3)-.58,.014)*.65);
   }
   default -> {
    // Symmetric jagged wings and a sinuous spine, with travelling molten light.
    for(int side:new int[]{-1,1})for(int rib=0;rib<5;rib++){
     double sx=side*.10,sy=-.45+rib*.2,ex=side*(.8-rib*.1),ey=-.65+rib*.29;
     double d=Math.min(segment(x,y,sx,sy,ex,ey),segment(x,y,ex,ey,side*.30,.65));
     ink=paint(ink,primary,stroke(d,.031));
     ink=paint(ink,accent,stroke(d,.009)*(.35+.65*Math.pow(.5+.5*Math.sin(y*7-t*2),3)));
    }
    double spine=x-.065*Math.sin(y*6-t*.7);
    ink=paint(ink,primary,stroke(spine,.035)*(Math.abs(y)<1.1?1:0));
    double head=Math.abs(x)*1.5+Math.abs(y+.74)-.22;
    ink=paint(ink,primary,fill(head));
    ink=paint(ink,accent,Math.exp(-Math.pow((Math.abs(x)-.065)*60,2)-Math.pow((y+.78)*70,2)));
   }
  }
  return ink;
 }
 private static double segment(double x,double y,double ax,double ay,double bx,double by){double dx=bx-ax,dy=by-ay,f=Math.clamp(((x-ax)*dx+(y-ay)*dy)/(dx*dx+dy*dy),0,1);return Math.hypot(x-ax-dx*f,y-ay-dy*f);}
 private static double stroke(double d,double width){return Math.clamp((width+.012-Math.abs(d))/.024,0,1);}
 private static double fill(double d){return Math.clamp(.5-d/.025,0,1);}
 private static int paint(int ink,int color,double alpha){return Colors.mix(ink,color,alpha);}
 private PremiumArtwork(){}
}
