package pl.xvisuals.modules.pickaxes;

import pl.xvisuals.XVisuals;
import java.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

/** Render-only model substitution. The inventory/server stack is never changed. */
public final class CustomPickaxes {
  public static final String[] STYLES={"Void Rift","Solar Forge","Frostbite","Sakura Spirit","Storm Coil","Jade Dragon","Neon Pixel","Short Pickaxe","Spoon","Gilded Warpick","Steel Prospector"};
  public static final String[] MATERIALS={"All pickaxes","Wooden","Stone","Copper","Iron","Golden","Diamond","Netherite"};
  public static final int FRAMES=32;
  private static final Identifier[][] MODELS=new Identifier[STYLES.length][FRAMES];
  private record Cached(ItemStack snapshot, ItemStack rendered, Identifier model) {}
  private static final Map<ItemStack,Cached> CACHE=new WeakHashMap<>();
  static {
    for(int i=0;i<STYLES.length;i++)for(int f=0;f<FRAMES;f++)MODELS[i][f]=Identifier.of("xvisuals","pickaxes/"+id(STYLES[i])+"/"+f);
  }
  public static String id(String style){return style.toLowerCase(Locale.ROOT).replace(' ','_');}
  public static boolean matches(String path,String material) {
    for(int i=1;i<MATERIALS.length;i++) if(path.equals(MATERIALS[i].toLowerCase(Locale.ROOT)+"_pickaxe"))
      return material.equals("All pickaxes") || material.equals(MATERIALS[i]);
    return false;
  }
  public static int frame(double seconds,double speed,boolean animated) {
    if (!animated || !Double.isFinite(seconds) || !Double.isFinite(speed)) return 0;
    double cycle = 2 / Math.clamp(speed,.1,3);
    return Math.floorMod((int)Math.floor((seconds % cycle) / cycle * FRAMES), FRAMES);
  }
  public static ItemStack appearance(ItemStack original) {
    if(!XVisuals.ready() || original.isEmpty())return original;
    var settings=XVisuals.config().module("custompickaxes");
    if(settings==null || !settings.enabled)return original;
    Identifier type=Registries.ITEM.getId(original.getItem());
    if(!type.getNamespace().equals("minecraft") || !matches(type.getPath(),settings.text("replace")))return original;
    var client=MinecraftClient.getInstance();
    double seconds=client.world==null ? net.minecraft.util.Util.getMeasuringTimeMs()/1000d
        : (client.world.getTime()+client.getRenderTickCounter().getTickProgress(false))/20d;
    int style=Math.max(0,Arrays.asList(STYLES).indexOf(settings.text("style")));
    boolean animate=settings.flag("animated")&&!XVisuals.config().module("performance").text("animation").equals("Off");
    Identifier model=MODELS[style][frame(seconds,settings.number("speed"),animate)];
    if(model==null)return original;
    Cached old=CACHE.get(original);
    if(old!=null && old.model.equals(model) && old.snapshot.getCount()==original.getCount()
        && ItemStack.areItemsAndComponentsEqual(old.snapshot,original))return old.rendered;
    ItemStack rendered=original.copy(); rendered.set(DataComponentTypes.ITEM_MODEL,model);
    if(CACHE.size()>128)CACHE.clear();
    CACHE.put(original,new Cached(original.copy(),rendered,model));
    return rendered;
  }
  private CustomPickaxes(){}
}
