package pl.xvisuals.modules.glint;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.*;
import net.minecraft.component.DataComponentTypes;
import pl.xvisuals.gui.components.Glass;
public final class GlintPreview {
 public static void draw(DrawContext g,float x,float y,float width){
  Item[] samples={Items.DIAMOND_SWORD,Items.NETHERITE_CHESTPLATE,Items.BOW};
  for(int i=0;i<samples.length;i++){
   var stack=new ItemStack(samples[i]);stack.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE,true);
   g.getMatrices().pushMatrix();g.getMatrices().translate(x+(i+.5f)*width/3-24,y+4);g.getMatrices().scale(3,3);
   g.drawItem(stack,0,0);g.getMatrices().popMatrix();
  }
  String hint=EnchantGlint.enabled()?"Live enchanted-item preview":"Enable Enchant Glint+ to preview changes";
  if(net.minecraft.client.MinecraftClient.getInstance().options.getGlintStrength().getValue()==0)hint="Minecraft Glint Strength is 0 - raise it in Video Settings";
  Glass.text(g,hint,x,y+62,0xffc6cbd6);
 }
 private GlintPreview(){}
}
