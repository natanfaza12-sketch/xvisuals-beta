package pl.xvisuals.modules.glint;

/** Periodic patterns tile without edges; independent of game state for verification. */
public final class GlintPattern {
  private static final double TAU=Math.PI*2;
  public static double intensity(String style,double u,double v) {
    double a=Math.sin(TAU*u),b=Math.sin(TAU*v);
    return switch(style) {
      case "Crosshatch" -> Math.max(Math.pow(Math.abs(a),12),Math.pow(Math.abs(b),12))*.8+.08;
      case "Prism" -> Math.pow(1-Math.abs(Math.sin(TAU*(u+v))),2)*.8+.08;
      case "Rings" -> Math.pow(.5+.5*Math.cos(TAU*(a+b)),7)*.85+.05;
      case "Stardust" -> Math.pow(Math.max(0,a*b),18)*.95+.025;
      case "Circuit" -> (Math.abs(a)<.12 || (Math.abs(b)<.12 && Math.cos(TAU*u)>.15))?.85:.04;
      default -> .06+.85*Math.pow(.5+.5*Math.sin(TAU*(u+v)+.7*Math.sin(TAU*v)),5);
    };
  }
  public static int pixel(String pattern,double u,double v,int first,int second,double mix,double brightness,double contrast) {
    double power=Math.pow(intensity(pattern,u,v),contrast)*brightness;
    mix=Math.clamp(mix,0,1);
    int r=channel(first>>16,second>>16,mix,power),g=channel(first>>8,second>>8,mix,power),b=channel(first,second,mix,power);
    return 0xFF000000|r<<16|g<<8|b;
  }
  private static int channel(int a,int b,double t,double p) {
    // SRC_COLOR + ONE blending squares RGB; encode the intended contribution
    // so mixed colours and dim pattern regions remain visible on framed items.
    double contribution=Math.clamp(((a&255)*(1-t)+(b&255)*t)*p/255.,0,1);
    return (int)Math.round(Math.sqrt(contribution)*255);
  }
  private GlintPattern() {}
}
