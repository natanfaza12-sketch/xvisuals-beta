package pl.xvisuals.modules.glint;
import pl.xvisuals.XVisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.*;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
/** Render-thread owned, repeating material shared by vanilla item and armour glint passes. */
public final class EnchantGlint {
 private static final Identifier ID=Identifier.of("xvisuals","dynamic/enchant_glint");
 private static NativeImageBackedTexture texture;
 private static Settings previous;
 private static long lastFrame=-1,lastTick;
 private static double clock;
 private record Settings(String pattern,String mode,int first,int second,double brightness,double contrast){}
 public static boolean enabled(){return XVisuals.ready()&&XVisuals.config().on("enchantglint");}
 public static boolean isGlint(Identifier id){return id.getNamespace().equals("minecraft")&&switch(id.getPath()){
  case "textures/misc/enchanted_glint_item.png","textures/misc/enchanted_glint_armor.png","textures/misc/enchanted_glint_entity.png"->true;default->false;};}
 public static double seconds(){
  long now=System.nanoTime();var c=MinecraftClient.getInstance();
  if(lastTick!=0&&!c.isPaused()&&!XVisuals.config().module("performance").text("animation").equals("Off"))clock+=Math.min(.1,(now-lastTick)/1e9);
  lastTick=now;return clock;
 }
 public static Matrix4f transform(float vanillaScale){
  var s=XVisuals.config().module("enchantglint");double phase=seconds()*s.number("speed");
  return new Matrix4f().translation((float)(-phase*.035%1),(float)(phase*.09%1),0)
    .rotateZ((float)Math.toRadians(s.number("angle"))).scale((float)(vanillaScale*s.number("scale")));
 }
 private static Settings settings(double time){
  var s=XVisuals.config().module("enchantglint");int a=s.color("color"),b=s.color("secondary");String mode=s.text("mode");
  if(mode.equals("Rainbow")){float hue=(float)(time*s.number("colourSpeed")*.15%1);a=java.awt.Color.HSBtoRGB(hue,.75f,1);b=java.awt.Color.HSBtoRGB((hue+.22f)%1,.75f,1);}
  if(mode.equals("Solid"))b=a;
  double strength=s.number("brightness")*(1-s.number("pulse")*(.5-.5*Math.cos(time*s.number("speed")*2)));
  return new Settings(s.text("pattern"),mode,a,b,strength,s.number("contrast"));
 }
 public static AbstractTexture texture(){
  long frame=net.minecraft.util.Util.getMeasuringTimeMs()/33;double time=seconds();Settings next=settings(time);
  // Static edits apply immediately; animated colours are capped at 30 texture uploads/second.
  if(texture!=null&&next.equals(previous))return texture;
  if(texture!=null&&frame==lastFrame&&previous!=null&&next.pattern.equals(previous.pattern)&&next.mode.equals(previous.mode)
     &&(next.mode.equals("Rainbow")||XVisuals.config().module("enchantglint").number("pulse")>0))return texture;
  if(texture==null){texture=new RepeatingTexture();MinecraftClient.getInstance().getTextureManager().registerTexture(ID,texture);}
  var image=texture.getImage();
  for(int y=0;y<128;y++)for(int x=0;x<128;x++){
   double u=x/128.,v=y/128.,blend=.5+.5*Math.sin(Math.PI*2*(u-v));
   image.setColorArgb(x,y,GlintPattern.pixel(next.pattern,u,v,next.first,next.second,blend,next.brightness,next.contrast));
  }
  texture.upload();previous=next;lastFrame=frame;return texture;
 }
 private static final class RepeatingTexture extends NativeImageBackedTexture {
  RepeatingTexture(){super(()->"Enchant Glint+ material",new NativeImage(128,128,false));}
  @Override public net.minecraft.client.gl.GpuSampler getSampler(){return com.mojang.blaze3d.systems.RenderSystem.getSamplerCache().getRepeated(com.mojang.blaze3d.textures.FilterMode.LINEAR);}
 }
 public static void init(){
  net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.END_CLIENT_TICK.register(c->{if(!enabled())release(c);});
  net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING.register(EnchantGlint::release);
 }
 private static void release(MinecraftClient c){if(texture!=null){c.getTextureManager().destroyTexture(ID);texture=null;}previous=null;lastFrame=-1;lastTick=0;}
 private EnchantGlint(){}
}
