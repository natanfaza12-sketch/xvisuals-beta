package pl.xvisuals.modules;

import java.util.*;

/** Shared, testable catalog rules. Search includes features nested inside modules. */
public final class ModuleCatalog {
  /** Modules added or substantially updated in the current unreleased update. */
  public static final Set<String> RECENT = Set.of(
      "meteorshower","dynamicmist","windfx","realisticrain","volumetriclight","mountainwinds","oceanspray","pollendrift","endatmosphere","emberstorm","ashfall","swampfog","junglemist","lavafallmist","heatdistortion","dimensionskies","itemphysics","shulkerpreview","constellations","fallingleaves","eyeadaptation","depthoffield","realityglitch","dynamicreflections","waterripples","portaldistortion","landingfx","smartwaypoints","autoreconnect","storm","lightning","realisticfog",
      "viewmodel", "angelwings", "playerafterimage", "afterimage", "killanimations", "shockwave", "glass", "pets", "larp", "playerfx", "footsteps", "chinahat", "armorfx", "capes",
      "handanimations", "cameraanimations", "custompickaxes", "customswords", "swing", "swingspeed", "crystals", "anchorshader",
      "cinematicsky", "fontchanger", "hitfx", "jumpcircles", "skinchanger", "namechanger",
      "noclouds", "totemtexture", "music", "explosionfx", "hud", "lowaxe",
      "visiblepowdersnow", "clearancientdebris", "clearwater", "clearlava", "fireplus");
  private static final List<String> LATEST = List.of("meteorshower", "dynamicmist", "windfx", "realisticrain", "volumetriclight", "viewmodel", "totemtexture", "customswords", "shockwave", "pets", "angelwings", "playerafterimage", "afterimage");
  public static int recentRank(ModuleSpec module) {
    int index = LATEST.indexOf(module.id());
    return index < 0 ? LATEST.size() : index;
  }
  public static boolean matches(ModuleSpec module, String query) {
    StringBuilder text = new StringBuilder(module.id()).append(' ').append(module.name())
        .append(' ').append(module.category()).append(' ').append(module.description());
    for (Setting setting : module.settings()) {
      text.append(' ').append(setting.label());
      for (String choice : setting.choices()) text.append(' ').append(choice);
    }
    if (module.id().equals("music")) text.append(" spotify lyrics now playing album music");
    if (module.id().equals("capes") || module.id().equals("elytraskins"))
      text.append(" cosmetic themes geometric space tech hearts broken hearts love constellations cyber");
    if (module.id().equals("hud")) text.append(" editor drag resize fps ping coordinates speed direction server biome clock armor potion effects keystrokes cps memory session");
    if (module.id().equals("menu")) text.append(" startup loading title pause main menu");
    if (module.id().equals("blocks")) text.append(" block esp chest shulker ender chest spawner ore portal bed");
    String haystack = normalize(text.toString());
    Set<String> words = new HashSet<>();
    for(String token:haystack.split(" +")) words.add(keyword(token));
    for(String word:normalize(query).strip().split(" +")) {
      if(word.isEmpty()) continue;
      if(!haystack.contains(word) && !words.contains(keyword(word))) return false;
    }
    return true;
  }

  public static boolean nameMatches(ModuleSpec module,String query) {
    String[] words=normalize(module.name()).strip().split(" +");
    for(String term:normalize(query).strip().split(" +")) {
      if(!term.isBlank() && Arrays.stream(words).noneMatch(w->keyword(w).startsWith(keyword(term))))return false;
    }
    return true;
  }
  public static int searchRank(ModuleSpec module,String query) {
    if(normalize(module.name()).strip().equals(normalize(query).strip()))return 0;
    return nameMatches(module,query)?1:2;
  }

  public static boolean preferNames(String search) {
    return !search.isBlank() && Modules.ALL.stream().anyMatch(m->nameMatches(m,search));
  }
  public static boolean visible(ModuleSpec module, String tab, String filter, String search, boolean favorite) {
    return visible(module,tab,filter,search,favorite,preferNames(search));
  }
  public static boolean visible(ModuleSpec module, String tab, String filter, String search, boolean favorite, boolean names) {
    if (tab.equals("Visuals") && filter.equals("New") && !RECENT.contains(module.id())) return false;
    if (!search.isBlank()) {
      // A direct name match wins over incidental prose/settings matches. Feature-only
      // searches still find nested controls when no module name matches.
      return names?nameMatches(module,search):matches(module,search);
    }
    if (tab.equals("Environment FX")) return module.category().equals("Environment FX");
    if (tab.equals("World")) return List.of("World", "Environment").contains(module.category());
    return switch (filter) {
      case "New" -> RECENT.contains(module.id());
      case "Entities" -> module.category().equals("Entities");
      case "Motion" -> List.of("Player", "Particles").contains(module.category());
      case "Starred" -> favorite;
      default -> true;
    };
  }

  private static String normalize(String text) {
    return java.text.Normalizer.normalize(text.toLowerCase(Locale.ROOT),java.text.Normalizer.Form.NFKD)
        .replaceAll("\\p{M}", "").replaceAll("[^a-z0-9]+", " ");
  }
  /** Shared vocabulary: plural forms and familiar alternatives work across the entire catalog. */
  private static String keyword(String word) {
    String stem=word;
    if(stem.endsWith("ies") && stem.length()>4) stem=stem.substring(0,stem.length()-3)+"y";
    else if(stem.endsWith("s") && !stem.endsWith("ss") && stem.length()>3) stem=stem.substring(0,stem.length()-1);
    return switch(stem) {
      case "sky", "skybox", "skyboxe", "skies" -> "sky";
      case "colour", "color", "tint" -> "color";
      case "music", "song", "audio", "spotify" -> "music";
      case "cape", "cloak" -> "cape";
      case "elytra", "wing" -> "wing";
      case "crit", "critical" -> "critical";
      case "fps", "framerate", "performance" -> "fps";
      case "config", "configuration", "option", "setting" -> "setting";
      case "hud", "overlay" -> "hud";
      case "particle", "particles", "mote" -> "particle";
      default -> stem;
    };
  }

  private ModuleCatalog() {}
}
